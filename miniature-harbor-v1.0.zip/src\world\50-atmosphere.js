/**
 * 50-atmosphere.js — 云、海雾、海鸥、烟/蒸汽、旗帜、浪花、航道灯、灯塔光束、微尘。
 * OWNER: t5 atmosphere-fx (exclusive write).
 *
 * Design notes
 * ------------
 *  - Everything is procedural: canvas textures + code geometry, no assets.
 *  - All animation is driven by the shared clock (`time`, seconds) so that
 *    ?freeze=1&t=.. reproduces a still. Particle integration uses dt, which
 *    is 0 while frozen, so particles hold their pose.
 *  - Budget: <= 600 particles, <= 40 draw calls for this module. Repeated
 *    billboards are packed into a single BufferGeometry; gulls are one
 *    dynamic mesh; smoke / spray / dust are three THREE.Points systems.
 *  - Motion is slow and heavy: nothing bounces, nothing snaps.
 *
 * Draw calls: cloud layer 1, high cloud layer 1, mist 1, gulls 1, perched 1,
 * smoke pts 1, spray pts 1, dust pts 1, channel lights 1, beam 2, lamp halo 1,
 * foam patches 1, flag cloth (one per flag) + merged poles.
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const L = H.layout;
	const clamp = U.clamp;
	const lerp = U.lerp;
	const smoothstep = U.smoothstep;
	const TAU = U.TAU;

	// ------------------------------------------------------------------
	// wind: a slow sea breeze blowing towards +x / -z (east / north-east).
	// flags, smoke and drifting spume all read this one vector.
	// ------------------------------------------------------------------
	const WIND = { x: 0.936, z: -0.352, speed: 0.125 };
	const WIND_YAW = Math.atan2(-WIND.z, WIND.x); // rotate.y so local +x == wind

	// ------------------------------------------------------------------
	// procedural canvas textures
	// ------------------------------------------------------------------
	function puffTexture(size, seed, opts) {
		opts = opts || {};
		const canvas = U.createCanvas(size);
		const g = canvas.getContext('2d');
		const field = U.tileableNoise(size, { period: opts.period || 5, octaves: 5, seed: seed });
		const detail = U.tileableNoise(size, { period: (opts.period || 5) * 3, octaves: 3, seed: seed + 17 });
		const img = g.createImageData(size, size);
		const feather = opts.feather != null ? opts.feather : 1.15;
		const core = opts.core != null ? opts.core : 0.8;
		for (let y = 0; y < size; y++) {
			for (let x = 0; x < size; x++) {
				const nx = (x / (size - 1)) * 2 - 1;
				const ny = (y / (size - 1)) * 2 - 1;
				const i = y * size + x;
				const n = field[i];
				const d = detail[i];
				const r = Math.sqrt(nx * nx * 0.92 + ny * ny * 1.08) + (n - 0.5) * 0.5 + (d - 0.5) * 0.14;
				let edge = smoothstep(feather, 0.1, r);
				// billowy, slightly torn rim: near the edge the alpha breaks up
				const rimDetail = smoothstep(0.8, 0.25, r);
				edge *= 0.72 + 0.38 * (0.5 + 0.5 * Math.sin(d * 12.0 + n * 9.0)) * (1 - rimDetail * 0.5);
				const a = Math.pow(clamp(edge, 0, 1), 1.35) * (core + (1 - core) * (0.55 + 0.45 * n));
				const j = i * 4;
				img.data[j] = 255;
				img.data[j + 1] = 252;
				img.data[j + 2] = 246;
				img.data[j + 3] = Math.round(clamp(a, 0, 1) * 255);
			}
		}
		g.putImageData(img, 0, 0);
		return U.canvasTex(canvas, { cacheKey: opts.key || 'atm:puff:' + seed, srgb: false });
	}

	function sparkTexture(size, inner) {
		const canvas = U.createCanvas(size);
		const g = canvas.getContext('2d');
		const c = size / 2;
		const grad = g.createRadialGradient(c, c, 0, c, c, c);
		grad.addColorStop(0, 'rgba(255,255,255,1)');
		grad.addColorStop(inner != null ? inner : 0.16, 'rgba(255,255,255,0.82)');
		grad.addColorStop(0.46, 'rgba(255,255,255,0.20)');
		grad.addColorStop(1, 'rgba(255,255,255,0)');
		g.fillStyle = grad;
		g.fillRect(0, 0, size, size);
		return U.canvasTex(canvas, { cacheKey: 'atm:spark:' + size, srgb: false });
	}

	function smokeTexture() {
		const size = 96;
		const canvas = U.createCanvas(size);
		const g = canvas.getContext('2d');
		const field = U.tileableNoise(size, { period: 4, octaves: 4, seed: 933 });
		const img = g.createImageData(size, size);
		for (let y = 0; y < size; y++) {
			for (let x = 0; x < size; x++) {
				const nx = (x / (size - 1)) * 2 - 1;
				const ny = (y / (size - 1)) * 2 - 1;
				const r = Math.sqrt(nx * nx + ny * ny) * 0.92 + (field[y * size + x] - 0.5) * 0.5;
				const a = Math.pow(smoothstep(1.02, 0.18, r), 1.6);
				const i = (y * size + x) * 4;
				img.data[i] = 255;
				img.data[i + 1] = 255;
				img.data[i + 2] = 255;
				img.data[i + 3] = Math.round(clamp(a, 0, 1) * 255);
			}
		}
		g.putImageData(img, 0, 0);
		return U.canvasTex(canvas, { cacheKey: 'atm:smoke', srgb: false });
	}

	function foamTexture() {
		const size = 128;
		const canvas = U.createCanvas(size);
		const g = canvas.getContext('2d');
		const field = U.tileableNoise(size, { period: 6, octaves: 4, seed: 481 });
		const img = g.createImageData(size, size);
		for (let y = 0; y < size; y++) {
			for (let x = 0; x < size; x++) {
				const nx = (x / (size - 1)) * 2 - 1;
				const ny = (y / (size - 1)) * 2 - 1;
				const n = field[y * size + x];
				const r = Math.sqrt(nx * nx * 0.8 + ny * ny * 1.2) + (n - 0.5) * 0.55;
				const a = Math.pow(smoothstep(1.0, 0.2, r), 1.5) * (0.35 + 0.8 * n);
				const i = (y * size + x) * 4;
				img.data[i] = 246;
				img.data[i + 1] = 250;
				img.data[i + 2] = 246;
				img.data[i + 3] = Math.round(clamp(a, 0, 1) * 255);
			}
		}
		g.putImageData(img, 0, 0);
		return U.canvasTex(canvas, { cacheKey: 'atm:foam', srgb: false });
	}

	// ------------------------------------------------------------------
	// flag cloth textures (procedural patterns only)
	// ------------------------------------------------------------------
	function flagTexture(kind) {
		const W = 320;
		const H = 200;
		const canvas = U.createCanvas(W, H);
		const g = canvas.getContext('2d');
		const r = U.rng(kind.length * 97 + 13);
		g.clearRect(0, 0, W, H);
		const cream = '#efe6d2';
		const teal = '#2f6f73';
		const red = '#a64532';
		const gold = '#c8a24b';
		const navy = '#3d5f86';
		if (kind === 'town') {
			// harbour town flag: three bands + golden sun
			g.fillStyle = cream;
			g.fillRect(0, 0, W, H);
			g.fillStyle = teal;
			g.fillRect(0, 0, W, H * 0.3);
			g.fillStyle = gold;
			g.fillRect(0, H * 0.3, W, H * 0.08);
			g.fillStyle = teal;
			g.fillRect(0, H * 0.62, W, H * 0.38);
			g.beginPath();
			g.arc(W * 0.34, H * 0.5, H * 0.17, 0, TAU);
			g.fillStyle = gold;
			g.fill();
			g.beginPath();
			g.arc(W * 0.34, H * 0.5, H * 0.1, 0, TAU);
			g.fillStyle = cream;
			g.fill();
			// little wave marks
			g.strokeStyle = 'rgba(239,230,210,0.55)';
			g.lineWidth = 3;
			for (let i = 0; i < 3; i++) {
				g.beginPath();
				for (let x = W * 0.55; x < W - 12; x += 8) {
					const y = H * 0.5 + Math.sin(x * 0.07 + i) * 6 + (i - 1) * 14;
					x === W * 0.55 ? g.moveTo(x, y) : g.lineTo(x, y);
				}
				g.stroke();
			}
		} else if (kind === 'church') {
			// cream field, crimson cross, gold border
			g.fillStyle = cream;
			g.fillRect(0, 0, W, H);
			g.strokeStyle = gold;
			g.lineWidth = 10;
			g.strokeRect(5, 5, W - 10, H - 10);
			g.fillStyle = red;
			g.fillRect(W * 0.44, H * 0.16, W * 0.12, H * 0.68);
			g.fillRect(W * 0.2, H * 0.42, W * 0.6, H * 0.16);
			g.fillStyle = 'rgba(166,69,50,0.35)';
			g.fillRect(0, H * 0.86, W, H * 0.14);
		} else if (kind === 'fort') {
			// signal flag: red/cream quarters + navy saltire
			g.fillStyle = cream;
			g.fillRect(0, 0, W, H);
			g.fillStyle = red;
			g.fillRect(0, 0, W / 2, H / 2);
			g.fillRect(W / 2, H / 2, W / 2, H / 2);
			g.strokeStyle = navy;
			g.lineWidth = 16;
			g.beginPath();
			g.moveTo(0, 0);
			g.lineTo(W, H);
			g.moveTo(W, 0);
			g.lineTo(0, H);
			g.stroke();
			g.strokeStyle = cream;
			g.lineWidth = 6;
			g.beginPath();
			g.moveTo(0, 0);
			g.lineTo(W, H);
			g.moveTo(W, 0);
			g.lineTo(0, H);
			g.stroke();
		} else if (kind === 'pennant') {
			// small boat pennant: red over cream, swallow tail painted with the
			// alpha channel so the plane silhouette reads as a pennant
			g.fillStyle = cream;
			g.fillRect(0, 0, W, H);
			g.fillStyle = red;
			g.fillRect(0, 0, W, H * 0.5);
			g.fillStyle = 'rgba(61,95,134,0.9)';
			g.fillRect(0, H * 0.46, W, H * 0.08);
			g.globalCompositeOperation = 'destination-out';
			g.beginPath();
			g.moveTo(W, 0);
			g.lineTo(W * 0.62, H * 0.5);
			g.lineTo(W, H);
			g.closePath();
			g.fill();
			g.globalCompositeOperation = 'source-over';
		} else {
			// boat flag / generic
			g.fillStyle = navy;
			g.fillRect(0, 0, W, H);
			g.fillStyle = cream;
			g.fillRect(0, H * 0.3, W, H * 0.12);
			g.fillRect(0, H * 0.58, W, H * 0.12);
			g.fillStyle = gold;
			g.beginPath();
			g.arc(W * 0.25, H * 0.5, H * 0.12, 0, TAU);
			g.fill();
		}
		// weave + wear: subtle horizontal fibres and edge darkening
		for (let i = 0; i < 2600; i++) {
			g.fillStyle = r.chance(0.5) ? 'rgba(255,255,255,0.05)' : 'rgba(60,50,40,0.05)';
			g.fillRect(r.range(0, W), r.range(0, H), r.range(2, 14), 1);
		}
		const edge = g.createLinearGradient(0, 0, 0, H);
		edge.addColorStop(0, 'rgba(255,255,255,0.10)');
		edge.addColorStop(0.5, 'rgba(0,0,0,0)');
		edge.addColorStop(1, 'rgba(40,30,20,0.16)');
		g.fillStyle = edge;
		g.fillRect(0, 0, W, H);
		return U.canvasTex(canvas, { cacheKey: 'atm:flag:' + kind });
	}

	// ------------------------------------------------------------------
	// mood: one shared colour set derived from the live env sky clock
	// (env.state.colors: zenith / horizon / sun / hemiSky / fog) so clouds,
	// mist, smoke, spray and dust all age together with the sky. Never a
	// fixed white cloud.
	// ------------------------------------------------------------------
	const MOOD = {
		cloudLit: new THREE.Color('#ffdcb4'),
		cloudShade: new THREE.Color('#7d8196'),
		cloudRim: new THREE.Color('#ffbe7c'),
		rimStrength: 0.85,
		cloudOpacity: 1.0,
		mist: new THREE.Color('#e9cba8'),
		mistOpacity: 0.2,
		airTint: new THREE.Color('#ffd2a0'),
		smokeCool: new THREE.Color('#bfbcb7'),
		smokeWarm: new THREE.Color('#e2c9ad'),
		spray: new THREE.Color('#eef4f2'),
		beam: new THREE.Color('#ffe0a6'),
		beamI: 0,
		night: 0,
		warm: 0,
		dust: new THREE.Color('#ffe0b0'),
		gull: new THREE.Color('#f2efe6'),
	};

	const _WHITE = new THREE.Color(1, 1, 1);
	const _cA = new THREE.Color();
	const _cB = new THREE.Color();
	const _GLOW = new THREE.Color('#ffd9a6');
	const _NIGHT_LIT = new THREE.Color('#38445c');
	const _NIGHT_SHADE = new THREE.Color('#0b1220');
	const _SMOKE_DAY = new THREE.Color('#c8c5c0');
	const _SMOKE_NIGHT = new THREE.Color('#3b3b46');
	const _SUNSET_RIM = new THREE.Color('#ffb877');

	// Pull the current sky palette from env and derive the atmosphere mood.
	// sunLow: 0 when the sun is high, 1 when it is close to the horizon.
	function moodFromEnv(envState) {
		const k = envState.colors;
		const night = envState.night || 0;
		const nightF = smoothstep(0.28, 0.88, night);
		const sunUp = envState.sunDir ? clamp(envState.sunDir.y, -0.2, 1) : 1;
		const sunLow = (1 - smoothstep(0.04, 0.5, sunUp)) * (1 - nightF);
		const warm = clamp(sunLow * 0.85 + night * 0.25, 0, 1);
		MOOD.night = night;
		MOOD.warm = warm;
		if (!k) return;
		// lit crown of a cloud: warm sun light mixed with the horizon glow
		_cA.copy(k.sun).lerp(k.horizon, 0.45).lerp(_WHITE, 0.12);
		_cB.copy(k.zenith).lerp(k.horizon, 0.32).multiplyScalar(1.15);
		_cB.multiplyScalar(0.85);
		MOOD.cloudLit.copy(_cA.lerp(_cB, nightF * 0.9));
		// shadowed belly: cool zenith / hemi sky, warm rim of the horizon at
		// dusk, very dark at night
		_cA.copy(k.zenith).lerp(k.hemiSky || k.zenith, 0.5).multiplyScalar(0.88);
		_cA.lerp(k.horizon, 0.1 * (1 - nightF));
		MOOD.cloudShade.copy(_cA.lerp(_NIGHT_SHADE, nightF * 0.85));
		// rim: the sun/moon colour itself (env swaps it to cold moon blue at night)
		MOOD.cloudRim.copy(k.sun).lerp(_SUNSET_RIM.clone().multiplyScalar(1.1), sunLow * 0.55);
		MOOD.rimStrength = 0.3 + warm * 0.8 + night * 0.2;
		MOOD.cloudOpacity = 0.8 + warm * 0.1 - nightF * 0.22;
		// mist is basically the aerial perspective colour
		MOOD.mist.copy(k.fog || k.horizon).lerp(k.horizon, 0.25);
		MOOD.mistOpacity = 0.15 + warm * 0.13 + night * 0.02;
		// smoke: grey by day, warm around lamps at night
		_cA.copy(_SMOKE_DAY).lerp(k.sun, 0.12 + warm * 0.12);
		MOOD.smokeCool.copy(_cA.lerp(_SMOKE_NIGHT, nightF * 0.72));
		_cB.copy(_SMOKE_DAY).lerp(_GLOW, 0.35 + night * 0.25);
		MOOD.smokeWarm.copy(_cB.lerp(_GLOW, nightF * 0.35));
		// spray / spume: cool foam with a kiss of the sky colour
		MOOD.spray.copy(k.horizon).lerp(_WHITE, 0.55).lerp(k.zenith, 0.18);
		// dust motes catch the sun
		MOOD.dust.copy(k.sun).lerp(_WHITE, 0.35);
		MOOD.gull.set('#8f969a').lerp(k.horizon, 0.12 + night * 0.3);
		// lighthouse beam
		MOOD.beam.set('#ffe0b0');
		MOOD.beamI = smoothstep(0.8, 0.95, night);
	}

	// ------------------------------------------------------------------
	// billboard batch: N camera-facing quads, one draw call.
	// ------------------------------------------------------------------
	const BB_VERT = `
		attribute vec3 aCenter;
		attribute vec2 aSize;
		attribute float aRot;
		attribute float aSeed;
		attribute float aTint;
		attribute float aShade;
		uniform float uDrift;
		uniform float uSpan;
		uniform float uWrapMin;
		uniform vec3 uSunDir;
		varying vec2 vUv;
		varying float vSeed;
		varying float vTint;
		varying float vShade;
		varying vec3 vWorld;
		varying vec3 vCenter;
		varying float vSunSide;
		void main() {
			float c = cos(aRot);
			float s = sin(aRot);
			vec2 corner = position.xy;
			vec2 off = vec2(corner.x * c - corner.y * s, corner.x * s + corner.y * c) * aSize;
			float wx = mod(aCenter.x + uDrift - uWrapMin, uSpan) + uWrapMin;
			vec3 center = vec3(wx, aCenter.y, aCenter.z);
			vec3 right = vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]);
			vec3 up = vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]);
			vec3 world = center + right * off.x + up * off.y;
			vWorld = world;
			vCenter = center;
			vUv = uv;
			vSeed = aSeed;
			vTint = aTint;
			vShade = aShade;
			vec2 sunH = normalize(vec2(uSunDir.x, uSunDir.z) + vec2(1e-4, 1e-4));
			vSunSide = dot(sunH, vec2(right.x, right.z));
			gl_Position = projectionMatrix * viewMatrix * vec4(world, 1.0);
		}
	`;

	const CLOUD_FRAG = `
		uniform sampler2D uMap;
		uniform vec3 uLit;
		uniform vec3 uShade;
		uniform vec3 uRim;
		uniform vec3 uSunDir;
		uniform vec3 uMoonDir;
		uniform vec3 uMoonColor;
		uniform float uOpacity;
		uniform float uRimStrength;
		uniform float uNight;
		uniform vec3 uFogColor;
		uniform float uFogDensity;
		varying vec2 vUv;
		varying float vSeed;
		varying float vTint;
		varying float vShade;
		varying vec3 vWorld;
		varying vec3 vCenter;
		varying float vSunSide;
		void main() {
			vec4 tex = texture2D(uMap, vUv);
			float a = tex.a;
			if (a < 0.004) discard;
			// vertical self-shadowing (clouds are lit from above by the sky)
			float vert = smoothstep(0.0, 1.0, vUv.y);
			float sunTop = clamp(uSunDir.y, 0.0, 1.0);
			float topLight = mix(0.55, 1.0, sunTop);
			float lit = clamp(0.33 + 0.78 * vert * topLight - 0.22 * vShade + 0.14 * vTint, 0.0, 1.0);
			// horizontal light: the face towards the sun catches more light
			float side = clamp(vSunSide * (vUv.x - 0.5) * 2.2, -1.0, 1.0);
			lit = clamp(lit + side * 0.24 * (1.0 - sunTop * 0.6), 0.0, 1.0);
			vec3 col = mix(uShade, uLit, lit);
			col *= 0.9 + 0.22 * vTint;
			vec3 vd = normalize(vWorld - cameraPosition);
			float rim = smoothstep(0.5, 1.0, length(vUv - 0.5) * 2.0);
			float scatter = pow(max(dot(vd, uSunDir), 0.0), 5.0);
			col += uRim * scatter * uRimStrength * (1.0 - uNight) * (0.28 + rim * 1.15);
			// sun-side silver lining even when looking away from the sun
			float sideRim = smoothstep(0.25, 1.0, side) * rim;
			col += uRim * sideRim * uRimStrength * 0.22 * (1.0 - uNight);
			float moonScatter = pow(max(dot(vd, uMoonDir), 0.0), 4.0);
			col += uMoonColor * moonScatter * uNight * 0.55 * (0.35 + rim);
			// warm rim along the sun-lit crown + a hint of inner glow
			col += uRim * rim * smoothstep(0.2, 0.95, vert) * 0.3 * (1.0 - uNight);
			col += uRim * lit * 0.05;
			col *= 1.06;
			// aerial perspective: distant clouds dissolve into the scene fog
			float depth = length(vWorld - cameraPosition);
			float fogF = 1.0 - exp(-pow(uFogDensity * depth, 2.0));
			col = mix(col, uFogColor, clamp(fogF, 0.0, 1.0) * 0.5);
			// a cloud bank belongs to the sky, never to the foreground: fade
			// out cards that the camera flies close to. Per-card density
			// variation breaks up the silhouette.
			float nearFade = smoothstep(28.0, 62.0, depth);
			float density = 0.62 + 0.5 * vTint;
			gl_FragColor = vec4(col, a * uOpacity * nearFade * density);
		}
	`;

	const MIST_FRAG = `
		uniform sampler2D uMap;
		uniform vec3 uColor;
		uniform vec3 uSunDir;
		uniform vec3 uSunColor;
		uniform float uOpacity;
		uniform float uTime;
		varying vec2 vUv;
		varying float vSeed;
		varying float vTint;
		varying float vShade;
		varying vec3 vWorld;
		varying vec3 vCenter;
		void main() {
			vec4 tex = texture2D(uMap, vUv);
			float breathe = 0.78 + 0.22 * sin(uTime * 0.17 + vSeed * 6.2831 + vTint * 3.1);
			float a = tex.a * uOpacity * breathe;
			if (a < 0.004) discard;
			vec3 vd = normalize(vWorld - cameraPosition);
			float glow = pow(max(dot(vd, uSunDir), 0.0), 6.0);
			vec3 col = uColor * (0.86 + 0.26 * vUv.y);
			col += uSunColor * glow * 0.16;
			gl_FragColor = vec4(col, a);
		}
	`;

	function buildBillboardGeometry(puffs, scale) {
		const SC = scale != null ? scale : 1;
		const n = puffs.length;
		const pos = new Float32Array(n * 4 * 3);
		const uv = new Float32Array(n * 4 * 2);
		const cen = new Float32Array(n * 4 * 3);
		const siz = new Float32Array(n * 4 * 2);
		const rot = new Float32Array(n * 4);
		const seed = new Float32Array(n * 4);
		const tint = new Float32Array(n * 4);
		const shade = new Float32Array(n * 4);
		const idx = new Uint32Array(n * 6);
		const corners = [
			[-0.5, -0.5],
			[0.5, -0.5],
			[0.5, 0.5],
			[-0.5, 0.5],
		];
		const uvs = [
			[0, 0],
			[1, 0],
			[1, 1],
			[0, 1],
		];
		for (let i = 0; i < n; i++) {
			const p = puffs[i];
			for (let k = 0; k < 4; k++) {
				const v = i * 4 + k;
				pos[v * 3] = corners[k][0];
				pos[v * 3 + 1] = corners[k][1];
				pos[v * 3 + 2] = 0;
				uv[v * 2] = uvs[k][0];
				uv[v * 2 + 1] = uvs[k][1];
				cen[v * 3] = p.x;
				cen[v * 3 + 1] = p.y;
				cen[v * 3 + 2] = p.z;
				siz[v * 2] = p.w * SC;
				siz[v * 2 + 1] = p.h * SC;
				rot[v] = p.rot || 0;
				seed[v] = p.seed != null ? p.seed : Math.random();
				tint[v] = p.tint != null ? p.tint : 0.5;
				shade[v] = p.shade != null ? p.shade : 0;
			}
			const b = i * 4;
			idx[i * 6] = b;
			idx[i * 6 + 1] = b + 1;
			idx[i * 6 + 2] = b + 2;
			idx[i * 6 + 3] = b;
			idx[i * 6 + 4] = b + 2;
			idx[i * 6 + 5] = b + 3;
		}
		const geo = new THREE.BufferGeometry();
		geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
		geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
		geo.setAttribute('aCenter', new THREE.BufferAttribute(cen, 3));
		geo.setAttribute('aSize', new THREE.BufferAttribute(siz, 2));
		geo.setAttribute('aRot', new THREE.BufferAttribute(rot, 1));
		geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
		geo.setAttribute('aTint', new THREE.BufferAttribute(tint, 1));
		geo.setAttribute('aShade', new THREE.BufferAttribute(shade, 1));
		geo.setIndex(new THREE.BufferAttribute(idx, 1));
		geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0, 0), 900);
		return geo;
	}

	function makeBillboardLayer(puffs, frag, extraUniforms, bbOpts) {
		const geo = buildBillboardGeometry(puffs, bbOpts && bbOpts.scale);
		const uniforms = Object.assign(
			{
				uMap: { value: frag.map },
				uDrift: { value: 0 },
				uSpan: { value: 320 },
				uWrapMin: { value: -160 },
				uOpacity: { value: 1 },
				uTime: { value: 0 },
				uSunDir: { value: new THREE.Vector3(0, 1, 0) },
				uMoonDir: { value: new THREE.Vector3(0, 1, 0) },
				uFogColor: { value: new THREE.Color('#ecc9a4') },
				uFogDensity: { value: 0.0064 },
			},
			extraUniforms || {}
		);
		uniforms.uMap.value = frag.map;
		const mat = new THREE.ShaderMaterial({
			uniforms: uniforms,
			vertexShader: BB_VERT,
			fragmentShader: frag.shader,
			transparent: true,
			depthWrite: false,
			depthTest: true,
			side: THREE.DoubleSide,
			blending: THREE.NormalBlending,
			toneMapped: false,
		});
		const mesh = new THREE.Mesh(geo, mat);
		mesh.frustumCulled = false;
		mesh.renderOrder = 2;
		mesh.castShadow = false;
		mesh.receiveShadow = false;
		return mesh;
	}

	// ------------------------------------------------------------------
	// cloud layout
	// ------------------------------------------------------------------
	const DEG = Math.PI / 180;

	function makeCloudPuffs(rng) {
		const near = [];
		const deck = [];
		function addCloud(out, cx, cy, cz, width, height, depth, opts) {
			opts = opts || {};
			const rw = width * 0.5;
			const rh = height * 0.5;
			const rd = depth * 0.5;
			const tintBase = rng.range(0.2, 0.85);
			const base = Math.round((opts.base != null ? opts.base : 18) * (opts.density || 1) * 0.8);
			const crown = Math.round((opts.crown != null ? opts.crown : 9) * (opts.density || 1) * 0.8);
			// flattened, heavily overlapping body
			for (let i = 0; i < base; i++) {
				const a = rng.range(0, TAU);
				const rr = Math.sqrt(rng.next());
				const px = Math.cos(a) * rr * rw;
				const pz = Math.sin(a) * rr * rd;
				const py = rng.range(-0.32, 0.2) * rh;
				const s = (1 - rr * 0.26) * rng.range(0.72, 1.15);
				out.push({
					x: cx + px,
					y: cy + py,
					z: cz + pz,
					w: rw * 0.6 * s,
					h: rh * 0.72 * s,
					rot: rng.range(-0.6, 0.6),
					seed: rng.next(),
					tint: clamp(tintBase + rng.range(-0.16, 0.16), 0, 1),
					shade: clamp(0.52 - (py / (rh || 1)) * 0.6 + rng.range(-0.12, 0.12), 0, 1),
				});
			}
			// sunlit crown: smaller lumps riding on top
			for (let i = 0; i < crown; i++) {
				const a = rng.range(0, TAU);
				const rr = Math.pow(rng.next(), 0.8) * 0.85;
				const px = Math.cos(a) * rr * rw * 0.88;
				const pz = Math.sin(a) * rr * rd * 0.7;
				const py = rh * (0.22 + rng.range(0, 0.5));
				const s = rng.range(0.42, 0.72) * (1 - rr * 0.25);
				out.push({
					x: cx + px,
					y: cy + py,
					z: cz + pz,
					w: rw * 0.52 * s,
					h: rh * 0.72 * s,
					rot: rng.range(-0.6, 0.6),
					seed: rng.next(),
					tint: clamp(tintBase + rng.range(0.08, 0.34), 0, 1),
					shade: rng.range(0.0, 0.3),
				});
			}
		}
		// --- backdrop band: hand placed for the default framing (the band of
		// dim sky / haze just above the hill silhouette). Small and dim on
		// purpose: the tilt-shift pass blurs the top of the frame, so these
		// read as soft warm cloud banks, never as hard white puffs. ----------
		const band = [
			[247, 50, 6.2, 16, 5.2, 9],
			[233, 34, 4.2, 12, 4.0, 7],
			[216, 42, 6.9, 14, 4.6, 8],
			[199, 31, 4.6, 10, 3.6, 6],
			[184, 54, 5.0, 19, 5.6, 10],
			[168, 36, 5.1, 11, 4.0, 7],
			[154, 45, 7.0, 14, 4.6, 8],
		];
		for (const b of band) {
			addCloud(near, Math.sin(b[0] * DEG) * b[1], b[2], Math.cos(b[0] * DEG) * b[1], b[3], b[4], b[5], { base: 15, crown: 7 });
		}
		// a sparse higher layer of wisps for depth / broken outline
		const wisps = [
			[238, 40, 3.6, 9, 2.6, 5],
			[212, 44, 4.0, 11, 3.0, 5],
			[188, 34, 3.4, 8, 2.4, 4],
			[171, 46, 4.4, 10, 2.8, 5],
			[156, 32, 3.2, 8, 2.4, 4],
			[226, 52, 4.8, 12, 3.2, 5],
		];
		for (const w of wisps) {
			addCloud(near, Math.sin(w[0] * DEG) * w[1], w[2], Math.cos(w[0] * DEG) * w[1], w[3], w[4], w[5], { base: 6, crown: 3 });
		}
		// --- upper deck: big soft clouds for low-angle orbit views ----------
		const upper = [
			[28, 92, 26, 40, 13, 18],
			[-42, 104, 31, 46, 14, 20],
			[96, 88, 23, 34, 12, 16],
			[-108, 96, 28, 40, 13, 17],
			[160, 110, 34, 48, 15, 20],
			[-150, 82, 22, 32, 11, 15],
		];
		for (const u of upper) {
			addCloud(deck, Math.sin(u[0] * DEG) * u[1], u[2], Math.cos(u[0] * DEG) * u[1], u[3], u[4], u[5], { density: 1.15, base: 12, crown: 6 });
		}
		// thin wisps in the sun's quarter of the sky
		for (let i = 0; i < 3; i++) {
			const az = -150 + i * 26 + rng.range(-6, 6);
			const rad = rng.range(110, 150);
			addCloud(deck, Math.sin(az * DEG) * rad, rng.range(34, 52), Math.cos(az * DEG) * rad, rng.range(44, 70), 6, 28, { density: 0.55, base: 8, crown: 3 });
		}
		// --- low warm stratus veil: wide, very flat cards layered just
		// above the ridge line, so the default framing gets a warm band with
		// some structure instead of an empty gradient. ---------------------
		const veil = [
			[198, 42, 4.4, 54, 5.0, 9],
			[221, 33, 3.5, 40, 4.0, 7],
			[171, 50, 4.3, 62, 5.2, 10],
			[241, 29, 3.1, 34, 3.6, 6],
			[186, 62, 5.4, 74, 5.8, 12],
		];
		for (const v of veil) {
			const cx = Math.sin(v[0] * DEG) * v[1];
			const cz = Math.cos(v[0] * DEG) * v[1];
			for (let i = 0; i < 10; i++) {
				near.push({
					x: cx + rng.range(-v[3] * 0.5, v[3] * 0.5),
					y: v[2] + rng.range(-v[4] * 0.16, v[4] * 0.3),
					z: cz + rng.range(-v[5] * 0.5, v[5] * 0.5),
					w: v[3] * rng.range(0.3, 0.52),
					h: v[4] * rng.range(0.5, 0.95),
					rot: rng.range(-0.06, 0.06),
					seed: rng.next(),
					tint: rng.range(0.78, 1.0),
					shade: rng.range(0.35, 0.75),
				});
			}
		}
		// a very thin warm band right under the top edge of the frame
		for (let i = 0; i < 4; i++) {
			const az = 158 + i * 22 + rng.range(-5, 5);
			const rad = rng.range(50, 74);
			const cx = Math.sin(az * DEG) * rad;
			const cz = Math.cos(az * DEG) * rad;
			const cy = rng.range(4.8, 6.6);
			for (let k = 0; k < 5; k++) {
				near.push({
					x: cx + rng.range(-24, 24),
					y: cy + rng.range(-0.6, 0.6),
					z: cz + rng.range(-7, 7),
					w: rng.range(16, 32),
					h: rng.range(1.8, 3.2),
					rot: rng.range(-0.05, 0.05),
					seed: rng.next(),
					tint: rng.range(0.72, 1.0),
					shade: rng.range(0.3, 0.7),
				});
			}
		}
		// a third, very faint far layer: different scale + height so the noon
		// sky reads as depth rather than one grey strip
		for (let i = 0; i < 3; i++) {
			const az = 164 + i * 24 + rng.range(-5, 5);
			const rad = rng.range(64, 86);
			const cx = Math.sin(az * DEG) * rad;
			const cz = Math.cos(az * DEG) * rad;
			const cy = rng.range(5.4, 7.6);
			for (let k = 0; k < 5; k++) {
				near.push({
					x: cx + rng.range(-30, 30),
					y: cy + rng.range(-0.8, 0.8),
					z: cz + rng.range(-9, 9),
					w: rng.range(26, 46),
					h: rng.range(2.4, 4.2),
					rot: rng.range(-0.04, 0.04),
					seed: rng.next(),
					tint: rng.range(0.04, 0.28),
					shade: rng.range(0.4, 0.8),
				});
			}
		}
		return { near, deck };
	}

	function makeMistPuffs(rng) {
		const puffs = [];
		// a very low haze plane behind / between the hills: warm fog bank
		for (let i = 0; i < 7; i++) {
			const az = 140 + (i / 6) * 120 + rng.range(-6, 6);
			const rad = rng.range(38, 68);
			puffs.push({
				x: Math.sin(az * DEG) * rad,
				y: rng.range(2.2, 4.2),
				z: Math.cos(az * DEG) * rad,
				w: rng.range(26, 46),
				h: rng.range(2.4, 4.2),
				rot: rng.range(-0.05, 0.05),
				seed: rng.next(),
				tint: rng.next(),
				shade: 0.5,
			});
		}
		// thin spindrift hugging the water rim of the diorama
		for (let i = 0; i < 8; i++) {
			const az = rng.range(0, 360);
			const rad = rng.range(13.8, 15.6);
			puffs.push({
				x: Math.sin(az * DEG) * rad,
				y: rng.range(0.16, 0.42),
				z: Math.cos(az * DEG) * rad,
				w: rng.range(2.2, 4.2),
				h: rng.range(0.32, 0.6),
				rot: rng.range(-0.12, 0.12),
				seed: rng.next(),
				tint: rng.next(),
				shade: 0.5,
			});
		}
		return puffs;
	}

	// ------------------------------------------------------------------
	// gulls: one template (body + head + beak + tail + two flapping wings),
	// merged into a single dynamic mesh for all flying gulls.
	// ------------------------------------------------------------------
	function buildGullTemplate() {
		const positions = [];
		const normals = [];
		const colors = [];
		const tags = []; // 0 = body, 1 = wing
		const sides = [];
		const tips = [];
		const indices = [];
		const cBody = new THREE.Color('#e2dfd6');
		const cWingRoot = new THREE.Color('#a9b0b3');
		const cWingTip = new THREE.Color('#4b555d');
		const cBeak = new THREE.Color('#c08a3e');
		const cTail = new THREE.Color('#b9bec0');
		function append(srcGeo, color, tag) {
			const pos = srcGeo.attributes.position;
			const nor = srcGeo.attributes.normal;
			const idx = srcGeo.index;
			const base = positions.length / 3;
			for (let i = 0; i < pos.count; i++) {
				positions.push(pos.getX(i), pos.getY(i), pos.getZ(i));
				normals.push(nor ? nor.getX(i) : 0, nor ? nor.getY(i) : 1, nor ? nor.getZ(i) : 0);
				colors.push(color.r, color.g, color.b);
				tags.push(tag);
				sides.push(0);
				tips.push(0);
			}
			if (idx) {
				for (let i = 0; i < idx.count; i++) indices.push(base + idx.getX(i));
			} else {
				for (let i = 0; i < pos.count; i++) indices.push(base + i);
			}
		}
		// --- body: small streamlined teardrop ----------------------------
		let geo = new THREE.SphereGeometry(0.5, 8, 6);
		geo.scale(0.095, 0.06, 0.27);
		append(geo, cBody, 0);
		geo.dispose();
		// --- head -------------------------------------------------------
		geo = new THREE.SphereGeometry(0.5, 6, 5);
		geo.scale(0.055, 0.05, 0.072);
		geo.translate(0, 0.022, 0.235);
		append(geo, cBody, 0);
		geo.dispose();
		// --- beak -------------------------------------------------------
		geo = new THREE.ConeGeometry(0.014, 0.062, 4);
		geo.rotateX(Math.PI / 2);
		geo.translate(0, 0.016, 0.305);
		append(geo, cBeak, 0);
		geo.dispose();
		// --- tail: flat fan ---------------------------------------------
		{
			const base = positions.length / 3;
			const tv = [
				[-0.062, 0.011, -0.12],
				[0.062, 0.011, -0.12],
				[0.0, 0.002, -0.3],
			];
			for (const v of tv) {
				positions.push(v[0], v[1], v[2]);
				normals.push(0, 1, 0);
				colors.push(cTail.r, cTail.g, cTail.b);
				tags.push(0);
				sides.push(0);
				tips.push(0);
			}
			indices.push(base, base + 1, base + 2);
		}
		// --- wings: two-section gull wing (inner arm + swept outer hand) --
		const wingSecs = [
			// x, leading-edge z, trailing-edge z, dihedral lift (clear V)
			[0.045, 0.1, -0.085, 0.012],
			[0.13, 0.112, -0.1, 0.032],
			[0.235, 0.107, -0.118, 0.058],
			[0.34, 0.082, -0.138, 0.088],
			[0.45, 0.05, -0.142, 0.118],
			[0.545, 0.02, -0.116, 0.145],
			[0.615, 0.0, -0.072, 0.165],
		];
		const wingTips = [0.0, 0.12, 0.3, 0.5, 0.7, 0.88, 1.0];
		for (const side of [-1, 1]) {
			const base = positions.length / 3;
			for (let i = 0; i < wingSecs.length; i++) {
				const sec = wingSecs[i];
				const tip = wingTips[i];
				const col = cWingRoot.clone().lerp(cWingTip, Math.pow(tip, 1.5));
				positions.push(sec[0] * side, sec[3] + 0.004, sec[1]);
				normals.push(0, 1, 0);
				colors.push(col.r, col.g, col.b);
				tags.push(1);
				sides.push(side);
				tips.push(tip);
				positions.push(sec[0] * side, sec[3], sec[2]);
				normals.push(0, 1, 0);
				colors.push(col.r, col.g, col.b);
				tags.push(1);
				sides.push(side);
				tips.push(tip);
			}
			for (let i = 0; i < wingSecs.length - 1; i++) {
				const a = base + i * 2;
				const b = a + 1;
				const c = a + 2;
				const d = a + 3;
				indices.push(a, c, b, b, c, d);
			}
		}
		return {
			positions: new Float32Array(positions),
			normals: new Float32Array(normals),
			colors: new Float32Array(colors),
			tags: new Uint8Array(tags),
			sides: new Float32Array(sides),
			tips: new Float32Array(tips),
			indices: new Uint16Array(indices),
			count: positions.length / 3,
		};
	}

	// transform one gull from the template into a combined buffer
	function writeGull(outPos, outNor, base, T, matrix, flap, size) {
		const e = matrix.elements;
		const tp = T.positions;
		const tn = T.normals;
		const n = T.count;
		for (let i = 0; i < n; i++) {
			let x = tp[i * 3];
			let y = tp[i * 3 + 1];
			let z = tp[i * 3 + 2];
			let nx = tn[i * 3];
			let ny = tn[i * 3 + 1];
			let nz = tn[i * 3 + 2];
			if (T.tags[i] === 1) {
				const elbow = Math.max(0, T.tips[i] - 0.45) / 0.55;
				const A = T.sides[i] * (flap * (0.42 + 1.0 * T.tips[i]) + flap * 0.3 * elbow);
				const cA = Math.cos(A);
				const sA = Math.sin(A);
				const xr = x * cA - y * sA;
				const yr = x * sA + y * cA;
				x = xr;
				y = yr;
				const nrx = nx * cA - ny * sA;
				const nry = nx * sA + ny * cA;
				nx = nrx;
				ny = nry;
				z -= T.tips[i] * Math.abs(flap) * 0.035;
			}
			x *= size;
			y *= size;
			z *= size;
			const o = (base + i) * 3;
			outPos[o] = e[0] * x + e[4] * y + e[8] * z + e[12];
			outPos[o + 1] = e[1] * x + e[5] * y + e[9] * z + e[13];
			outPos[o + 2] = e[2] * x + e[6] * y + e[10] * z + e[14];
			const nxr = e[0] * nx + e[4] * ny + e[8] * nz;
			const nyr = e[1] * nx + e[5] * ny + e[9] * nz;
			const nzr = e[2] * nx + e[6] * ny + e[10] * nz;
			const inv = 1 / (Math.hypot(nxr, nyr, nzr) || 1);
			outNor[o] = nxr * inv;
			outNor[o + 1] = nyr * inv;
			outNor[o + 2] = nzr * inv;
		}
	}

	// ------------------------------------------------------------------
	// generic GPU point-sprite system (smoke, spray, dust, lights)
	// ------------------------------------------------------------------
	const POINT_VERT = `
		attribute float aSize;
		attribute float aAlpha;
		attribute float aTint;
		attribute float aSeed;
		uniform float uScale;
		uniform float uMaxSize;
		varying float vAlpha;
		varying float vTint;
		varying float vSeed;
		varying vec3 vWorld;
		void main() {
			vec4 mv = modelViewMatrix * vec4(position, 1.0);
			vWorld = (modelMatrix * vec4(position, 1.0)).xyz;
			gl_Position = projectionMatrix * mv;
			gl_PointSize = min(aSize * uScale / max(0.08, -mv.z), uMaxSize);
			vAlpha = aAlpha;
			vTint = aTint;
			vSeed = aSeed;
		}
	`;

	const POINT_FRAG = `
		uniform sampler2D uMap;
		uniform vec3 uColorA;
		uniform vec3 uColorB;
		uniform vec3 uColorC;
		uniform float uOpacity;
		uniform float uNight;
		uniform float uTime;
		uniform float uNearFade;
		varying float vAlpha;
		varying float vTint;
		varying float vSeed;
		varying vec3 vWorld;
		void main() {
			vec4 tex = texture2D(uMap, gl_PointCoord);
			float a = tex.a * vAlpha * uOpacity;
			if (uNearFade > 0.0) a *= smoothstep(uNearFade * 0.5, uNearFade, length(vWorld - cameraPosition));
			if (a < 0.004) discard;
			vec3 col = mix(uColorA, uColorB, vTint);
			col = mix(col, uColorC, uNight * 0.45);
			gl_FragColor = vec4(col, a);
		}
	`;

	const LIGHT_FRAG = `
		uniform sampler2D uMap;
		uniform float uOpacity;
		uniform float uTime;
		uniform float uNearFade;
		varying float vAlpha;
		varying float vTint;
		varying float vSeed;
		varying vec3 vWorld;
		void main() {
			vec4 tex = texture2D(uMap, gl_PointCoord);
			float blink = 0.2 + 0.8 * pow(max(sin(uTime * 1.35 + vSeed * 6.2831), 0.0), 7.0);
			float a = tex.a * vAlpha * uOpacity * blink;
			if (uNearFade > 0.0) a *= smoothstep(uNearFade * 0.5, uNearFade, length(vWorld - cameraPosition));
			if (a < 0.004) discard;
			vec3 warm = vec3(1.0, 0.82, 0.52);
			vec3 red = vec3(1.0, 0.28, 0.16);
			vec3 green = vec3(0.42, 1.0, 0.62);
			vec3 col = vTint < 0.5 ? mix(red, warm, vTint * 1.4) : mix(warm, green, (vTint - 0.5) * 1.6);
			gl_FragColor = vec4(col, a);
		}
	`;

	function makePointSystem(opts) {
		const max = opts.max;
		const geo = new THREE.BufferGeometry();
		const pos = new Float32Array(max * 3);
		const aSize = new Float32Array(max);
		const aAlpha = new Float32Array(max);
		const aTint = new Float32Array(max);
		const aSeed = new Float32Array(max);
		geo.setAttribute('position', new THREE.BufferAttribute(pos, 3).setUsage(THREE.DynamicDrawUsage));
		geo.setAttribute('aSize', new THREE.BufferAttribute(aSize, 1).setUsage(THREE.DynamicDrawUsage));
		geo.setAttribute('aAlpha', new THREE.BufferAttribute(aAlpha, 1).setUsage(THREE.DynamicDrawUsage));
		geo.setAttribute('aTint', new THREE.BufferAttribute(aTint, 1).setUsage(THREE.DynamicDrawUsage));
		geo.setAttribute('aSeed', new THREE.BufferAttribute(aSeed, 1).setUsage(THREE.DynamicDrawUsage));
		geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1200);
		const mat = new THREE.ShaderMaterial({
			uniforms: {
				uMap: { value: opts.texture },
				uScale: { value: 900 },
				uMaxSize: { value: 260 },
				uColorA: { value: new THREE.Color(opts.colorA || '#d8d4ce') },
				uColorB: { value: new THREE.Color(opts.colorB || '#f0e4d2') },
				uColorC: { value: new THREE.Color(opts.colorC || '#c9a882') },
				uOpacity: { value: opts.opacity != null ? opts.opacity : 1 },
				uNight: { value: 0 },
				uTime: { value: 0 },
				uNearFade: { value: opts.nearFade != null ? opts.nearFade : 0 },
			},
			vertexShader: POINT_VERT,
			fragmentShader: opts.light ? LIGHT_FRAG : POINT_FRAG,
			transparent: true,
			depthWrite: false,
			depthTest: true,
			blending: opts.additive ? THREE.AdditiveBlending : THREE.NormalBlending,
			toneMapped: false,
		});
		const points = new THREE.Points(geo, mat);
		points.frustumCulled = false;
		points.renderOrder = opts.renderOrder != null ? opts.renderOrder : 5;
		points.name = opts.name || 'points';
		return { points, geo, mat, max, pos, aSize, aAlpha, aTint, aSeed };
	}

	// ------------------------------------------------------------------
	// lighthouse beam: soft additive cone shell
	// ------------------------------------------------------------------
	function makeBeamGeometry(len, r0, r1, segs, rings) {
		const pos = [];
		const nor = [];
		const tArr = [];
		for (let i = 0; i <= rings; i++) {
			const t = i / rings;
			const r = lerp(r0, r1, Math.pow(t, 0.9));
			for (let j = 0; j <= segs; j++) {
				const a = (j / segs) * TAU;
				pos.push(Math.cos(a) * r, Math.sin(a) * r, t * len);
				nor.push(Math.cos(a), Math.sin(a), 0);
				tArr.push(t);
			}
		}
		const idx = [];
		for (let i = 0; i < rings; i++) {
			for (let j = 0; j < segs; j++) {
				const a = i * (segs + 1) + j;
				const b = a + 1;
				const c = a + segs + 1;
				const d = c + 1;
				idx.push(a, b, c, b, d, c);
			}
		}
		const geo = new THREE.BufferGeometry();
		geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pos), 3));
		geo.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(nor), 3));
		geo.setAttribute('aT', new THREE.BufferAttribute(new Float32Array(tArr), 1));
		geo.setIndex(idx);
		return geo;
	}

	const BEAM_VERT = `
		attribute float aT;
		varying float vT;
		varying vec3 vWorld;
		varying vec3 vNormal;
		void main() {
			vec4 wp = modelMatrix * vec4(position, 1.0);
			vWorld = wp.xyz;
			vNormal = normalize(mat3(modelMatrix) * normal);
			vT = aT;
			gl_Position = projectionMatrix * viewMatrix * wp;
		}
	`;

	const BEAM_FRAG = `
		uniform vec3 uColor;
		uniform float uOpacity;
		uniform float uTime;
		varying float vT;
		varying vec3 vWorld;
		varying vec3 vNormal;
		void main() {
			if (uOpacity < 0.002) discard;
			vec3 vd = cameraPosition - vWorld;
			float vl = length(vd);
			vd = vl > 1e-4 ? vd / vl : vec3(0.0, 0.0, 1.0);
			vec3 vn = normalize(vNormal + vec3(1e-5));
			float facing = clamp(abs(dot(vn, vd)), 0.0, 1.0);
			float t = clamp(vT, 0.0, 1.0);
			float soft = 0.18 + 0.82 * facing * facing;
			float fall = 1.0 - smoothstep(0.0, 1.0, t);
			float near = smoothstep(0.0, 0.06, t);
			float flick = 0.9 + 0.1 * sin(uTime * 2.4 + t * 7.0);
			float a = fall * soft * near * uOpacity * flick;
			if (!(a >= 0.002)) discard;
			gl_FragColor = vec4(uColor, a * 0.22);
		}
	`;

	// ------------------------------------------------------------------
	// cloth flag material: standard PBR + a travelling wave in the vertex
	// shader so the flag keeps correct scene lighting.
	// ------------------------------------------------------------------
	function makeFlagMaterial(texture, width, seed) {
		const uniforms = {
			uTime: { value: 0 },
			uPhase: { value: seed },
			uWidth: { value: width },
			uAmp: { value: 0.055 },
		};
		const mat = new THREE.MeshStandardMaterial({
			map: texture,
			side: THREE.DoubleSide,
			roughness: 0.88,
			metalness: 0.0,
			transparent: true,
			alphaTest: 0.35,
		});
		mat.userData.uniforms = uniforms;
		mat.onBeforeCompile = (shader) => {
			shader.uniforms.uTime = uniforms.uTime;
			shader.uniforms.uPhase = uniforms.uPhase;
			shader.uniforms.uWidth = uniforms.uWidth;
			shader.uniforms.uAmp = uniforms.uAmp;
			shader.vertexShader =
				'uniform float uTime;\nuniform float uPhase;\nuniform float uWidth;\nuniform float uAmp;\n' +
				shader.vertexShader;
			shader.vertexShader = shader.vertexShader.replace(
				'#include <beginnormal_vertex>',
				`#include <beginnormal_vertex>
				float uu = clamp(position.x / uWidth, 0.0, 1.0);
				float dw = (cos(uu * 6.6 - uTime * 2.7 + uPhase) * 0.72 + cos(uu * 12.4 - uTime * 4.1 + uPhase * 1.7) * 0.28) * 6.6;
				dw *= uAmp * (0.32 + uu * 1.3) / uWidth;
				objectNormal = normalize(vec3(-dw * 0.85, 0.1 * sin(uu * 4.2 - uTime * 1.9 + uPhase), 1.0));`
			);
			shader.vertexShader = shader.vertexShader.replace(
				'#include <begin_vertex>',
				`#include <begin_vertex>
				float uu2 = clamp(position.x / uWidth, 0.0, 1.0);
				float amp2 = uAmp * (0.32 + uu2 * 1.3);
				float wave = sin(uu2 * 6.6 - uTime * 2.7 + uPhase) * 0.72 + sin(uu2 * 12.4 - uTime * 4.1 + uPhase * 1.7) * 0.28;
				transformed.z += wave * amp2;
				transformed.y += sin(uu2 * 3.1 - uTime * 1.55 + uPhase * 0.6) * amp2 * 0.4 - uu2 * uu2 * 0.014;
				transformed.x -= uu2 * amp2 * 0.3;`
			);
		};
		mat.customProgramCacheKey = () => 'atm-flag-cloth';
		return mat;
	}

	// ------------------------------------------------------------------
	// module
	// ------------------------------------------------------------------
	H.register('atmosphere', {
		create(ctx) {
			const g = ctx.group('atmosphere');
			const M = ctx.materials;
			const scene = ctx.scene;
			const env = ctx.env;
			const state = ctx.state;
			const rng = U.rng(0xa77e5);
			const T = {
				puff: puffTexture(128, 811),
				puffFar: puffTexture(128, 377, { key: 'atm:puff:377', period: 4, feather: 1.25, core: 0.4 }),
				smoke: smokeTexture(),
				foam: foamTexture(),
				spark: sparkTexture(64),
			};

			// ---------------- clouds ----------------
			const cloudSets = makeCloudPuffs(rng);
			const clouds = makeBillboardLayer(
				cloudSets.near,
				{
					map: T.puff,
					shader: CLOUD_FRAG,
				},
				{},
				{ scale: 0.6 }
			);
			clouds.name = 'clouds';
			g.add(clouds);
			const cloudUniforms = clouds.material.uniforms;
			cloudUniforms.uLit = { value: MOOD.cloudLit };
			cloudUniforms.uShade = { value: MOOD.cloudShade };
			cloudUniforms.uRim = { value: MOOD.cloudRim };
			cloudUniforms.uRimStrength = { value: MOOD.rimStrength };
			cloudUniforms.uMoonColor = { value: new THREE.Color('#a8c2ef') };
			cloudUniforms.uNight = { value: 0 };

			// upper cloud deck (separate card set, softer texture): reads when
			// the viewer lowers the orbit towards the horizon
			const farClouds = makeBillboardLayer(cloudSets.deck, { map: T.puffFar, shader: CLOUD_FRAG }, {}, { scale: 0.6 });
			farClouds.name = 'clouds-far';
			farClouds.renderOrder = 1;
			g.add(farClouds);
			const farUniforms = farClouds.material.uniforms;
			farUniforms.uLit = { value: MOOD.cloudLit };
			farUniforms.uShade = { value: MOOD.cloudShade };
			farUniforms.uRim = { value: MOOD.cloudRim };
			farUniforms.uRimStrength = { value: MOOD.rimStrength * 0.7 };
			farUniforms.uMoonColor = { value: new THREE.Color('#a8c2ef') };
			farUniforms.uNight = { value: 0 };

			// ---------------- sea mist ----------------
			const mist = makeBillboardLayer(
				makeMistPuffs(rng),
				{ map: T.puffFar, shader: MIST_FRAG },
				{
					uColor: { value: MOOD.mist.clone() },
					uSunColor: { value: new THREE.Color('#ffcf9a') },
				}
			);
			mist.name = 'sea-mist';
			mist.renderOrder = 3;
			g.add(mist);
			const mistUniforms = mist.material.uniforms;

			// ================================================================
			// surface probes: since the other modules are authored in parallel,
			// every emitter / flag is placed by raycasting the *finished* scene
			// instead of hard-coding heights. Cheap and robust to layout drift.
			// ================================================================
			const probeRoots = ['town', 'quay', 'industrial', 'lighthouse', 'vessels', 'props', 'street']
				.map((n) => scene.getObjectByName('group:' + n))
				.filter(Boolean);
			const _ray = new THREE.Raycaster();
			const _down = new THREE.Vector3(0, -1, 0);
			const _rayFrom = new THREE.Vector3();
			_ray.camera = ctx.camera; // sprites inside other modules need this
			ctx.camera.updateMatrixWorld();
			function probeTop(x, z, fromY, fallback) {
				_rayFrom.set(x, fromY != null ? fromY : 30, z);
				_ray.set(_rayFrom, _down);
				_ray.far = 60;
				let best = -Infinity;
				const roots = probeRoots.length ? probeRoots : [scene];
				for (let r = 0; r < roots.length; r++) {
					const hits = _ray.intersectObject(roots[r], true);
					for (let i = 0; i < hits.length; i++) {
						const h = hits[i];
						if (!h.object.isMesh) continue;
						const y = h.point.y;
						if (y > best && y < 30 && y > -2.4) best = y;
					}
				}
				if (Number.isFinite(best)) return best;
				return fallback != null ? fallback : null;
			}

			// ================================================================
			// GULLS —12 flying + a few perched, each a merged body+wings.
			// All flying gulls share one dynamic mesh (1 draw call).
			// ================================================================
			const gullT = buildGullTemplate();
			const GULL_MAX = 10;
			const gullGeo = new THREE.BufferGeometry();
			const vertsPerGull = gullT.count;
			const flyPos = new Float32Array(GULL_MAX * vertsPerGull * 3);
			const flyNor = new Float32Array(GULL_MAX * vertsPerGull * 3);
			const flyCol = new Float32Array(GULL_MAX * vertsPerGull * 3);
			for (let i = 0; i < GULL_MAX; i++) flyCol.set(gullT.colors, i * vertsPerGull * 3);
			const flyIdx = new Uint32Array(GULL_MAX * gullT.indices.length);
			for (let i = 0; i < GULL_MAX; i++) {
				for (let k = 0; k < gullT.indices.length; k++) flyIdx[i * gullT.indices.length + k] = gullT.indices[k] + i * vertsPerGull;
			}
			gullGeo.setAttribute('position', new THREE.BufferAttribute(flyPos, 3).setUsage(THREE.DynamicDrawUsage));
			gullGeo.setAttribute('normal', new THREE.BufferAttribute(flyNor, 3).setUsage(THREE.DynamicDrawUsage));
			gullGeo.setAttribute('color', new THREE.BufferAttribute(flyCol, 3));
			gullGeo.setIndex(new THREE.BufferAttribute(flyIdx, 1));
			gullGeo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 4, 4), 60);
			const gullMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.78, metalness: 0.0, side: THREE.DoubleSide });
			const gullMesh = new THREE.Mesh(gullGeo, gullMat);
			gullMesh.frustumCulled = false;
			gullMesh.name = 'gulls';
			gullMesh.renderOrder = 1;
			g.add(gullMesh);

			const gullDefs = [];
			for (let i = 0; i < 4; i++) {
				gullDefs.push({
					kind: 'circle',
					cx: 0.3,
					cz: 5.4,
					r: 2.8 + (i % 2) * 0.5,
					cy: 5.0 + (i % 2) * 0.6,
					speed: (0.15 + i * 0.004) * (i % 2 ? -1 : 1),
					phase: (i / 4) * TAU + 0.4,
					size: 0.19 + (i % 3) * 0.012,
					flapFreq: 6.4 + i * 0.25,
					glideBias: 0.35 + i * 0.06,
				});
			}
			for (let i = 0; i < 3; i++) {
				gullDefs.push({
					kind: 'figure8',
					cx: 0.8,
					cz: 2.2,
					ax: 3.5 + (i % 2) * 0.5,
					az: 1.9,
					cy: 5.8 + (i % 2) * 0.5,
					speed: (0.17 + i * 0.006) * (i % 2 ? -1 : 1),
					phase: (i / 4) * TAU,
					size: 0.18 + (i % 3) * 0.012,
					flapFreq: 6.0 + i * 0.3,
					glideBias: 0.45 + i * 0.05,
				});
			}
			gullDefs.push({ kind: 'skim', cx: 0.4, cz: 11.6, rx: 5.0, rz: 1.0, cy: 1.0, speed: 0.23, phase: 0.6, size: 0.17, flapFreq: 7.2, glideBias: 0.18 });
			gullDefs.push({ kind: 'skim', cx: 0.4, cz: 11.6, rx: 5.6, rz: 1.15, cy: 1.25, speed: -0.19, phase: 3.1, size: 0.16, flapFreq: 7.6, glideBias: 0.22 });
			gullDefs.push({ kind: 'beach', ax: -9.2, az: 4.6, bx: -12.2, bz: 4.0, cy: 1.55, speed: 0.11, phase: 0.2, size: 0.17, flapFreq: 7.0, glideBias: 0.25 });

			function gullPoint(def, tt) {
				let x, y, z;
				if (def.kind === 'circle') {
					const u = tt * def.speed + def.phase;
					x = def.cx + Math.cos(u) * def.r;
					z = def.cz + Math.sin(u) * def.r;
					y = def.cy + Math.sin(tt * 0.27 + def.phase * 2.3) * 0.55;
				} else if (def.kind === 'figure8') {
					const u = tt * def.speed + def.phase;
					x = def.cx + Math.sin(u) * def.ax;
					z = def.cz + Math.sin(u * 2) * def.az;
					y = def.cy + Math.sin(tt * 0.22 + def.phase) * 0.6;
				} else if (def.kind === 'skim') {
					const u = tt * def.speed + def.phase;
					x = def.cx + Math.cos(u) * def.rx;
					z = def.cz + Math.sin(u) * def.rz;
					y = def.cy + Math.sin(u * 2.0 + def.phase) * 0.22;
				} else {
					const cyc = U.pingPong(tt * def.speed + def.phase * 2.0, 1);
					x = lerp(def.ax, def.bx, cyc);
					z = lerp(def.az, def.bz, cyc);
					y = def.cy + Math.sin(cyc * Math.PI) * 0.35;
				}
				return [x, y, z];
			}

			const _gA = new THREE.Vector3();
			const _gB = new THREE.Vector3();
			const _gC = new THREE.Vector3();
			const _gD = new THREE.Vector3();
			const _gQ = new THREE.Quaternion();
			const _gE = new THREE.Euler(0, 0, 0, 'YXZ');
			const _gM = new THREE.Matrix4();

			function updateGulls(time) {
				const vis = 1 - smoothstep(0.48, 0.85, MOOD.night);
				gullMesh.visible = vis > 0.02;
				for (let i = 0; i < GULL_MAX; i++) {
					const def = gullDefs[i];
					const a = gullPoint(def, time);
					const b = gullPoint(def, time + 0.06);
					const c = gullPoint(def, time + 0.35);
					_gA.set(a[0], a[1], a[2]);
					_gB.set(b[0], b[1], b[2]);
					_gC.set(c[0], c[1], c[2]);
					_gD.subVectors(_gB, _gA);
					_gD.normalize();
					const yawA = Math.atan2(_gD.x, _gD.z);
					const fy = _gD.y;
					_gD.subVectors(_gC, _gB);
					_gD.normalize();
					let yawB = Math.atan2(_gD.x, _gD.z);
					let dyaw = yawB - yawA;
					while (dyaw > Math.PI) dyaw -= TAU;
					while (dyaw < -Math.PI) dyaw += TAU;
					const roll = clamp(-dyaw * 2.1, -0.62, 0.62);
					const pitch = -Math.asin(clamp(fy, -1, 1)) * 0.65;
					// flap envelope: long glides broken by bursts of wing beats
					const envelope = 0.5 + 0.5 * Math.sin(time * 0.33 + def.phase * 2.7);
					const glide = smoothstep(0.3, 0.72, envelope) * def.glideBias + (1 - def.glideBias) * 0.1;
					const amp = lerp(0.85, 0.08, glide);
					let flap = Math.sin(time * def.flapFreq + def.phase * 6.0) * amp;
					flap += 0.1 * glide;
					const size = def.size * vis;
					_gE.set(pitch, yawA, roll, 'YXZ');
					_gQ.setFromEuler(_gE);
					_gM.makeRotationFromQuaternion(_gQ);
					_gM.setPosition(_gA);
					writeGull(flyPos, flyNor, i * vertsPerGull, gullT, _gM, flap, size);
				}
				gullGeo.attributes.position.needsUpdate = true;
				gullGeo.attributes.normal.needsUpdate = true;
			}
			updateGulls(0);

			// perched gulls (silhouettes that stay at night)
			const perchSpots = [
				[5.2, 8.0, 0.9, 0.13],
				[0.4, 9.4, -1.9, 0.12],
				[-3.0, 8.4, 2.4, 0.12],
				[2.2, 9.3, 1.2, 0.11],
			];
			{
				const perchCount = perchSpots.length;
				const pPos = new Float32Array(perchCount * vertsPerGull * 3);
				const pNor = new Float32Array(perchCount * vertsPerGull * 3);
				const pIdx = new Uint32Array(perchCount * gullT.indices.length);
				const pCol = new Float32Array(perchCount * vertsPerGull * 3);
				const pYaw = new THREE.Matrix4();
				for (let i = 0; i < perchCount; i++) {
					const s = perchSpots[i];
					const top = probeTop(s[0], s[1], 25, 1.5);
					const y = Math.max(top != null ? top : 1.5, 1.3) + 0.015;
					_gE.set(0, s[2], 0, 'YXZ');
					_gQ.setFromEuler(_gE);
					pYaw.makeRotationFromQuaternion(_gQ);
					pYaw.setPosition(s[0], y, s[1]);
					writeGull(pPos, pNor, i * vertsPerGull, gullT, pYaw, -1.05, s[3]);
					pCol.set(gullT.colors, i * vertsPerGull * 3);
					for (let k = 0; k < gullT.indices.length; k++) pIdx[i * gullT.indices.length + k] = gullT.indices[k] + i * vertsPerGull;
				}
				const pGeo = new THREE.BufferGeometry();
				pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
				pGeo.setAttribute('normal', new THREE.BufferAttribute(pNor, 3));
				pGeo.setAttribute('color', new THREE.BufferAttribute(pCol, 3));
				pGeo.setIndex(new THREE.BufferAttribute(pIdx, 1));
				pGeo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 1.5, 8), 30);
				const perchMesh = new THREE.Mesh(pGeo, gullMat);
				perchMesh.name = 'gulls-perched';
				perchMesh.frustumCulled = false;
				g.add(perchMesh);
			}

			// ================================================================
			// SMOKE & STEAM —one Points system, emitters discovered with probes.
			// ================================================================
			const smoke = makePointSystem({ max: 110, texture: T.smoke, colorA: '#b0aaa1', colorB: '#cbbcab', colorC: '#b08a63', name: 'smoke' });
			smoke.points.renderOrder = 7;
			g.add(smoke.points);
			const SMOKE_MAX = smoke.max;
			const sX = new Float32Array(SMOKE_MAX),
				sY = new Float32Array(SMOKE_MAX),
				sZ = new Float32Array(SMOKE_MAX);
			const sVX = new Float32Array(SMOKE_MAX),
				sVY = new Float32Array(SMOKE_MAX),
				sVZ = new Float32Array(SMOKE_MAX);
			const sAge = new Float32Array(SMOKE_MAX),
				sLife = new Float32Array(SMOKE_MAX);
			const sS0 = new Float32Array(SMOKE_MAX),
				sS1 = new Float32Array(SMOKE_MAX);
			const sRise = new Float32Array(SMOKE_MAX),
				sDrift = new Float32Array(SMOKE_MAX),
				sAlpha = new Float32Array(SMOKE_MAX);
			let smokeCursor = 0;

			function spawnSmoke(x, y, z, spec) {
				const i = smokeCursor;
				smokeCursor = (smokeCursor + 1) % SMOKE_MAX;
				const rnd = rng.next;
				sX[i] = x + (rnd() - 0.5) * (spec.spread || 0.05);
				sY[i] = y + (rnd() - 0.5) * 0.02;
				sZ[i] = z + (rnd() - 0.5) * (spec.spread || 0.05);
				sVX[i] = (rnd() - 0.5) * 0.02;
				sVY[i] = lerp(spec.rise[0], spec.rise[1], rnd());
				sVZ[i] = (rnd() - 0.5) * 0.02;
				sAge[i] = 0;
				sLife[i] = lerp(spec.life[0], spec.life[1], rnd());
				sS0[i] = lerp(spec.s0[0], spec.s0[1], rnd());
				sS1[i] = lerp(spec.s1[0], spec.s1[1], rnd());
				sRise[i] = sVY[i];
				sDrift[i] = lerp(spec.drift[0], spec.drift[1], rnd());
				sAlpha[i] = spec.alpha != null ? spec.alpha : 0.5;
				smoke.aTint[i] = lerp(spec.tint[0], spec.tint[1], rnd());
				smoke.aSeed[i] = rnd();
			}

			const emitters = [];
			function addEmitter(x, y, z, spec) {
				emitters.push({ x, y, z, rate: spec.rate, acc: rng.range(0.2, 1.4), spec });
			}
			function lotNear(px, pz) {
				let best = null;
				let bd = 1e9;
				for (const lot of L.townLots) {
					const d = Math.hypot(lot.pos[0] - px, lot.pos[1] - pz);
					if (d < bd) {
						bd = d;
						best = lot;
					}
				}
				return best;
			}
			function addChimney(lot) {
				if (!lot) return;
				const x = lot.pos[0] + 0.17;
				const z = lot.pos[1] + 0.13;
				const fallback = L.LEVEL.town + 0.62 + lot.floors * 0.3 + 0.3;
				const top = probeTop(x, z, 26, fallback);
				let y = fallback;
				if (top != null && top > L.LEVEL.town + 0.8 && top < L.LEVEL.town + 4.6) y = top + 0.04;
				addEmitter(x, y, z, {
					rate: 1.35,
					spread: 0.05,
					life: [5.6, 8.4],
					s0: [0.028, 0.049],
					s1: [0.38, 0.66],
					rise: [0.12, 0.2],
					drift: [1.5, 2.3],
					tint: [0.3, 0.9],
					alpha: 0.22,
				});
			}
			addChimney(lotNear(-2.6, -6.4));
			addChimney(lotNear(0.6, -3.4));
			addChimney(lotNear(-6.4, -2.2));
			// fish market steam (low, fast, white)
			{
				const p = L.ANCHORS.fishMarket.pos;
				const top = probeTop(p[0] + 0.2, p[1] + 0.15, 22, L.LEVEL.quay + 0.9);
				const y = top != null && top > L.LEVEL.quay + 0.25 ? top + 0.08 : L.LEVEL.quay + 0.95;
				addEmitter(p[0] + 0.2, y, p[1] + 0.2, {
					rate: 0.95,
					spread: 0.2,
					life: [2.4, 3.6],
					s0: [0.042, 0.07],
					s1: [0.39, 0.64],
					rise: [0.18, 0.27],
					drift: [1.6, 2.4],
					tint: [0.08, 0.4],
					alpha: 0.16,
				});
			}
			// gantry crane / winch steam on the working quay
			{
				const p = L.ANCHORS.gantryCrane.pos;
				const top = probeTop(p[0] - 0.4, p[1] + 0.4, 22, L.LEVEL.quay + 0.5);
				const y = Math.min(top != null ? top : L.LEVEL.quay + 0.5, L.LEVEL.quay + 2.6) + 0.05;
				addEmitter(p[0] - 0.42, y, p[1] + 0.45, {
					rate: 0.5,
					spread: 0.05,
					life: [1.7, 2.7],
					s0: [0.025, 0.039],
					s1: [0.21, 0.36],
					rise: [0.21, 0.31],
					drift: [1.5, 2.1],
					tint: [0.05, 0.38],
					alpha: 0.15,
				});
			}

			function updateSmoke(dt, time) {
				for (let e = 0; e < emitters.length; e++) {
					const em = emitters[e];
					em.acc += dt * em.rate;
					while (em.acc >= 1) {
						em.acc -= 1;
						spawnSmoke(em.x, em.y, em.z, em.spec);
					}
				}
				const windX = WIND.x * WIND.speed;
				const windZ = WIND.z * WIND.speed;
				for (let i = 0; i < SMOKE_MAX; i++) {
					if (sLife[i] <= 0) {
						if (smoke.aAlpha[i] !== 0) smoke.aAlpha[i] = 0;
						continue;
					}
					sAge[i] += dt;
					const ageK = sAge[i] / sLife[i];
					if (ageK >= 1) {
						sLife[i] = 0;
						smoke.aAlpha[i] = 0;
						continue;
					}
					const drag = Math.min(1, dt * 1.1);
					sVX[i] += (windX * sDrift[i] - sVX[i]) * drag;
					sVZ[i] += (windZ * sDrift[i] - sVZ[i]) * drag;
					sVY[i] += (sRise[i] - sVY[i]) * Math.min(1, dt * 0.8);
					sX[i] += sVX[i] * dt;
					sY[i] += sVY[i] * dt;
					sZ[i] += sVZ[i] * dt;
					smoke.pos[i * 3] = sX[i];
					smoke.pos[i * 3 + 1] = sY[i];
					smoke.pos[i * 3 + 2] = sZ[i];
					smoke.aSize[i] = lerp(sS0[i], sS1[i], Math.pow(ageK, 0.42));
					smoke.aAlpha[i] = smoothstep(0.0, 0.06, ageK) * (1 - smoothstep(0.12, 0.85, ageK)) * sAlpha[i];
				}
				smoke.geo.attributes.position.needsUpdate = true;
				smoke.geo.attributes.aSize.needsUpdate = true;
				smoke.geo.attributes.aAlpha.needsUpdate = true;
				smoke.geo.attributes.aTint.needsUpdate = true;
				smoke.geo.attributes.aSeed.needsUpdate = true;
			}

			// ================================================================
			// FLAGS —procedural cloth, pole bases found by probe
			// ================================================================
			const flagMeshes = [];
			const poleGeos = [];
			const flagTexCache = {};
			function flagTexFor(kind) {
				if (!flagTexCache[kind]) flagTexCache[kind] = flagTexture(kind);
				return flagTexCache[kind];
			}
			function addPole(x, baseY, z, height, radius) {
				const geo = new THREE.CylinderGeometry(radius * 0.7, radius, height, 6);
				geo.translate(x, baseY + height * 0.5, z);
				poleGeos.push(geo);
				const fin = new THREE.SphereGeometry(radius * 1.8, 6, 4);
				fin.translate(x, baseY + height + radius, z);
				poleGeos.push(fin);
				return baseY + height;
			}
			function addFlag(x, poleTop, z, w, h, kind, phase) {
				const geo = new THREE.PlaneGeometry(w, h, 10, 5);
				geo.translate(w * 0.5, 0, 0);
				const mat = makeFlagMaterial(flagTexFor(kind), w, phase);
				const mesh = new THREE.Mesh(geo, mat);
				mesh.position.set(x, poleTop - h * 0.5 - 0.02, z);
				mesh.rotation.y = WIND_YAW;
				mesh.castShadow = false;
				mesh.receiveShadow = false;
				mesh.name = 'flag-' + kind;
				g.add(mesh);
				flagMeshes.push(mesh);
				return mesh;
			}
			// plaza flagpole
			{
				const p = L.ANCHORS.plaza;
				const x = p.pos[0] + 1.16;
				const z = p.pos[1] + 0.92;
				const base = probeTop(x, z, 26, L.LEVEL.town);
				const top = addPole(x, base, z, 1.62, 0.016);
				addFlag(x, top, z, 0.62, 0.4, 'town', 0.4);
			}
			// church tower finial flag
			{
				const p = L.ANCHORS.church.pos;
				const top = probeTop(p[0], p[1], 30, null);
				if (top != null && top > L.LEVEL.town + 1.4) {
					const py = addPole(p[0], top - 0.03, p[1], 0.46, 0.009);
					addFlag(p[0], py, p[1], 0.34, 0.22, 'church', 1.7);
				}
			}
			// Fort Point: the structures module already owns the signal tower's
			// brass staff + red pennant, so nothing is added here (no doubles).
			// customs house civic flag
			{
				const p = L.ANCHORS.customsHouse.pos;
				const top = probeTop(p[0], p[1], 26, null);
				if (top != null && top > L.LEVEL.quay + 0.5) {
					const py = addPole(p[0] + 0.32, top - 0.02, p[1] + 0.2, 0.4, 0.008);
					addFlag(p[0] + 0.32, py, p[1] + 0.2, 0.28, 0.19, 'town', 4.2);
				}
			}
			// boat masthead pennants (moored boats published by the vessels module)
			{
				const vw = ctx.world.vessels;
				const boats = vw && vw.boats ? vw.boats : [];
				let count = 0;
				for (const b of boats) {
					if (count >= 3) break;
					// only boats actually at a berth (moored = static pennant ok)
					let moored = false;
					for (const berth of L.berths) {
						if (Math.hypot(berth.pos[0] - b.x, berth.pos[1] - b.z) < 0.35) {
							moored = true;
							break;
						}
					}
					if (!moored) continue;
					const top = probeTop(b.x, b.z, 20, null);
					if (top == null || top < 0.45 || top > 3.4) continue;
					const py = addPole(b.x, top - 0.03, b.z, 0.3, 0.006);
					addFlag(b.x, py, b.z, 0.2, 0.13, 'pennant', count * 1.9 + 0.5);
					count++;
				}
			}
			if (poleGeos.length) {
				const mergedPoleGeo = U.merge(poleGeos);
				const poleMat = M.get('steelDark').clone();
				poleMat.roughness = 0.55;
				const poles = new THREE.Mesh(mergedPoleGeo, poleMat);
				poles.name = 'flagpoles';
				poles.castShadow = false;
				poles.receiveShadow = false;
				g.add(poles);
				for (const geo of poleGeos) geo.dispose();
			}

			// ================================================================
			// LIGHTHOUSE BEAM + LAMP GLOW (night)
			// ================================================================
			const lh = L.BREAKWATER.lighthouse;
			const lhTop = probeTop(lh[0], lh[1], 30, L.LEVEL.breakwater + 2.9);
			const lampY = lhTop != null && lhTop > L.LEVEL.breakwater + 1.0 ? lhTop - 0.34 : L.LEVEL.breakwater + 2.5;
			const beamPivot = new THREE.Group();
			beamPivot.name = 'lighthouse-beam';
			beamPivot.position.set(lh[0], lampY, lh[1]);
			g.add(beamPivot);
			const beamGeo = makeBeamGeometry(24, 0.09, 0.85, 20, 12);
			const beamUniforms = { uColor: { value: MOOD.beam.clone() }, uOpacity: { value: 0 }, uTime: { value: 0 } };
			const beamMat = new THREE.ShaderMaterial({
				uniforms: beamUniforms,
				vertexShader: BEAM_VERT,
				fragmentShader: BEAM_FRAG,
				transparent: true,
				depthWrite: false,
				blending: THREE.AdditiveBlending,
				side: THREE.DoubleSide,
				toneMapped: false,
			});
			const beam = new THREE.Mesh(beamGeo, beamMat);
			beam.frustumCulled = false;
			beam.rotation.x = 0.018;
			beamPivot.add(beam);
			const coreUniforms = { uColor: { value: new THREE.Color('#fff0d0') }, uOpacity: { value: 0 }, uTime: { value: 0 } };
			const coreMat = new THREE.ShaderMaterial({
				uniforms: coreUniforms,
				vertexShader: BEAM_VERT,
				fragmentShader: BEAM_FRAG,
				transparent: true,
				depthWrite: false,
				blending: THREE.AdditiveBlending,
				side: THREE.DoubleSide,
				toneMapped: false,
			});
			const beamCore = new THREE.Mesh(makeBeamGeometry(22, 0.035, 0.22, 14, 8), coreMat);
			beamCore.frustumCulled = false;
			beamCore.rotation.x = 0.018;
			beamCore.renderOrder = 9;
			beamPivot.add(beamCore);
			// lamp halo
			const haloTex = T.spark;
			const lampHaloMat = new THREE.SpriteMaterial({
				map: haloTex,
				color: 0xffd9a0,
				transparent: true,
				depthWrite: false,
				blending: THREE.AdditiveBlending,
				toneMapped: false,
				opacity: 0,
			});
			const lampHalo = new THREE.Sprite(lampHaloMat);
			lampHalo.position.set(lh[0], lampY, lh[1]);
			lampHalo.scale.setScalar(0.85);
			lampHalo.renderOrder = 10;
			g.add(lampHalo);
			// harbour entrance beacons: soft glow matching t4's blinking nav buoys
			const channelLights = makePointSystem({ max: 6, texture: T.spark, light: true, additive: true, nearFade: 9, name: 'channel-lights' });
			const channelDefs = [
				[-4.9, 0.4, 8.9, 0.0, 0.3],
				[-6.95, 0.4, 9.5, 1.0, 0.34],
				[4.9, 0.4, 10.8, 0.0, 0.32],
				[7.15, 0.4, 9.85, 1.0, 0.36],
			];
			for (let i = 0; i < channelDefs.length; i++) {
				const c = channelDefs[i];
				channelLights.pos[i * 3] = c[0];
				channelLights.pos[i * 3 + 1] = c[1];
				channelLights.pos[i * 3 + 2] = c[2];
				channelLights.aSize[i] = 0.35;
				channelLights.aAlpha[i] = 0.9;
				channelLights.aTint[i] = c[3];
				channelLights.aSeed[i] = c[4];
			}
			channelLights.points.renderOrder = 11;
			g.add(channelLights.points);
			// warm lamps glinting on the harbour water: a handful of additive
			// motes that only exist at night. The water surface itself is
			// untouched (that is t1's module) — this is pure atmosphere.
			const glints = makePointSystem({ max: 18, texture: T.spark, additive: true, colorA: '#ffb56c', colorB: '#fff1d2', nearFade: 9, name: 'water-glints' });
			const glintSpots = [
				[-9.3, 2.9], [-6.4, 3.1], [-3.4, 3.3], [-0.8, 3.5], [1.8, 3.3], [3.6, 2.9],
				[2.6, 4.2], [-6.0, 3.9], [-8.6, 3.6], [5.0, 4.3], [5.8, 5.0], [-11.2, 4.0],
				[0.6, 5.2], [-4.6, 5.6], [3.2, 6.2], [-1.8, 7.0], [6.4, 6.6], [-7.6, 6.4],
			];
			let glintCount = 0;
			for (const spot of glintSpots) {
				if (!L.isWater(spot[0], spot[1], 0.05)) continue;
				const i = glintCount++;
				glints.pos[i * 3] = spot[0];
				glints.pos[i * 3 + 1] = 0.03;
				glints.pos[i * 3 + 2] = spot[1];
				glints.aSize[i] = rng.range(0.072, 0.162);
				glints.aAlpha[i] = 1;
				glints.aTint[i] = rng.next();
				glints.aSeed[i] = rng.range(0, TAU);
			}
			glints.points.renderOrder = 12;
			g.add(glints.points);

			// ================================================================
			// SPRAY —throttled bursts against the breakwater rocks & beach
			// ================================================================
			const spray = makePointSystem({ max: 90, texture: T.foam, colorA: '#e2eeea', colorB: '#ffffff', colorC: '#d8e6e2', name: 'spray' });
			spray.points.renderOrder = 8;
			g.add(spray.points);
			const SPRAY_MAX = spray.max;
			const wX = new Float32Array(SPRAY_MAX),
				wY = new Float32Array(SPRAY_MAX),
				wZ = new Float32Array(SPRAY_MAX);
			const wVX = new Float32Array(SPRAY_MAX),
				wVY = new Float32Array(SPRAY_MAX),
				wVZ = new Float32Array(SPRAY_MAX);
			const wAge = new Float32Array(SPRAY_MAX),
				wLife = new Float32Array(SPRAY_MAX);
			const wSize = new Float32Array(SPRAY_MAX);
			let sprayCursor = 0;
			function spawnSpray(x, y, z, vx, vy, vz, size, life) {
				const i = sprayCursor;
				sprayCursor = (sprayCursor + 1) % SPRAY_MAX;
				wX[i] = x;
				wY[i] = y;
				wZ[i] = z;
				wVX[i] = vx;
				wVY[i] = vy;
				wVZ[i] = vz;
				wAge[i] = 0;
				wLife[i] = life;
				wSize[i] = size;
				spray.aSeed[i] = rng.next();
				spray.aTint[i] = rng.next();
			}
			const spraySpots = [];
			{
				const path = L.BREAKWATER.path;
				for (let i = 1; i < path.length - 1; i++) {
					const a = path[i - 1];
					const p = path[i];
					const b = path[i + 1];
					const tx = b[0] - a[0];
					const tz = b[1] - a[1];
					const tl = Math.hypot(tx, tz) || 1;
					let nx = tz / tl;
					let nz = -tx / tl;
					if (nz < 0) {
						nx = -nx;
						nz = -nz;
					}
					const off = L.BREAKWATER.width * 0.5 + 0.22;
					spraySpots.push({ x: p[0] + nx * off, z: p[1] + nz * off, nx, nz, next: rng.range(0.3, 4.0) });
				}
				// beach cove wash
				for (const b of [
					[-11.3, 4.6],
					[-12.2, 3.9],
					[-10.2, 5.1],
					[-9.4, 4.7],
				]) {
					spraySpots.push({ x: b[0], z: b[1], nx: -0.5, nz: 0.85, next: rng.range(1.0, 5.0) });
				}
			}
			function updateSpray(dt, time) {
				for (let s = 0; s < spraySpots.length; s++) {
					const sp = spraySpots[s];
					sp.next -= dt;
					if (sp.next > 0) continue;
					sp.next = rng.range(2.4, 6.0);
					const burst = rng.int(2, 4);
					for (let k = 0; k < burst; k++) {
						const spread = rng.range(-0.22, 0.22);
						spawnSpray(
							sp.x + rng.range(-0.3, 0.3),
							0.12 + rng.range(0, 0.1),
							sp.z + rng.range(-0.3, 0.3),
							sp.nx * rng.range(0.35, 0.85) + spread,
							rng.range(0.35, 0.95),
							sp.nz * rng.range(0.35, 0.85) + spread,
							rng.range(0.05, 0.12),
							rng.range(1.0, 2.0)
						);
					}
				}
				for (let i = 0; i < SPRAY_MAX; i++) {
					if (wLife[i] <= 0) {
						if (spray.aAlpha[i] !== 0) spray.aAlpha[i] = 0;
						continue;
					}
					wAge[i] += dt;
					const k = wAge[i] / wLife[i];
					if (k >= 1) {
						wLife[i] = 0;
						spray.aAlpha[i] = 0;
						continue;
					}
					wVY[i] -= 1.35 * dt;
					wX[i] += wVX[i] * dt;
					wY[i] += wVY[i] * dt;
					wZ[i] += wVZ[i] * dt;
					if (wY[i] < 0.02) {
						wY[i] = 0.02;
						wVY[i] *= -0.22;
						wVX[i] *= 0.6;
						wVZ[i] *= 0.6;
					}
					spray.pos[i * 3] = wX[i];
					spray.pos[i * 3 + 1] = wY[i];
					spray.pos[i * 3 + 2] = wZ[i];
					spray.aSize[i] = wSize[i] * (1 + k * 0.7);
					spray.aAlpha[i] = (1 - k) * (1 - k) * 0.7;
				}
				spray.geo.attributes.position.needsUpdate = true;
				spray.geo.attributes.aSize.needsUpdate = true;
				spray.geo.attributes.aAlpha.needsUpdate = true;
				spray.geo.attributes.aTint.needsUpdate = true;
				spray.geo.attributes.aSeed.needsUpdate = true;
			}

			// ================================================================
			// DUST / POLLEN —sparse warm motes in the air
			// ================================================================
			const dust = makePointSystem({ max: 64, texture: T.spark, additive: true, colorA: '#ffd9a4', colorB: '#ffefd2', colorC: '#ffc27c', name: 'dust' });
			dust.points.renderOrder = 3;
			g.add(dust.points);
			const DUST_MAX = dust.max;
			const dX = new Float32Array(DUST_MAX),
				dY = new Float32Array(DUST_MAX),
				dZ = new Float32Array(DUST_MAX);
			const dPh = new Float32Array(DUST_MAX);
			const dSp = new Float32Array(DUST_MAX);
			for (let i = 0; i < DUST_MAX; i++) {
				dX[i] = rng.range(-13, 13);
				dY[i] = rng.range(0.4, 5.2);
				dZ[i] = rng.range(-11, 13);
				dPh[i] = rng.range(0, TAU);
				dSp[i] = rng.range(0.25, 0.7);
				dust.pos[i * 3] = dX[i];
				dust.pos[i * 3 + 1] = dY[i];
				dust.pos[i * 3 + 2] = dZ[i];
				dust.aSize[i] = rng.range(0.016, 0.04);
				dust.aTint[i] = rng.next();
				dust.aSeed[i] = rng.next();
			}
			function updateDust(dt, time) {
				for (let i = 0; i < DUST_MAX; i++) {
					const ph = dPh[i];
					dX[i] += (Math.sin(time * 0.1 + ph) * 0.04 + WIND.x * 0.012) * dt * 6.0;
					dY[i] += Math.sin(time * 0.16 + ph * 2.1) * 0.012 * dt * 6.0;
					dZ[i] += (Math.cos(time * 0.08 + ph * 1.4) * 0.035 + WIND.z * 0.012) * dt * 6.0;
					if (dX[i] > 14) dX[i] = -14;
					if (dX[i] < -14) dX[i] = 14;
					if (dZ[i] > 14) dZ[i] = -12;
					if (dZ[i] < -12) dZ[i] = 14;
					if (dY[i] > 6.0) dY[i] = 0.4;
					if (dY[i] < 0.3) dY[i] = 5.8;
					dust.pos[i * 3] = dX[i];
					dust.pos[i * 3 + 1] = dY[i];
					dust.pos[i * 3 + 2] = dZ[i];
					dust.aAlpha[i] = 0.3 + 0.5 * (0.5 + 0.5 * Math.sin(time * 0.6 + ph * 3.1));
				}
				dust.geo.attributes.position.needsUpdate = true;
				dust.geo.attributes.aAlpha.needsUpdate = true;
			}
			for (let i = 0; i < DUST_MAX; i++) dust.aAlpha[i] = 0.4;

			// warm up the particle systems so a frozen first frame is not empty
			{
				let wt = 0;
				for (let step = 0; step < 160; step++) {
					wt += 0.1;
					updateSmoke(0.1, wt);
					updateSpray(0.1, wt);
				}
				updateDust(0.1, 0);
			}

			let drift = 0;
			let lastHour = -999;

			function applyMood() {
				moodFromEnv(env.state);
				const sunDir = env.state.sunDir;
				const moonDir = env.state.moonDir;
				const k = env.state.colors;
				for (const layer of [clouds, farClouds]) {
					const u = layer.material.uniforms;
					u.uLit.value.copy(MOOD.cloudLit);
					u.uShade.value.copy(MOOD.cloudShade);
					u.uRim.value.copy(MOOD.cloudRim);
					u.uRimStrength.value = layer === clouds ? MOOD.rimStrength : MOOD.rimStrength * 0.7;
					u.uSunDir.value.copy(sunDir);
					u.uMoonDir.value.copy(moonDir);
					u.uNight.value = MOOD.night;
					u.uOpacity.value = MOOD.cloudOpacity * (layer === clouds ? 1.0 : 0.7);
					u.uFogColor.value.copy(k.fog);
					u.uFogDensity.value = env.state.fogD * 0.85;
				}
				mistUniforms.uColor.value.copy(MOOD.mist);
				mistUniforms.uOpacity.value = MOOD.mistOpacity;
				mistUniforms.uSunDir.value.copy(sunDir);
				mistUniforms.uSunColor.value.copy(MOOD.cloudRim);
				mistUniforms.uFogColor.value.copy(k.fog);
				mistUniforms.uFogDensity.value = env.state.fogD;
				// character / particles / lights
				smoke.mat.uniforms.uColorA.value.copy(MOOD.smokeCool);
				smoke.mat.uniforms.uColorB.value.copy(MOOD.smokeWarm);
				smoke.mat.uniforms.uNight.value = MOOD.night;
				spray.mat.uniforms.uColorA.value.copy(MOOD.spray);
				spray.mat.uniforms.uColorB.value.copy(k.horizon);
				dust.mat.uniforms.uColorA.value.copy(MOOD.dust);
				dust.mat.uniforms.uColorB.value.copy(MOOD.cloudLit);
				gullMat.color.copy(MOOD.gull);
				beamUniforms.uColor.value.copy(MOOD.beam);
				lampHaloMat.color.copy(MOOD.beam);
				lastHour = env.state.hour;
			}

			function update(dt, time) {
				// clouds drift slowly across the sky; the shader wraps the layer
				drift += dt * WIND.speed * 0.5;
				clouds.material.uniforms.uDrift.value = drift;
				farClouds.material.uniforms.uDrift.value = drift * 0.35;
				mist.material.uniforms.uDrift.value = drift * 1.6;
				mist.material.uniforms.uTime.value = time;
				// point sprite pixel scale (depends on viewport + camera fov)
				const drawH = ctx.renderer.domElement.height || 800;
				const scaleU = drawH / (2 * Math.tan((ctx.camera.fov * Math.PI) / 360));
				// gulls
				updateGulls(time);
				// smoke & steam
				updateSmoke(dt, time);
				// spray
				updateSpray(dt, time);
				// dust
				updateDust(dt, time);
				// flags
				for (let i = 0; i < flagMeshes.length; i++) flagMeshes[i].material.userData.uniforms.uTime.value = time;
				// lighthouse beam sweeping slowly (a heavy 13 s revolution)
				beamPivot.rotation.y = time * 0.48;
				beamPivot.rotation.z = Math.sin(time * 0.11) * 0.012;
				beamUniforms.uTime.value = time;
				beamUniforms.uOpacity.value = MOOD.beamI * 0.1375;
				const beamOn = MOOD.beamI > 0.02;
				beamPivot.visible = beamOn;
				coreUniforms.uTime.value = time;
				coreUniforms.uOpacity.value = MOOD.beamI * 0.15;
				const haloPulse = 0.55 + 0.45 * MOOD.beamI;
				lampHaloMat.opacity = 0.02 + MOOD.beamI * 0.5;
				lampHalo.scale.setScalar(0.42 + MOOD.beamI * 0.28);
				channelLights.mat.uniforms.uTime.value = time;
				channelLights.mat.uniforms.uOpacity.value = 0.35 + MOOD.night * 0.75;
				// particle uniforms
				smoke.mat.uniforms.uScale.value = scaleU;
				smoke.mat.uniforms.uTime.value = time;
				smoke.mat.uniforms.uOpacity.value = 1 - MOOD.night * 0.12;
				spray.mat.uniforms.uScale.value = scaleU;
				spray.mat.uniforms.uTime.value = time;
				spray.mat.uniforms.uNight.value = MOOD.night * 0.55;
				dust.mat.uniforms.uScale.value = scaleU;
				dust.mat.uniforms.uTime.value = time;
				dust.mat.uniforms.uOpacity.value = (0.45 + MOOD.warm * 0.55) * (1 - MOOD.night * 0.82);
				channelLights.mat.uniforms.uScale.value = scaleU;
				glints.mat.uniforms.uScale.value = scaleU;
				glints.mat.uniforms.uTime.value = time;
				glints.mat.uniforms.uOpacity.value = Math.pow(U.smoothstep(0.03, 0.45, MOOD.night), 0.9) * 0.57;
				if (glintCount) {
					for (let i = 0; i < glintCount; i++) {
						glints.aAlpha[i] = 0.3 + 0.6 * (0.5 + 0.5 * Math.sin(time * 0.55 + glints.aSeed[i] * 3.1));
					}
					glints.geo.attributes.aAlpha.needsUpdate = true;
				}
				beamUniforms.uColor.value.copy(MOOD.beam);
			}

			applyMood();
			return {
				update,
				onEnv() {
					applyMood();
				},
			};
		},
	});
})(window.HARBOR);
