/**
 * patch-core.mjs — one-off maintenance patches applied by the Lead.
 * (Kept in the repo so the changes are auditable; not part of the app.)
 */
import fs from 'node:fs';

function patch(file, fn) {
	const src = fs.readFileSync(file, 'utf8');
	const out = fn(src);
	if (out === src) console.warn('[patch] no change in ' + file);
	else fs.writeFileSync(file, out);
}

// ------------------------------------------------------------------
// 1. dark studio backdrop below the horizon (the diorama floats in a
//    dark museum room; the warm colours were making the whole frame sepia)
// ------------------------------------------------------------------
patch('src/core/env.js', (s) =>
	s
		.replace(/ground: '#070a0e'/g, "ground: '#0a0b0e'")
		.replace(/ground: '#080b10'/g, "ground: '#0a0b0e'")
		.replace(/ground: '#251d1c'/g, "ground: '#0d0e11'")
		.replace(/ground: '#5c4a3a'/g, "ground: '#171717'")
		.replace(/ground: '#6b6656'/g, "ground: '#1b1b19'")
		.replace(/ground: '#6e6a5c'/g, "ground: '#1c1c1a'")
		.replace(/ground: '#6d6454'/g, "ground: '#1b1a18'")
		.replace(/ground: '#6b5744'/g, "ground: '#181614'")
		.replace(/ground: '#5a4034'/g, "ground: '#141210'")
		.replace(/ground: '#33241f'/g, "ground: '#101010'")
		.replace(/ground: '#121018'/g, "ground: '#0c0c10'")
);

// ------------------------------------------------------------------
// 2. contrastier key light / less milky ambient at golden hour
// ------------------------------------------------------------------
patch('src/core/env.js', (s) =>
	s
		.replace(/sunI: 3\.2, hemiSky: '#c6ddf0', hemiGround: '#736c58', hemiI: 1\.1, fog: '#d6e4e8', fogD: 0\.0068/, "sunI: 3.5, hemiSky: '#c6ddf0', hemiGround: '#736c58', hemiI: 0.95, fog: '#d6e4e8', fogD: 0.0068")
		.replace(/sunI: 3\.5, hemiSky: '#cfe6f7', hemiGround: '#7b7460', hemiI: 1\.15, fog: '#dcebee', fogD: 0\.0058, night: 0\.0, exposure: 0\.99, envI: 1\.2/, "sunI: 3.9, hemiSky: '#cfe6f7', hemiGround: '#7b7460', hemiI: 1.0, fog: '#dcebee', fogD: 0.0058, night: 0.0, exposure: 0.97, envI: 1.1")
		.replace(/sunI: 3\.4, hemiSky: '#c9dced', hemiGround: '#7a6f56', hemiI: 1\.1, fog: '#e3e1d0', fogD: 0\.0062/, "sunI: 3.7, hemiSky: '#c9dced', hemiGround: '#7a6f56', hemiI: 0.92, fog: '#e3e1d0', fogD: 0.0062")
		.replace(/sunI: 3\.9, hemiSky: '#a7bfd4', hemiGround: '#7c6146', hemiI: 1\.0, fog: '#ecc9a4', fogD: 0\.0072, night: 0\.03, exposure: 1\.02, envI: 0\.95/, "sunI: 4.5, hemiSky: '#a7bfd4', hemiGround: '#7c6146', hemiI: 0.82, fog: '#ecc9a4', fogD: 0.0064, night: 0.03, exposure: 1.0, envI: 0.86")
		.replace(/sunI: 2\.5, hemiSky: '#8b9ac0', hemiGround: '#5c3e30', hemiI: 0\.8, fog: '#e5a07a', fogD: 0\.0086/, "sunI: 2.9, hemiSky: '#8b9ac0', hemiGround: '#5c3e30', hemiI: 0.68, fog: '#e5a07a', fogD: 0.0078")
);

// ------------------------------------------------------------------
// 3. a dark museum display floor + a warm rim light for silhouettes
// ------------------------------------------------------------------
patch('src/core/env.js', (s) => {
	if (s.includes('displayFloor')) return s;
	const anchor = '\t\tsunLight.target.position.set(0, 0, 0);\n\t\tscene.add(sunLight);\n\t\tscene.add(sunLight.target);\n';
	const insert = anchor + `
		// ---- museum display floor: a dark matte disc that floats the
		// diorama against the void and catches the long golden shadow ----
		const floorC = U.createCanvas(512);
		const fctx = floorC.getContext('2d');
		const fg = fctx.createRadialGradient(256, 256, 20, 256, 256, 256);
		fg.addColorStop(0, '#3a3b42');
		fg.addColorStop(0.28, '#2a2b31');
		fg.addColorStop(0.62, '#17181d');
		fg.addColorStop(1, '#08090c');
		fctx.fillStyle = fg;
		fctx.fillRect(0, 0, 512, 512);
		const floorTex = U.canvasTex(floorC, { srgb: true });
		floorTex.wrapS = floorTex.wrapT = THREE.ClampToEdgeWrapping;
		const floorMat = new THREE.MeshStandardMaterial({ map: floorTex, color: 0xffffff, roughness: 0.52, metalness: 0.28 });
		const displayFloor = new THREE.Mesh(new THREE.CircleGeometry(64, 96), floorMat);
		displayFloor.rotation.x = -Math.PI / 2;
		displayFloor.position.y = -2.66;
		displayFloor.receiveShadow = true;
		displayFloor.name = 'display-floor';
		scene.add(displayFloor);

		// subtle warm rim light from behind the diorama (studio backlight)
		const rimLight = new THREE.DirectionalLight(0xffb478, 0.42);
		rimLight.position.set(-24, 11, -30);
		rimLight.target.position.set(0, 1.5, 0);
		scene.add(rimLight);
		scene.add(rimLight.target);
		state.rimLight = rimLight;
`;
	return s.replace(anchor, insert);
});

// rim light responds to the clock
patch('src/core/env.js', (s) => {
	const anchor = '\t\themiLight.intensity = k.hemiI;\n';
	if (s.includes('state.rimLight')) {
		return s.replace(
			anchor,
			anchor +
				'\t\tif (state.rimLight) state.rimLight.intensity = 0.3 + 0.22 * (1 - k.night) - k.night * 0.12;\n\t\tif (state.rimLight) state.rimLight.color.copy(k.sun).lerp(new THREE.Color(0x9fb6de), 0.45);\n'
		);
	}
	return s;
});

// ------------------------------------------------------------------
// 4. slightly richer grade, a touch less tilt blur so detail reads
// ------------------------------------------------------------------
patch('src/core/render.js', (s) =>
	s
		.replace('uSaturation: { value: 1.1 }', 'uSaturation: { value: 1.16 }')
		.replace('uContrast: { value: 1.045 }', 'uContrast: { value: 1.06 }')
		.replace('uWarmth: { value: 0.05 }', 'uWarmth: { value: 0.07 }')
		.replace('tiltBlur: 2.3', 'tiltBlur: 1.95')
);

// ------------------------------------------------------------------
// 5. pull the default overview back so the whole diorama fits with margin
// ------------------------------------------------------------------
patch('src/core/layout.js', (s) => s.replace('pos: [14.6, 19.2, 33.4],', 'pos: [16.4, 21.4, 37.2],').replace('target: [0.4, 1.0, 0.6],', 'target: [0.3, 1.5, 0.5],'));

console.log('[patch] done');
