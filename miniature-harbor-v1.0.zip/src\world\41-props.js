/**
 * 41-props.js —QUAY CLUTTER, VEHICLES, TREES & VEGETATION.
 * ==================================================================
 * OWNER: vessels-props teammate.
 *
 * Everything here is procedural and colour-baked: each repeated prop is
 * one merged, vertex-coloured template rendered through a single shared
 * material as an InstancedMesh, so ~700 individual objects cost around
 * 30 draw calls. Unique clusters (fish market, beach gear) are merged
 * into single meshes.
 *
 * Placement rules:
 *  - quay clutter sits on the flat LEVEL.quay terrace, validated against
 *    roads, pier roots, landmark anchors and the sea;
 *  - vegetation is clustered (never uniform random): wooded north hills,
 *    NE cliffs, west ridge, plus ornamental street trees in town;
 *  - beach gear follows ctx.groundHeight on the sandy cove.
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const L = H.layout;
	const P = U.PALETTE;

	// ==================================================================
	// helpers
	// ==================================================================
	function hash3(x, y, z) {
		const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
		return s - Math.floor(s);
	}

	function tintGeo(geo, color, jitter) {
		if (geo.index) geo = geo.toNonIndexed();
		if (geo.attributes.uv) geo.deleteAttribute('uv');
		if (geo.attributes.uv1) geo.deleteAttribute('uv1');
		const posAttr = geo.attributes.position;
		const n = posAttr.count;
		const arr = new Float32Array(n * 3);
		const c = color.isColor ? color : new THREE.Color(color);
		const px = posAttr.array;
		for (let i = 0; i < n; i++) {
			let k = 1;
			if (jitter) k = 1 + (hash3(px[i * 3] * 3.1, px[i * 3 + 1] * 3.3, px[i * 3 + 2] * 3.7) - 0.5) * jitter;
			arr[i * 3] = c.r * k;
			arr[i * 3 + 1] = c.g * k;
			arr[i * 3 + 2] = c.b * k;
		}
		geo.setAttribute('color', new THREE.BufferAttribute(arr, 3));
		return geo;
	}

	function mergedMesh(geos, mat, name, cast, receive) {
		if (!geos || !geos.length) return null;
		let geo = geos.length === 1 ? geos[0] : U.merge(geos);
		if (!geo) {
			console.warn('[props] geometry merge failed: ' + name);
			return null;
		}
		const mesh = new THREE.Mesh(geo, mat);
		mesh.name = name;
		mesh.castShadow = !!cast;
		mesh.receiveShadow = !!receive;
		return mesh;
	}

	/** instanced mesh with optional per-instance tint.
	 *  item = [x, y, z, rotY, sx, sy, sz, tintHex] */
	function instanced(geo, mat, list, opts) {
		opts = opts || {};
		if (!list.length) return null;
		const m = new THREE.InstancedMesh(geo, mat, list.length);
		const dummy = new THREE.Object3D();
		const color = new THREE.Color();
		let hasColor = false;
		for (let i = 0; i < list.length; i++) {
			const t = list[i];
			dummy.position.set(t[0], t[1], t[2]);
			dummy.rotation.set(0, t[3] || 0, 0);
			const sx = t[4] != null ? t[4] : 1;
			const sy = t[5] != null ? t[5] : sx;
			const sz = t[6] != null ? t[6] : sx;
			dummy.scale.set(sx, sy, sz);
			dummy.updateMatrix();
			m.setMatrixAt(i, dummy.matrix);
			if (t[7] != null) {
				color.set(t[7]);
				m.setColorAt(i, color);
				hasColor = true;
			}
		}
		m.instanceMatrix.needsUpdate = true;
		if (hasColor && m.instanceColor) m.instanceColor.needsUpdate = true;
		m.castShadow = opts.cast !== false;
		m.receiveShadow = opts.receive !== false;
		if (opts.name) m.name = opts.name;
		return m;
	}

	// ==================================================================
	// Paint —colour-baked primitives merged into one geometry
	// ==================================================================
	function Paint() {
		this.geos = [];
	}
	Paint.prototype.raw = function (geo, color, jitter) {
		this.geos.push(tintGeo(geo, color, jitter));
		return this;
	};
	Paint.prototype.box = function (w, h, d, x, y, z, color, rot, jitter) {
		const g = new THREE.BoxGeometry(w, h, d);
		if (rot) {
			if (rot[0]) g.rotateX(rot[0]);
			if (rot[1]) g.rotateY(rot[1]);
			if (rot[2]) g.rotateZ(rot[2]);
		}
		g.translate(x, y, z);
		return this.raw(g, color, jitter);
	};
	Paint.prototype.cyl = function (rt, rb, h, seg, x, y, z, color, rot, jitter) {
		const g = new THREE.CylinderGeometry(rt, rb, h, seg, 1, false);
		if (rot) {
			if (rot[0]) g.rotateX(rot[0]);
			if (rot[1]) g.rotateY(rot[1]);
			if (rot[2]) g.rotateZ(rot[2]);
		}
		g.translate(x, y, z);
		return this.raw(g, color, jitter);
	};
	Paint.prototype.sphere = function (r, x, y, z, color, scale, jitter) {
		const g = new THREE.SphereGeometry(r, 7, 5);
		if (scale) g.scale(scale[0], scale[1], scale[2]);
		g.translate(x, y, z);
		return this.raw(g, color, jitter);
	};
	Paint.prototype.torus = function (r, tube, x, y, z, color, rot, arc) {
		const g = new THREE.TorusGeometry(r, tube, 5, 12, arc != null ? arc : Math.PI * 2);
		if (rot) {
			if (rot[0]) g.rotateX(rot[0]);
			if (rot[1]) g.rotateY(rot[1]);
			if (rot[2]) g.rotateZ(rot[2]);
		}
		g.translate(x, y, z);
		return this.raw(g, color);
	};
	Paint.prototype.ico = function (r, detail, x, y, z, color, scale) {
		const g = new THREE.IcosahedronGeometry(r, detail || 0);
		if (scale) g.scale(scale[0], scale[1], scale[2]);
		g.translate(x, y, z);
		return this.raw(g, color, 0.16);
	};
	Paint.prototype.dodeca = function (r, x, y, z, color, scale) {
		const g = new THREE.DodecahedronGeometry(r, 0);
		if (scale) g.scale(scale[0], scale[1], scale[2]);
		g.translate(x, y, z);
		return this.raw(g, color, 0.2);
	};
	Paint.prototype.merge = function () {
		if (!this.geos.length) return null;
		return this.geos.length === 1 ? this.geos[0] : U.merge(this.geos);
	};

	// ==================================================================
	// prop templates (unit is world unit; each sits on y = 0)
	// ==================================================================
	const WOOD = '#a8815a';
	const WOOD_DARK = '#7c5a3c';
	const RUST = '#8a5238';

	function crateTemplate() {
		const p = new Paint();
		p.box(0.086, 0.08, 0.086, 0, 0.04, 0, '#b08a5c', null, 0.14);
		// frame corner posts + top/bottom rails
		for (const sx of [-1, 1]) {
			for (const sz of [-1, 1]) p.box(0.012, 0.088, 0.012, sx * 0.041, 0.044, sz * 0.041, WOOD_DARK, null, 0.1);
		}
		for (const sy of [0.008, 0.074]) {
			p.box(0.094, 0.012, 0.012, 0, sy, 0.043, WOOD_DARK, null, 0.1);
			p.box(0.094, 0.012, 0.012, 0, sy, -0.043, WOOD_DARK, null, 0.1);
			p.box(0.012, 0.012, 0.094, 0.043, sy, 0, WOOD_DARK, null, 0.1);
			p.box(0.012, 0.012, 0.094, -0.043, sy, 0, WOOD_DARK, null, 0.1);
		}
		// diagonal batten on the visible faces
		p.box(0.09, 0.012, 0.008, 0, 0.042, 0.045, '#8a6746', [0, 0, 0.6], 0.1);
		p.box(0.09, 0.012, 0.008, 0, 0.042, -0.045, '#8a6746', [0, 0, -0.6], 0.1);
		return p.merge();
	}

	function palletTemplate() {
		const p = new Paint();
		for (let i = 0; i < 5; i++) p.box(0.1, 0.008, 0.014, 0, 0.014, -0.036 + i * 0.018, '#a8815a');
		for (const z of [-0.036, 0, 0.036]) p.box(0.1, 0.012, 0.012, 0, 0.005, z, '#8a6746');
		return p.merge();
	}

	function barrelTemplate() {
		const p = new Paint();
		p.cyl(0.031, 0.033, 0.082, 10, 0, 0.041, 0, '#4e6b7a', null, 0.16);
		p.cyl(0.034, 0.034, 0.008, 10, 0, 0.02, 0, '#3a3f44');
		p.cyl(0.034, 0.034, 0.008, 10, 0, 0.036, 0, '#3a3f44');
		p.cyl(0.034, 0.034, 0.008, 10, 0, 0.064, 0, '#3a3f44');
		p.cyl(0.03, 0.03, 0.006, 10, 0, 0.084, 0, '#5b6f7a');
		return p.merge();
	}

	function fishBoxTemplate(open) {
		const p = new Paint();
		p.box(0.078, 0.048, 0.052, 0, 0.024, 0, '#e8e6de');
		p.box(0.082, 0.008, 0.056, 0, 0.05, 0, '#3d5f86');
		if (open) {
			p.box(0.066, 0.004, 0.04, 0, 0.052, 0, '#d9d5c8');
			for (let i = 0; i < 5; i++) {
				p.box(0.022, 0.008, 0.012, -0.026 + i * 0.013, 0.058, (i % 2 ? 0.008 : -0.008), '#9dbcc6', [0, 0.3, 0]);
			}
		}
		return p.merge();
	}

	function ropeCoilTemplate() {
		const p = new Paint();
		p.torus(0.042, 0.011, 0, 0.011, 0, '#b9a882', [Math.PI / 2, 0, 0]);
		p.torus(0.026, 0.01, 0, 0.024, 0, '#a89a74', [Math.PI / 2, 0, 0]);
		p.box(0.05, 0.012, 0.02, 0.01, 0.008, 0.035, '#a89a74', [0, 0.4, 0]);
		return p.merge();
	}

	function anchorTemplate() {
		const p = new Paint();
		p.box(0.012, 0.1, 0.012, 0, 0.05, 0, '#3a3f44');
		p.box(0.075, 0.01, 0.01, 0, 0.088, 0, '#3a3f44');
		p.box(0.03, 0.012, 0.045, -0.026, 0.014, 0.016, '#3a3f44', [0, 0.5, 0.35]);
		p.box(0.03, 0.012, 0.045, 0.026, 0.014, 0.016, '#3a3f44', [0, -0.5, -0.35]);
		p.torus(0.016, 0.005, 0, 0.11, 0, '#4a4f54', [0, 0, 0]);
		return p.merge();
	}

	function tireTemplate() {
		const p = new Paint();
		p.torus(0.03, 0.012, 0, 0.03, 0, '#26282a', [0, 0, 0]);
		p.cyl(0.014, 0.014, 0.018, 8, 0, 0.03, 0, '#3a3f44', [Math.PI / 2, 0, 0]);
		return p.merge();
	}

	function lifeRingTemplate() {
		const p = new Paint();
		p.torus(0.028, 0.008, 0, 0.03, 0, '#efe2c9');
		for (let i = 0; i < 4; i++) {
			const a = (i / 4) * Math.PI * 2;
			p.box(0.014, 0.011, 0.006, Math.cos(a) * 0.028, 0.03 + Math.sin(a) * 0.028, 0.001, '#b3453b', [0, 0, a]);
		}
		return p.merge();
	}

	function bucketTemplate() {
		const p = new Paint();
		p.cyl(0.02, 0.016, 0.034, 8, 0, 0.017, 0, '#6d767d');
		p.torus(0.019, 0.003, 0, 0.036, 0, '#9dbcc6', [0, 0, 0], Math.PI);
		return p.merge();
	}

	function netPileTemplate() {
		const p = new Paint();
		p.ico(0.055, 0, 0, 0.035, 0, '#4a5548', [1.4, 0.55, 1.0]);
		p.ico(0.045, 0, 0.05, 0.03, 0.02, '#414a40', [1.2, 0.5, 0.95]);
		p.ico(0.035, 0, -0.04, 0.025, 0.02, '#4f5a4c', [1.1, 0.5, 0.9]);
		for (let i = 0; i < 4; i++) p.sphere(0.012, -0.06 + i * 0.04, 0.014, -0.03 + (i % 2) * 0.05, i === 1 ? '#d9a13b' : '#b3453b');
		p.torus(0.03, 0.006, 0.02, 0.05, 0.02, '#b9a882', [0.4, 0, 0.3]);
		return p.merge();
	}

	function floatsTemplate() {
		const p = new Paint();
		p.sphere(0.022, -0.03, 0.02, 0, '#d9a13b', [1, 1, 1]);
		p.sphere(0.02, 0.02, 0.018, 0.02, '#cf6b2f', [1, 1, 1]);
		p.sphere(0.018, 0.02, 0.016, -0.03, '#d9a13b', [1, 1, 1]);
		p.cyl(0.004, 0.004, 0.06, 4, 0, 0.03, 0.02, '#b9a882');
		return p.merge();
	}

	function rockTemplate(seed, r) {
		const p = new Paint();
		p.dodeca(r, 0, r * 0.55, 0, '#6e6258', [1.2, 0.75, 1]);
		p.dodeca(r * 0.55, r * 0.7, r * 0.3, r * 0.2, '#5c5248', [1, 0.7, 1]);
		p.dodeca(r * 0.4, -r * 0.6, r * 0.22, -r * 0.15, '#7d7166', [1, 0.65, 1]);
		return p.merge();
	}

	function shrubTemplate() {
		const p = new Paint();
		p.ico(0.09, 0, 0, 0.075, 0, '#4f6b3e', [1.2, 0.8, 1.1]);
		p.ico(0.07, 0, 0.07, 0.06, 0.03, '#5c7443', [1, 0.8, 1]);
		p.ico(0.055, 0, -0.06, 0.05, -0.02, '#7d8f57', [1.1, 0.8, 1]);
		p.cyl(0.01, 0.014, 0.06, 5, 0, 0.03, 0, '#5b4028');
		return p.merge();
	}

	function weedTemplate() {
		const p = new Paint();
		for (let i = 0; i < 6; i++) {
			const a = (i / 6) * Math.PI * 2 + 0.3;
			const h = 0.06 + (i % 3) * 0.02;
			p.box(0.006, h, 0.002, Math.cos(a) * 0.014, h / 2, Math.sin(a) * 0.014, i % 2 ? '#7d8f57' : '#5c6c42', [0.25 * Math.sin(a), a, 0.25 * Math.cos(a)]);
		}
		return p.merge();
	}

	function flowerTemplate() {
		const p = new Paint();
		p.ico(0.03, 0, 0, 0.022, 0, '#4f6b3e', [1.2, 0.7, 1.2]);
		const cols = ['#d96a56', '#e0a24b', '#e8d06b', '#d67ba1'];
		for (let i = 0; i < 7; i++) {
			const a = (i / 7) * Math.PI * 2;
			p.sphere(0.011, Math.cos(a) * 0.026, 0.04 + (i % 2) * 0.012, Math.sin(a) * 0.026, cols[i % 4]);
		}
		p.sphere(0.009, 0, 0.05, 0, '#efe2c9');
		return p.merge();
	}

	function benchTemplate() {
		const p = new Paint();
		for (let i = 0; i < 3; i++) p.box(0.2, 0.008, 0.022, 0, 0.038, -0.024 + i * 0.024, '#8a5b34');
		p.box(0.2, 0.018, 0.006, 0, 0.062, -0.032, '#8a5b34', [0.2, 0, 0]);
		p.box(0.2, 0.018, 0.006, 0, 0.062, 0.032, '#8a5b34', [-0.2, 0, 0]);
		for (const sx of [-1, 1]) {
			p.box(0.01, 0.04, 0.05, sx * 0.088, 0.02, 0, '#3a3f44');
			p.box(0.008, 0.045, 0.008, sx * 0.088, 0.06, -0.03, '#3a3f44');
		}
		return p.merge();
	}

	function planterTemplate() {
		const p = new Paint();
		p.box(0.11, 0.055, 0.07, 0, 0.028, 0, '#b5654a');
		p.box(0.1, 0.01, 0.06, 0, 0.055, 0, '#4a3a28');
		p.box(0.12, 0.01, 0.08, 0, 0.058, 0, '#a9503d');
		for (let i = 0; i < 4; i++) p.ico(0.02, 0, -0.038 + i * 0.025, 0.075, (i % 2 ? 0.012 : -0.012), '#5c7443', [1.1, 0.9, 1.1]);
		const cols = ['#d96a56', '#e0a24b', '#d67ba1', '#e8d06b'];
		for (let i = 0; i < 4; i++) p.sphere(0.009, -0.03 + i * 0.02, 0.085, 0.01, cols[i]);
		return p.merge();
	}

	function bicycleTemplate() {
		const p = new Paint();
		p.torus(0.028, 0.004, 0, 0.028, -0.055, '#2b2b2c', [0, Math.PI / 2, 0]);
		p.torus(0.028, 0.004, 0, 0.028, 0.055, '#2b2b2c', [0, Math.PI / 2, 0]);
		p.box(0.005, 0.006, 0.11, 0, 0.045, 0, '#3f6688', [0.2, 0, 0]);
		p.box(0.005, 0.045, 0.006, 0, 0.05, -0.04, '#3f6688', [0, 0, 0.35]);
		p.box(0.005, 0.045, 0.006, 0, 0.05, 0.04, '#3f6688', [0, 0, -0.3]);
		p.box(0.03, 0.005, 0.005, 0, 0.068, 0.05, '#2b2b2c');
		p.box(0.012, 0.006, 0.025, 0, 0.062, -0.03, '#4e3726');
		return p.merge();
	}

	/** dock cat (very small, ~0.07 long) */
	function catTemplate() {
		const p = new Paint();
		p.sphere(0.024, 0, 0.02, 0, '#b07a44', [1.25, 0.8, 0.95]);
		p.sphere(0.016, 0, 0.042, 0.022, '#b07a44', [1, 0.9, 1]);
		p.cyl(0.002, 0.008, 0.012, 4, -0.008, 0.057, 0.022, '#8a5b34', [0, 0, -0.22]);
		p.cyl(0.002, 0.008, 0.012, 4, 0.008, 0.057, 0.022, '#8a5b34', [0, 0, 0.22]);
		p.cyl(0.0035, 0.0035, 0.05, 4, 0.012, 0.045, -0.03, '#8a5b34', [0.55, 0, 0.35]);
		for (const sx of [-1, 1]) p.cyl(0.005, 0.006, 0.026, 5, sx * 0.011, 0.013, 0.018, '#a06e3c');
		return p.merge();
	}

	/** net-drying rack with hanging nets and floats */
	function netRackTemplate() {
		const p = new Paint();
		p.cyl(0.009, 0.012, 0.22, 4, -0.12, 0.11, 0, '#6b4f36');
		p.cyl(0.009, 0.012, 0.22, 4, 0.12, 0.11, 0, '#6b4f36');
		p.box(0.26, 0.012, 0.012, 0, 0.22, 0, '#6b4f36');
		p.box(0.21, 0.13, 0.008, 0, 0.145, 0.004, '#4a5548');
		p.box(0.17, 0.09, 0.006, 0.01, 0.11, -0.008, '#414a40');
		for (let i = 0; i < 3; i++) p.sphere(0.011, -0.06 + i * 0.06, 0.082, 0.012, i === 1 ? '#b3453b' : '#d9a13b');
		p.cyl(0.004, 0.004, 0.2, 4, 0.145, 0.1, 0.02, '#c8a24b', [0, 0, 0.18]);
		return p.merge();
	}

	function handcartTemplate() {
		const p = new Paint();
		p.box(0.12, 0.012, 0.07, 0, 0.028, 0, '#8a6746');
		p.box(0.12, 0.02, 0.008, 0, 0.04, -0.035, '#8a6746');
		p.torus(0.022, 0.006, 0, 0.022, 0.03, '#2b2b2c', [0, Math.PI / 2, 0]);
		p.box(0.008, 0.05, 0.008, 0, 0.045, -0.05, '#6d767d', [0.5, 0, 0]);
		p.box(0.05, 0.008, 0.008, 0, 0.066, -0.062, '#6d767d');
		return p.merge();
	}

	function forkliftTemplate() {
		const p = new Paint();
		p.box(0.09, 0.05, 0.12, 0, 0.048, -0.01, '#d9a13b');
		p.box(0.07, 0.035, 0.05, 0, 0.09, 0.03, '#e0a92f');
		p.box(0.05, 0.03, 0.04, 0, 0.1, -0.04, '#3a3f44');
		p.box(0.012, 0.12, 0.012, 0.035, 0.1, 0.06, '#3a3f44');
		p.box(0.012, 0.12, 0.012, -0.035, 0.1, 0.06, '#3a3f44');
		p.box(0.008, 0.008, 0.1, 0.028, 0.046, 0.12, '#3a3f44');
		p.box(0.008, 0.008, 0.1, -0.028, 0.046, 0.12, '#3a3f44');
		p.box(0.02, 0.004, 0.07, 0, 0.05, 0.115, '#6d767d');
		for (const sx of [-1, 1]) {
			p.cyl(0.02, 0.02, 0.015, 8, sx * 0.045, 0.02, 0.035, '#26282a', [0, 0, Math.PI / 2]);
			p.cyl(0.016, 0.016, 0.015, 8, sx * 0.045, 0.016, -0.05, '#26282a', [0, 0, Math.PI / 2]);
		}
		return p.merge();
	}

	// vehicle body templates are painted white so instance colours tint them
	function sedanBody() {
		const p = new Paint();
		p.box(0.12, 0.036, 0.27, 0, 0.042, 0, '#ffffff');
		p.box(0.1, 0.038, 0.13, 0, 0.078, -0.01, '#ffffff');
		p.box(0.11, 0.02, 0.07, 0, 0.062, 0.09, '#ffffff', [0.1, 0, 0]);
		p.box(0.11, 0.02, 0.07, 0, 0.062, -0.095, '#ffffff', [-0.1, 0, 0]);
		p.box(0.122, 0.008, 0.272, 0, 0.024, 0, '#e8e2d2');
		return p.merge();
	}
	function sedanDark() {
		const p = new Paint();
		for (const sx of [-1, 1]) {
			for (const sz of [-1, 1]) {
				p.cyl(0.021, 0.021, 0.014, 9, sx * 0.055, 0.021, sz * 0.082, '#26282a', [0, 0, Math.PI / 2]);
			}
		}
		// windows
		p.box(0.086, 0.024, 0.006, 0, 0.078, 0.055, '#2a3a42', [0.35, 0, 0]);
		p.box(0.086, 0.024, 0.006, 0, 0.078, -0.075, '#2a3a42', [-0.35, 0, 0]);
		p.box(0.006, 0.022, 0.11, 0.051, 0.078, -0.01, '#2a3a42');
		p.box(0.006, 0.022, 0.11, -0.051, 0.078, -0.01, '#2a3a42');
		// bumpers + lights
		p.box(0.11, 0.012, 0.008, 0, 0.032, 0.136, '#3a3f44');
		p.box(0.11, 0.012, 0.008, 0, 0.032, -0.136, '#3a3f44');
		p.box(0.024, 0.008, 0.006, 0.038, 0.052, 0.137, '#efe2c9');
		p.box(0.024, 0.008, 0.006, -0.038, 0.052, 0.137, '#efe2c9');
		return p.merge();
	}
	function vanBody() {
		const p = new Paint();
		p.box(0.13, 0.085, 0.3, 0, 0.062, 0, '#ffffff');
		p.box(0.125, 0.03, 0.29, 0, 0.115, 0, '#f4efe3');
		p.box(0.128, 0.012, 0.302, 0, 0.104, 0, '#e8e2d2');
		p.box(0.132, 0.008, 0.15, 0, 0.03, 0.03, '#e8e2d2');
		return p.merge();
	}
	function vanDark() {
		const p = new Paint();
		for (const sx of [-1, 1]) {
			for (const sz of [-1, 1]) p.cyl(0.023, 0.023, 0.015, 9, sx * 0.058, 0.023, sz * 0.095, '#26282a', [0, 0, Math.PI / 2]);
		}
		p.box(0.09, 0.03, 0.006, 0, 0.098, 0.147, '#2a3a42', [0.2, 0, 0]);
		p.box(0.006, 0.03, 0.06, 0.064, 0.098, 0.06, '#2a3a42');
		p.box(0.006, 0.03, 0.06, -0.064, 0.098, 0.06, '#2a3a42');
		p.box(0.12, 0.014, 0.008, 0, 0.034, 0.15, '#3a3f44');
		p.box(0.12, 0.014, 0.008, 0, 0.034, -0.15, '#3a3f44');
		return p.merge();
	}
	function truckBody() {
		const p = new Paint();
		p.box(0.13, 0.06, 0.11, 0, 0.06, 0.12, '#ffffff');
		p.box(0.12, 0.035, 0.1, 0, 0.11, 0.12, '#ffffff');
		p.box(0.13, 0.012, 0.2, 0, 0.075, -0.06, '#a8815a');
		p.box(0.128, 0.03, 0.012, 0, 0.02, -0.155, '#8a6746');
		p.box(0.008, 0.035, 0.19, 0.062, 0.042, -0.06, '#c8a24b');
		p.box(0.008, 0.035, 0.19, -0.062, 0.042, -0.06, '#c8a24b');
		p.box(0.008, 0.035, 0.012, 0.062, 0.042, 0.04, '#c8a24b');
		return p.merge();
	}
	function truckDark() {
		const p = new Paint();
		for (const sx of [-1, 1]) {
			p.cyl(0.025, 0.025, 0.016, 9, sx * 0.058, 0.025, 0.1, '#26282a', [0, 0, Math.PI / 2]);
			p.cyl(0.025, 0.025, 0.016, 9, sx * 0.058, 0.025, -0.1, '#26282a', [0, 0, Math.PI / 2]);
		}
		p.box(0.1, 0.032, 0.006, 0, 0.115, 0.172, '#2a3a42', [0.15, 0, 0]);
		p.box(0.03, 0.012, 0.008, 0.045, 0.045, 0.178, '#efe2c9');
		p.box(0.03, 0.012, 0.008, -0.045, 0.045, 0.178, '#efe2c9');
		p.box(0.11, 0.014, 0.008, 0, 0.03, 0.178, '#3a3f44');
		return p.merge();
	}

	// ==================================================================
	// trees —baked colour, instanced per species
	// ==================================================================
	/** tall narrow cypress: visible trunk + five slightly offset cone layers */
	function cypressTemplate() {
		const p = new Paint();
		p.cyl(0.016, 0.026, 0.24, 5, 0, 0.12, 0, '#4e3726', [0.02, 0, 0.01]);
		const layers = [
			[0.17, 0.4, 0.3, '#3f5c3a'],
			[0.15, 0.36, 0.46, '#48663d'],
			[0.12, 0.3, 0.62, '#537247'],
			[0.085, 0.24, 0.77, '#5f7c4c'],
			[0.05, 0.17, 0.9, '#6a8756'],
		];
		for (let i = 0; i < layers.length; i++) {
			const L = layers[i];
			p.cyl(0.001, L[0], L[1], 6, Math.sin(i * 2.1) * 0.008, L[2], Math.cos(i * 1.7) * 0.008, L[3]);
		}
		return p.merge();
	}
	/** stone / umbrella pine: tall bare trunk, flat layered canopy plates */
	function pineTemplate() {
		const p = new Paint();
		p.cyl(0.018, 0.036, 0.62, 6, 0, 0.31, 0, '#6b4f36', [0.03, 0, 0.05]);
		p.cyl(0.008, 0.013, 0.17, 4, 0.06, 0.54, 0.02, '#5b4028', [0, 0, -0.5]);
		p.cyl(0.007, 0.011, 0.15, 4, -0.05, 0.61, -0.03, '#5b4028', [0, 0, 0.55]);
		p.ico(0.24, 0, 0.02, 0.71, 0, '#4f6b3e', [1.5, 0.3, 1.4]);
		p.ico(0.18, 0, -0.15, 0.65, 0.09, '#557246', [1.25, 0.28, 1.2]);
		p.ico(0.16, 0, 0.17, 0.77, -0.06, '#61804a', [1.35, 0.32, 1.25]);
		p.ico(0.12, 0, 0.02, 0.85, 0.02, '#6d8a52', [1.2, 0.34, 1.1]);
		return p.merge();
	}
	/** broadleaf: trunk + branch forks + layered rounded crown */
	function roundTreeTemplate() {
		const p = new Paint();
		p.cyl(0.022, 0.038, 0.38, 6, 0, 0.19, 0, '#5b4028', [0.02, 0, -0.04]);
		p.cyl(0.01, 0.015, 0.17, 4, 0.055, 0.43, 0.03, '#5b4028', [0, 0, -0.5]);
		p.cyl(0.008, 0.012, 0.15, 4, -0.05, 0.42, -0.02, '#5b4028', [0, 0, 0.5]);
		const blobs = [
			[0.19, 0.0, 0.58, 0.0, '#557246', 1.05, 0.9, 1.0],
			[0.15, 0.15, 0.5, 0.1, '#4f6b3e', 1.0, 0.9, 1.0],
			[0.145, -0.16, 0.53, -0.06, '#61804a', 1.0, 0.85, 1.0],
			[0.13, 0.05, 0.68, 0.05, '#6d8a52', 1.0, 0.85, 1.0],
			[0.115, -0.06, 0.73, -0.1, '#7d8f57', 1.0, 0.8, 1.0],
			[0.105, 0.13, 0.74, -0.04, '#5c7443', 1.0, 0.8, 1.0],
			[0.085, 0.0, 0.82, 0.02, '#8a9b6b', 1.0, 0.8, 1.0],
		];
		for (const b of blobs) p.ico(b[0], 0, b[1], b[2], b[3], b[4], [b[5], b[6], b[7]]);
		return p.merge();
	}
	/** olive: short gnarled trunk, wide silver-green crown */
	function oliveTemplate() {
		const p = new Paint();
		p.cyl(0.026, 0.046, 0.3, 5, 0, 0.15, 0, '#6b5a44', [0.15, 0, 0.12]);
		p.cyl(0.012, 0.02, 0.2, 4, 0.08, 0.32, 0.03, '#6b5a44', [0.1, 0, -0.4]);
		p.cyl(0.01, 0.016, 0.16, 4, -0.07, 0.34, -0.02, '#6b5a44', [0, 0, 0.5]);
		p.ico(0.22, 0, 0.04, 0.5, 0.02, '#8a9b6b', [1.4, 0.45, 1.25]);
		p.ico(0.15, 0, -0.16, 0.46, 0.07, '#7d8f57', [1.2, 0.42, 1.1]);
		p.ico(0.12, 0, 0.2, 0.54, -0.08, '#94a574', [1.1, 0.4, 1.0]);
		p.ico(0.09, 0, 0.02, 0.6, 0.1, '#a3b184', [1.0, 0.4, 1.0]);
		return p.merge();
	}

	// ==================================================================
	// module
	// ==================================================================
	H.register('props', {
		create(ctx) {
			const g = ctx.group('props');
			const M = ctx.materials;
			const r = U.rng(6612);

			const MAT = {
				prop: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.72, metalness: 0.05 }),
				veg: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, metalness: 0.0 }),
				vehicle: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.34, metalness: 0.42 }),
				lamp: new THREE.MeshStandardMaterial({
					color: new THREE.Color('#160f08'),
					emissive: new THREE.Color('#ffcf8a'),
					emissiveIntensity: 0.15,
					roughness: 0.6,
					metalness: 0.0,
				}),
			};

			const T = {
				crate: crateTemplate(),
				pallet: palletTemplate(),
				barrel: barrelTemplate(),
				fishCrate: fishBoxTemplate(true),
				ropeCoil: ropeCoilTemplate(),
				anchor: anchorTemplate(),
				tire: tireTemplate(),
				lifeRing: lifeRingTemplate(),
				bucket: bucketTemplate(),
				netPile: netPileTemplate(),
				floats: floatsTemplate(),
				rockA: rockTemplate(1, 0.15),
				shrub: shrubTemplate(),
				weed: weedTemplate(),
				flower: flowerTemplate(),
				bench: benchTemplate(),
				planter: planterTemplate(),
				bicycle: bicycleTemplate(),
				handcart: handcartTemplate(),
				cat: catTemplate(),
				netRack: netRackTemplate(),
				forklift: forkliftTemplate(),
				sedanBody: sedanBody(),
				sedanDark: sedanDark(),
				vanBody: vanBody(),
				vanDark: vanDark(),
				truckBody: truckBody(),
				truckDark: truckDark(),
				cypress: cypressTemplate(),
				pine: pineTemplate(),
				roundTree: roundTreeTemplate(),
				olive: oliveTemplate(),
			};

			// ---- instance lists ------------------------------------
			const lists = {};
			function L_(name) {
				if (!lists[name]) lists[name] = [];
				return lists[name];
			}
			function put(name, x, y, z, ry, s, sy, sz, tint) {
				L_(name).push([x, y, z, ry || 0, s != null ? s : 1, sy != null ? sy : s != null ? s : 1, sz != null ? sz : s != null ? s : 1, tint || null]);
			}

			// ---- placement validation ------------------------------
			const CLEAR = [];
			function clearZone(name, radius) {
				const a = L.ANCHORS[name];
				if (a) CLEAR.push([a.pos[0], a.pos[1], radius]);
			}
			clearZone('church', 0.85);
			clearZone('plaza', 1.7);
			clearZone('marketHall', 0.95);
			clearZone('customsHouse', 0.95);
			clearZone('fishMarket', 0.5);
			clearZone('warehouseA', 1.6);
			clearZone('warehouseB', 1.3);
			clearZone('containerYard', 1.45);
			clearZone('gantryCrane', 1.0);
			clearZone('fuelTank', 0.75);
			clearZone('railYard', 1.1);
			clearZone('beachCove', 0.55);
			clearZone('cottageHill', 0.75);
			clearZone('watchtower', 0.75);
			clearZone('windmill', 0.85);
			clearZone('seaStack', 1.3);
			clearZone('lighthouseRock', 1.1);
			clearZone('fortTower', 0.9);

			const LOTS = L.townLots.map((l) => [l.pos[0], l.pos[1], 0.5 * Math.hypot(l.width, l.depth) + 0.2]);
			function nearClear(x, z) {
				for (let i = 0; i < CLEAR.length; i++) {
					const c = CLEAR[i];
					if ((x - c[0]) * (x - c[0]) + (z - c[1]) * (z - c[1]) < c[2] * c[2]) return true;
				}
				return false;
			}
			function nearLot(x, z, extra) {
				for (let i = 0; i < LOTS.length; i++) {
					const c = LOTS[i];
					const rad = c[2] + (extra || 0);
					if ((x - c[0]) * (x - c[0]) + (z - c[1]) * (z - c[1]) < rad * rad) return true;
				}
				return false;
			}
			function nearRoad(x, z, margin) {
				for (let i = 0; i < L.ROADS.length; i++) {
					const road = L.ROADS[i];
					if (L.distToPolyline(x, z, road.points) < road.width / 2 + margin) return true;
				}
				return false;
			}
			function slopeAt(x, z) {
				return (
					Math.abs(L.groundHeight(x + 0.22, z) - L.groundHeight(x - 0.22, z)) +
					Math.abs(L.groundHeight(x, z + 0.22) - L.groundHeight(x, z - 0.22))
				);
			}
			const placed = [];
			function occOk(x, z, radius) {
				for (let i = 0; i < placed.length; i++) {
					const p = placed[i];
					const dx = x - p[0];
					const dz = z - p[1];
					const rr = radius + p[2];
					if (dx * dx + dz * dz < rr * rr) return false;
				}
				return true;
			}
			function occAdd(x, z, radius) {
				placed.push([x, z, radius]);
			}
			function treeOk(x, z) {
				if (Math.hypot(x, z) > 13.5) return false;
				const gh = L.groundHeight(x, z);
				if (gh < 0.55) return false;
				if (nearRoad(x, z, 0.22)) return false;
				if (nearClear(x, z)) return false;
				if (nearLot(x, z, 0.25)) return false;
				if (slopeAt(x, z) > 0.52) return false;
				return occOk(x, z, 0.16);
			}
			function plantOk(x, z, minH, maxSlope, roadMargin, lotExtra, spacing) {
				if (Math.hypot(x, z) > 13.55) return false;
				const gh = L.groundHeight(x, z);
				if (gh < minH) return false;
				if (nearRoad(x, z, roadMargin)) return false;
				if (nearClear(x, z)) return false;
				if (nearLot(x, z, lotExtra)) return false;
				if (slopeAt(x, z) > maxSlope) return false;
				return occOk(x, z, spacing);
			}

			// ---- pier surface helper ------------------------------
			function pierPos(id, along, across) {
				const pier = L.PIERS.find((p) => p.id === id);
				if (!pier) return null;
				const dl = Math.hypot(pier.dir[0], pier.dir[1]);
				const dx = pier.dir[0] / dl;
				const dz = pier.dir[1] / dl;
				return { x: pier.start[0] + dx * along - dz * across, z: pier.start[1] + dz * along + dx * across, y: pier.deck + 0.045 };
			}

			// ==============================================================
			// 1. FISH MARKET & QUAY CLUTTER
			// ==============================================================
			const QY = L.LEVEL.quay;
			// ---- quay placement helpers -----------------------------------
			function nearStructure(x, z, pad) {
				const list = [
					['warehouseA', 0.2],
					['warehouseB', 0.2],
					['containerYard', 0.3],
					['gantryCrane', 0.55],
					['fuelTank', 0.6],
					['railYard', 0.85],
					['marketHall', 0.6],
					['customsHouse', 0.8],
					['fishMarket', 0.45],
				];
				for (const it of list) {
					const a = L.ANCHORS[it[0]];
					if (!a) continue;
					const p = it[1] + (pad || 0);
					if (a.size) {
						if (Math.abs(x - a.pos[0]) < a.size[0] / 2 + p && Math.abs(z - a.pos[1]) < a.size[1] / 2 + p) return true;
					} else if (Math.hypot(x - a.pos[0], z - a.pos[1]) < p) {
						return true;
					}
				}
				return false;
			}
			/** true when (x,z) is safe for quay clutter: on the flat 1.0
			 *  terrace, clear of the quay-wall paving (T2), the roads and
			 *  the industrial building footprints. */
			function quayOK(x, z) {
				const gh = L.groundHeight(x, z);
				if (gh < 0.82 || gh > 1.26) return false;
				const d = L.districtAt(x, z);
				if (d !== 'quay' && d !== 'yard') return false;
				if (L.signedDistToPoly(x, z, L.COAST) < 0.78) return false;
				if (nearRoad(x, z, 0.1)) return false;
				if (nearStructure(x, z, 0.16)) return false;
				return occOk(x, z, 0.1);
			}

			// --- cargo-shed market stalls on the working apron -------------
			const marketPaint = new Paint();
			function marketStall(x, z, ry) {
				marketPaint.box(0.3, 0.018, 0.14, 0, 0.062, 0, '#8a5b34', [0, ry, 0]);
				for (const sx of [-1, 1]) {
					for (const sz of [-1, 1]) marketPaint.box(0.014, 0.06, 0.014, sx * 0.13, 0.032, sz * 0.055, '#5b4028', [0, ry, 0]);
				}
				for (let i = 0; i < 6; i++) marketPaint.box(0.04, 0.012, 0.02, -0.11 + i * 0.042, 0.078, 0.01, '#9dbcc6', [0, ry + 0.24, 0]);
				marketPaint.box(0.085, 0.075, 0.085, -0.19, 0.038, 0.02, '#b08a5c', [0, ry, 0]);
				marketPaint.box(0.085, 0.075, 0.085, 0.2, 0.038, -0.02, '#a8815a', [0, ry, 0]);
				marketPaint.box(0.07, 0.045, 0.05, 0.1, 0.085, -0.05, '#e8e6de', [0, ry, 0]);
				for (const sx of [-1, 1]) {
					for (const sz of [-1, 1]) marketPaint.box(0.008, 0.2, 0.008, sx * 0.15, 0.16, sz * 0.07, '#5b4028', [0, ry, 0]);
				}
				marketPaint.box(0.34, 0.01, 0.17, 0, 0.265, 0, '#efe2c9', [0.14, ry, 0]);
				marketPaint.box(0.34, 0.006, 0.03, 0, 0.272, 0.045, '#b3453b', [0.14, ry, 0]);
			}
			marketStall(-5.5, 0.12, 0.15);
			marketStall(-4.05, 0.06, -0.1);
			const stallMesh = mergedMesh(marketPaint.geos, MAT.prop, 'quay-market', true, true);
			if (stallMesh) {
				stallMesh.position.y = QY;
				g.add(stallMesh);
			}

			// --- working-apron clutter -----------------------------------
			const QUAY_CLUTTER = [
				// west end / rail yard
				['crate', -9.25, 0.35, 0.3, 1.05],
				['crate', -9.1, 0.52, 0.9, 0.95],
				['pallet', -8.95, 0.18, 0.1, 1.0],
				['barrel', -9.35, 0.05, 0, 1.0],
				['barrel', -9.18, -0.12, 0, 0.9],
				['netPile', -8.8, 0.45, 0.4, 0.9],
				['anchor', -8.68, 0.08, 2.4, 1.0],
				['tire', -9.0, -0.48, 0.4, 1.0],
				['tire', -8.84, -0.58, 0.2, 0.85],
				['ropeCoil', -9.32, 0.56, 0.1, 1.0],
				// boat shed
				['crate', -7.9, 0.55, 0.2, 1.0],
				['crate', -7.74, 0.34, 0.8, 0.9],
				['pallet', -7.5, 0.1, 0.3, 1.0],
				['barrel', -7.36, 0.46, 0, 1.0],
				['netPile', -7.1, 0.26, 0.5, 1.0],
				['floats', -7.0, 0.52, 0.2, 1.0],
				['bucket', -7.55, -0.18, 0, 0.9],
				['handcart', -8.25, 0.32, 1.3, 1.0],
				['ropeCoil', -6.95, -0.15, 0.4, 0.9],
				['fishCrate', -7.2, 0.62, 0.2, 1.0],
				['tire', -8.05, -0.5, 0.1, 0.9],
				// cargo warehouse front
				['crate', -5.86, 0.5, 0.3, 1.05],
				['crate', -5.66, 0.3, 0.9, 0.95],
				['pallet', -5.36, 0.56, 0.1, 1.0],
				['pallet', -5.1, 0.36, 1.2, 1.0],
				['barrel', -5.46, 0.72, 0, 1.0],
				['barrel', -5.2, 0.14, 0, 0.9],
				['fishCrate', -5.92, 0.04, 0.3, 1.0],
				['fishCrate', -5.56, 0.0, 0.9, 1.0],
				['netPile', -5.0, 0.6, 0.4, 1.0],
				['ropeCoil', -4.8, 0.3, 0.1, 1.0],
				['bucket', -4.64, 0.52, 0, 0.9],
				['crate', -4.4, 0.56, 0.6, 1.0],
				['crate', -4.2, 0.36, 1.2, 0.95],
				['handcart', -3.9, 0.5, 1.3, 1.0],
				['pallet', -3.7, 0.26, 0.2, 1.0],
				// container yard front
				['pallet', -2.3, 0.46, 0.1, 1.0],
				['crate', -2.05, 0.62, 0.4, 1.0],
				['crate', -1.8, 0.42, 1.0, 0.95],
				['barrel', -1.5, 0.72, 0, 0.9],
				['barrel', -1.25, 0.52, 0, 1.0],
				['pallet', -0.9, 0.66, 0.3, 1.1],
				['crate', -0.55, 0.52, 1.1, 1.0],
				['bucket', -0.2, 0.72, 0, 0.9],
				['tire', -0.35, 0.22, 0.4, 1.0],
				['netPile', -1.95, 0.18, 0.2, 0.9],
				['floats', -0.75, 0.22, 0.2, 1.0],
				// gantry / quay crane zone
				['crate', 0.42, 0.52, 0.3, 1.0],
				['pallet', 0.68, 0.3, 0.1, 1.0],
				['barrel', 0.92, 0.62, 0, 1.0],
				['ropeCoil', 1.16, 0.2, 0.4, 1.0],
				['crate', 1.46, 0.56, 0.8, 1.0],
				['handcart', 1.7, 0.26, 1.3, 0.95],
				['barrel', 2.0, 0.5, 0, 0.9],
				// fuel tank
				['barrel', 2.15, -0.18, 0, 1.0],
				['barrel', 3.3, -0.14, 0, 0.95],
				['barrel', 2.9, 0.12, 0, 1.0],
				['barrel', 3.16, -0.36, 0, 0.9],
				['crate', 2.5, 0.26, 0.4, 0.95],
				['bucket', 2.35, 0.06, 0, 0.9],
				['anchor', 3.42, 0.2, 2.0, 0.9],
				// western apron near the pier roots
				['crate', -7.9, 1.26, 0.3, 1.0],
				['pallet', -7.52, 1.12, 0.2, 1.0],
				['ropeCoil', -7.2, 1.3, 0.4, 1.0],
				['netPile', -6.9, 1.16, 0.1, 0.9],
				['fishCrate', -6.5, 1.26, 0.3, 1.0],
				['barrel', -6.15, 1.12, 0, 1.0],
				['bucket', -5.9, 1.3, 0, 0.9],
				['crate', -3.15, 0.35, 0.6, 1.0],
				['pallet', -2.85, 0.5, 0.1, 1.0],
				['barrel', -2.55, 0.3, 0, 0.95],
				// customs house terrace
				['bench', -9.8, 1.35, 1.4, 1.0],
				['planter', -10.05, 1.2, 0.3, 1.0],
				['bicycle', -9.65, 1.0, 1.5, 1.0],
				['crate', -9.9, 0.75, 0.3, 0.95],
				['barrel', -9.6, 1.55, 0, 0.9],
			];
			let clutterMade = 0;
			for (const it of QUAY_CLUTTER) {
				if (!quayOK(it[1], it[2])) continue;
				put(it[0], it[1], L.groundHeight(it[1], it[2]), it[2], it[3], it[4]);
				occAdd(it[1], it[2], 0.07);
				clutterMade++;
			}
			put('forklift', -2.65, L.groundHeight(-2.65, 0.3), 0.3, -0.6, 1.0);

			// ---- pier-head details (T2 furnishes the decks themselves) ----
			const HEAD_PROPS = [
				['pierA', 3.45, 0.0, 'ropeCoil', 0.5, 1.0],
				['pierA', 3.2, 0.42, 'lifeRing', 0, 1.0],
				['pierA', 3.0, -0.42, 'bucket', 0, 0.9],
				['pierA', 3.3, -0.3, 'fishCrate', 0.3, 1.0],
				['pierB', 2.8, 0.0, 'fishCrate', 0.3, 1.0],
				['pierB', 2.55, 0.22, 'floats', 0.2, 1.0],
				['pierB', 3.0, -0.3, 'lifeRing', 0, 1.0],
				['pierB', 2.3, -0.12, 'netPile', 0.5, 0.85],
				['pierC', 3.15, 0.0, 'lifeRing', 0, 1.0],
				['pierC', 2.95, 0.3, 'ropeCoil', 0.5, 0.8],
				['pierD', 2.35, 0.42, 'anchor', 2.2, 1.0],
				['pierD', 2.05, -0.35, 'barrel', 0, 1.0],
				['pierD', 1.75, 0.4, 'ropeCoil', 0, 1.0],
			];
			const headPaint = new Paint();
			for (const it of HEAD_PROPS) {
				const p = pierPos(it[0], it[1], it[2]);
				if (!p) continue;
				if (it[3] === 'lifeRing') {
					headPaint.box(0.028, 0.2, 0.028, p.x, p.y + 0.1, p.z, '#5b4028');
					put('lifeRing', p.x, p.y + 0.16, p.z, it[1] * 0.8, it[4]);
				} else {
					put(it[3], p.x, p.y, p.z, it[1] * 2.1, it[4]);
				}
			}
			const headMesh = mergedMesh(headPaint.geos, MAT.prop, 'pier-head-posts', false, true);
			if (headMesh) g.add(headMesh);

			// ==============================================================
			// 2. BEACH COVE GEAR
			// ==============================================================
			const BEACH = [
				['netPile', -11.72, 5.68, 0.4, 1.0],
				['floats', -11.48, 5.9, 0.1, 1.1],
				['floats', -11.6, 5.55, 0.2, 1.0],
				['crate', -11.05, 5.28, 0.6, 1.0],
				['barrel', -11.9, 5.4, 0, 1.0],
				['ropeCoil', -10.85, 5.42, 0.2, 1.0],
				['anchor', -10.95, 5.12, 1.2, 0.9],
				['bucket', -11.55, 5.78, 0, 0.9],
				['tire', -12.0, 5.72, 0.8, 1.0],
			];
			for (const it of BEACH) {
				const gh = L.groundHeight(it[1], it[2]);
				if (gh < 0.12) continue;
				if (nearRoad(it[1], it[2], 0.06)) continue;
				put(it[0], it[1], gh - 0.004, it[2], it[3], it[4]);
				occAdd(it[1], it[2], 0.05);
			}

			// ==============================================================
			// 3. BENCHES / PLANTERS / BICYCLES / LIFE RINGS
			// ==============================================================
			const [plx, plz] = L.ANCHORS.plaza.pos;
			for (let i = 0; i < 4; i++) {
				const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
				const bx = plx + Math.cos(a) * 1.25;
				const bz = plz + Math.sin(a) * 1.25;
				if (!nearRoad(bx, bz, 0.05) && occOk(bx, bz, 0.1)) {
					put('bench', bx, L.LEVEL.town + 0.01, bz, -a + Math.PI / 2, 1.0);
					occAdd(bx, bz, 0.1);
				}
				const pa = a + Math.PI / 8;
				const px2 = plx + Math.cos(pa) * 1.42;
				const pz2 = plz + Math.sin(pa) * 1.42;
				if (!nearRoad(px2, pz2, 0.05) && occOk(px2, pz2, 0.08)) {
					put('planter', px2, L.LEVEL.town + 0.01, pz2, pa, 1.0);
					occAdd(px2, pz2, 0.08);
				}
			}
			const BENCHES = [
				[-9.9, 2.0, 1.3],
				[-6.3, -1.9, 2.0],
				[-2.2, -5.35, 0.2],
				[-7.6, -5.0, 1.6],
				[-4.7, 1.35, 2.5],
				[2.2, -1.55, 0.4],
			];
			for (const b of BENCHES) {
				const gh = L.groundHeight(b[0], b[1]);
				if (gh < 0.5) continue;
				if (nearRoad(b[0], b[1], 0.0)) continue;
				if (!occOk(b[0], b[1], 0.1)) continue;
				put('bench', b[0], gh + 0.005, b[1], b[2], 1.0);
				occAdd(b[0], b[1], 0.1);
			}
			const PLANTERS = [
				[-9.55, 1.75, 0.3],
				[-5.35, 1.55, 0.1],
				[-3.7, 1.25, 0.6],
				[1.85, 0.95, 0.2],
				[-2.0, -2.75, 0.4],
				[-8.2, -3.1, 0.8],
				[1.4, -3.5, 0.3],
			];
			for (const b of PLANTERS) {
				const gh = L.groundHeight(b[0], b[1]);
				if (gh < 0.5) continue;
				if (nearRoad(b[0], b[1], 0.02)) continue;
				if (!occOk(b[0], b[1], 0.08)) continue;
				put('planter', b[0], gh + 0.005, b[1], b[2], 1.0);
				occAdd(b[0], b[1], 0.08);
			}
			const BIKES = [
				[-9.65, 1.45, 1.4],
				[-3.9, -2.1, 0.4],
				[-6.65, -2.2, 2.6],
			];
			for (const b of BIKES) {
				const gh = L.groundHeight(b[0], b[1]);
				if (gh < 0.5) continue;
				if (nearRoad(b[0], b[1], 0.02)) continue;
				if (!occOk(b[0], b[1], 0.08)) continue;
				put('bicycle', b[0], gh + 0.005, b[1], b[2], 1.0);
				occAdd(b[0], b[1], 0.08);
			}
			// ---- dock lanterns, cats and net-drying racks -----------------
			const LANTERNS = [
				[-6.55, 0.85],
				[1.05, 0.95],
			];
			const edgePaint = new Paint();
			for (const lp of LANTERNS) {
				const gh = L.groundHeight(lp[0], lp[1]);
				if (gh < 0.5) continue;
				edgePaint.box(0.028, 0.36, 0.028, lp[0], gh + 0.18, lp[1], '#4e3726');
				edgePaint.box(0.05, 0.05, 0.05, lp[0], gh + 0.39, lp[1], '#3a3f44');
			}
			const edgeMesh = mergedMesh(edgePaint.geos, MAT.prop, 'quay-posts', false, true);
			if (edgeMesh) g.add(edgeMesh);
			const lampPaint = new Paint();
			for (const lp of LANTERNS) {
				const gh = L.groundHeight(lp[0], lp[1]);
				if (gh < 0.5) continue;
				lampPaint.box(0.032, 0.032, 0.032, lp[0], gh + 0.39, lp[1], '#ffcf8a');
			}
			const lampMesh = mergedMesh(lampPaint.geos, MAT.lamp, 'market-lanterns', false, false);
			if (lampMesh) g.add(lampMesh);
			// dock cats
			const CATS = [
				[-5.28, 0.86, 1.2],
				[-6.86, 0.66, -0.4],
				[-1.15, 0.9, 2.4],
				[-8.4, 0.76, 0.9],
			];
			for (const c of CATS) {
				if (!quayOK(c[0], c[1])) continue;
				put('cat', c[0], L.groundHeight(c[0], c[1]) + 0.004, c[1], c[2], 1.0);
				occAdd(c[0], c[1], 0.05);
			}
			// net drying racks: boat shed and the beach lane
			const NETS = [
				[-6.36, 0.78, 0.5],
				[-10.55, 2.9, 1.1],
			];
			for (const n of NETS) {
				const gh = L.groundHeight(n[0], n[1]);
				if (gh < 0.4) continue;
				if (nearRoad(n[0], n[1], 0.06)) continue;
				if (nearStructure(n[0], n[1], 0.1)) continue;
				put('netRack', n[0], gh + 0.004, n[1], n[2], 1.0);
				occAdd(n[0], n[1], 0.12);
			}

			// ==============================================================
			// 4. VEHICLES
			// ==============================================================
			function parkVehicle(roadId, dist, side, type, color) {
				const road = L.ROADS.find((x) => x.id === roadId);
				if (!road) return;
				const p = L.pointAlong(road.points, dist);
				const off = side * (road.width / 2 - 0.2);
				const x = p.x - p.dirZ * off;
				const z = p.z + p.dirX * off;
				if (Math.hypot(x, z) > 13.4) return;
				const y = L.groundHeight(x, z);
				if (y < 0.3) return;
				const ry = p.angle + (side > 0 ? 0 : Math.PI);
				// T3 lays the road as a 0.04-thick slab at level+0.025: lift the
				// vehicles onto that surface so they never look half-buried
				const yRoad = y + 0.052;
				if (type === 'sedan') {
					put('sedanBody', x, yRoad, z, ry, 1.0, 1.0, 1.0, color);
					put('sedanDark', x, yRoad, z, ry, 1.0);
				} else if (type === 'van') {
					put('vanBody', x, yRoad, z, ry, 1.0, 1.0, 1.0, color);
					put('vanDark', x, yRoad, z, ry, 1.0);
				} else {
					put('truckBody', x, yRoad, z, ry, 1.0, 1.0, 1.0, color);
					put('truckDark', x, yRoad, z, ry, 1.0);
				}
				occAdd(x, z, 0.16);
			}
			const CARS = [
				['quayRoad', 1.2, 1, 'sedan', '#b3453b'],
				['quayRoad', 3.1, 1, 'van', '#e8e2d2'],
				['quayRoad', 5.4, 1, 'sedan', '#3d5f86'],
				['quayRoad', 8.3, 1, 'sedan', '#d9a13b'],
				['quayRoad', 11.0, -1, 'van', '#b9ac96'],
				['mainStreet', 1.4, -1, 'sedan', '#4a5b52'],
				['mainStreet', 3.6, 1, 'van', '#8a6746'],
				['mainStreet', 6.8, -1, 'sedan', '#efe2c9'],
				['mainStreet', 10.2, 1, 'truck', '#4a6b7c'],
				['fortRoad', 1.1, -1, 'sedan', '#6d3a32'],
			];
			for (const c of CARS) parkVehicle(c[0], c[1], c[2], c[3], c[4]);

			// one slow-moving delivery truck along the quay road
			const movePaint = new Paint();
			(function () {
				movePaint.geos.push(truckBody());
				movePaint.geos.push(truckDark());
			})();
			const moveMesh = mergedMesh(movePaint.geos, MAT.vehicle, 'moving-truck', true, true);
			const moveGroup = new THREE.Group();
			moveGroup.name = 'moving-truck';
			if (moveMesh) moveGroup.add(moveMesh);
			g.add(moveGroup);
			const moveRoad = L.ROADS.find((x) => x.id === 'quayRoad');
			const moveLen = moveRoad ? L.polylineLength(moveRoad.points) : 1;
			let moveS = 0;

			// ==============================================================
			// 5. TREES
			// ==============================================================
			const treeCounts = { cypress: 0, pine: 0, roundTree: 0, olive: 0 };
			const TREE_TINTS = ['#c9d9ae', '#b7cba0', '#aec69a', '#d3cfa9', '#9fb98c', '#c2c8a2'];
			function addTree(x, z, species, size, tint) {
				// sample the height field around the trunk and bury the base a
				// little: terrain triangles can dip below the analytic height
				// on steep hillsides, which used to make trees look airborne
				const gh0 = L.groundHeight(x, z);
				const gh1 = L.groundHeight(x + 0.18, z);
				const gh2 = L.groundHeight(x - 0.18, z);
				const gh3 = L.groundHeight(x, z + 0.18);
				const gh4 = L.groundHeight(x, z - 0.18);
				const gh = Math.min(gh0, gh1, gh2, gh3, gh4);
				if (gh < 0.5) return;
				put(species, x, gh - 0.035, z, r.range(0, Math.PI * 2), size * r.range(0.86, 1.12), size, size * r.range(0.86, 1.12), tint || r.pick(TREE_TINTS));
				treeCounts[species]++;
				occAdd(x, z, 0.14);
			}
			// clustered woodland on the north hills / NE cliffs / west ridge
			const WOODS = [
				[-9.0, -11.4, 2.3, 20],
				[-5.4, -12.1, 2.1, 17],
				[-2.2, -11.9, 1.8, 12],
				[-11.9, -9.7, 1.8, 11],
				[-12.7, -7.2, 1.6, 9],
				[0.7, -12.1, 1.7, 10],
				[-8.2, -13.0, 1.7, 11],
				[4.3, -9.5, 1.9, 11],
				[5.6, -7.0, 1.6, 9],
				[4.6, -5.3, 1.4, 7],
				[-12.6, -4.4, 1.5, 7],
				[-11.9, -2.6, 1.3, 6],
				[-10.3, -6.2, 1.6, 9],
				[-8.3, -8.6, 1.5, 8],
				[-1.2, -10.6, 1.6, 9],
				[2.2, -9.4, 1.6, 8],
				[-13.0, -10.5, 1.2, 6],
				[6.2, -9.0, 1.3, 6],
			];
			for (const cl of WOODS) {
				let made = 0;
				let tries = 0;
				while (made < cl[3] && tries < cl[3] * 14) {
					tries++;
					const a = r.range(0, Math.PI * 2);
					const rad = cl[2] * Math.sqrt(r.next());
					const x = cl[0] + Math.cos(a) * rad;
					const z = cl[1] + Math.sin(a) * rad;
					if (!treeOk(x, z)) continue;
					// noise-driven clearings / thickets so the woodland does not
					// read as an evenly spaced plantation
					const dens = U.fbm(x * 0.33, z * 0.33, { octaves: 3, seed: 31 });
					if (dens < -0.12 && r.chance(0.62)) continue;
					const species = r.pick(['pine', 'pine', 'pine', 'cypress', 'roundTree', 'olive', 'pine', 'roundTree', 'cypress', 'olive']);
					const size = U.clamp(r.range(0.42, 0.92) * (1.08 - 0.3 * (rad / cl[2])), 0.35, 0.95);
					addTree(x, z, species, size);
					made++;
				}
			}
			// ornamental trees in town and along the waterfront
			const TOWN_TREES = [
				[-0.75, -8.05, 'roundTree', 0.55],
				[-3.55, -7.45, 'roundTree', 0.5],
				[0.55, -6.1, 'olive', 0.45],
				[-9.85, 1.2, 'roundTree', 0.52],
				[-7.95, -0.5, 'roundTree', 0.56],
				[-6.35, -3.6, 'roundTree', 0.55],
				[-9.4, -9.1, 'pine', 0.74],
				[-4.4, -10.0, 'cypress', 0.84],
				[2.1, -4.9, 'roundTree', 0.5],
				[-0.9, -4.25, 'olive', 0.42],
				[-12.5, 4.35, 'olive', 0.5],
				[-12.0, 5.95, 'pine', 0.62],
				[-10.9, -2.05, 'cypress', 0.6],
				[-8.55, -6.95, 'roundTree', 0.5],
				[-3.1, -9.4, 'olive', 0.45],
				[1.6, -7.7, 'cypress', 0.62],
				[-3.4, -3.0, 'roundTree', 0.55],
				[-1.4, -3.6, 'roundTree', 0.5],
				[-6.9, -4.9, 'roundTree', 0.55],
				[-9.9, -4.6, 'pine', 0.65],
				[-2.7, -9.2, 'cypress', 0.7],
				[-7.2, -7.6, 'roundTree', 0.55],
				[-0.2, -5.0, 'olive', 0.42],
				[-5.0, -8.9, 'roundTree', 0.5],
				[1.2, -6.0, 'roundTree', 0.45],
				[-10.3, -8.0, 'pine', 0.66],
				[-4.1, -3.3, 'olive', 0.4],
			];
			for (const t of TOWN_TREES) {
				if (!treeOk(t[0], t[1])) continue;
				addTree(t[0], t[1], t[2], t[3]);
			}

			// ==============================================================
			// 6. UNDERGROWTH: shrubs / flowers / weeds
			// ==============================================================
			function scatterPlants(zones, countTotal) {
				let n = 0;
				for (const zn of zones) {
					let made = 0;
					let tries = 0;
					while (made < zn[3] && tries < zn[3] * 12 && n < countTotal) {
						tries++;
						const a = r.range(0, Math.PI * 2);
						const rad = zn[2] * Math.sqrt(r.next());
						const x = zn[0] + Math.cos(a) * rad;
						const z = zn[1] + Math.sin(a) * rad;
						if (!plantOk(x, z, zn[4] != null ? zn[4] : 0.4, 1.0, 0.08, 0.1, 0.09)) continue;
						put('shrub', x, L.groundHeight(x, z) - 0.03, z, r.range(0, 6.28), r.range(0.7, 1.5));
						occAdd(x, z, 0.09);
						made++;
						n++;
					}
				}
				return n;
			}
			const SHRUBS = [
				[-9.2, -10.2, 2.6, 16, 0.4],
				[-4.2, -11.0, 2.6, 14, 0.4],
				[1.0, -11.2, 2.0, 9, 0.4],
				[5.0, -8.2, 2.0, 10, 0.4],
				[-12.2, -6.6, 2.0, 9, 0.4],
				[-12.7, -2.8, 1.6, 7, 0.4],
				[-10.9, 4.9, 1.3, 7, 0.28],
				[-11.7, 5.8, 1.0, 5, 0.28],
				[-6.6, -3.2, 1.5, 6, 0.5],
				[-2.7, -9.8, 1.5, 5, 0.5],
				[2.9, -3.4, 1.2, 5, 0.5],
				[-9.6, 2.6, 0.9, 5, 0.6],
				[-1.6, -2.9, 0.9, 4, 0.6],
			];
			const shrubCount = scatterPlants(SHRUBS, 130);

			const FLOWER_ZONES = [
				[-2.1, -6.9, 1.75, 12, 0.9],
				[-9.7, 1.6, 1.0, 8, 0.8],
				[-6.4, 2.0, 0.9, 7, 0.8],
				[-12.2, 5.2, 1.0, 6, 0.28],
				[-9.3, -9.3, 1.6, 8, 0.4],
				[-4.6, -9.9, 1.6, 8, 0.4],
				[3.9, -3.0, 1.2, 6, 0.5],
				[4.9, -6.9, 1.3, 6, 0.5],
				[-7.9, -6.6, 1.3, 6, 0.4],
			];
			let flowerCount = 0;
			for (const zn of FLOWER_ZONES) {
				let made = 0;
				let tries = 0;
				while (made < zn[3] && tries < zn[3] * 10) {
					tries++;
					const a = r.range(0, Math.PI * 2);
					const rad = zn[2] * Math.sqrt(r.next());
					const x = zn[0] + Math.cos(a) * rad;
					const z = zn[1] + Math.sin(a) * rad;
					if (!plantOk(x, z, zn[4], 0.9, 0.05, 0.08, 0.05)) continue;
					put('flower', x, L.groundHeight(x, z) - 0.015, z, r.range(0, 6.28), r.range(0.8, 1.5));
					occAdd(x, z, 0.05);
					made++;
					flowerCount++;
				}
			}

			const WEED_ZONES = [
				[-9.5, -10.5, 2.8, 42, 0.35],
				[-4.5, -11.4, 2.8, 38, 0.35],
				[0.0, -11.6, 2.4, 26, 0.35],
				[4.6, -8.8, 2.4, 26, 0.35],
				[-12.3, -6.4, 2.2, 22, 0.3],
				[-12.8, -2.6, 1.8, 18, 0.3],
				[-11.2, 5.2, 1.3, 14, 0.22],
				[3.2, 1.6, 0.9, 10, 0.6],
				[-7.0, 3.2, 0.8, 8, 0.6],
				[-10.2, 3.4, 0.9, 10, 0.5],
				[2.4, -10.2, 1.8, 14, 0.4],
			];
			let weedCount = 0;
			for (const zn of WEED_ZONES) {
				let made = 0;
				let tries = 0;
				while (made < zn[3] && tries < zn[3] * 8) {
					tries++;
					const a = r.range(0, Math.PI * 2);
					const rad = zn[2] * Math.sqrt(r.next());
					const x = zn[0] + Math.cos(a) * rad;
					const z = zn[1] + Math.sin(a) * rad;
					const gh = L.groundHeight(x, z);
					if (gh < zn[4]) continue;
					if (nearRoad(x, z, 0.02)) continue;
					if (nearClear(x, z)) continue;
					if (!occOk(x, z, 0.05)) continue;
					put('weed', x, gh - 0.02, z, r.range(0, 6.28), r.range(0.7, 1.6));
					occAdd(x, z, 0.05);
					made++;
					weedCount++;
				}
			}

			// ==============================================================
			// 7. ROCKS
			// ==============================================================
			const ROCK_ZONES = [
				[-12.9, 6.7, 1.4, 12, 0.1],
				[-11.9, 4.6, 1.1, 9, 0.1],
				[-13.1, 2.9, 1.3, 8, 0.1],
				[6.6, -6.9, 1.3, 9, 0.1],
				[7.0, -4.0, 1.1, 7, 0.1],
				[-11.1, -9.7, 1.4, 7, 0.1],
				[-5.6, -12.6, 1.2, 6, 0.1],
				[3.7, -7.5, 1.0, 5, 0.1],
			];
			let rockCount = 0;
			for (const zn of ROCK_ZONES) {
				let made = 0;
				let tries = 0;
				while (made < zn[3] && tries < zn[3] * 10) {
					tries++;
					const a = r.range(0, Math.PI * 2);
					const rad = zn[2] * Math.sqrt(r.next());
					const x = zn[0] + Math.cos(a) * rad;
					const z = zn[1] + Math.sin(a) * rad;
					const gh = L.groundHeight(x, z);
					if (gh < zn[4]) continue;
					if (nearRoad(x, z, 0.02)) continue;
					if (nearClear(x, z)) continue;
					if (!occOk(x, z, 0.08)) continue;
					const big = r.chance(0.45);
					const type = 'rockA';
					const s = big ? r.range(0.7, 1.5) : r.range(0.5, 0.95);
					const tint = r.chance(0.5) ? '#a89d8c' : '#8d8578';
					put(type, x, gh - 0.075, z, r.range(0, 6.28), s, s * r.range(0.6, 1.0), s, tint);
					occAdd(x, z, 0.1);
					made++;
					rockCount++;
				}
			}

			// ==============================================================
			// build instanced meshes
			// ==============================================================
			const INSTANCED = [
				['crate', MAT.prop, true],
				['pallet', MAT.prop, false],
				['barrel', MAT.prop, true],
				['fishCrate', MAT.prop, false],
				['ropeCoil', MAT.prop, false],
				['anchor', MAT.prop, false],
				['tire', MAT.prop, false],
				['lifeRing', MAT.prop, false],
				['bucket', MAT.prop, false],
				['netPile', MAT.prop, false],
				['floats', MAT.prop, false],
				['rockA', MAT.prop, false],
				['shrub', MAT.veg, false],
				['weed', MAT.veg, false],
				['flower', MAT.veg, false],
				['bench', MAT.prop, false],
				['planter', MAT.prop, false],
				['bicycle', MAT.prop, false],
				['handcart', MAT.prop, false],
				['cat', MAT.prop, false],
				['netRack', MAT.prop, false],
				['forklift', MAT.prop, false],
				['sedanBody', MAT.vehicle, true],
				['sedanDark', MAT.vehicle, false],
				['vanBody', MAT.vehicle, true],
				['vanDark', MAT.vehicle, false],
				['truckBody', MAT.vehicle, true],
				['truckDark', MAT.vehicle, false],
				['cypress', MAT.veg, true],
				['pine', MAT.veg, true],
				['roundTree', MAT.veg, true],
				['olive', MAT.veg, true],
			];
			let instCount = 0;
			for (const it of INSTANCED) {
				const list = lists[it[0]];
				if (!list || !list.length) continue;
				const mesh = instanced(T[it[0]], it[1], list, { cast: it[2], receive: true, name: it[0] });
				if (mesh) g.add(mesh);
				instCount += list.length;
			}

			console.log('[props] ' + instCount + ' instanced props, ' + (treeCounts.cypress + treeCounts.pine + treeCounts.roundTree + treeCounts.olive) + ' trees, ' + shrubCount + ' shrubs, ' + weedCount + ' weeds, ' + flowerCount + ' flowers, ' + rockCount + ' rocks');
			ctx.world.props = { trees: treeCounts, instances: instCount };

			return {
				update(dt, t) {
					const night = (ctx.env && ctx.env.state && ctx.env.state.night) || 0;
					MAT.lamp.emissiveIntensity = 0.1 + night * 2.6;
					if (moveRoad) {
						moveS = (moveS + dt * 0.16) % moveLen;
						const p = L.pointAlong(moveRoad.points, moveS);
						const off = 0.17;
						const tx = p.x - p.dirZ * off;
						const tz = p.z + p.dirX * off;
						let y = L.groundHeight(tx, tz);
						if (Math.abs(y - moveRoad.level) > 0.3) y = moveRoad.level;
						moveGroup.position.set(tx, y + 0.052, tz);
						moveGroup.rotation.y = p.angle;
					}
				},
			};
		},
	});
})(window.HARBOR);

