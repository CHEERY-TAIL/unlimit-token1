/**
 * materials.js — shared procedural PBR material library.
 * ==================================================================
 * All materials are generated at runtime from canvas textures, so the
 * project has zero external asset dependencies and opens from file://.
 *
 * Use shared instances through H.materials.get('concrete') so draw calls
 * can batch across modules. For colour variants use painted()/tinted()
 * which cache per colour.
 *
 *   const M = H.materials;
 *   M.get('concrete')            -> MeshStandardMaterial (shared)
 *   M.painted('#c0765b')         -> smooth painted metal/wood, cached
 *   M.roofTile('#a9503d')        -> terracotta tiles, cached
 *   M.emissive('#ffd9a0', 2)     -> glow for windows / lamps
 *   M.unique('concrete', {color:'#888'}) -> private clone if you must tweak
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;

	const P = U.PALETTE;
	let anisotropy = 8;
	const cache = new Map();
	const texSets = new Map();

	function mark(m) {
		m.userData.procedural = true;
		return m;
	}

	// ------------------------------------------------------------------
	// texture sets (map / normalMap / roughnessMap)
	// ------------------------------------------------------------------
	function tset(key, factory) {
		if (!texSets.has(key)) texSets.set(key, factory());
		return texSets.get(key);
	}

	function concreteSet() {
		return tset('concrete', () =>
			U.surface({
				size: 512,
				seed: 31,
				repeat: [1, 1],
				cacheKey: 'concrete512',
				normalStrength: 1.6,
				color(ctx, s, r) {
					ctx.fillStyle = '#a9a49a';
					ctx.fillRect(0, 0, s, s);
					// large stains
					for (let i = 0; i < 26; i++) {
						const x = r.range(0, s),
							y = r.range(0, s),
							rad = r.range(20, 130);
						const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
						const dark = r.chance(0.5);
						g.addColorStop(0, dark ? 'rgba(96,92,86,0.16)' : 'rgba(214,208,196,0.14)');
						g.addColorStop(1, 'rgba(0,0,0,0)');
						ctx.fillStyle = g;
						ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2);
					}
					// aggregate specks
					for (let i = 0; i < 4200; i++) {
						const v = r.range(0, 1);
						ctx.fillStyle = `rgba(${v < 0.5 ? '70,68,64' : '196,192,182'},${r.range(0.05, 0.22)})`;
						ctx.fillRect(r.range(0, s), r.range(0, s), r.range(0.6, 2.2), r.range(0.6, 2.2));
					}
					// formwork seam lines
					ctx.strokeStyle = 'rgba(84,80,74,0.35)';
					ctx.lineWidth = 1.5;
					for (let i = 0; i < 3; i++) {
						const y = r.range(0, s);
						ctx.beginPath();
						ctx.moveTo(0, y);
						for (let x = 0; x <= s; x += 32) ctx.lineTo(x, y + Math.sin(x * 0.02 + i) * 2);
						ctx.stroke();
					}
					// hairline cracks
					ctx.strokeStyle = 'rgba(66,62,58,0.30)';
					ctx.lineWidth = 1;
					for (let i = 0; i < 5; i++) {
						let x = r.range(0, s),
							y = r.range(0, s);
						ctx.beginPath();
						ctx.moveTo(x, y);
						for (let k = 0; k < 14; k++) {
							x += r.range(-9, 12);
							y += r.range(-7, 7);
							ctx.lineTo(x, y);
						}
						ctx.stroke();
					}
				},
				height(ctx, s, r) {
					ctx.fillStyle = '#8d8d8d';
					ctx.fillRect(0, 0, s, s);
					for (let i = 0; i < 9000; i++) {
						const v = Math.floor(r.range(96, 176));
						ctx.fillStyle = `rgb(${v},${v},${v})`;
						ctx.fillRect(r.range(0, s), r.range(0, s), r.range(0.7, 2.6), r.range(0.7, 2.6));
					}
					for (let i = 0; i < 30; i++) {
						const x = r.range(0, s),
							y = r.range(0, s),
							rad = r.range(20, 120);
						const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
						g.addColorStop(0, 'rgba(180,180,180,0.12)');
						g.addColorStop(1, 'rgba(0,0,0,0)');
						ctx.fillStyle = g;
						ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2);
					}
				},
			})
		);
	}

	function asphaltSet() {
		return tset('asphalt', () =>
			U.surface({
				size: 512,
				seed: 47,
				cacheKey: 'asphalt512',
				normalStrength: 1.2,
				color(ctx, s, r) {
					ctx.fillStyle = '#4b4a47';
					ctx.fillRect(0, 0, s, s);
					for (let i = 0; i < 9000; i++) {
						const v = r.range(30, 90);
						ctx.fillStyle = `rgba(${v},${v - 2},${v - 4},${r.range(0.2, 0.7)})`;
						ctx.fillRect(r.range(0, s), r.range(0, s), r.range(0.8, 2.4), r.range(0.8, 2.4));
					}
					for (let i = 0; i < 12; i++) {
						const x = r.range(0, s),
							y = r.range(0, s),
							rad = r.range(30, 100);
						const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
						g.addColorStop(0, 'rgba(120,118,112,0.10)');
						g.addColorStop(1, 'rgba(0,0,0,0)');
						ctx.fillStyle = g;
						ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2);
					}
				},
				height(ctx, s, r) {
					ctx.fillStyle = '#7c7c7c';
					ctx.fillRect(0, 0, s, s);
					for (let i = 0; i < 12000; i++) {
						const v = Math.floor(r.range(90, 150));
						ctx.fillStyle = `rgb(${v},${v},${v})`;
						ctx.fillRect(r.range(0, s), r.range(0, s), r.range(1, 3.4), r.range(1, 3.4));
					}
				},
			})
		);
	}

	function cobbleSet() {
		return tset('cobble', () =>
			U.surface({
				size: 512,
				seed: 83,
				cacheKey: 'cobble512',
				normalStrength: 3.2,
				color(ctx, s, r) {
					ctx.fillStyle = '#6f685c';
					ctx.fillRect(0, 0, s, s);
					const rowH = 30;
					let row = 0;
					for (let y = -rowH; y < s + rowH; y += rowH) {
						const off = (row % 2) * 22;
						for (let x = -30; x < s + 40; x += 44) {
							const w = 36 + r.range(-5, 6);
							const h = rowH - 6 + r.range(-3, 3);
							const cx = x + off + r.range(-2.5, 2.5);
							const cy = y + r.range(-2, 2);
							const base = r.range(0.32, 0.62);
							const warm = r.range(0.02, 0.12);
							const col = new THREE.Color().setHSL(0.09 + warm, 0.09 + r.range(0, 0.07), base * 0.62);
							ctx.fillStyle = '#' + col.getHexString();
							ctx.beginPath();
							ctx.ellipse(cx, cy, w / 2, h / 2, r.range(-0.1, 0.1), 0, Math.PI * 2);
							ctx.fill();
							ctx.strokeStyle = 'rgba(38,34,29,0.55)';
							ctx.lineWidth = 2.5;
							ctx.stroke();
							// highlight
							ctx.strokeStyle = `rgba(232,224,208,${r.range(0.06, 0.18)})`;
							ctx.lineWidth = 1.2;
							ctx.beginPath();
							ctx.ellipse(cx - 3, cy - 4, w / 2 - 4, h / 2 - 4, 0, Math.PI * 1.05, Math.PI * 1.7);
							ctx.stroke();
						}
						row++;
					}
					// dirt in the joints
					for (let i = 0; i < 2600; i++) {
						ctx.fillStyle = `rgba(44,38,30,${r.range(0.04, 0.2)})`;
						ctx.fillRect(r.range(0, s), r.range(0, s), r.range(1, 6), r.range(1, 4));
					}
				},
				height(ctx, s, r) {
					ctx.fillStyle = '#3a3a3a';
					ctx.fillRect(0, 0, s, s);
					const rowH = 30;
					let row = 0;
					for (let y = -rowH; y < s + rowH; y += rowH) {
						const off = (row % 2) * 22;
						for (let x = -30; x < s + 40; x += 44) {
							const w = 36 + r.range(-5, 6);
							const h = rowH - 6 + r.range(-3, 3);
							const cx = x + off + r.range(-2.5, 2.5);
							const cy = y + r.range(-2, 2);
							ctx.fillStyle = `rgb(${Math.floor(r.range(180, 240))},${Math.floor(r.range(180, 240))},${Math.floor(r.range(180, 240))})`;
							ctx.beginPath();
							ctx.ellipse(cx, cy, w / 2 - 3, h / 2 - 3, 0, 0, Math.PI * 2);
							ctx.fill();
						}
						row++;
					}
				},
			})
		);
	}

	function plankSet(key, base, dark, seed) {
		return tset(key, () =>
			U.surface({
				size: 512,
				seed,
				cacheKey: key + '512',
				normalStrength: 2.4,
				color(ctx, s, r) {
					ctx.fillStyle = base;
					ctx.fillRect(0, 0, s, s);
					const plankH = s / 8;
					for (let i = 0; i < 8; i++) {
						const y = i * plankH;
						const tone = r.range(-0.05, 0.06);
						const c = new THREE.Color(base).offsetHSL(0.01 * r.range(-1, 1), r.range(-0.05, 0.05), tone);
						ctx.fillStyle = '#' + c.getHexString();
						ctx.fillRect(0, y + 2, s, plankH - 4);
						// grain
						for (let g = 0; g < 26; g++) {
							const gy = y + r.range(4, plankH - 4);
							ctx.strokeStyle = `rgba(${dark},${r.range(0.04, 0.14)})`;
							ctx.lineWidth = r.range(0.5, 1.6);
							ctx.beginPath();
							ctx.moveTo(0, gy);
							for (let x = 0; x <= s; x += 40) ctx.lineTo(x, gy + Math.sin(x * 0.013 + i * 2.1 + g) * r.range(0.4, 2.2));
							ctx.stroke();
						}
						// knots
						if (r.chance(0.5)) {
							const kx = r.range(20, s - 20),
								ky = y + plankH / 2 + r.range(-6, 6);
							for (let k = 4; k > 0; k--) {
								ctx.strokeStyle = `rgba(${dark},${0.1 + k * 0.02})`;
								ctx.beginPath();
								ctx.ellipse(kx, ky, k * 2.2, k * 1.4, 0, 0, Math.PI * 2);
								ctx.stroke();
							}
						}
						// nails
						ctx.fillStyle = 'rgba(40,34,28,0.55)';
						ctx.beginPath();
						ctx.arc(14 + r.range(0, 4), y + plankH / 2, 1.8, 0, Math.PI * 2);
						ctx.arc(s - 14 - r.range(0, 4), y + plankH / 2, 1.8, 0, Math.PI * 2);
						ctx.fill();
						// gap
						ctx.fillStyle = 'rgba(28,22,17,0.65)';
						ctx.fillRect(0, y, s, 2);
					}
					for (let i = 0; i < 900; i++) {
						ctx.fillStyle = `rgba(30,24,18,${r.range(0.02, 0.08)})`;
						ctx.fillRect(r.range(0, s), r.range(0, s), r.range(2, 10), r.range(1, 2));
					}
				},
				height(ctx, s, r) {
					ctx.fillStyle = '#9a9a9a';
					ctx.fillRect(0, 0, s, s);
					const plankH = s / 8;
					for (let i = 0; i < 8; i++) {
						const y = i * plankH;
						ctx.fillStyle = '#141414';
						ctx.fillRect(0, y, s, 2.5);
						for (let g = 0; g < 40; g++) {
							const gy = y + r.range(4, plankH - 4);
							ctx.strokeStyle = `rgba(${Math.floor(r.range(70, 130))},${Math.floor(r.range(70, 130))},${Math.floor(r.range(70, 130))},0.35)`;
							ctx.lineWidth = 1;
							ctx.beginPath();
							ctx.moveTo(0, gy);
							ctx.lineTo(s, gy + r.range(-2, 2));
							ctx.stroke();
						}
					}
				},
			})
		);
	}

	function brickSet() {
		return tset('brick', () =>
			U.surface({
				size: 512,
				seed: 19,
				cacheKey: 'brick512',
				normalStrength: 3.4,
				color(ctx, s, r) {
					ctx.fillStyle = '#9c8b7a';
					ctx.fillRect(0, 0, s, s);
					const rowH = 34;
					let row = 0;
					for (let y = 0; y < s; y += rowH) {
						const off = (row % 2) * 42;
						for (let x = -50; x < s + 50; x += 84) {
							const c = r.pick(['#a9503d', '#9c4a39', '#b05a44', '#96503e', '#ad6a4e', '#8d4a3a']);
							ctx.fillStyle = c;
							ctx.fillRect(x + off + 2, y + 2, 80, rowH - 4);
							// brick face noise
							for (let i = 0; i < 12; i++) {
								ctx.fillStyle = `rgba(255,235,220,${r.range(0.02, 0.06)})`;
								ctx.fillRect(x + off + r.range(3, 76), y + r.range(3, rowH - 5), r.range(2, 10), r.range(1, 3));
							}
						}
						row++;
					}
					// soot / age
					for (let i = 0; i < 30; i++) {
						const x = r.range(0, s),
							y = r.range(0, s),
							rad = r.range(20, 90);
						const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
						g.addColorStop(0, 'rgba(40,34,30,0.10)');
						g.addColorStop(1, 'rgba(0,0,0,0)');
						ctx.fillStyle = g;
						ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2);
					}
				},
				height(ctx, s, r) {
					ctx.fillStyle = '#3c3c3c';
					ctx.fillRect(0, 0, s, s);
					const rowH = 34;
					let row = 0;
					for (let y = 0; y < s; y += rowH) {
						const off = (row % 2) * 42;
						for (let x = -50; x < s + 50; x += 84) {
							ctx.fillStyle = `rgb(${Math.floor(r.range(190, 230))},${Math.floor(r.range(190, 230))},${Math.floor(r.range(190, 230))})`;
							ctx.fillRect(x + off + 2, y + 2, 80, rowH - 4);
						}
						row++;
					}
					for (let i = 0; i < 2000; i++) {
						const v = Math.floor(r.range(120, 220));
						ctx.fillStyle = `rgb(${v},${v},${v})`;
						ctx.fillRect(r.range(0, s), r.range(0, s), 2, 2);
					}
				},
			})
		);
	}

	function stoneWallSet() {
		return tset('stoneWall', () =>
			U.surface({
				size: 512,
				seed: 57,
				cacheKey: 'stonewall512',
				normalStrength: 3.6,
				color(ctx, s, r) {
					ctx.fillStyle = '#6a6156';
					ctx.fillRect(0, 0, s, s);
					// irregular ashlar blocks
					const rows = 9;
					let y = 0;
					for (let row = 0; row < rows; row++) {
						const h = s / rows;
						let x = -r.range(0, 40);
						while (x < s + 40) {
							const w = r.range(28, 78);
							const base = r.range(0.34, 0.58);
							const c = new THREE.Color().setHSL(r.range(0.08, 0.12), r.range(0.06, 0.16), base);
							ctx.fillStyle = '#' + c.getHexString();
							ctx.beginPath();
							ctx.roundRect(x + 2, y + 2, w - 4, h - 4, 2.5);
							ctx.fill();
							ctx.strokeStyle = 'rgba(34,30,26,0.55)';
							ctx.lineWidth = 2.6;
							ctx.stroke();
							// mossy top
							if (r.chance(0.35)) {
								ctx.fillStyle = `rgba(96,116,74,${r.range(0.08, 0.22)})`;
								ctx.fillRect(x + 4, y + 2, w - 8, r.range(3, 7));
							}
							x += w;
						}
						y += s / rows;
					}
					for (let i = 0; i < 2600; i++) {
						ctx.fillStyle = `rgba(30,26,22,${r.range(0.02, 0.1)})`;
						ctx.fillRect(r.range(0, s), r.range(0, s), r.range(1, 5), r.range(1, 3));
					}
				},
				height(ctx, s, r) {
					ctx.fillStyle = '#2c2c2c';
					ctx.fillRect(0, 0, s, s);
					const rows = 9;
					let y = 0;
					for (let row = 0; row < rows; row++) {
						const h = s / rows;
						let x = -r.range(0, 40);
						while (x < s + 40) {
							const w = r.range(28, 78);
							const v = Math.floor(r.range(180, 246));
							ctx.fillStyle = `rgb(${v},${v},${v})`;
							ctx.beginPath();
							ctx.roundRect(x + 3, y + 3, w - 6, h - 6, 3);
							ctx.fill();
							x += w;
						}
						y += s / rows;
					}
				},
			})
		);
	}

	function rockSet() {
		return tset('rock', () =>
			U.surface({
				size: 512,
				seed: 103,
				cacheKey: 'rock512',
				normalStrength: 2.8,
				color(ctx, s, r) {
					const field = U.tileableNoise(s, { period: 5, octaves: 5, seed: 103 });
					const img = ctx.createImageData(s, s);
					for (let i = 0; i < field.length; i++) {
						const v = field[i];
						// strata-ish banding
						const y = Math.floor(i / s);
						const band = Math.sin(y * 0.09 + v * 6) * 0.5 + 0.5;
						const base = new THREE.Color('#6e6258');
						const c = base.clone();
						c.offsetHSL(0, (v - 0.5) * 0.08, (v - 0.5) * 0.28 + (band - 0.5) * 0.08);
						const j = i * 4;
						img.data[j] = c.r * 255;
						img.data[j + 1] = c.g * 255;
						img.data[j + 2] = c.b * 255;
						img.data[j + 3] = 255;
					}
					ctx.putImageData(img, 0, 0);
					// cracks
					ctx.strokeStyle = 'rgba(36,32,28,0.4)';
					ctx.lineWidth = 1.6;
					for (let i = 0; i < 14; i++) {
						let x = r.range(0, s),
							y = r.range(0, s);
						ctx.beginPath();
						ctx.moveTo(x, y);
						for (let k = 0; k < 16; k++) {
							x += r.range(-18, 22);
							y += r.range(-10, 14);
							ctx.lineTo(x, y);
						}
						ctx.stroke();
					}
				},
				height(ctx, s, r) {
					const field = U.tileableNoise(s, { period: 4, octaves: 5, seed: 104 });
					const img = ctx.createImageData(s, s);
					for (let i = 0; i < field.length; i++) {
						const v = field[i] * 255;
						const j = i * 4;
						img.data[j] = img.data[j + 1] = img.data[j + 2] = v;
						img.data[j + 3] = 255;
					}
					ctx.putImageData(img, 0, 0);
				},
			})
		);
	}

	function sandSet() {
		return tset('sand', () =>
			U.surface({
				size: 512,
				seed: 71,
				cacheKey: 'sand512',
				normalStrength: 1.4,
				repeat: [2, 2],
				color(ctx, s, r) {
					ctx.fillStyle = '#d9c49a';
					ctx.fillRect(0, 0, s, s);
					for (let i = 0; i < 16000; i++) {
						const v = r.range(0, 1);
						ctx.fillStyle = v < 0.5 ? `rgba(160,140,105,${r.range(0.06, 0.3)})` : `rgba(244,232,204,${r.range(0.06, 0.3)})`;
						ctx.fillRect(r.range(0, s), r.range(0, s), r.range(0.6, 1.8), r.range(0.6, 1.8));
					}
					// ripples
					for (let i = 0; i < 26; i++) {
						ctx.strokeStyle = `rgba(150,130,98,${r.range(0.05, 0.14)})`;
						ctx.lineWidth = r.range(1, 3);
						ctx.beginPath();
						const y0 = r.range(0, s);
						for (let x = 0; x <= s; x += 12) ctx.lineTo(x, y0 + Math.sin(x * 0.02 + i) * 6);
						ctx.stroke();
					}
				},
				height(ctx, s, r) {
					const field = U.tileableNoise(s, { period: 24, octaves: 3, seed: 72 });
					const img = ctx.createImageData(s, s);
					for (let i = 0; i < field.length; i++) {
						const v = 128 + field[i] * 60;
						const j = i * 4;
						img.data[j] = img.data[j + 1] = img.data[j + 2] = v;
						img.data[j + 3] = 255;
					}
					ctx.putImageData(img, 0, 0);
				},
			})
		);
	}

	function grassSet() {
		return tset('grass', () =>
			U.surface({
				size: 512,
				seed: 91,
				cacheKey: 'grass512',
				normalStrength: 1.5,
				repeat: [1.6, 1.6],
				color(ctx, s, r) {
					const field = U.tileableNoise(s, { period: 6, octaves: 4, seed: 91 });
					const img = ctx.createImageData(s, s);
					for (let i = 0; i < field.length; i++) {
						const v = field[i];
						const c = new THREE.Color().setHSL(0.22 + (v - 0.5) * 0.05, 0.26 + v * 0.12, 0.24 + v * 0.14);
						const j = i * 4;
						img.data[j] = c.r * 255;
						img.data[j + 1] = c.g * 255;
						img.data[j + 2] = c.b * 255;
						img.data[j + 3] = 255;
					}
					ctx.putImageData(img, 0, 0);
					for (let i = 0; i < 9000; i++) {
						const v = r.range(0, 1);
						ctx.strokeStyle = v < 0.5 ? `rgba(122,150,86,${r.range(0.12, 0.4)})` : `rgba(70,92,54,${r.range(0.12, 0.4)})`;
						ctx.lineWidth = 1;
						const x = r.range(0, s),
							y = r.range(0, s);
						ctx.beginPath();
						ctx.moveTo(x, y);
						ctx.lineTo(x + r.range(-2, 2), y - r.range(2, 6));
						ctx.stroke();
					}
				},
				height(ctx, s, r) {
					const field = U.tileableNoise(s, { period: 30, octaves: 2, seed: 92 });
					const img = ctx.createImageData(s, s);
					for (let i = 0; i < field.length; i++) {
						const v = 128 + field[i] * 70;
						const j = i * 4;
						img.data[j] = img.data[j + 1] = img.data[j + 2] = v;
						img.data[j + 3] = 255;
					}
					ctx.putImageData(img, 0, 0);
					for (let i = 0; i < 12000; i++) {
						ctx.fillStyle = `rgb(${Math.floor(r.range(120, 220))},${Math.floor(r.range(120, 220))},${Math.floor(r.range(120, 220))})`;
						ctx.fillRect(r.range(0, s), r.range(0, s), 2, 2);
					}
				},
			})
		);
	}

	function roofTileSet(key, base) {
		return tset(key, () =>
			U.surface({
				size: 512,
				seed: 37,
				cacheKey: key + '512',
				normalStrength: 3.6,
				color(ctx, s, r) {
					const c = new THREE.Color(base);
					ctx.fillStyle = '#' + c.clone().offsetHSL(0, 0, -0.12).getHexString();
					ctx.fillRect(0, 0, s, s);
					const rowH = 30;
					const tileW = 26;
					let row = 0;
					for (let y = -rowH; y < s + rowH; y += rowH) {
						const off = (row % 2) * (tileW / 2);
						for (let x = -tileW; x < s + tileW; x += tileW) {
							const col = c.clone().offsetHSL(0, r.range(-0.05, 0.05), r.range(-0.1, 0.09));
							ctx.fillStyle = '#' + col.getHexString();
							ctx.beginPath();
							ctx.moveTo(x + off, y + rowH);
							ctx.quadraticCurveTo(x + off + tileW / 2, y - rowH * 0.35, x + off + tileW, y + rowH);
							ctx.closePath();
							ctx.fill();
							ctx.strokeStyle = 'rgba(60,30,22,0.28)';
							ctx.lineWidth = 1.5;
							ctx.stroke();
						}
						row++;
					}
					for (let i = 0; i < 1400; i++) {
						ctx.fillStyle = `rgba(60,50,42,${r.range(0.02, 0.1)})`;
						ctx.fillRect(r.range(0, s), r.range(0, s), r.range(2, 10), r.range(2, 5));
					}
				},
				height(ctx, s, r) {
					ctx.fillStyle = '#3c3c3c';
					ctx.fillRect(0, 0, s, s);
					const rowH = 30;
					const tileW = 26;
					let row = 0;
					for (let y = -rowH; y < s + rowH; y += rowH) {
						const off = (row % 2) * (tileW / 2);
						for (let x = -tileW; x < s + tileW; x += tileW) {
							const g = ctx.createLinearGradient(x + off, 0, x + off + tileW, 0);
							g.addColorStop(0, '#5a5a5a');
							g.addColorStop(0.5, '#d0d0d0');
							g.addColorStop(1, '#5a5a5a');
							ctx.fillStyle = g;
							ctx.beginPath();
							ctx.moveTo(x + off, y + rowH);
							ctx.quadraticCurveTo(x + off + tileW / 2, y - rowH * 0.55, x + off + tileW, y + rowH);
							ctx.closePath();
							ctx.fill();
						}
						row++;
					}
				},
			})
		);
	}

	function metalSet(key, base, rusty) {
		return tset(key, () =>
			U.surface({
				size: 512,
				seed: 61,
				cacheKey: key + '512',
				normalStrength: 1.6,
				color(ctx, s, r) {
					ctx.fillStyle = base;
					ctx.fillRect(0, 0, s, s);
					for (let i = 0; i < 6000; i++) {
						const v = r.range(0, 1);
						ctx.strokeStyle = v < 0.5 ? `rgba(255,255,255,${r.range(0.02, 0.07)})` : `rgba(0,0,0,${r.range(0.02, 0.08)})`;
						ctx.lineWidth = r.range(0.5, 1.4);
						const y = r.range(0, s),
							x = r.range(0, s);
						ctx.beginPath();
						ctx.moveTo(x, y);
						ctx.lineTo(x + r.range(10, 90), y + r.range(-1, 1));
						ctx.stroke();
					}
					if (rusty) {
						for (let i = 0; i < 30; i++) {
							const x = r.range(0, s),
								y = r.range(0, s),
								rad = r.range(18, 90);
							const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
							g.addColorStop(0, `rgba(122,58,32,${r.range(0.2, 0.6)})`);
							g.addColorStop(0.6, `rgba(96,50,30,${r.range(0.1, 0.3)})`);
							g.addColorStop(1, 'rgba(0,0,0,0)');
							ctx.fillStyle = g;
							ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2);
						}
						for (let i = 0; i < 300; i++) {
							ctx.fillStyle = `rgba(132,64,36,${r.range(0.1, 0.35)})`;
							ctx.fillRect(r.range(0, s), r.range(0, s), r.range(1, 8), r.range(1, 5));
						}
					}
				},
				height(ctx, s, r) {
					ctx.fillStyle = '#8a8a8a';
					ctx.fillRect(0, 0, s, s);
					for (let i = 0; i < 4000; i++) {
						const v = Math.floor(r.range(110, 160));
						ctx.fillStyle = `rgb(${v},${v},${v})`;
						ctx.fillRect(r.range(0, s), r.range(0, s), r.range(6, 60), 1);
					}
				},
			})
		);
	}

	// ------------------------------------------------------------------
	// material constructors
	// ------------------------------------------------------------------
	function standard(opts) {
		const m = new THREE.MeshStandardMaterial(opts);
		return mark(m);
	}

	function build(key) {
		switch (key) {
			case 'concrete': {
				const t = concreteSet();
				return standard({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, roughness: 0.92, metalness: 0.0, normalScale: new THREE.Vector2(0.6, 0.6), color: 0xffffff });
			}
			case 'concreteDark': {
				const t = concreteSet();
				return standard({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, roughness: 0.95, metalness: 0.0, color: 0x8a877f, normalScale: new THREE.Vector2(0.5, 0.5) });
			}
			case 'asphalt': {
				const t = asphaltSet();
				return standard({ map: t.map, normalMap: t.normalMap, roughness: 0.96, metalness: 0.0, normalScale: new THREE.Vector2(0.4, 0.4) });
			}
			case 'cobble': {
				const t = cobbleSet();
				return standard({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, roughness: 0.9, metalness: 0.02, normalScale: new THREE.Vector2(0.9, 0.9) });
			}
			case 'stoneWall': {
				const t = stoneWallSet();
				return standard({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, roughness: 0.94, metalness: 0.0, normalScale: new THREE.Vector2(0.95, 0.95) });
			}
			case 'brick': {
				const t = brickSet();
				return standard({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, roughness: 0.92, metalness: 0.0, normalScale: new THREE.Vector2(0.9, 0.9) });
			}
			case 'rock': {
				const t = rockSet();
				return standard({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, roughness: 0.96, metalness: 0.0, normalScale: new THREE.Vector2(1.1, 1.1) });
			}
			case 'sand': {
				const t = sandSet();
				return standard({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, roughness: 1.0, metalness: 0.0, normalScale: new THREE.Vector2(0.35, 0.35) });
			}
			case 'grass': {
				const t = grassSet();
				return standard({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, roughness: 0.98, metalness: 0.0, normalScale: new THREE.Vector2(0.5, 0.5) });
			}
			case 'wood': {
				const t = plankSet('plank', '#8a6746', '70,48,30', 43);
				return standard({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, roughness: 0.85, metalness: 0.0, normalScale: new THREE.Vector2(0.7, 0.7) });
			}
			case 'woodLight': {
				const t = plankSet('plankLight', '#b08a5c', '76,52,32', 44);
				return standard({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, roughness: 0.8, metalness: 0.0, normalScale: new THREE.Vector2(0.7, 0.7) });
			}
			case 'woodDark': {
				const t = plankSet('plankDark', '#5b4028', '40,26,16', 45);
				return standard({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, roughness: 0.86, metalness: 0.0, normalScale: new THREE.Vector2(0.7, 0.7) });
			}
			case 'steel': {
				const t = metalSet('steel', '#6d767d', false);
				return standard({ map: t.map, normalMap: t.normalMap, roughness: 0.42, metalness: 0.82, normalScale: new THREE.Vector2(0.4, 0.4) });
			}
			case 'steelDark': {
				const t = metalSet('steelDark', '#4a5157', false);
				return standard({ map: t.map, normalMap: t.normalMap, roughness: 0.5, metalness: 0.75, normalScale: new THREE.Vector2(0.5, 0.5) });
			}
			case 'rusted': {
				const t = metalSet('rusted', '#8a5238', true);
				return standard({ map: t.map, normalMap: t.normalMap, roughness: 0.78, metalness: 0.45, normalScale: new THREE.Vector2(0.8, 0.8) });
			}
			case 'copper': {
				return standard({ color: 0x7d9c84, roughness: 0.5, metalness: 0.7 });
			}
			case 'brass': {
				return standard({ color: 0xc8a24b, roughness: 0.3, metalness: 0.95 });
			}
			case 'glass': {
				return standard({ color: 0x2a3a42, roughness: 0.08, metalness: 0.9, envMapIntensity: 1.6 });
			}
			case 'glassSky': {
				return standard({ color: 0x35505e, roughness: 0.06, metalness: 0.95, envMapIntensity: 2.0 });
			}
			case 'rope': {
				return standard({ color: 0x9b8a6a, roughness: 0.95, metalness: 0 });
			}
			case 'rubber': {
				return standard({ color: 0x24272a, roughness: 0.9, metalness: 0 });
			}
			case 'tar': {
				return standard({ color: 0x2b2c2d, roughness: 0.92, metalness: 0.02 });
			}
			default:
				throw new Error('unknown material: ' + key);
		}
	}

	function get(key) {
		if (!cache.has(key)) cache.set(key, build(key));
		return cache.get(key);
	}

	/** flat paint (houses, cranes, boats) — cached per colour */
	function painted(hex, opts = {}) {
		const key = 'paint:' + hex + ':' + (opts.roughness != null ? opts.roughness : '') + ':' + (opts.metalness != null ? opts.metalness : '');
		if (cache.has(key)) return cache.get(key);
		const m = standard({
			color: new THREE.Color(hex),
			roughness: opts.roughness != null ? opts.roughness : 0.62,
			metalness: opts.metalness != null ? opts.metalness : 0.05,
		});
		cache.set(key, m);
		return m;
	}

	function roofTile(hex) {
		const key = 'roof:' + hex;
		if (cache.has(key)) return cache.get(key);
		const t = roofTileSet(key.replace(':', '-'), hex);
		const m = standard({ map: t.map, normalMap: t.normalMap, roughnessMap: t.roughnessMap, roughness: 0.85, metalness: 0.0, normalScale: new THREE.Vector2(1.0, 1.0) });
		cache.set(key, m);
		return m;
	}

	function emissive(hex, intensity = 1.5) {
		const key = 'emit:' + hex + ':' + intensity;
		if (cache.has(key)) return cache.get(key);
		const m = standard({
			color: new THREE.Color(hex).multiplyScalar(0.18),
			emissive: new THREE.Color(hex),
			emissiveIntensity: intensity,
			roughness: 0.6,
			metalness: 0.0,
		});
		m.userData.baseEmissive = intensity;
		cache.set(key, m);
		return m;
	}

	/** unique clone — geometry-specific material (roughness tweaks etc.) */
	function unique(key, overrides = {}) {
		const m = get(key).clone();
		mark(m);
		for (const k of Object.keys(overrides)) {
			if (k === 'color') m.color = new THREE.Color(overrides[k]);
			else m[k] = overrides[k];
		}
		return m;
	}

	/** apply envMap settings correctly when three manages scene.environment */
	function init() {
		for (const t of texSets.values()) {
			for (const tex of [t.map, t.normalMap, t.roughnessMap]) {
				if (tex) tex.anisotropy = anisotropy;
			}
		}
	}

	H.materials = {
		get,
		painted,
		roofTile,
		emissive,
		unique,
		init,
		surface: (opts) => U.surface(opts),
		texture: (canvas, opts) => U.canvasTex(canvas, opts),
		_palette: P,
	};
})(window.HARBOR);
