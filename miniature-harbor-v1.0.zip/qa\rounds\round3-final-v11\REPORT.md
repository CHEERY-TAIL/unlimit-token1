# QA 自动报告 · 微型港口 MINIATURE HARBOUR

- 轮次: **v1.1-verification**（round=3-final-v11）
- 生成时间: 2026-10-27T03:21:48.414Z
- 总耗时: 337.0s，用例 21 个
- 截图服务: 正常 ✓
- 被测源码: 21 个文件，最后改动 `30-town.js` @ 2026/10/27 11:13:24

## 0. 结论摘要

✅ 本轮无阻塞性错误：所有用例成功出图，无页面/模块错误。

- Draw calls: 最大 **396**（用例 qa-r3-final-v11-v11-view-overview-night），预算 550 → 达标 ✓
- Triangles: 最大 **624K**（用例 qa-r3-final-v11-v11-view-overview-dusk），预算 2.50M → 达标 ✓
- high 画质最低 fps: **39**（用例 qa-r3-final-v11-v11-view-overview-dusk），目标 55 → ⚠ 未达标（无头共享 daemon 下 fps 仅作参考，以真机为准）
- 截图口径: 场景图 = WebGL canvas 原像素（1600×1000 @1.5 DPR → 2400×1500，无 HUD）；HUD / 移动端 / 交互用例 = 整页截图（含 HUD，可能存在 headless 瓦片黑块，仅作 UI 验证）

## 1. 主矩阵（7 视角 × 黄昏/正午/夜晚，high，1600×1000，ui=0，canvas 原像素）

| 视角 / 时间 | view | hour | 画质 | fps | draw | tri | 错误 | 输出像素 | 截图 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

## 2. 画质档位（总览 / 黄昏）

| 画质 | fps | draw calls | triangles | 分辨率 | 错误 | 截图 |
| --- | --- | --- | --- | --- | --- | --- |

## 3. 模块隔离（?only=<模块>，用于错误归因）

| 模块 | only | 出图 | ready | draw | tri | 错误数 | 截图 |
| --- | --- | --- | --- | --- | --- | --- | --- |

## 4. 移动端 / HUD / 冻结 / skip

| 组 | 用例 | 分辨率 | fps | draw | tri | 错误 | 截图 |
| --- | --- | --- | --- | --- | --- | --- | --- |

## 7. 错误明细

✅ 没有错误。

## 8. 全部截图索引

| id | group | capture | 输出像素 | fps | draw | tri | flags | 截图 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| qa-r3-final-v11-v11-view-overview-dusk | v11 | canvas | 2400×1500 | 39 | 395 | 624K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-v11-view-overview-dusk.png` |
| qa-r3-final-v11-v11-view-harbor-dusk | v11 | canvas | 2400×1500 | 39 | 357 | 609K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-v11-view-harbor-dusk.png` |
| qa-r3-final-v11-v11-view-town-dusk | v11 | canvas | 2400×1500 | 48 | 257 | 544K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-v11-view-town-dusk.png` |
| qa-r3-final-v11-v11-view-lighthouse-dusk | v11 | canvas | 2400×1500 | 65 | 337 | 608K | ✅ | `qa/shots/qa-r3-final-v11-v11-view-lighthouse-dusk.png` |
| qa-r3-final-v11-v11-view-marina-dusk | v11 | canvas | 2400×1500 | 45 | 313 | 579K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-v11-view-marina-dusk.png` |
| qa-r3-final-v11-v11-view-quay-dusk | v11 | canvas | 2400×1500 | 47 | 283 | 573K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-v11-view-quay-dusk.png` |
| qa-r3-final-v11-v11-view-top-dusk | v11 | canvas | 2400×1500 | 50 | 370 | 614K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-v11-view-top-dusk.png` |
| qa-r3-final-v11-v11-view-overview-day | v11 | canvas | 2400×1500 | 39 | 389 | 624K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-v11-view-overview-day.png` |
| qa-r3-final-v11-v11-view-overview-night | v11 | canvas | 2400×1500 | 54 | 396 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-v11-view-overview-night.png` |
| qa-r3-final-v11-v11-hud-dusk | v11 | page | 1600×1000 | 41 | 395 | 624K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-v11-hud-dusk.png` |
| qa-r3-final-v11-v11-file-offline | v11 | canvas | 2400×1500 | 60 | 395 | 624K | ✅ | `qa/shots/qa-r3-final-v11-v11-file-offline.png` |
| qa-r3-final-v11-v11-fps-overview-dusk-high | v11 | none | 1600×1000 | 57 | 395 | 624K | ✅ | `qa/shots/qa-r3-final-v11-v11-fps-overview-dusk-high.png` |
| qa-r3-final-v11-v11-fps-overview-night-high | v11 | none | 1600×1000 | 43 | 396 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-v11-fps-overview-night-high.png` |
| qa-r3-final-v11-orbit-000 | orbit | canvas | 2400×1500 | 44 | 395 | 624K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-orbit-000.png` |
| qa-r3-final-v11-orbit-045 | orbit | canvas | 2400×1500 | 39 | 395 | 624K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-orbit-045.png` |
| qa-r3-final-v11-orbit-090 | orbit | canvas | 2400×1500 | 49 | 395 | 624K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-orbit-090.png` |
| qa-r3-final-v11-orbit-135 | orbit | canvas | 2400×1500 | 47 | 395 | 624K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-orbit-135.png` |
| qa-r3-final-v11-orbit-180 | orbit | canvas | 2400×1500 | 57 | 395 | 624K | ✅ | `qa/shots/qa-r3-final-v11-orbit-180.png` |
| qa-r3-final-v11-orbit-225 | orbit | canvas | 2400×1500 | 63 | 395 | 624K | ✅ | `qa/shots/qa-r3-final-v11-orbit-225.png` |
| qa-r3-final-v11-orbit-270 | orbit | canvas | 2400×1500 | 54 | 395 | 624K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-orbit-270.png` |
| qa-r3-final-v11-orbit-315 | orbit | canvas | 2400×1500 | 45 | 395 | 624K | ⚠ low-fps | `qa/shots/qa-r3-final-v11-orbit-315.png` |

---
_本报告由 `qa/run-qa.mjs` 自动生成。预算: draw calls ≤ 550，triangles ≤ 2.50M，high 画质 fps ≥ 55（1600×1000）。_