/**
 * shot.mjs — client for the screenshot daemon.
 * ------------------------------------------------------------------
 * Writes a request into qa/requests, waits for qa/results/<id>.json,
 * prints a compact report. Safe to call from any agent; it never spawns
 * a browser itself (the daemon owns Chrome).
 *
 * Examples:
 *   node tools/shot.mjs --id harbor-overview --url "/index.html?view=overview"
 *   node tools/shot.mjs --id boats-close --url "/index.html?view=marina&t=18.4" --w 1920 --h 1200 --wait 1800
 *   node tools/shot.mjs --id my-view --url "/index.html" --jsfile qa/scripts/my-view.js
 *
 * Exit code 0 when the screenshot was captured (even if the page reported
 * runtime errors — check "pageErrors" in the output), 1 when the daemon is
 * unreachable / timed out.
 */
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';

const ROOT = path.resolve(path.dirname(url.fileURLToPath(import.meta.url)), '..');
const REQ_DIR = path.join(ROOT, 'qa', 'requests');
const RES_DIR = path.join(ROOT, 'qa', 'results');
const STATUS = path.join(ROOT, 'qa', 'daemon-status.json');

function parseArgs(argv) {
	const out = {};
	for (let i = 0; i < argv.length; i++) {
		const a = argv[i];
		if (!a.startsWith('--')) continue;
		const key = a.slice(2);
		const next = argv[i + 1];
		if (next === undefined || next.startsWith('--')) {
			out[key] = true;
		} else {
			out[key] = next;
			i++;
		}
	}
	return out;
}

const args = parseArgs(process.argv.slice(2));
const id = args.id || 'shot-' + Date.now();
const waitMs = Number(args.wait != null ? args.wait : 1200);
const timeoutMs = Number(args.timeout != null ? args.timeout : 90000);

function fail(msg) {
	console.error('SHOT FAIL: ' + msg);
	process.exit(1);
}

// daemon health check (HTTP ping first, heartbeat file as fallback)
async function checkDaemon() {
	try {
		const res = await fetch('http://127.0.0.1:17321/__health', { signal: AbortSignal.timeout(4000) });
		if (res.ok) {
			const body = await res.json();
			if (body && body.ok) return { ok: true, via: 'http' };
		}
	} catch (err) {
		/* fall through to file check */
	}
	try {
		const status = JSON.parse(fs.readFileSync(STATUS, 'utf8'));
		const age = Date.now() - (status.ts || 0);
		if (status && (status.state === 'running' || status.state === 'starting') && age < 10 * 60 * 1000) {
			return { ok: true, via: 'heartbeat', age };
		}
		return { ok: false, reason: `stale heartbeat (state=${status && status.state}, age=${Math.round(age / 1000)}s)` };
	} catch (err) {
		return { ok: false, reason: 'daemon unreachable' };
	}
}
const health = await checkDaemon();
if (!health.ok) {
	fail(`screenshot daemon not alive (${health.reason}) — the Lead must restart: node tools/shoot-daemon.mjs`);
}
if (!fs.existsSync(path.join(ROOT, 'qa'))) fs.mkdirSync(path.join(ROOT, 'qa'));

fs.mkdirSync(REQ_DIR, { recursive: true });
fs.mkdirSync(RES_DIR, { recursive: true });
const resPath = path.join(RES_DIR, id + '.json');
fs.rmSync(resPath, { force: true });

const req = {
	id,
	url: args.url || '/index.html',
	width: Number(args.w || args.width || 1600),
	height: Number(args.h || args.height || 1000),
	wait: waitMs,
	timeout: timeoutMs,
	hideUI: !!args.hideUI,
};
if (args.js) req.js = args.js;
if (args.jsfile) req.jsfile = args.jsfile;
if (args.out) req.out = args.out;
if (args.dpr) req.dpr = Number(args.dpr);
if (args.selector) req.selector = args.selector;
if (args.ready) req.ready = args.ready;
// capture=canvas (default, exact WebGL pixels, no HUD) | page (full page) | both | ui
if (args.capture) req.capture = String(args.capture);

const reqFile = path.join(REQ_DIR, `${Date.now()}-${id}.json`);
fs.writeFileSync(reqFile, JSON.stringify(req, null, 2));

const started = Date.now();
let result = null;
while (Date.now() - started < timeoutMs + 20000) {
	if (fs.existsSync(resPath)) {
		try {
			result = JSON.parse(fs.readFileSync(resPath, 'utf8'));
			break;
		} catch {}
	}
	await new Promise((r) => setTimeout(r, 200));
}

if (!result) {
	try {
		fs.rmSync(reqFile, { force: true });
	} catch {}
	fail('timed out waiting for daemon result');
}

const lines = [];
lines.push(`id=${result.id} ok=${result.ok} ready=${result.ready} ${result.ms}ms`);
if (result.image) lines.push(`image=${result.image}`);
if (result.uiImage) lines.push(`uiImage=${result.uiImage}`);
if (result.capture) lines.push(`capture=${result.capture}`);
if (result.error) lines.push(`error=${result.error}`);
if (result.diagnostics) lines.push('diagnostics=' + JSON.stringify(result.diagnostics));
if (result.pageErrors && result.pageErrors.length) {
	lines.push('pageErrors:');
	for (const e of result.pageErrors.slice(0, 8)) lines.push('  ' + String(e).split('\n')[0]);
}
if (result.console && result.console.length) {
	const bad = result.console.filter((l) => /\[(error|warning)\]/.test(l));
	if (bad.length) {
		lines.push('console warnings/errors:');
		for (const e of bad.slice(0, 12)) lines.push('  ' + e);
	}
}
console.log(lines.join('\n'));

if (args.json) console.log(JSON.stringify(result, null, 2));
process.exit(0);
