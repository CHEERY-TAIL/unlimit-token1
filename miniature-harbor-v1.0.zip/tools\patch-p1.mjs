import fs from 'node:fs';

function patch(file, pairs) {
	let s = fs.readFileSync(file, 'utf8');
	for (const [a, b] of pairs) {
		if (!s.includes(a)) console.warn('[patch] missing in ' + file + ': ' + a.slice(0, 70));
		s = s.split(a).join(b);
	}
	fs.writeFileSync(file, s);
	console.log('[patch] ' + file);
}

// P1 polish: golden hour clearer air + stronger key contrast; noon less bleached.
patch('src/core/env.js', [
	[
		"sun: '#ffc077', sunI: 4.9, hemiSky: '#a7bfd4', hemiGround: '#7c6146', hemiI: 0.76, fog: '#ecc9a4', fogD: 0.0052, night: 0.03, exposure: 1.0, envI: 0.86",
		"sun: '#ffc077', sunI: 5.2, hemiSky: '#a7bfd4', hemiGround: '#7c6146', hemiI: 0.70, fog: '#e3bd92', fogD: 0.0042, night: 0.03, exposure: 1.02, envI: 0.84",
	],
	[
		"sun: '#fff7e8', sunI: 3.9, hemiSky: '#cfe6f7', hemiGround: '#7b7460', hemiI: 1.0, fog: '#dcebee', fogD: 0.005, night: 0.0, exposure: 0.97, envI: 1.1",
		"sun: '#fff7e8', sunI: 4.1, hemiSky: '#cfe6f7', hemiGround: '#7b7460', hemiI: 0.92, fog: '#d6e6ee', fogD: 0.0042, night: 0.0, exposure: 0.94, envI: 1.06",
	],
]);
