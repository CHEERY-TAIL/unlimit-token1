/**
 * 22-lighthouse.js �?breakwater head lighthouse (red & white tower, rotating
 * night beam), Fort Point green entrance beacon, the stone signal tower with
 * its flagpole, and the ruined cliff watchtower on the NE cliffs.
 * OWNER: t2 structures.
 * ----------------------------------------------------------------------
 * Sits on the quay module's breakwater head platform: its paving top is at
 * LEVEL.breakwater + 0.07, so the tower base is placed there.
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const L = H.layout;
	const M = H.materials;
	const PI = Math.PI;
	const TAU = PI * 2;
	// actual terrain height (T1 exposes HARBOR._t1.height; fall back to layout)
	function gh(x, z) {
		const t1 = H._t1;
		return t1 && typeof t1.height === 'function' ? t1.height(x, z) : L.groundHeight(x, z);
	}
	const BW_Y = L.BREAKWATER.crest; // head platform top is +0.07

	function boxG(w, h, d, x, y, z, ry, rx, rz) {
		const g = new THREE.BoxGeometry(w, h, d);
		if (rx) g.rotateX(rx);
		if (rz) g.rotateZ(rz);
		if (ry) g.rotateY(ry);
		g.translate(x, y, z);
		return g;
	}
	function cylG(rt, rb, h, seg, x, y, z, ry, rx, rz) {
		const g = new THREE.CylinderGeometry(rt, rb, h, seg);
		if (rx) g.rotateX(rx);
		if (rz) g.rotateZ(rz);
		if (ry) g.rotateY(ry);
		g.translate(x, y, z);
		return g;
	}
	function tubeG(a, b, radius, seg) {
		const dx = b[0] - a[0],
			dy = b[1] - a[1],
			dz = b[2] - a[2];
		const len = Math.hypot(dx, dy, dz) || 1e-4;
		const g = new THREE.CylinderGeometry(radius, radius, len, seg || 5, 1, false);
		const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(dx / len, dy / len, dz / len));
		g.applyQuaternion(q);
		g.translate((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2);
		return g;
	}
	function mergedMesh(geos, mat, opts) {
		opts = opts || {};
		const m = new THREE.Mesh(U.merge(geos), mat);
		m.castShadow = opts.cast !== false;
		m.receiveShadow = opts.receive !== false;
		if (opts.name) m.name = opts.name;
		return m;
	}
	function sign(text, worldW, color, bg) {
		const t = U.textTexture(text, { font: '700 90px "Segoe UI", "Microsoft YaHei", sans-serif', padding: 24, color: color || '#2a251f', background: bg || 'rgba(0,0,0,0)' });
		const mat = new THREE.MeshBasicMaterial({ map: t.texture, transparent: true, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
		return new THREE.Mesh(new THREE.PlaneGeometry(worldW, worldW / t.aspect), mat);
	}
	function glowTexture() {
		const c = U.createCanvas(128);
		const g = c.getContext('2d');
		const grad = g.createRadialGradient(64, 64, 0, 64, 64, 64);
		grad.addColorStop(0, 'rgba(255,246,220,1)');
		grad.addColorStop(0.25, 'rgba(255,214,150,0.55)');
		grad.addColorStop(1, 'rgba(255,190,120,0)');
		g.fillStyle = grad;
		g.fillRect(0, 0, 128, 128);
		return U.canvasTex(c, { srgb: true, cacheKey: 't2lightglow' });
	}

	H.register('lighthouse', {
		create(ctx) {
			const g = ctx.group('lighthouse');
			const rng = U.rng(3311);

			// ---------------- materials ----------------
			const stone = M.unique('stoneWall', { color: 0x9c917f });
			const stoneDark = M.unique('stoneWall', { color: 0x7f7566 });
			const concrete = M.get('concrete');
			const iron = M.get('rusted');
			const steelDark = M.get('steelDark');
			const brass = M.get('brass');
			const rubber = M.get('rubber');
			const redPaint = M.painted('#a3473c', { roughness: 0.68, metalness: 0.06 });
			const creamPaint = M.painted('#d9ceb5', { roughness: 0.72, metalness: 0.04 });
			const greenPaint = M.painted('#2f6b52', { roughness: 0.55, metalness: 0.15 });
			const domePaint = M.painted('#7c4234', { roughness: 0.45, metalness: 0.35 });
			const darkPaint = M.painted('#33342f', { roughness: 0.7 });
			const lampMat = M.emissive('#ffdca6', 0.2);
			const greenLampMat = M.emissive('#57b98a', 0.06);
			const glassMat = new THREE.MeshStandardMaterial({ color: 0x2b3b42, roughness: 0.12, metalness: 0.55, emissive: new THREE.Color('#ffd9a0'), emissiveIntensity: 0.0 });
			const greenGlassMat = new THREE.MeshStandardMaterial({ color: 0x1e4a38, roughness: 0.15, metalness: 0.4, emissive: new THREE.Color('#57b98a'), emissiveIntensity: 0.0 });
			const woodDark = M.get('woodDark');
			const ivyMat = M.painted('#4e6338', { roughness: 0.95 });
			const glowTex = glowTexture();
			const nightLights = [];
			const anims = [];

			// ==================================================================
			// 1. BREAKWATER HEAD LIGHTHOUSE
			// ==================================================================
			const lx = L.BREAKWATER.lighthouse[0],
				lz = L.BREAKWATER.lighthouse[1];
			const baseY = BW_Y + 0.07;
			const lh = U.group(g, 'breakwater-lighthouse');
			const stoneG = [],
				redG = [],
				creamG = [],
				ironG = [],
				brassG = [];
			// stone base ring + steps
			stoneG.push(cylG(0.44, 0.5, 0.24, 16, lx, baseY + 0.12, lz));
			stoneG.push(cylG(0.4, 0.4, 0.05, 16, lx, baseY + 0.26, lz));
			// door direction = towards the walkway (north-west)
			const doorAng = Math.atan2(-0.32, -0.25);
			// tower bands: taper 0.30 -> 0.20 over 5 bands
			const BANDS = 5,
				BAND_H = 0.36,
				y0 = baseY + 0.26;
			for (let i = 0; i < BANDS; i++) {
				const rb = U.lerp(0.3, 0.2, i / BANDS);
				const rt = U.lerp(0.3, 0.2, (i + 1) / BANDS);
				const mat = i % 2 === 0 ? redG : creamG;
				mat.push(cylG(rt, rb, BAND_H, 20, lx, y0 + BAND_H * i + BAND_H / 2, lz));
				// joint ring
				ironG.push(cylG(rt + 0.02, rt + 0.02, 0.04, 20, lx, y0 + BAND_H * (i + 1), lz));
				// window slits on white bands
				if (i % 2 === 1) {
					for (const a of [doorAng + PI * 0.55, doorAng - PI * 0.62]) {
						stoneG.push(boxG(0.05, 0.11, 0.025, lx + Math.sin(a) * (rb + 0.004), y0 + BAND_H * i + BAND_H * 0.55, lz + Math.cos(a) * (rb + 0.004), a));
					}
				}
			}
			const towerTop = y0 + BAND_H * BANDS;
			// maintenance door + steps
			stoneG.push(boxG(0.17, 0.3, 0.06, lx + Math.sin(doorAng) * 0.31, baseY + 0.17, lz + Math.cos(doorAng) * 0.31, doorAng));
			stoneG.push(boxG(0.14, 0.24, 0.02, lx + Math.sin(doorAng) * 0.335, baseY + 0.16, lz + Math.cos(doorAng) * 0.335, doorAng));
			// nameplate
			const plate = sign('LT-01  HARBOUR', 0.34, '#e9dfc8', '#3a3330');
			plate.position.set(lx + Math.sin(doorAng) * 0.325, baseY + 0.34, lz + Math.cos(doorAng) * 0.325);
			plate.rotation.y = doorAng;
			lh.add(plate);
			// gallery deck + brackets
			const gallery = y0 + BAND_H * BANDS + 0.02;
			ironG.push(cylG(0.31, 0.31, 0.045, 20, lx, gallery, lz));
			for (let i = 0; i < 8; i++) {
				const a = (i / 8) * TAU;
				ironG.push(boxG(0.1, 0.1, 0.14, lx + Math.sin(a) * 0.26, gallery - 0.07, lz + Math.cos(a) * 0.26, a));
			}
			// gallery railing
			for (let i = 0; i < 14; i++) {
				const a = (i / 14) * TAU;
				ironG.push(cylG(0.008, 0.008, 0.22, 4, lx + Math.sin(a) * 0.29, gallery + 0.11, lz + Math.cos(a) * 0.29));
			}
			ironG.push(new THREE.TorusGeometry(0.29, 0.009, 4, 24).rotateX(PI / 2).translate(lx, gallery + 0.22, lz));
			ironG.push(new THREE.TorusGeometry(0.29, 0.006, 4, 24).rotateX(PI / 2).translate(lx, gallery + 0.12, lz));
			// lamp room
			const lampBase = gallery + 0.03;
			ironG.push(cylG(0.17, 0.17, 0.03, 16, lx, lampBase + 0.015, lz));
			const glassRoom = new THREE.Mesh(new THREE.CylinderGeometry(0.148, 0.155, 0.27, 16), glassMat);
			glassRoom.position.set(lx, lampBase + 0.17, lz);
			glassRoom.castShadow = false;
			lh.add(glassRoom);
			// mullions + rings
			for (let i = 0; i < 10; i++) {
				const a = (i / 10) * TAU;
				brassG.push(boxG(0.014, 0.27, 0.014, lx + Math.sin(a) * 0.152, lampBase + 0.17, lz + Math.cos(a) * 0.152, a));
			}
			brassG.push(cylG(0.16, 0.16, 0.018, 16, lx, lampBase + 0.045, lz));
			brassG.push(cylG(0.155, 0.155, 0.018, 16, lx, lampBase + 0.3, lz));
			// lamp + dome + ventilator
			const lampY = lampBase + 0.17;
			const lampCore = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), lampMat);
			lampCore.position.set(lx, lampY, lz);
			lh.add(lampCore);
			const dome = new THREE.Mesh(new THREE.SphereGeometry(0.165, 16, 10, 0, TAU, 0, PI / 2), domePaint);
			dome.position.set(lx, lampBase + 0.32, lz);
			dome.castShadow = true;
			lh.add(dome);
			brassG.push(cylG(0.02, 0.02, 0.16, 6, lx, lampBase + 0.53, lz));
			brassG.push(new THREE.SphereGeometry(0.035, 8, 6).translate(lx, lampBase + 0.44, lz));
			brassG.push(cylG(0.006, 0.012, 0.3, 4, lx, lampBase + 0.7, lz));
			// lightning rod tip glow
			// access ladder up the seaward face
			const ladAng = doorAng + PI * 0.92;
			for (const s of [-1, 1]) ironG.push(cylG(0.012, 0.012, 2.3, 4, lx + Math.sin(ladAng) * 0.3 + Math.cos(ladAng) * s * 0.07, baseY + 1.3, lz + Math.cos(ladAng) * 0.3 - Math.sin(ladAng) * s * 0.07));
			for (let k = 0; k < 11; k++) ironG.push(boxG(0.14, 0.016, 0.016, lx + Math.sin(ladAng) * 0.3, baseY + 0.3 + k * 0.2, lz + Math.cos(ladAng) * 0.3, ladAng));
			// rust streaks below gallery
			const rustG = [];
			for (let i = 0; i < 7; i++) {
				const a = rng.range(0, TAU);
				const h = rng.range(0.2, 0.5);
				const gq = new THREE.PlaneGeometry(rng.range(0.025, 0.07), h);
				gq.rotateY(a);
				gq.translate(lx + Math.sin(a) * 0.245, gallery - 0.12 - h / 2, lz + Math.cos(a) * 0.245);
				rustG.push(gq);
			}
			lh.add(mergedMesh(stoneG, stone, { name: 'lh-stone', cast: true, receive: true }));
			lh.add(mergedMesh(redG, redPaint, { name: 'lh-red', cast: true, receive: true }));
			lh.add(mergedMesh(creamG, creamPaint, { name: 'lh-cream', cast: true, receive: true }));
			lh.add(mergedMesh(ironG, iron, { name: 'lh-iron', cast: false, receive: true }));
			lh.add(mergedMesh(brassG, brass, { name: 'lh-brass', cast: false, receive: false }));
			lh.add(mergedMesh(rustG, M.painted('#7b4a33', { roughness: 0.9 }), { name: 'lh-rust', cast: false, receive: false }));

			// --- rotating searchlight (t5-atmosphere provides the visible light
			// shaft; we only swing the real spot light inside the lantern so the
			// two never double up) ---
			const beamGroup = U.group(lh, 'beam');
			beamGroup.position.set(lx, lampY, lz);
			// glow sprite at the lantern
			const glowSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, color: 0xffe6bb, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, fog: false, toneMapped: false }));
			glowSprite.position.set(lx, lampY, lz);
			glowSprite.scale.setScalar(0.75);
			lh.add(glowSprite);
			// spotlight riding the beam (child of the rotating group)
			const spot = new THREE.SpotLight(0xffdca6, 0, 24, 0.1, 0.6, 1.2);
			spot.position.set(0, 0, 0);
			spot.target.position.set(0, -0.9, 5);
			beamGroup.add(spot);
			beamGroup.add(spot.target);
			const lampLight = new THREE.PointLight(0xffd9a0, 0, 12, 1.6);
			lampLight.position.set(lx, lampY, lz);
			lh.add(lampLight);
			anims.push({ beamGroup, spot, lampLight, glowSprite, phase: 0 });

			// ---- lighthouse head dressing: toolbox, hand lantern, capstan, door light
			{
				const dress = [];
				const dx0 = Math.sin(doorAng) * 0.62,
					dz0 = Math.cos(doorAng) * 0.62;
				dress.push(boxG(0.12, 0.05, 0.06, lx + dx0, baseY + 0.06, lz + dz0, doorAng));
				dress.push(boxG(0.13, 0.012, 0.065, lx + dx0, baseY + 0.09, lz + dz0, doorAng));
				dress.push(new THREE.TorusGeometry(0.07, 0.013, 4, 12).rotateX(PI / 2).translate(lx + dx0 * 1.35, baseY + 0.013, lz + dz0 * 1.35));
				const capAng = doorAng + PI * 0.75;
				const cxp = lx + Math.sin(capAng) * 0.72,
					czp = lz + Math.cos(capAng) * 0.72;
				dress.push(cylG(0.09, 0.11, 0.16, 10, cxp, baseY + 0.08, czp));
				dress.push(new THREE.TorusGeometry(0.11, 0.02, 4, 12).rotateX(PI / 2).translate(cxp, baseY + 0.17, czp));
				g.add(mergedMesh(dress, iron, { name: 'lh-head-gear', cast: true, receive: true }));
				// a hand lantern left on the platform edge
				const lamAng = doorAng - PI * 0.5;
				const lx2 = lx + Math.sin(lamAng) * 0.85,
					lz2 = lz + Math.cos(lamAng) * 0.85;
				g.add(mergedMesh([cylG(0.028, 0.035, 0.05, 8, lx2, baseY + 0.03, lz2), cylG(0.02, 0.02, 0.09, 6, lx2, baseY + 0.1, lz2)], iron, { name: 'lh-hand-lantern', cast: true, receive: true }));
				const lGlass = new THREE.Mesh(new THREE.SphereGeometry(0.032, 8, 6), lampMat);
				lGlass.position.set(lx2, baseY + 0.075, lz2);
				lh.add(lGlass);
				// warm lamp above the maintenance door (night)
				const doorLampMat = M.emissive('#ffb45c', 0.2);
				const dLamp = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.045, 0.045), doorLampMat);
				dLamp.position.set(lx + Math.sin(doorAng) * 0.37, baseY + 0.44, lz + Math.cos(doorAng) * 0.37);
				lh.add(dLamp);
				const doorLight = new THREE.PointLight(0xffb066, 0, 3.4, 2);
				doorLight.position.copy(dLamp.position);
				lh.add(doorLight);
				anims.push({ doorLight, doorLampMat });
			}

			// ==================================================================
			// 2. FORT POINT GREEN ENTRANCE BEACON (on a stone pier head)
			// ==================================================================
			const bx = L.ANCHORS.beaconGreen.pos[0],
				bz = L.ANCHORS.beaconGreen.pos[1];
			const beacon = U.group(g, 'beacon-green');
			const bStone = [],
				bWhite = [],
				bGreen = [],
				bIron = [],
				bBrass = [];
			// stone pier head out of the water
			bStone.push(cylG(0.32, 0.52, 4.3, 12, bx, -1.35, bz));
			bStone.push(cylG(0.36, 0.32, 0.12, 12, bx, 0.78, bz));
			bStone.push(cylG(0.28, 0.28, 0.1, 12, bx, 0.89, bz));
			// rubble mound around the base
			const rockGeos = [];
			const rockBase = new THREE.DodecahedronGeometry(0.4, 0);
			for (let i = 0; i < 14; i++) {
				const a = rng.range(0, TAU);
				const r = rng.range(0.45, 1.0);
				const rg = rockBase.clone();
				rg.scale(rng.range(0.6, 1.15), rng.range(0.45, 0.85), rng.range(0.6, 1.15));
				rg.rotateY(rng.range(0, TAU));
				rg.translate(bx + Math.cos(a) * r, rng.range(-1.1, -0.2), bz + Math.sin(a) * r);
				rockGeos.push(rg);
			}
			g.add(mergedMesh(rockGeos, M.get('rock'), { name: 'beacon-rocks', cast: true, receive: true }));
			const bTop = 0.94;
			// white tapered tower with a green band
			bWhite.push(cylG(0.1, 0.13, 0.66, 14, bx, bTop + 0.33, bz));
			bGreen.push(cylG(0.105, 0.105, 0.1, 14, bx, bTop + 0.68, bz));
			// gallery + lantern cage
			bIron.push(cylG(0.17, 0.17, 0.03, 14, bx, bTop + 0.77, bz));
			for (let i = 0; i < 10; i++) {
				const a = (i / 10) * TAU;
				bIron.push(cylG(0.006, 0.006, 0.17, 3, bx + Math.sin(a) * 0.16, bTop + 0.86, bz + Math.cos(a) * 0.16));
			}
			bIron.push(new THREE.TorusGeometry(0.16, 0.008, 4, 16).rotateX(PI / 2).translate(bx, bTop + 0.94, bz));
			bIron.push(new THREE.TorusGeometry(0.16, 0.007, 4, 16).rotateX(PI / 2).translate(bx, bTop + 0.8, bz));
			const greenRoom = new THREE.Mesh(new THREE.CylinderGeometry(0.082, 0.088, 0.15, 12), greenGlassMat);
			greenRoom.position.set(bx, bTop + 0.87, bz);
			beacon.add(greenRoom);
			for (let i = 0; i < 6; i++) {
				const a = (i / 6) * TAU;
				bBrass.push(boxG(0.01, 0.15, 0.01, bx + Math.sin(a) * 0.086, bTop + 0.87, bz + Math.cos(a) * 0.086, a));
			}
			// dome + finial
			const bDome = new THREE.Mesh(new THREE.SphereGeometry(0.098, 12, 8, 0, TAU, 0, PI / 2), greenPaint);
			bDome.position.set(bx, bTop + 0.945, bz);
			beacon.add(bDome);
			bBrass.push(cylG(0.012, 0.018, 0.14, 5, bx, bTop + 1.08, bz));
			bBrass.push(new THREE.SphereGeometry(0.022, 6, 5).translate(bx, bTop + 1.0, bz));
			// ladder on the seaward side
			for (const s of [-1, 1]) bIron.push(cylG(0.008, 0.008, 0.85, 4, bx + 0.15 + s * 0.045, bTop + 0.4, bz + 0.1));
			for (let k = 0; k < 5; k++) bIron.push(boxG(0.1, 0.01, 0.01, bx + 0.15, bTop + 0.15 + k * 0.15, bz + 0.1));
			beacon.add(mergedMesh(bStone, stoneDark, { name: 'beacon-stone', cast: true, receive: true }));
			beacon.add(mergedMesh(bWhite, creamPaint, { name: 'beacon-white', cast: true, receive: true }));
			beacon.add(mergedMesh(bGreen, greenPaint, { name: 'beacon-band', cast: true, receive: true }));
			beacon.add(mergedMesh(bIron, steelDark, { name: 'beacon-iron', cast: false, receive: false }));
			beacon.add(mergedMesh(bBrass, brass, { name: 'beacon-brass', cast: false, receive: false }));
			// green light + glow
			const gCore = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), greenLampMat);
			gCore.position.set(bx, bTop + 0.87, bz);
			beacon.add(gCore);
			const gGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, color: 0x6cffb0, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, fog: false, toneMapped: false }));
			gGlow.position.set(bx, bTop + 0.87, bz);
			gGlow.scale.setScalar(0.9);
			beacon.add(gGlow);
			const gLight = new THREE.PointLight(0x57b98a, 0, 7, 1.8);
			gLight.position.set(bx, bTop + 0.9, bz);
			beacon.add(gLight);
			// sign on the plinth
			const bSign = sign('ENTRANCE', 0.3, '#e9dfc8', '#2f4a3c');
			bSign.position.set(bx + 0.33, 0.98, bz + 0.05);
			bSign.rotation.y = PI / 2 + 0.4;
			beacon.add(bSign);

			// ==================================================================
			// 3. FORT POINT SIGNAL TOWER + RAMPART + FLAGPOLE
			// ==================================================================
			const fx = L.ANCHORS.fortTower.pos[0],
				fz = L.ANCHORS.fortTower.pos[1];
			const fy = gh(fx, fz);
			const fort = U.group(g, 'signal-tower');
			const fStone = [],
				fStoneDark = [],
				fIron = [],
				fWood = [],
				fGlass = [];
			// rampart ring with a gap towards the harbour
			const ringR = 0.84,
				segN = 26,
				gapA = Math.atan2(-0.55, 1.0);
			for (let i = 0; i < segN; i++) {
				const a = (i / segN) * TAU;
				// gap towards the harbour + a second gate towards the fort road
				let da = Math.abs(((a - gapA + PI) % TAU) - PI);
				const da2 = Math.abs(((a - (gapA + PI * 0.85) + PI) % TAU) - PI);
				if (da < 0.22 || da2 < 0.16) continue;
				const wx = fx + Math.sin(a) * ringR,
					wz = fz + Math.cos(a) * ringR;
				fStoneDark.push(boxG(0.3, 0.42, 0.2, wx, fy + 0.21, wz, a));
				// merlons on every other segment
				if (i % 2 === 0) fStone.push(boxG(0.24, 0.16, 0.18, wx, fy + 0.5, wz, a));
			}
			// central drum tower
			fStone.push(cylG(0.34, 0.42, 1.62, 8, fx, fy + 0.81, fz));
			fStone.push(cylG(0.38, 0.38, 0.09, 8, fx, fy + 0.045, fz));
			// crenellated top
			for (let i = 0; i < 8; i++) {
				const a = (i / 8) * TAU;
				fStoneDark.push(boxG(0.16, 0.18, 0.12, fx + Math.sin(a) * 0.32, fy + 1.7, fz + Math.cos(a) * 0.32, a));
			}
			fStoneDark.push(cylG(0.3, 0.3, 0.08, 8, fx, fy + 1.65, fz));
			// arched door facing the harbour
			const doorA = Math.atan2(-0.3, 0.95);
			fStoneDark.push(boxG(0.18, 0.32, 0.06, fx + Math.sin(doorA) * 0.38, fy + 0.2, fz + Math.cos(doorA) * 0.38, doorA));
			fIron.push(boxG(0.14, 0.28, 0.02, fx + Math.sin(doorA) * 0.41, fy + 0.18, fz + Math.cos(doorA) * 0.41, doorA));
			// window slits
			for (const a of [doorA + 1.6, doorA - 1.9, doorA + PI]) fIron.push(boxG(0.05, 0.12, 0.02, fx + Math.sin(a) * 0.37, fy + 0.95, fz + Math.cos(a) * 0.37, a));
			// small flag staff + pennant
			const fBrass = [];
			fBrass.push(cylG(0.018, 0.024, 1.2, 6, fx, fy + 2.32, fz));
			fBrass.push(new THREE.SphereGeometry(0.035, 8, 6).translate(fx, fy + 2.94, fz));
			fort.add(mergedMesh(fStone, stone, { name: 'fort-stone', cast: true, receive: true }));
			fort.add(mergedMesh(fStoneDark, stoneDark, { name: 'fort-dark', cast: true, receive: true }));
			fort.add(mergedMesh(fIron, iron, { name: 'fort-iron', cast: false, receive: false }));
			fort.add(mergedMesh(fBrass, brass, { name: 'flag-staff', cast: false, receive: false }));
			// pennant (animated)
			const flag = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.14, 4, 1), M.painted('#b3453b', { roughness: 0.8, side: THREE.DoubleSide }));
			flag.position.set(fx + 0.19, fy + 2.76, fz);
			flag.material.side = THREE.DoubleSide;
			fort.add(flag);
			// small lantern by the gate
			const fLantern = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.08, 0.06), lampMat);
			fLantern.position.set(fx + Math.sin(doorA) * 0.52, fy + 0.62, fz + Math.cos(doorA) * 0.52);
			fort.add(fLantern);
			const fLight = new THREE.PointLight(0xffd9a0, 0, 3.5, 2);
			fLight.position.copy(fLantern.position);
			fort.add(fLight);
			anims.push({ flag, gLight, gGlow, fLight });
			// flagpole pennant sway
			anims.push({ flagSway: true, flag });

			// ==================================================================
			// 4. NE CLIFF WATCHTOWER RUIN
			// ==================================================================
			const wx = L.ANCHORS.watchtower.pos[0],
				wz = L.ANCHORS.watchtower.pos[1];
			// sample the cliff top so the ruin is planted, not floating
			let wyMin = Infinity,
				wyMax = -Infinity;
			for (let i = 0; i < 12; i++) {
				const a = (i / 12) * TAU;
				const hh = gh(wx + Math.cos(a) * 0.62, wz + Math.sin(a) * 0.62);
				wyMin = Math.min(wyMin, hh);
				wyMax = Math.max(wyMax, hh);
			}
			const wy = Math.min(wyMin, gh(wx, wz)) - 0.02;
			const ruin = U.group(g, 'watchtower-ruin');
			const rStone = [],
				rDark = [],
				rIvy = [],
				rWood = [];
			// rubble plinth: tall enough to swallow the slope
			const plinthH = 0.38 + Math.max(0, wyMax - wy);
			rDark.push(cylG(0.72, 0.86, plinthH, 12, wx, wy + plinthH / 2, wz));
			const plinthTop = wy + plinthH;
			// broken circular wall, 18 segments with variable heights
			const wallR = 0.56,
				NS = 18;
			const doorSeg = 3; // gap for the arched doorway
			for (let i = 0; i < NS; i++) {
				if (i === doorSeg) continue;
				const a = (i / NS) * TAU;
				const h = (i % 4 === 0 ? 0.55 : i % 3 === 0 ? 1.15 : 1.55) + rng.range(-0.16, 0.16);
				if (i === 7) continue; // collapsed section
				const sx = wx + Math.sin(a) * wallR,
					sz = wz + Math.cos(a) * wallR;
				rStone.push(boxG(0.21, h, 0.18, sx, plinthTop + h / 2, sz, a));
				if (i % 3 === 1) rStone.push(boxG(0.16, 0.12, 0.15, sx, plinthTop + h + 0.05, sz, a + 0.2));
			}
			// arched doorway header (3 blocks)
			{
				const a = (doorSeg / NS) * TAU;
				const dx = wx + Math.sin(a) * wallR,
					dz = wz + Math.cos(a) * wallR;
				rStone.push(boxG(0.2, 0.14, 0.2, dx + Math.sin(a + 0.35) * 0.1, plinthTop + 0.75, dz + Math.cos(a + 0.35) * 0.1, a));
				rStone.push(boxG(0.2, 0.14, 0.2, dx - Math.sin(a + 0.35) * 0.1, plinthTop + 0.75, dz - Math.cos(a + 0.35) * 0.1, a));
				rStone.push(boxG(0.2, 0.12, 0.22, dx, plinthTop + 0.88, dz, a));
				rDark.push(boxG(0.24, 0.6, 0.02, dx, plinthTop + 0.42, dz, a));
			}
			// collapsed wall slab on the ground
			{
				const a = (7 / NS) * TAU;
				const sx = wx + Math.sin(a) * (wallR + 0.5),
					sz = wz + Math.cos(a) * (wallR + 0.5);
				rStone.push(boxG(0.9, 0.16, 0.22, sx, plinthTop, sz, a + 0.3, 0, 0.22));
			}
			// rubble
			for (let i = 0; i < 9; i++) {
				const a = rng.range(0, TAU);
				const r = rng.range(0.7, 1.1);
				rStone.push(boxG(rng.range(0.1, 0.24), rng.range(0.08, 0.16), rng.range(0.1, 0.2), wx + Math.cos(a) * r, plinthTop, wz + Math.sin(a) * r, rng.range(0, TAU), rng.range(0, 0.4), rng.range(0, 0.4)));
			}
			// broken floor beams
			for (const [ox, oz, len] of [
				[0.1, -0.1, 0.5],
				[-0.2, 0.15, 0.35],
			]) rWood.push(boxG(len, 0.05, 0.08, wx + ox, plinthTop + 1.1, wz + oz, rng.range(0, TAU), 0, rng.range(-0.2, 0.2)));
			// ivy patches climbing the wall
			for (let i = 0; i < 12; i++) {
				const a = rng.range(0, TAU);
				const h = rng.range(0.25, 1.2);
				const gq = new THREE.PlaneGeometry(rng.range(0.12, 0.3), rng.range(0.15, 0.4));
				gq.rotateY(a);
				gq.translate(wx + Math.sin(a) * (wallR + 0.01), plinthTop + 0.05 + h, wz + Math.cos(a) * (wallR + 0.01));
				rIvy.push(gq);
			}
			ruin.add(mergedMesh(rStone, stone, { name: 'ruin-stone', cast: true, receive: true }));
			ruin.add(mergedMesh(rDark, stoneDark, { name: 'ruin-dark', cast: true, receive: true }));
			ruin.add(mergedMesh(rWood, woodDark, { name: 'ruin-beams', cast: true, receive: true }));
			ruin.add(mergedMesh(rIvy, ivyMat, { name: 'ruin-ivy', cast: false, receive: false }));
			// a lonely lantern on the broken wall (optional warm accent at night)
			const rLight = new THREE.PointLight(0xffc98a, 0, 3, 2);
			rLight.position.set(wx + 0.55, plinthTop + 1.0, wz + 0.3);
			ruin.add(rLight);

			// ==================================================================
			// NIGHT
			// ==================================================================
			function onEnv(state) {
				const n = state.night || 0;
				lampMat.emissiveIntensity = 0.15 + n * 3.6;
				greenLampMat.emissiveIntensity = 0.02 + n * 1.2;
				glassMat.emissiveIntensity = n * 0.55;
				greenGlassMat.emissiveIntensity = n * 0.4;
				for (const an of anims) {
					if (an.doorLight) {
						an.doorLight.intensity = n * 1.8;
						an.doorLampMat.emissiveIntensity = 0.15 + n * 3.2;
					}
					if (an.gLight) an.gLight.intensity = n * 0.6;
					if (an.gGlow) an.gGlow.material.opacity = n * 0.85;
					if (an.fLight) an.fLight.intensity = n * 1.3;
				}
				if (rLight) rLight.intensity = n * 1.6;
			}
			if (ctx.env && ctx.env.onEnv) ctx.env.onEnv(onEnv);

			return {
				update(dt, t) {
					for (const an of anims) {
						if (an.beamGroup) {
							an.beamGroup.rotation.y = t * 0.62;
							// slow double flash
							const pulse = Math.pow(Math.max(0, Math.sin(t * 1.15 + 0.4)), 5);
							const night = ctx.env && ctx.env.state ? ctx.env.state.night : 0;
							an.spot.intensity = night * (5.76 * pulse + 1.08);
							an.lampLight.intensity = night * (2 + 3 * pulse);
							an.glowSprite.material.opacity = night * (0.28 + 0.32 * pulse);
						}
						if (an.flagSway) {
							an.flag.rotation.y = Math.sin(t * 1.7) * 0.22;
							an.flag.rotation.x = Math.sin(t * 2.3) * 0.06;
						}
					}
				},
				onEnv,
			};
		},
	});
})(window.HARBOR);
