/**
 * render.js — renderer, post-processing chain and quality levels.
 * ==================================================================
 * Chain:  scene -> RenderPass -> UnrealBloom -> OutputPass -> DioramaPass
 * DioramaPass does the "miniature" look: gentle tilt-shift blur towards
 * the top/bottom of the frame, subtle chromatic aberration, a custom
 * teal-warm grade, vignette and animated film grain.
 *
 * Exposed:
 *   H.render.init(ctx)
 *   H.render.renderer / composer / quality
 *   H.render.setQuality('high'|'medium'|'low')
 *   H.render.onQuality(cb)
 *   H.render.render(dt, time)
 *   H.render.stats()
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const ADDONS = H.ADDONS;

	const QUALITY = {
		high: {
			id: 'high',
			label: '高',
			pixelRatio: 1.5,
			msaa: 4,
			shadowMap: 2048,
			bloom: true,
			bloomStrength: 0.24,
			bloomRadius: 0.72,
			bloomThreshold: 0.88,
			tilt: true,
			tiltBlur: 1.15,
			reflection: 1536,
			reflectionEnabled: true,
			grain: 0.024,
		},
		medium: {
			id: 'medium',
			label: '中',
			pixelRatio: 1.15,
			msaa: 2,
			shadowMap: 1536,
			bloom: true,
			bloomStrength: 0.24,
			bloomRadius: 0.6,
			bloomThreshold: 0.85,
			tilt: true,
			tiltBlur: 1.45,
			reflection: 512,
			reflectionEnabled: true,
			grain: 0.02,
		},
		low: {
			id: 'low',
			label: '低',
			pixelRatio: 1,
			msaa: 0,
			shadowMap: 1024,
			bloom: false,
			bloomStrength: 0,
			tilt: false,
			tiltBlur: 0,
			reflection: 0,
			reflectionEnabled: false,
			grain: 0.016,
		},
	};

	const DIORAMA_SHADER = {
		uniforms: {
			tDiffuse: { value: null },
			uResolution: { value: new THREE.Vector2(1, 1) },
			uTime: { value: 0 },
			uTiltBlur: { value: 1.15 },
			uFocus: { value: 0.54 },
			uBand: { value: 0.33 },
			uVignette: { value: 0.5 },
			uGrain: { value: 0.022 },
			uCA: { value: 0.9 },
			uSaturation: { value: 1.27 },
			uContrast: { value: 1.12 },
			uWarmth: { value: 0.012 },
		},
		vertexShader: `
			varying vec2 vUv;
			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
			}
		`,
		fragmentShader: `
			uniform sampler2D tDiffuse;
			uniform vec2 uResolution;
			uniform float uTime;
			uniform float uTiltBlur;
			uniform float uFocus;
			uniform float uBand;
			uniform float uVignette;
			uniform float uGrain;
			uniform float uCA;
			uniform float uSaturation;
			uniform float uContrast;
			uniform float uWarmth;
			varying vec2 vUv;

			float hash(vec2 p) {
				p = fract(p * vec2(123.34, 456.21));
				p += dot(p, p + 45.32);
				return fract(p.x * p.y);
			}

			void main() {
				vec2 uv = vUv;
				vec2 px = 1.0 / uResolution;

				// --- miniature depth of field (screen-space tilt-shift) ---
				float d = abs(uv.y - uFocus);
				float blurAmt = smoothstep(uBand, uBand + 0.36, d);
				float radius = blurAmt * blurAmt * uTiltBlur;
				vec3 col;
				if (radius > 0.06) {
					col = vec3(0.0);
					float wsum = 0.0;
					for (int i = 0; i < 12; i++) {
						float fi = float(i);
						float a = fi * 2.39996323;
						float rr = sqrt((fi + 0.5) / 12.0);
						vec2 off = vec2(cos(a), sin(a)) * rr * radius * px;
						float w = 1.0 - rr * 0.45;
						col += texture2D(tDiffuse, uv + off).rgb * w;
						wsum += w;
					}
					col /= wsum;
					// keep the sharp image visible in the middle of the blur
					vec3 sharp = texture2D(tDiffuse, uv).rgb;
					col = mix(sharp, col, smoothstep(0.0, 1.0, blurAmt));
				} else {
					col = texture2D(tDiffuse, uv).rgb;
				}

				// --- chromatic aberration (stronger towards the edges) ---
				float edge = length(uv - 0.5);
				float ca = uCA * 0.0006 * (0.25 + edge * 1.6) * px.x / (1.0 / 1600.0);
				if (uCA > 0.01) {
					col.r = mix(col.r, texture2D(tDiffuse, uv + vec2(ca, 0.0) * px).r, 0.55);
					col.b = mix(col.b, texture2D(tDiffuse, uv - vec2(ca, 0.0) * px).b, 0.55);
				}

				// --- grade: warm highlights, teal shadows, gentle S-curve ---
				float lum = dot(col, vec3(0.2126, 0.7152, 0.0722));
				col = mix(vec3(lum), col, uSaturation);
				vec3 shadowTint = vec3(0.91, 1.0, 1.06);
				vec3 highTint = vec3(1.045, 1.01, 0.955);
				col *= mix(shadowTint, highTint, smoothstep(0.15, 0.85, lum));
				col = (col - 0.5) * uContrast + 0.5;
				col += uWarmth * smoothstep(0.5, 1.0, lum) * vec3(0.02, 0.008, -0.012);

				// --- vignette ---
				vec2 q = uv - 0.5;
				float vig = 1.0 - uVignette * pow(smoothstep(0.18, 0.78, length(q * vec2(1.0, 0.92))), 1.6);
				col *= vig;

				// --- film grain ---
				float n = hash(uv * uResolution + fract(uTime) * 137.0 + 11.0) - 0.5;
				col += n * uGrain;

				gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
			}
		`,
	};

	let ctx = null;
	let renderer = null;
	let composer = null;
	let renderTarget = null;
	let renderPass = null;
	let bloomPass = null;
	let outputPass = null;
	let dioramaPass = null;
	let quality = QUALITY.high;
	const qualityListeners = [];
	let width = 1,
		height = 1;
	let pr = 1;

	function init(c) {
		ctx = c;
		const canvas = c.canvas;
		renderer = new THREE.WebGLRenderer({
			canvas,
			antialias: false,
			alpha: false,
			stencil: false,
			powerPreference: 'high-performance',
			preserveDrawingBuffer: false,
		});
		renderer.setClearColor(0x0a0d12, 1);
		renderer.outputColorSpace = THREE.SRGBColorSpace;
		renderer.toneMapping = THREE.ACESFilmicToneMapping;
		renderer.toneMappingExposure = 1.0;
		renderer.shadowMap.enabled = true;
		renderer.shadowMap.type = THREE.PCFSoftShadowMap;
		renderer.info.autoReset = false;

		width = window.innerWidth;
		height = window.innerHeight;
		pr = c.pixelRatioOverride || quality.pixelRatio;
		renderer.setPixelRatio(pr);
		renderer.setSize(width, height, false);

		renderTarget = new THREE.WebGLRenderTarget(width * pr, height * pr, {
			type: THREE.HalfFloatType,
			samples: quality.msaa,
			depthBuffer: true,
			stencilBuffer: false,
		});
		renderTarget.texture.name = 'composer';

		composer = new ADDONS.EffectComposer(renderer, renderTarget);
		composer.setPixelRatio(pr);
		composer.setSize(width, height);

		renderPass = new ADDONS.RenderPass(c.scene, c.camera);
		composer.addPass(renderPass);

		bloomPass = new ADDONS.UnrealBloomPass(new THREE.Vector2(width, height), quality.bloomStrength, quality.bloomRadius, quality.bloomThreshold);
		composer.addPass(bloomPass);

		outputPass = new ADDONS.OutputPass();
		composer.addPass(outputPass);

		dioramaPass = new ADDONS.ShaderPass(DIORAMA_SHADER);
		dioramaPass.renderToScreen = true;
		dioramaPass.uniforms.uTiltBlur.value = quality.tilt ? quality.tiltBlur : 0;
		dioramaPass.uniforms.uGrain.value = quality.grain;
		composer.addPass(dioramaPass);

		resize(width, height);
		setQualityFromName(c.qualityName || 'high', true);
	}

	function applyQualityToRenderer() {
		renderer.setPixelRatio(pr);
		renderer.setSize(width, height, false);
		composer.setPixelRatio(pr);
		composer.setSize(width, height);
		const shadowSize = quality.shadowMap;
		const sun = ctx.env && ctx.env.sunLight;
		if (sun) {
			sun.shadow.mapSize.set(shadowSize, shadowSize);
			if (sun.shadow.map) {
				sun.shadow.map.dispose();
				sun.shadow.map = null;
			}
		}
		if (dioramaPass) {
			dioramaPass.uniforms.uTiltBlur.value = quality.tilt ? quality.tiltBlur : 0;
			dioramaPass.uniforms.uGrain.value = quality.grain;
		}
		if (bloomPass) {
			bloomPass.enabled = quality.bloom;
			bloomPass.strength = quality.bloomStrength;
			bloomPass.radius = quality.bloomRadius;
			bloomPass.threshold = quality.bloomThreshold;
		}
	}

	function setQualityFromName(name, silent = false) {
		if (!QUALITY[name]) name = 'high';
		quality = QUALITY[name];
		if (ctx && ctx.pixelRatioOverride) pr = ctx.pixelRatioOverride;
		else pr = quality.pixelRatio;
		applyQualityToRenderer();
		resize(window.innerWidth, window.innerHeight);
		if (!silent) {
			for (const cb of qualityListeners) {
				try {
					cb(quality);
				} catch (err) {
					console.error('[render] quality listener failed', err);
				}
			}
		}
		return quality;
	}

	function resize(w, h) {
		width = w;
		height = h;
		renderer.setPixelRatio(pr);
		renderer.setSize(w, h, false);
		composer.setPixelRatio(pr);
		composer.setSize(w, h);
		if (ctx && ctx.camera) {
			ctx.camera.aspect = w / h;
			ctx.camera.updateProjectionMatrix();
		}
		if (dioramaPass) {
			dioramaPass.uniforms.uResolution.value.set(w * pr, h * pr);
			// tilt shift band is authored for a 16:10 frame; keep it stable
			dioramaPass.uniforms.uFocus.value = 0.535;
		}
	}

	let frameCount = 0;
	function render(dt, time) {
		frameCount++;
		renderer.info.reset();
		if (dioramaPass) {
			dioramaPass.uniforms.uTime.value = time;
			dioramaPass.uniforms.uResolution.value.set(width * pr, height * pr);
		}
		composer.render(dt);
	}

	function stats() {
		const info = renderer.info;
		return {
			calls: info.render.calls,
			triangles: info.render.triangles,
			geometries: info.memory.geometries,
			textures: info.memory.textures,
			programs: info.programs ? info.programs.length : 0,
			frame: frameCount,
			quality: quality.id,
			pixelRatio: pr,
		};
	}

	H.render = {
		init,
		resize,
		render,
		stats,
		setQuality: setQualityFromName,
		onQuality: (cb) => {
			qualityListeners.push(cb);
			try {
				cb(quality);
			} catch (err) {
				console.error(err);
			}
			return () => {
				const i = qualityListeners.indexOf(cb);
				if (i >= 0) qualityListeners.splice(i, 1);
			};
		},
		get quality() {
			return quality;
		},
		get renderer() {
			return renderer;
		},
		get composer() {
			return composer;
		},
		get pixelRatio() {
			return pr;
		},
		QUALITY,
	};
})(window.HARBOR);
