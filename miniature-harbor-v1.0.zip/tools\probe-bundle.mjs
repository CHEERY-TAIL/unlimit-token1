﻿import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
const mod = await import(pathToFileURL('node_modules/esbuild-wasm/lib/browser.js').href);
const esbuild = mod.default || mod;
const wasm = await WebAssembly.compile(fs.readFileSync('node_modules/esbuild-wasm/esbuild.wasm'));
await esbuild.initialize({ wasmModule: wasm, worker: false });
const result = await esbuild.build({
  entryPoints: ['probe/entry.js'],
  bundle: true, format: 'iife', globalName: 'Probe',
  write: false, logLevel: 'silent',
});
fs.mkdirSync('qa/_probe', { recursive: true });
fs.writeFileSync('qa/_probe/bundle.js', result.outputFiles[0].text);
console.log('BUNDLE OK bytes=', result.outputFiles[0].text.length);
