/**
 * 20-quay.js — harbour waterfront: masonry quay wall, four piers and the
 * curved breakwater with its crest walkway.  OWNER: t2 structures.
 * ----------------------------------------------------------------------
 * CONTRACT
 *  - The harbour water edge is the COAST chain (harbour stretch); the quay
 *    wall, coping, bollards etc. sit exactly on it. The flat 1.0 terrace
 *    behind it was laid out by the Lead.
 *  - Builds exactly HARBOR.layout.PIERS (ids, start, dir, length, width,
 *    deck level) so vessels can moor to HARBOR.layout.berths.
 *  - Breakwater follows HARBOR.layout.BREAKWATER.path; the lighthouse at
 *    BREAKWATER.lighthouse is built by 22-lighthouse.js on our head
 *    platform (top y = LEVEL.breakwater = 1.45).
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const L = H.layout;
	const M = H.materials;
	const PI = Math.PI;
	const TAU = PI * 2;

	// ==================================================================
	// local geometry helpers (all return raw BufferGeometry)
	// ==================================================================
	function boxG(w, h, d, x, y, z, ry, rx, rz) {
		const g = new THREE.BoxGeometry(w, h, d);
		if (rx) g.rotateX(rx);
		if (rz) g.rotateZ(rz);
		if (ry) g.rotateY(ry);
		g.translate(x, y, z);
		return g;
	}
	function cylG(rt, rb, h, seg, x, y, z, ry, rx, rz) {
		const g = new THREE.CylinderGeometry(rt, rb, h, seg);
		if (rx) g.rotateX(rx);
		if (rz) g.rotateZ(rz);
		if (ry) g.rotateY(ry);
		g.translate(x, y, z);
		return g;
	}
	function tubeG(a, b, radius, seg) {
		const dx = b[0] - a[0],
			dy = b[1] - a[1],
			dz = b[2] - a[2];
		const len = Math.hypot(dx, dy, dz) || 1e-4;
		const g = new THREE.CylinderGeometry(radius, radius, len, seg || 6, 1, false);
		const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(dx / len, dy / len, dz / len));
		g.applyQuaternion(q);
		g.translate((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2);
		return g;
	}
	/**
	 * Loft a cross-section along a polyline. pts = [[x,z]], profile = [[u,y]]
	 * where +u is the RIGHT normal (-tz,tx). Profile must be ordered so the
	 * surface normal points outward (matches a clockwise loop in (u,y)).
	 */
	function loftG(pts, profile) {
		const n = pts.length,
			m = profile.length;
		const pos = [],
			uvs = [],
			idx = [];
		const pdist = [0];
		for (let j = 1; j < m; j++) pdist[j] = pdist[j - 1] + Math.hypot(profile[j][0] - profile[j - 1][0], profile[j][1] - profile[j - 1][1]);
		const rings = [];
		let dist = 0;
		for (let i = 0; i < n; i++) {
			let tx, tz;
			if (i === 0) {
				tx = pts[1][0] - pts[0][0];
				tz = pts[1][1] - pts[0][1];
			} else if (i === n - 1) {
				tx = pts[n - 1][0] - pts[n - 2][0];
				tz = pts[n - 1][1] - pts[n - 2][1];
			} else {
				tx = pts[i + 1][0] - pts[i - 1][0];
				tz = pts[i + 1][1] - pts[i - 1][1];
			}
			const tl = Math.hypot(tx, tz) || 1;
			tx /= tl;
			tz /= tl;
			const rx = -tz,
				rz = tx;
			if (i > 0) dist += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
			const ring = new Array(m);
			for (let j = 0; j < m; j++) ring[j] = [pts[i][0] + rx * profile[j][0], profile[j][1], pts[i][1] + rz * profile[j][0]];
			rings.push({ ring, dist });
		}
		for (let i = 0; i < n; i++)
			for (let j = 0; j < m; j++) {
				pos.push(rings[i].ring[j][0], rings[i].ring[j][1], rings[i].ring[j][2]);
				uvs.push(rings[i].dist / 1.15, pdist[j] / 1.15);
			}
		const v = (i, j) => i * m + j;
		for (let i = 0; i < n - 1; i++)
			for (let j = 0; j < m - 1; j++) {
				const a = v(i, j),
					b = v(i, j + 1),
					c = v(i + 1, j + 1),
					d = v(i + 1, j);
				idx.push(a, b, c, a, c, d);
			}
		const geo = new THREE.BufferGeometry();
		geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
		geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
		geo.setIndex(idx);
		geo.computeVertexNormals();
		return geo;
	}
	function scaleUV(g, su, sv) {
		const uv = g.attributes.uv;
		for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * su, uv.getY(i) * sv);
		return g;
	}
	function mergedMesh(geos, mat, opts) {
		opts = opts || {};
		const m = new THREE.Mesh(U.merge(geos), mat);
		m.castShadow = opts.cast !== false;
		m.receiveShadow = opts.receive !== false;
		if (opts.name) m.name = opts.name;
		return m;
	}
	function instanced(group, geo, mat, list, opts) {
		opts = opts || {};
		if (!list.length) return null;
		const m = U.instances(geo, mat, list, { cast: opts.cast !== false, receive: opts.receive !== false });
		if (opts.name) m.name = opts.name;
		group.add(m);
		return m;
	}

	// ==================================================================
	// polyline helpers
	// ==================================================================
	function polyLength(pts) {
		let s = 0;
		for (let i = 1; i < pts.length; i++) s += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
		return s;
	}
	function pointAt(pts, s) {
		let acc = 0;
		const total = polyLength(pts);
		s = U.clamp(s, 0, total);
		for (let i = 1; i < pts.length; i++) {
			const a = pts[i - 1],
				b = pts[i];
			const seg = Math.hypot(b[0] - a[0], b[1] - a[1]);
			if (s <= acc + seg || i === pts.length - 1) {
				const f = seg > 1e-9 ? (s - acc) / seg : 0;
				const tx = seg > 1e-9 ? (b[0] - a[0]) / seg : 1,
					tz = seg > 1e-9 ? (b[1] - a[1]) / seg : 0;
				return { x: U.lerp(a[0], b[0], f), z: U.lerp(a[1], b[1], f), tx, tz, nx: -tz, nz: tx, s };
			}
			acc += seg;
		}
		const a = pts[0];
		return { x: a[0], z: a[1], tx: 1, tz: 0, nx: 0, nz: 1, s: 0 };
	}
	function slicePolyline(pts, s0, s1) {
		const total = polyLength(pts);
		s0 = U.clamp(s0, 0, total);
		s1 = U.clamp(s1, 0, total);
		if (s1 - s0 < 1e-3) return null;
		const a = pointAt(pts, s0),
			b = pointAt(pts, s1);
		const out = [[a.x, a.z]];
		let acc = 0;
		for (let i = 1; i < pts.length; i++) {
			const p = pts[i - 1],
				q = pts[i];
			acc += Math.hypot(q[0] - p[0], q[1] - p[1]);
			if (acc > s0 + 1e-4 && acc < s1 - 1e-4) out.push([q[0], q[1]]);
		}
		out.push([b.x, b.z]);
		return out;
	}
	function projectOnPolyline(pts, px, pz) {
		let best = { s: 0, d: Infinity, x: 0, z: 0 };
		let acc = 0;
		for (let i = 1; i < pts.length; i++) {
			const a = pts[i - 1],
				b = pts[i];
			const vx = b[0] - a[0],
				vz = b[1] - a[1];
			const len2 = vx * vx + vz * vz || 1e-9;
			const seg = Math.sqrt(len2);
			const t = U.clamp(((px - a[0]) * vx + (pz - a[1]) * vz) / len2, 0, 1);
			const cx = a[0] + vx * t,
				cz = a[1] + vz * t;
			const d = Math.hypot(px - cx, pz - cz);
			if (d < best.d) best = { s: acc + seg * t, d, x: cx, z: cz };
			acc += seg;
		}
		return best;
	}
	/** intersect ray O+t*D with polyline, return arc length or null */
	function rayPolylineS(pts, ox, oz, dx, dz) {
		let acc = 0;
		for (let i = 1; i < pts.length; i++) {
			const a = pts[i - 1],
				b = pts[i];
			const ex = b[0] - a[0],
				ez = b[1] - a[1];
			const segLen = Math.hypot(ex, ez);
			const den = dx * ez - dz * ex;
			if (Math.abs(den) < 1e-9) {
				acc += segLen;
				continue;
			}
			const wx = a[0] - ox,
				wz = a[1] - oz;
			const t = (wx * ez - wz * ex) / den;
			const u = (wx * dz - wz * dx) / den;
			if (t >= -0.001 && u >= -0.001 && u <= 1.001) return acc + U.clamp(u, 0, 1) * segLen;
			acc += segLen;
		}
		return null;
	}
	function mergeIntervals(list) {
		list.sort((a, b) => a[0] - b[0]);
		const out = [];
		for (const iv of list) {
			if (!out.length || iv[0] > out[out.length - 1][1]) out.push([iv[0], iv[1]]);
			else out[out.length - 1][1] = Math.max(out[out.length - 1][1], iv[1]);
		}
		return out;
	}

	// ==================================================================
	// layout constants
	// ==================================================================
	// harbour water edge = COAST harbour stretch (west -> east)
	const EDGE = [
		[-10.7, 4.85],
		[-8.3, 3.35],
		[-5.4, 2.55],
		[-2.7, 1.95],
		[-0.2, 1.45],
		[2.1, 0.95],
		[4.0, 0.55],
		[5.15, 0.9],
		[5.85, 1.55],
	];
	// marina corner: sea wall retaining the fort terrace down to the cove
	const FORT_WALL = [
		[5.85, 1.55],
		[6.05, 2.75],
	];
	// actual terrain height where the T1 terrain differs from the layout field (wild areas)
	function gh(x, z) {
		const t1 = H._t1;
		return t1 && typeof t1.height === 'function' ? t1.height(x, z) : L.groundHeight(x, z);
	}
	const DECK = L.LEVEL.quay; // 1.0
	const PAVE = DECK + 0.02; // paved edge strip
	const WALL_TOP = 0.99;
	const WALL_BOTTOM = -1.35;

	H.register('quay', {
		create(ctx) {
			const g = ctx.group('quay');
			const rng = U.rng(70213);

			// ---------------- shared materials ----------------
			const stone = M.unique('stoneWall', { side: THREE.DoubleSide, color: 0x8b8377 });
			const stoneDark = M.unique('stoneWall', { color: 0x837a6d });
			const concrete = M.unique('concrete', { color: 0x827c72 });
			const concreteDark = M.unique('concreteDark', { color: 0x7d7870 });
			const cobble = M.unique('cobble', { side: THREE.DoubleSide, color: 0x6b655e });
			const wood = M.get('wood');
			const woodDark = M.get('woodDark');
			const woodLight = M.get('woodLight');
			const steel = M.get('steel');
			const steelDark = M.get('steelDark');
			const iron = M.get('rusted');
			const rubber = M.get('rubber');
			const brass = M.get('brass');
			const ropeMat = M.get('rope');
			const rockMat = M.get('rock');
			const tar = M.unique('tar', { color: 0x3d3e38 });
			const mossMat = M.painted('#47502f', { roughness: 0.97 });
			const paintRed = M.painted('#b3453b', { roughness: 0.6 });
			const paintWhite = M.painted('#efe6d2', { roughness: 0.6 });
			const paintGreen = M.painted('#3c4f45', { roughness: 0.55, metalness: 0.25 });
			const lampMat = M.emissive('#ffd9a0', 0.25);

			// ---------------- instancing collectors ----------------
			const ironBollards = [];
			const stoneBollards = [];
			const cleats = [];
			const tires = [];
			const rings = [];
			const ladders = [];
			const lampPosts = [];
			const lampHeads = [];
			const lampsPoint = [];
			const crates = [];
			const drums = [];

			function addBollard(x, z, y, kind) {
				const rot = rng.range(0, TAU);
				if (kind === 'stone') stoneBollards.push([x, y, z, rot]);
				else ironBollards.push([x, y, z, rot]);
			}
			function addTire(x, z, y, outwardAngle, s) {
				tires.push([x, y, z, outwardAngle, s || rng.range(0.9, 1.1)]);
			}
			function addLadder(x, z, y, outwardAngle) {
				ladders.push([x, y, z, outwardAngle]);
			}
			function addLamp(x, z, y, outwardAngle, withLight) {
				lampPosts.push([x, y, z, outwardAngle]);
				const lx = x + Math.sin(outwardAngle) * 0.06,
					lz = z + Math.cos(outwardAngle) * 0.06;
				lampHeads.push([lx, y + 0.58, lz, outwardAngle]);
				if (withLight) lampsPoint.push([lx, y + 0.6, lz]);
			}
			function addRing(x, z, y, outwardAngle) {
				rings.push([x, y, z, outwardAngle]);
			}

			// ==========================================================
			// 1. QUAY WALL
			// ==========================================================
			const wallGeos = [];
			const pillarGeos = [];
			const paveGeos = [];
			const copeGeos = [];
			const mossGeos = [];
			const stainGeos = [];
			const tideGeos = [];
			const woodGeos = [];
			const steelGeos = [];
			const ironGeos = [];
			const ropeGeos = [];

			// --- wall line: main quay + the short fort sea wall ----------
			const EDGE_LEN = polyLength(EDGE);
			const FORT_LEN = polyLength(FORT_WALL);

			// --- openings (piers that cross the wall + stairs) ----------
			const openings = [];
			const pierOpenings = [];
			for (const pier of L.PIERS) {
				if (pier.style === 'pontoon') continue;
				const len = Math.hypot(pier.dir[0], pier.dir[1]);
				const dx = pier.dir[0] / len,
					dz = pier.dir[1] / len;
				const s = rayPolylineS(EDGE, pier.start[0], pier.start[1], dx, dz);
				if (s == null) continue;
				const half = pier.width / 2 + 0.14;
				pierOpenings.push({ pier, s, half });
				openings.push([s - half, s + half]);
			}
			const stairs = [];
			for (const target of [
				[-6.6, 2.7],
				[2.8, 1.0],
			]) {
				const p = projectOnPolyline(EDGE, target[0], target[1]);
				if (p.d < 0.45) {
					stairs.push({ s: p.s, half: 0.52 });
					openings.push([p.s - 0.52, p.s + 0.52]);
				}
			}
			const openIv = mergeIntervals(openings);
			const pieces = [];
			let cursor = 0;
			for (const iv of openIv) {
				if (iv[0] > cursor + 0.03) pieces.push([cursor, iv[0]]);
				cursor = Math.max(cursor, iv[1]);
			}
			if (cursor < EDGE_LEN - 0.03) pieces.push([cursor, EDGE_LEN]);

			// --- masonry wall body (solid, buried 0.2 inland) -----------
			const wallProfile = [
				[-0.42, WALL_TOP],
				[0.23, WALL_TOP],
				[0.23, WALL_BOTTOM],
				[-0.42, WALL_BOTTOM],
			];
			for (const [s0, s1] of pieces) {
				const sub = slicePolyline(EDGE, s0, s1);
				if (!sub || sub.length < 2) continue;
				wallGeos.push(loftG(sub, wallProfile));
				for (const s of [s0, s1]) {
					const p = pointAt(EDGE, s);
					const ang = Math.atan2(p.nx, p.nz);
					pillarGeos.push(scaleUV(boxG(0.44, WALL_TOP - WALL_BOTTOM, 0.5, p.x, WALL_TOP - (WALL_TOP - WALL_BOTTOM) / 2, p.z, ang), 0.38, 2.05));
					pillarGeos.push(scaleUV(boxG(0.52, 0.1, 0.58, p.x, WALL_TOP + 0.03, p.z, ang), 0.45, 0.1));
				}
			}
			// fort side sea wall (retains the 1.5 terrace)
			const fortProfile = [
				[-0.5, 1.52],
				[0.23, 1.52],
				[0.23, WALL_BOTTOM - 0.3],
				[-0.5, WALL_BOTTOM - 0.3],
			];
			for (let k = 0; k < 3; k++) {
				const sub = slicePolyline(FORT_WALL, (FORT_LEN * k) / 3, (FORT_LEN * (k + 1)) / 3);
				if (sub) wallGeos.push(loftG(sub, fortProfile));
			}
			const cornerP = pointAt(FORT_WALL, 0);
			wallGeos.push(boxG(0.7, 1.6, 0.7, cornerP.x, 1.52 - 0.8, cornerP.z, Math.atan2(cornerP.nx, cornerP.nz)));
			g.add(mergedMesh(wallGeos, stone, { name: 'quay-wall', cast: true, receive: true }));
			if (pillarGeos.length) g.add(mergedMesh(pillarGeos, M.painted('#6c6458', { roughness: 0.92 }), { name: 'quay-wall-pillars', cast: true, receive: true }));

			// --- paving strip + coping on the water edge ---------------
			const paveProfile = [
				[-0.42, PAVE],
				[0.06, PAVE],
				[0.06, PAVE - 0.14],
				[-0.42, PAVE - 0.14],
			];
			const copeProfile = [
				[0.04, PAVE + 0.045],
				[0.25, PAVE + 0.045],
				[0.25, PAVE - 0.09],
				[0.04, PAVE - 0.09],
			];
			for (const [s0, s1] of pieces) {
				const sub = slicePolyline(EDGE, s0, s1);
				if (!sub || sub.length < 2) continue;
				paveGeos.push(loftG(sub, paveProfile));
				copeGeos.push(loftG(sub, copeProfile));
			}
			g.add(mergedMesh(paveGeos, cobble, { name: 'quay-paving', cast: false, receive: true }));
			g.add(mergedMesh(copeGeos, concrete, { name: 'quay-coping', cast: false, receive: true }));

			// fort wall coping
			{
				const fortCope = [
					[0.04, 1.56],
					[0.26, 1.56],
					[0.26, 1.44],
					[0.04, 1.44],
				];
				const sub = slicePolyline(FORT_WALL, 0, FORT_LEN);
				if (sub) g.add(mergedMesh([loftG(sub, fortCope)], concrete, { name: 'fort-coping', cast: true, receive: true }));
				// steps from the fort wall top down to the marina quay
				const st = [];
				const p = pointAt(FORT_WALL, 0.18);
				const ang = Math.atan2(p.tx, p.tz);
				for (let k = 0; k < 5; k++) st.push(boxG(0.9, 0.13, 0.24, p.x - p.nx * (0.2 + k * 0.24), 1.5 - 0.1 - k * 0.1, p.z - p.nz * (0.2 + k * 0.24), ang));
				for (const side of [-1, 1]) st.push(boxG(0.1, 0.62, 1.5, p.x + p.tx * side * 0.5 - p.nx * 0.85, 1.2, p.z + p.tz * side * 0.5 - p.nz * 0.85, ang));
				g.add(mergedMesh(st, stoneDark, { name: 'fort-steps', cast: true, receive: true }));
			}

			// --- tide line, moss, salt stains on the wall face ---------
			const faceU = 0.232;
			for (let k = 0; k < 8; k++) {
				const sub = slicePolyline(EDGE, (EDGE_LEN * k) / 8, (EDGE_LEN * (k + 1)) / 8);
				if (sub) tideGeos.push(loftG(sub, [[faceU + 0.01, 0.34], [faceU + 0.01, -0.62]]));
			}
			g.add(mergedMesh(tideGeos, tar, { name: 'quay-tide', cast: false, receive: false }));
			// dark slimy wet band right at the waterline
			const wetBandGeos = [];
			for (let k = 0; k < 8; k++) {
				const sub = slicePolyline(EDGE, (EDGE_LEN * k) / 8, (EDGE_LEN * (k + 1)) / 8);
				if (sub) wetBandGeos.push(loftG(sub, [[faceU + 0.014, 0.26], [faceU + 0.014, -0.12]]));
			}
			g.add(mergedMesh(wetBandGeos, M.painted('#26292a', { roughness: 0.92 }), { name: 'quay-wetband', cast: false, receive: false }));
			// patched repairs: a few newer / brighter stone panels
			const repairGeos = [];
			for (const [ss, ww, hh] of [
				[2.1, 0.5, 0.36],
				[6.9, 0.34, 0.3],
				[11.9, 0.55, 0.4],
				[14.6, 0.3, 0.34],
			]) {
				const p = pointAt(EDGE, ss);
				const ang = Math.atan2(p.nx, p.nz);
				const gq = new THREE.PlaneGeometry(ww, hh);
				gq.rotateY(ang);
				gq.translate(p.x + p.nx * (faceU + 0.02), 0.5 + rng.range(-0.15, 0.2), p.z + p.nz * (faceU + 0.02));
				repairGeos.push(gq);
			}
			g.add(mergedMesh(repairGeos, M.unique('stoneWall', { color: 0xa39a8b, side: THREE.DoubleSide }), { name: 'quay-repairs', cast: false, receive: false }));
			for (let s = 0.35; s < EDGE_LEN; s += 0.5) {
				if (rng.chance(0.5)) continue;
				const p = pointAt(EDGE, s);
				const ang = Math.atan2(p.nx, p.nz);
				const gq = new THREE.PlaneGeometry(rng.range(0.1, 0.24), rng.range(0.07, 0.16));
				gq.rotateY(ang);
				gq.translate(p.x + p.nx * (faceU + 0.006), rng.range(0.02, 0.5), p.z + p.nz * (faceU + 0.006));
				mossGeos.push(gq);
			}
			if (mossGeos.length) g.add(mergedMesh(mossGeos, mossMat, { name: 'quay-moss', cast: false, receive: false }));
			for (let s = 0.9; s < EDGE_LEN; s += 2.1) {
				const p = pointAt(EDGE, s);
				const ang = Math.atan2(p.nx, p.nz);
				const h = rng.range(0.4, 0.95);
				const gq = new THREE.PlaneGeometry(rng.range(0.09, 0.26), h);
				gq.rotateY(ang);
				gq.translate(p.x + p.nx * (faceU + 0.005), PAVE - 0.1 - h / 2, p.z + p.nz * (faceU + 0.005));
				stainGeos.push(gq);
			}
			g.add(mergedMesh(stainGeos, M.painted('#8f897c', { roughness: 0.94 }), { name: 'quay-stains', cast: false, receive: false }));

			// --- outfall drains ---------------------------------------
			const drainAlgae = [];
			for (let s = 1.7; s < EDGE_LEN - 0.8; s += 3.3) {
				const p = pointAt(EDGE, s);
				const ang = Math.atan2(p.nx, p.nz);
				ironGeos.push(cylG(0.05, 0.06, 0.24, 8, p.x + p.nx * (faceU + 0.1), 0.5, p.z + p.nz * (faceU + 0.1), ang, PI / 2));
				ironGeos.push(cylG(0.075, 0.075, 0.05, 8, p.x + p.nx * (faceU + 0.01), 0.5, p.z + p.nz * (faceU + 0.01), ang, PI / 2));
				const gq = new THREE.PlaneGeometry(0.15, 0.55);
				gq.rotateY(ang);
				gq.translate(p.x + p.nx * (faceU + 0.005), 0.16, p.z + p.nz * (faceU + 0.005));
				drainAlgae.push(gq);
			}
			g.add(mergedMesh(drainAlgae, M.painted('#485739', { roughness: 0.96 }), { name: 'drain-algae', cast: false, receive: false }));

			// --- bollards / rings / fenders / tires / ladders / lamps --
			for (let s = 0.7; s < EDGE_LEN - 0.3; s += 1.25) {
				const p = pointAt(EDGE, s);
				addBollard(p.x - p.nx * 0.06, p.z - p.nz * 0.06, PAVE, rng.chance(0.22) ? 'stone' : 'iron');
			}
			for (let s = 1.1; s < EDGE_LEN - 0.5; s += 1.9) {
				const p = pointAt(EDGE, s);
				addRing(p.x + p.nx * (faceU + 0.024), p.z + p.nz * (faceU + 0.024), 0.76, Math.atan2(p.nx, p.nz));
			}
			for (let s = 1.9; s < EDGE_LEN - 0.6; s += 2.9) {
				const p = pointAt(EDGE, s);
				addTire(p.x + p.nx * (faceU + 0.05), p.z + p.nz * (faceU + 0.05), 0.33, Math.atan2(p.nx, p.nz));
				const tx = p.x + p.nx * (faceU + 0.05),
					tz = p.z + p.nz * (faceU + 0.05);
				ironGeos.push(tubeG([tx, 0.42, tz], [tx, 0.93, tz], 0.008, 3));
			}
			for (let s = 1.3; s < EDGE_LEN - 1.1; s += 2.3) {
				const p = pointAt(EDGE, s);
				const ang = Math.atan2(p.tx, p.tz);
				woodGeos.push(boxG(0.1, 0.14, 1.65, p.x + p.nx * (faceU + 0.07), 0.72, p.z + p.nz * (faceU + 0.07), ang));
				// hanging straps that tie the fender to the coping
				for (const off of [-0.7, 0.7]) {
					const sx = p.x + p.tx * off + p.nx * (faceU + 0.09);
					const sz = p.z + p.tz * off + p.nz * (faceU + 0.09);
					ironGeos.push(tubeG([sx, 0.79, sz], [sx, 0.95, sz], 0.012, 4));
				}
			}
			for (const p of [
				{ s: 2.2, light: true },
				{ s: 6.4, light: true },
				{ s: 10.8, light: false },
				{ s: 13.9, light: false },
			]) {
				const q = pointAt(EDGE, p.s);
				addLamp(q.x - q.nx * 0.28, q.z - q.nz * 0.28, PAVE, Math.atan2(q.nx, q.nz), p.light);
			}
			for (const s of [1.2, 4.6, 8.4, 11.6, 13.6]) {
				const p = pointAt(EDGE, s);
				addLadder(p.x + p.nx * (faceU + 0.026), p.z + p.nz * (faceU + 0.026), PAVE, Math.atan2(p.nx, p.nz));
			}

			// --- stone stairs down to the water ------------------------
			const stairsGeos = [];
			for (const st of stairs) {
				const p = pointAt(EDGE, st.s);
				const ang = Math.atan2(p.tx, p.tz);
				for (let k = 0; k < 8; k++) {
					stairsGeos.push(boxG(0.92, 0.15, 0.25, p.x + p.nx * (0.2 + k * 0.235), PAVE - 0.05 - k * 0.13, p.z + p.nz * (0.2 + k * 0.235), ang));
				}
				for (const side of [-1, 1]) stairsGeos.push(boxG(0.11, 1.15, 2.0, p.x + p.tx * side * 0.53 + p.nx * 1.15, PAVE - 0.5, p.z + p.tz * side * 0.53 + p.nz * 1.15, ang));
				addBollard(p.x + p.tx * 0.75 - p.nx * 0.3, p.z + p.tz * 0.75 - p.nz * 0.3, PAVE, 'iron');
			}
			// west end: steps down to the sandy beach (0.25)
			{
				const p = pointAt(EDGE, 0);
				const ang = Math.atan2(p.tx, p.tz);
				for (let k = 0; k < 6; k++) {
					stairsGeos.push(boxG(1.3, 0.14, 0.26, p.x - p.tx * (0.2 + k * 0.24), PAVE - 0.06 - k * 0.125, p.z - p.tz * (0.2 + k * 0.24), ang));
				}
				for (const side of [-1, 1]) stairsGeos.push(boxG(0.12, 0.9, 1.6, p.x + p.nx * side * 0.7 - p.tx * 0.9, PAVE - 0.35, p.z + p.nz * side * 0.7 - p.tz * 0.9, ang));
			}
			g.add(mergedMesh(stairsGeos, stoneDark, { name: 'quay-stairs', cast: true, receive: true }));

			// --- west apron clutter (capstan, coils, lifebuoy) --------
			{
				const p = pointAt(EDGE, 1.9);
				const bx = p.x - p.nx * 0.9,
					bz = p.z - p.nz * 0.9;
				ironGeos.push(cylG(0.11, 0.14, 0.22, 10, bx, PAVE + 0.11, bz));
				ironGeos.push(new THREE.TorusGeometry(0.14, 0.026, 5, 12).rotateX(PI / 2).translate(bx, PAVE + 0.24, bz));
				ironGeos.push(cylG(0.035, 0.035, 0.22, 6, bx, PAVE + 0.24, bz));
				for (let k = 0; k < 3; k++) ropeGeos.push(new THREE.TorusGeometry(0.07 + k * 0.035, 0.012, 4, 10).rotateX(PI / 2).translate(p.x - p.nx * 1.5 + p.tx * 0.4, PAVE + 0.012 + k * 0.02, p.z - p.nz * 1.5 + p.tz * 0.4));
				// lifebuoy on a post
				const lx = p.x - p.nx * 0.42,
					lz = p.z - p.nz * 0.42;
				steelGeos.push(cylG(0.018, 0.018, 0.85, 6, lx, PAVE + 0.42, lz));
				steelGeos.push(boxG(0.05, 0.05, 0.3, lx, PAVE + 0.8, lz, Math.atan2(p.nx, p.nz)));
			}
			const buoyRed = [],
				buoyWhite = [];
			buoyRed.push([pointAt(EDGE, 1.9).x - pointAt(EDGE, 1.9).nx * 0.42, PAVE + 0.62, pointAt(EDGE, 1.9).z - pointAt(EDGE, 1.9).nz * 0.42, Math.atan2(pointAt(EDGE, 1.9).nx, pointAt(EDGE, 1.9).nz)]);
			for (let k = 0; k < 4; k++) {
				const a = (k / 4) * TAU + PI / 4;
				const q = pointAt(EDGE, 1.9);
				buoyWhite.push([q.x - q.nx * 0.42 + Math.cos(a) * 0.075, PAVE + 0.62 + Math.sin(a) * 0.075, q.z - q.nz * 0.42 + 0.01, Math.atan2(q.nx, q.nz)]);
			}
			// staging clutter along the wide west apron (crates / drums / rope coils)
			for (let k = 0; k < 7; k++) {
				const ss = 0.5 + k * 0.42;
				const p = pointAt(EDGE, ss);
				const off = 0.6 + rng.range(0, 0.35);
				const bx = p.x - p.nx * off + p.tx * rng.range(-0.25, 0.25);
				const bz = p.z - p.nz * off + p.tz * rng.range(-0.25, 0.25);
				const rr = rng.next();
				if (rr < 0.45) crates.push([bx, PAVE + 0.09, bz, Math.atan2(p.tx, p.tz) + rng.range(-0.6, 0.6), rng.range(0.7, 1.15)]);
				else if (rr < 0.75) drums.push([bx, PAVE + 0.12, bz, rng.range(0, TAU)]);
				else ropeGeos.push(new THREE.TorusGeometry(0.07, 0.012, 4, 10).rotateX(PI / 2).translate(bx, PAVE + 0.012, bz));
			}

			// ==========================================================
			// 2. PIERS
			// ==========================================================
			const pileConcrete = [];
			const pileTimber = [];
			const pontoonBobbers = [];
			const deckConcrete = [];
			const deckTimber = [];
			const deckStone = [];
			const joists = [];
			const braces = [];

			function pierFrame(pier) {
				const len = Math.hypot(pier.dir[0], pier.dir[1]);
				const dx = pier.dir[0] / len,
					dz = pier.dir[1] / len;
				return {
					dx,
					dz,
					angle: Math.atan2(dx, dz),
					at(along, side) {
						return { x: pier.start[0] + dx * along - dz * side, z: pier.start[1] + dz * along + dx * side };
					},
				};
			}

			for (const pier of L.PIERS) {
				const f = pierFrame(pier);
				const pg = U.group(g, pier.id);
				const W = pier.width,
					LEN = pier.length,
					Y = pier.deck;
				const angle = f.angle;
				const topDeck = Y + 0.035;

				if (pier.style === 'concrete') {
					// deck slab (extends 0.55 inland so it merges with the quay)
					const len0 = LEN + 0.62;
					const c0 = f.at((len0 / 2) - 0.47, 0);
					deckConcrete.push(boxG(W, 0.18, len0, c0.x, topDeck - 0.09, c0.z, angle));
					// edge beams + cross beams
					for (const side of [-1, 1]) {
						const p = f.at((len0 / 2) - 0.47, side * (W / 2 - 0.07));
						deckConcrete.push(boxG(0.14, 0.28, len0 - 0.1, p.x, topDeck - 0.26, p.z, angle));
					}
					for (let i = 1; i <= 7; i++) {
						const a = -0.35 + ((i - 0.5) / 7) * (LEN + 0.2);
						const p = f.at(a, 0);
						joists.push(boxG(W - 0.16, 0.15, 0.11, p.x, topDeck - 0.3, p.z, angle));
					}
					// kerbs
					for (const side of [-1, 1]) {
						const p = f.at(LEN / 2, side * (W / 2 - 0.055));
						deckConcrete.push(boxG(0.11, 0.1, LEN, p.x, topDeck + 0.05, p.z, angle));
					}
					// piles + caps
					for (let i = 0; i <= 5; i++) {
						const a = 0.25 + (i / 5) * (LEN - 0.35);
						for (const side of [-1, 1]) {
							const p = f.at(a, side * (W / 2 - 0.11));
							const base = Math.min(L.groundHeight(p.x, p.z) - 0.3, -0.75);
							const topY = topDeck - 0.2;
							const h = topY - base;
							if (h < 0.3) continue;
							pileConcrete.push([p.x, base + h / 2, p.z, rng.range(0, 1), 1, 1, h, 1]);
							deckConcrete.push(boxG(0.2, 0.1, 0.2, p.x, topY + 0.02, p.z, angle));
						}
					}
					// cross bracing
					for (let i = 1; i < 4; i++) {
						const a = 0.25 + ((i + 0.5) / 5) * (LEN - 0.35);
						for (const side of [-1, 1]) {
							const p0 = f.at(a - 0.19, side * (W / 2 - 0.11));
							const p1 = f.at(a + 0.19, side * (W / 2 - 0.11));
							braces.push(tubeG([p0.x, 0.2, p0.z], [p1.x, topDeck - 0.4, p1.z], 0.028, 5));
						}
					}
					// head timber fender + davit crane
					const hp = f.at(LEN - 0.05, 0);
					steelGeos.push(cylG(0.05, 0.07, 0.85, 8, hp.x - f.dx * 0.2, topDeck + 0.42, hp.z - f.dz * 0.2));
					steelGeos.push(boxG(0.09, 0.09, 0.9, hp.x - f.dx * 0.2 + f.dx * 0.45, topDeck + 0.75, hp.z - f.dz * 0.2 + f.dz * 0.45, angle, -0.3));
					steelGeos.push(tubeG([hp.x + f.dx * 0.68, topDeck + 0.98, hp.z + f.dz * 0.68], [hp.x + f.dx * 0.68, topDeck + 0.55, hp.z + f.dz * 0.68], 0.006, 4));
					steelGeos.push(boxG(0.1, 0.13, 0.06, hp.x + f.dx * 0.68, topDeck + 0.49, hp.z + f.dz * 0.68, angle));
				} else if (pier.style === 'timber') {
					const len0 = LEN + 0.55;
					const c0 = f.at((len0 / 2) - 0.42, 0);
					deckTimber.push(boxG(W, 0.1, len0, c0.x, topDeck - 0.05, c0.z, angle));
					for (const side of [-1, 1]) {
						const p = f.at((len0 / 2) - 0.42, side * (W / 2 - 0.09));
						joists.push(boxG(0.12, 0.17, len0 - 0.1, p.x, topDeck - 0.18, p.z, angle));
					}
					for (let i = 0; i <= 9; i++) {
						const a = -0.35 + (i / 9) * (LEN + 0.15);
						const p = f.at(a, 0);
						joists.push(boxG(W, 0.12, 0.09, p.x, topDeck - 0.15, p.z, angle));
					}
					for (let i = 0; i <= 5; i++) {
						const a = 0.2 + (i / 5) * (LEN - 0.3);
						for (const side of [-1, 1]) {
							const p = f.at(a, side * (W / 2 - 0.1));
							const base = Math.min(L.groundHeight(p.x, p.z) - 0.3, -0.65);
							const h = topDeck - 0.12 - base;
							if (h < 0.3) continue;
							pileTimber.push([p.x, base + h / 2, p.z, rng.range(0, 1), 1, 1, h, 1]);
						}
					}
					for (let i = 0; i < 5; i++) {
						const a = 0.35 + (i / 5) * (LEN - 0.6);
						for (const side of [-1, 1]) {
							const p0 = f.at(a - 0.21, side * (W / 2 - 0.1));
							const p1 = f.at(a + 0.21, side * (W / 2 - 0.1));
							braces.push(tubeG([p0.x, 0.12, p0.z], [p1.x, topDeck - 0.28, p1.z], 0.026, 5));
						}
					}
				} else if (pier.style === 'pontoon') {
					// floating composite deck + HDPE floats; gentle bobbing
					const bob = U.group(pg, 'pontoon');
					const c0 = f.at(LEN / 2, 0);
					const deckMesh = new THREE.Mesh(boxG(W, 0.17, LEN, c0.x, Y - 0.02, c0.z, angle), woodLight);
					deckMesh.castShadow = true;
					deckMesh.receiveShadow = true;
					bob.add(deckMesh);
					const trim = [];
					for (const side of [-1, 1]) {
						const p = f.at(LEN / 2, side * (W / 2 - 0.03));
						trim.push(boxG(0.07, 0.12, LEN, p.x, Y + 0.02, p.z, angle));
					}
					bob.add(mergedMesh(trim, paintGreen, { cast: false, receive: true }));
					const floatGeo = new THREE.CylinderGeometry(0.15, 0.15, LEN - 0.2, 10).rotateX(PI / 2);
					const floatMat = new THREE.MeshStandardMaterial({ color: 0x2f3632, roughness: 0.7, metalness: 0.1 });
					for (const side of [-1, 1]) {
						const p = f.at(LEN / 2, side * (W / 2 - 0.14));
						const fl = new THREE.Mesh(floatGeo, floatMat);
						fl.rotation.y = angle;
						fl.position.set(p.x, -0.11, p.z);
						fl.castShadow = true;
						bob.add(fl);
					}
					for (let i = 0; i < 6; i++) {
						const a = 0.3 + (i / 6) * (LEN - 0.6);
						for (const side of [-1, 1]) {
							const p = f.at(a, side * (W / 2 - 0.1));
							cleats.push([p.x, Y + 0.06, p.z, angle]);
						}
					}
					// gangway from the quay coping down to the pontoon deck
					{
						const root = f.at(0, 0);
						const p0 = { x: root.x - f.dx * 0.22, y: PAVE + 0.02, z: root.z - f.dz * 0.22 };
						const p1 = { x: root.x + f.dx * 1.28, y: Y + 0.03, z: root.z + f.dz * 1.28 };
						const v = new THREE.Vector3(p1.x - p0.x, p1.y - p0.y, p1.z - p0.z);
						const glen = v.length();
						const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), v.clone().normalize());
						const rampGeo = new THREE.BoxGeometry(0.82, 0.07, glen);
						rampGeo.applyQuaternion(q);
						rampGeo.translate((p0.x + p1.x) / 2, (p0.y + p1.y) / 2, (p0.z + p1.z) / 2);
						const ramp = new THREE.Mesh(rampGeo, wood);
						ramp.castShadow = true;
						ramp.receiveShadow = true;
						bob.add(ramp);
						// hand rails
						const lat = { x: -f.dz, z: f.dx };
						const railG = [];
						for (const side of [-1, 1]) {
							for (const hh of [0.45, 0.9]) {
								const a = [p0.x + lat.x * side * 0.4, p0.y + hh, p0.z + lat.z * side * 0.4];
								const b = [p1.x + lat.x * side * 0.4, p1.y + hh, p1.z + lat.z * side * 0.4];
								railG.push(tubeG(a, b, 0.014, 5));
							}
							const a = [p1.x + lat.x * side * 0.4, p1.y, p1.z + lat.z * side * 0.4];
							const b = [p1.x + lat.x * side * 0.4, p1.y + 0.95, p1.z + lat.z * side * 0.4];
							railG.push(tubeG(a, b, 0.016, 5));
						}
						bob.add(mergedMesh(railG, steelDark, { cast: false, receive: false }));
						pontoonBobbers.push({ obj: bob, seed: rng.range(0, TAU) });
					}
					for (const side of [-1, 1]) {
						const p = f.at(LEN - 0.3, side * (W / 2 + 0.02));
						addLadder(p.x, p.z, Y - 0.04, angle + (side > 0 ? 0 : PI));
					}
					for (let i = 0; i < 2; i++) {
						const p = f.at(0.7 + i * 2.2, -(W / 2) - 0.02);
						addTire(p.x, p.z, 0.14, angle + PI / 2, 0.75);
					}
					const lp = f.at(0.22, W / 2 - 0.1);
					addLamp(lp.x, lp.z, Y, angle, false);
				} else {
					// stone ferry jetty: masonry side walls + cobbled top
					const len0 = LEN + 0.55;
					const c0 = f.at((len0 / 2) - 0.42, 0);
					// segmented top so the stone texture keeps its scale
					{
						const segs = 7;
						for (let sgi = 0; sgi < segs; sgi++) {
							const al = -0.42 + ((len0) * (sgi + 0.5)) / segs;
							const pp = f.at(al, 0);
							deckStone.push(boxG(W - 0.12, 0.22, len0 / segs + 0.02, pp.x, topDeck - 0.1, pp.z, angle));
						}
					}
					for (const side of [-1, 1]) {
						const p = f.at((len0 / 2) - 0.42, side * (W / 2 - 0.1));
						const base = Math.min(L.groundHeight(p.x, p.z) - 0.2, -1.25);
						deckStone.push(boxG(0.22, topDeck - base, len0 - 0.1, p.x, base + (topDeck - base) / 2, p.z, angle));
					}
					for (const side of [-1, 1]) {
						const p = f.at((len0 / 2) - 0.42, side * (W / 2 - 0.1));
						deckStone.push(boxG(0.3, 0.08, len0, p.x, topDeck + 0.03, p.z, angle));
					}
					// steps down to the water at the head
					for (let k = 0; k < 5; k++) {
						const p = f.at(LEN - 0.1 - k * 0.2, 0);
						deckStone.push(boxG(W - 0.3, 0.14, 0.2, p.x, topDeck - 0.02 - k * 0.16, p.z, angle));
					}
					const hp = f.at(LEN - 0.25, 0);
					addLamp(hp.x, hp.z, topDeck + 0.04, angle, false);
				}

				// ---- furniture shared by all piers ----
				if (pier.style !== 'pontoon') {
					const sideList = pier.id === 'pierD' ? [1] : [-1, 1];
					for (let i = 0; i < 4; i++) {
						const a = -0.25 + (i / 4) * (LEN + 0.1);
						for (const side of sideList) {
							const p = f.at(a, side * (W / 2 - 0.14));
							addBollard(p.x, p.z, topDeck, pier.style === 'stone' ? 'stone' : 'iron');
						}
					}
					for (let i = 0; i < 4; i++) {
						const a = 0.5 + (i / 4) * (LEN - 0.9);
						for (const side of sideList) {
							const p = f.at(a, side * (W / 2 + 0.01));
							addTire(p.x, p.z, 0.36, angle + (side > 0 ? PI / 2 : -PI / 2));
						}
					}
					const lp = f.at(LEN - 0.2, W / 2 + 0.03);
					addLadder(lp.x, lp.z, topDeck, angle + PI / 2);
					const p1 = f.at(-0.15, W / 2 - 0.1);
					addLamp(p1.x, p1.z, topDeck, angle + PI / 2, pier.id === 'pierA');
					if (LEN > 3.2) {
						const p2 = f.at(LEN * 0.7, -(W / 2) + 0.1);
						addLamp(p2.x, p2.z, topDeck, angle - PI / 2, false);
					}
					const nCrates = pier.style === 'timber' ? 7 : 4;
					for (let i = 0; i < nCrates; i++) {
						const a = 0.45 + rng.range(0, LEN - 1.0);
						const side = rng.chance(0.5) ? 1 : -1;
						const p = f.at(a, side * (W / 2 - 0.27));
						crates.push([p.x, topDeck + 0.09, p.z, angle + rng.range(-0.5, 0.5), rng.range(0.7, 1.15)]);
					}
					for (let i = 0; i < 2; i++) {
						const a = 0.7 + rng.range(0, LEN - 1.4);
						const p = f.at(a, rng.range(-W / 3, W / 3));
						drums.push([p.x, topDeck + 0.12, p.z, rng.range(0, TAU)]);
					}
					const rp = f.at(0.5, W / 2 - 0.28);
					for (let k = 0; k < 2; k++) ropeGeos.push(new THREE.TorusGeometry(0.06 + k * 0.04, 0.011, 4, 10).rotateX(PI / 2).translate(rp.x, topDeck + 0.012 + k * 0.02, rp.z));
				}
			}

			if (deckConcrete.length) g.add(mergedMesh(deckConcrete, concrete, { name: 'pier-concrete', cast: true, receive: true }));
			if (deckTimber.length) g.add(mergedMesh(deckTimber, wood, { name: 'pier-timber', cast: true, receive: true }));
			if (deckStone.length) g.add(mergedMesh(deckStone, stoneDark, { name: 'pier-stone', cast: true, receive: true }));
			if (joists.length) g.add(mergedMesh(joists, woodDark, { name: 'pier-joists', cast: true, receive: true }));
			if (braces.length) g.add(mergedMesh(braces, woodDark, { name: 'pier-braces', cast: false, receive: true }));

			// ==========================================================
			// 3. BREAKWATER
			// ==========================================================
			const bw = L.BREAKWATER;
			const BW = [[6.85, 2.55]].concat(bw.path, [[-4.4, 7.55]]);
			const BW_LEN = polyLength(BW);
			const bwY = bw.crest;
			const walkTop = bwY + 0.02;
			const bwSamples = [];
			for (let s = 0; s <= BW_LEN; s += 0.4) bwSamples.push(pointAt(BW, s));
			if (bwSamples[bwSamples.length - 1].s < BW_LEN - 0.2) bwSamples.push(pointAt(BW, BW_LEN));

			// narrow rock-armour mound: a low crest ridge, not a wall. The seaward
			// slope is a pile of irregular armour stones stepping down into the water.
			const core = [
				[-2.05, -3.4],
				[-1.78, -1.3],
				[-1.38, -0.35],
				[-0.98, 0.45],
				[-0.66, 0.98],
				[-0.42, 1.16],
				[0.42, 1.16],
				[0.64, 1.02],
				[0.96, 0.35],
				[1.32, -0.5],
				[1.64, -1.4],
				[1.86, -3.4],
			];
			const bwPts = bwSamples.map((p) => [p.x, p.z]);
			g.add(mergedMesh([loftG(bwPts, core)], M.unique('rock', { color: 0x4d463d }), { name: 'breakwater-core', cast: true, receive: true }));
			// height of the mound surface at a given cross offset
			function coreY(u) {
				for (let i = 1; i < core.length; i++) {
					const a = core[i - 1],
						b = core[i];
					if ((u >= a[0] && u <= b[0]) || (u <= a[0] && u >= b[0])) return U.lerp(a[1], b[1], (u - a[0]) / ((b[0] - a[0]) || 1e-6));
				}
				return -3.4;
			}

			// armour rocks — always planted on the mound surface
			const rockGeos = [];
			const rockBase = new THREE.DodecahedronGeometry(0.5, 0);
			const ROCK_TONES = [new THREE.Color('#6b6156'), new THREE.Color('#7a7164'), new THREE.Color('#5d554c')];
			function addRock(x, y, z, sc) {
				const gq = rockBase.clone();
				sc *= 0.75; // overall armour stones a touch smaller
				gq.scale(sc * rng.range(0.8, 1.3), sc * rng.range(0.5, 1.0), sc * rng.range(0.8, 1.3));
				gq.rotateX(rng.range(0, TAU));
				gq.rotateY(rng.range(0, TAU));
				gq.rotateZ(rng.range(0, TAU));
				gq.translate(x, y, z);
				// per-stone warm tone, darkened below the waterline
				const c = ROCK_TONES[rng.int(0, ROCK_TONES.length - 1)].clone();
				c.offsetHSL(rng.range(-0.01, 0.01), rng.range(-0.03, 0.03), rng.range(-0.05, 0.04));
				if (y < 0.05) c.multiplyScalar(0.75);
				const n = gq.attributes.position.count;
				const cols = new Float32Array(n * 3);
				for (let i = 0; i < n; i++) {
					cols[i * 3] = c.r;
					cols[i * 3 + 1] = c.g;
					cols[i * 3 + 2] = c.b;
				}
				gq.setAttribute('color', new THREE.BufferAttribute(cols, 3));
				rockGeos.push(gq);
			}
			for (let i = 0; i < bwSamples.length; i++) {
				const p = bwSamples[i];
				// seaward slope: dense armour, stones sitting proud of the core
				for (let k = 0; k < 18; k++) {
					const u = -rng.range(0.3, 1.95);
					const sy = coreY(u);
					if (sy < -2.1) continue;
					const sc = U.lerp(0.5, 0.22, U.clamp((sy + 1.7) / 2.5, 0, 1)) * rng.range(0.85, 1.45);
					addRock(p.x + p.nx * u, sy + sc * 0.4, p.z + p.nz * u, sc);
				}
				// small stones filling the gaps between armour blocks
				for (let k = 0; k < 8; k++) {
					const u = -rng.range(0.34, 1.9);
					const sy = coreY(u);
					if (sy < -2.0) continue;
					addRock(p.x + p.nx * u, sy + 0.03, p.z + p.nz * u, rng.range(0.07, 0.15));
				}
				// waterline armour: big half-submerged boulders, irregular height
				for (const side of [-1, 1]) {
					const u = side * rng.range(0.95, 1.6);
					const sy = coreY(u);
					addRock(p.x + p.nx * u, Math.min(sy + 0.3, 0.16) + rng.range(-0.06, 0.14), p.z + p.nz * u, rng.range(0.34, 0.6));
				}
				// harbour slope: smaller stones
				for (let k = 0; k < 12; k++) {
					const u = rng.range(0.3, 1.68);
					const sy = coreY(u);
					if (sy < -1.7) continue;
					const sc = rng.range(0.12, 0.32);
					addRock(p.x + p.nx * u, sy + sc * 0.4, p.z + p.nz * u, sc);
				}
				for (let k = 0; k < 5; k++) {
					const u = rng.range(0.36, 1.55);
					const sy = coreY(u);
					if (sy < -1.6) continue;
					addRock(p.x + p.nx * u, sy + 0.02, p.z + p.nz * u, rng.range(0.06, 0.13));
				}
				// irregular low crest edge on the seaward side (breaks the wall line)
				for (let k = 0; k < 3; k++) {
					const uEdge = -rng.range(0.3, 0.55);
					addRock(p.x + p.nx * uEdge, rng.range(0.98, 1.2), p.z + p.nz * uEdge, rng.range(0.11, 0.26));
				}
				if (i % 5 === 0) addRock(p.x + p.nx * -rng.range(0.28, 0.48), rng.range(0.98, 1.14), p.z + p.nz * -rng.range(0.28, 0.48), rng.range(0.22, 0.34));
			}
			// rocks along the west beach transition and the fort point (planted)
			for (let k = 0; k < 16; k++) {
				const x = -10.0 - rng.range(0, 1.8);
				const z = 4.7 + rng.range(0, 1.4);
				const sy = gh(x, z);
				if (sy < -1.2) continue;
				addRock(x, Math.max(sy, -0.5) + rng.range(-0.05, 0.12), z, rng.range(0.16, 0.36));
			}
			for (let k = 0; k < 12; k++) {
				const x = 6.9 + rng.range(-0.5, 1.0);
				const z = 3.0 + rng.range(0, 0.9);
				const sy = gh(x, z);
				if (sy < -1.4) continue;
				addRock(x, Math.max(sy, -0.6) + rng.range(-0.05, 0.1), z, rng.range(0.16, 0.4));
			}
						{
				// one merged, vertex-coloured armour mesh: warm grey-brown stones, no
				// glossy specular sparkle
				const rockTex = rockMat.map;
				const armourMat = new THREE.MeshStandardMaterial({
					map: rockTex,
					vertexColors: true,
					color: 0xffffff,
					roughness: 0.95,
					metalness: 0.0,
					normalScale: new THREE.Vector2(0.35, 0.35),
					envMapIntensity: 0.45,
				});
				g.add(mergedMesh(rockGeos, armourMat, { name: 'breakwater-rocks', cast: true, receive: true }));
			}
			// subtle wet line along the seaward waterline (warm grey, not black)
			{
				const wetMat = new THREE.MeshStandardMaterial({ color: 0x4a453d, roughness: 0.55, metalness: 0.05, transparent: true, opacity: 0.4, side: THREE.DoubleSide, depthWrite: false });
				const wetG = [];
				for (let k = 0; k < 12; k++) {
					const sub = slicePolyline(BW, (BW_LEN * k) / 12, (BW_LEN * (k + 1)) / 12);
					if (sub) wetG.push(loftG(sub, [[-1.62, 0.1], [-1.2, 0.1]]));
				}
				g.add(mergedMesh(wetG, wetMat, { name: 'breakwater-wetline', cast: false, receive: false }));
			}

			// narrow crest walkway (weathered concrete)
			const walkMat = M.unique('concreteDark', { color: 0x736d63 });
			const walkProfile = [
				[-0.32, walkTop],
				[0.32, walkTop],
				[0.32, walkTop - 0.21],
				[-0.32, walkTop - 0.21],
			];
			const walkGeos = [];
			for (let k = 0; k < 10; k++) {
				const sub = slicePolyline(BW, (BW_LEN * k) / 10, (BW_LEN * (k + 1)) / 10);
				if (sub) walkGeos.push(loftG(sub, walkProfile));
			}
			g.add(mergedMesh(walkGeos, walkMat, { name: 'breakwater-walkway', cast: true, receive: true }));

			// (no drawn foam ring here: the water module owns the shoreline foam)

			// harbour-side railing: slim dark iron posts + two thin rails
			const railIron = M.painted('#3b3e39', { roughness: 0.62, metalness: 0.38 });
			const railPostGeo = U.merge([cylG(0.014, 0.018, 0.5, 5, 0, 0.25, 0), cylG(0.022, 0.022, 0.035, 5, 0, 0.018, 0)]);
			const railPosts = [];
			const railPos = [];
			for (let s = 0.8; s < BW_LEN - 0.7; s += 0.95) {
				const p = pointAt(BW, s);
				const x = p.x + p.nx * 0.27,
					z = p.z + p.nz * 0.27;
				railPosts.push([x, walkTop, z, Math.atan2(p.nx, p.nz)]);
				railPos.push([x, z]);
			}
			const railGeos = [];
			for (const h of [0.25, 0.46]) {
				for (let i = 1; i < railPos.length; i++) railGeos.push(tubeG([railPos[i - 1][0], walkTop + h, railPos[i - 1][1]], [railPos[i][0], walkTop + h, railPos[i][1]], 0.011, 4));
			}
			g.add(mergedMesh(railGeos, railIron, { name: 'breakwater-railing', cast: false, receive: false }));
			instanced(g, railPostGeo, railIron, railPosts, { cast: false, receive: false, name: 'breakwater-railposts' });

			// breakwater furniture
			for (let s = 1.8; s < BW_LEN - 1.2; s += 2.5) {
				const p = pointAt(BW, s);
				addBollard(p.x + p.nx * 0.12, p.z + p.nz * 0.12, walkTop, 'iron');
			}
			for (let s = 1.3; s < BW_LEN - 1.0; s += 3.2) {
				const p = pointAt(BW, s);
				addTire(p.x + p.nx * 1.3, p.z + p.nz * 1.3, 0.06, Math.atan2(p.nx, p.nz), 0.85);
			}
			for (const s of [2.8, 7.4, 11.8]) {
				const p = pointAt(BW, s);
				addLadder(p.x + p.nx * 1.26, p.z + p.nz * 1.26, 0.32, Math.atan2(p.nx, p.nz));
			}
			for (const s of [2.2, 5.8, 9.6, 13.4, 15.4]) {
				const p = pointAt(BW, s);
				addLamp(p.x + p.nx * 0.18, p.z + p.nz * 0.18, walkTop, Math.atan2(p.nx, p.nz), s === 5.8 || s === 13.4);
			}
			// steps down to the harbour on two spots
			const bwSteps = [];
			for (const ss of [4.4, 9.2]) {
				const p = pointAt(BW, ss);
				const ang = Math.atan2(p.tx, p.tz);
				for (let k = 0; k < 6; k++) bwSteps.push(boxG(0.5, 0.15, 0.25, p.x + p.nx * (0.36 + k * 0.22), walkTop - 0.07 - k * 0.14, p.z + p.nz * (0.36 + k * 0.22), ang));
				for (const side of [-1, 1]) bwSteps.push(boxG(0.08, 0.8, 1.25, p.x + p.tx * side * 0.3 + p.nx * 1.0, walkTop - 0.36, p.z + p.tz * side * 0.3 + p.nz * 1.0, ang));
			}
			g.add(mergedMesh(bwSteps, concreteDark, { name: 'breakwater-steps', cast: true, receive: true }));

			// winch near the lighthouse head
			const bwIronGeos = [];
			{
				const p = pointAt(BW, BW_LEN - 2.0);
				const bx = p.x + p.nx * 0.28,
					bz = p.z + p.nz * 0.28;
				bwIronGeos.push(cylG(0.06, 0.08, 0.22, 8, bx, walkTop + 0.11, bz));
				bwIronGeos.push(new THREE.TorusGeometry(0.09, 0.018, 5, 10).rotateX(PI / 2).translate(bx, walkTop + 0.24, bz));
			}
			g.add(mergedMesh(bwIronGeos, iron, { name: 'breakwater-winch', cast: false, receive: true }));

			// head platform for the lighthouse (top = LEVEL.breakwater)
			const head = bw.lighthouse;
			const headTop = bwY + 0.07;
			const headGeos = [cylG(1.05, 1.25, 4.4, 18, head[0], headTop - 2.2, head[1]), cylG(1.07, 1.07, 0.16, 18, head[0], headTop - 0.08, head[1])];
			g.add(mergedMesh(headGeos, stone, { name: 'breakwater-head', cast: true, receive: true }));
			// two shallow steps from the walkway up onto the head platform
			{
				const st = [];
				const p = pointAt(BW, BW_LEN - 0.35);
				const ang = Math.atan2(p.tx, p.tz);
				st.push(boxG(1.5, 0.1, 0.3, head[0] + 1.25, walkTop + 0.04, head[1] + 0.15, ang));
				st.push(boxG(1.5, 0.1, 0.3, head[0] + 1.05, walkTop + 0.12, head[1] + 0.13, ang));
				g.add(mergedMesh(st, concreteDark, { name: 'head-steps', cast: true, receive: true }));
			}
			const headPosts = [];
			const headRails = [];
			for (let i = 0; i < 14; i++) {
				const a = (i / 14) * TAU;
				headPosts.push([head[0] + Math.cos(a) * 0.95, headTop, head[1] + Math.sin(a) * 0.95, -a]);
			}
			for (let i = 0; i < 14; i++) {
				const a = headPosts[i],
					b = headPosts[(i + 1) % 14];
				headRails.push(tubeG([a[0], headTop + 0.46, a[2]], [b[0], headTop + 0.46, b[2]], 0.017, 5));
				headRails.push(tubeG([a[0], headTop + 0.24, a[2]], [b[0], headTop + 0.24, b[2]], 0.013, 5));
			}
			instanced(g, railPostGeo, steelDark, headPosts, { cast: false, receive: false, name: 'head-railposts' });
			g.add(mergedMesh(headRails, steelDark, { name: 'head-railing', cast: false, receive: false }));
			g.add(mergedMesh([cylG(0.88, 0.88, 0.07, 18, head[0], headTop - 0.035, head[1])], cobble, { name: 'head-paving', cast: false, receive: true }));
			addLadder(head[0] + 1.18, head[1] + 0.15, headTop - 0.05, PI / 2);
			for (let i = 0; i < 4; i++) {
				const a = (i / 4) * TAU + 0.4;
				addRing(head[0] + Math.cos(a) * 1.25, head[1] + Math.sin(a) * 1.25, headTop - 0.55, Math.atan2(Math.cos(a), Math.sin(a)));
			}
			// winch near the head
			{
				const p = pointAt(BW, BW_LEN - 2.0);
				const bx = p.x + p.nx * 0.32,
					bz = p.z + p.nz * 0.32;
				ironGeos.push(cylG(0.07, 0.09, 0.24, 8, bx, walkTop + 0.12, bz));
				ironGeos.push(new THREE.TorusGeometry(0.1, 0.02, 5, 10).rotateX(PI / 2).translate(bx, walkTop + 0.26, bz));
			}
			// fort-side abutment
			{
				const p = pointAt(BW, 0.25);
				const ang = Math.atan2(p.tx, p.tz);
				g.add(mergedMesh([boxG(1.5, 0.5, 1.7, p.x - p.tx * 0.4, bwY - 0.25, p.z - p.tz * 0.4, ang), boxG(1.1, 0.35, 1.2, p.x + p.tx * 0.6, bwY - 0.45, p.z + p.tz * 0.6, ang)], concreteDark, { name: 'breakwater-abutment', cast: true, receive: true }));
			}

			// ---- breakwater life layer: fishermen, gear, chairs ----
			{
				const fisherDark = M.painted('#2e3438', { roughness: 0.9 });
				const fisherCoat = M.painted('#8f4b3a', { roughness: 0.85 });
				const silhouettes = [];
				const coatGeos = [];
				const rods = [];
				const cratesBw = [];
				const woodBits = [];
				const lineGeos = [];
				const chairs = [];
				function fisher(ss, side, coat) {
					const pp = pointAt(BW, ss);
					const bx = pp.x + pp.nx * side * 0.2;
					const bz = pp.z + pp.nz * side * 0.2;
					silhouettes.push(new THREE.BoxGeometry(0.032, 0.046, 0.024).translate(bx, walkTop + 0.045, bz));
					silhouettes.push(new THREE.SphereGeometry(0.013, 6, 5).translate(bx, walkTop + 0.077, bz));
					silhouettes.push(new THREE.BoxGeometry(0.028, 0.016, 0.05).translate(bx - pp.nx * side * 0.025, walkTop + 0.012, bz - pp.nz * side * 0.025));
					const tipx = bx - pp.nx * side * 0.34,
						tipz = bz - pp.nz * side * 0.34;
					rods.push(tubeG([bx - pp.nx * side * 0.02, walkTop + 0.06, bz - pp.nz * side * 0.02], [tipx, walkTop + 0.17, tipz], 0.0045, 3));
					lineGeos.push(tubeG([tipx, walkTop + 0.17, tipz], [tipx, walkTop - 0.12, tipz], 0.0018, 2));
					if (coat) coatGeos.push(new THREE.BoxGeometry(0.036, 0.03, 0.028).translate(bx, walkTop + 0.05, bz));
				}
				fisher(5.2, 1, true);
				fisher(12.9, 1, false);
				const f1 = pointAt(BW, 4.55);
				cratesBw.push(boxG(0.16, 0.12, 0.14, f1.x + f1.nx * 0.14, walkTop + 0.06, f1.z + f1.nz * 0.14, Math.atan2(f1.tx, f1.tz)));
				woodBits.push(cylG(0.05, 0.05, 0.13, 8, f1.x + f1.tx * 0.22, walkTop + 0.065, f1.z + f1.tz * 0.22));
				for (const ang of [0.35, 2.1]) {
					const cxp = head[0] + Math.cos(ang) * 0.62,
						czp = head[1] + Math.sin(ang) * 0.62;
					chairs.push(boxG(0.1, 0.012, 0.09, cxp, headTop + 0.045, czp, -ang));
					chairs.push(boxG(0.1, 0.1, 0.012, cxp + Math.cos(ang) * 0.045, headTop + 0.1, czp + Math.sin(ang) * 0.045, -ang));
					for (const [ox, oz] of [[-0.04, -0.035], [0.04, -0.035], [-0.04, 0.035], [0.04, 0.035]]) chairs.push(boxG(0.008, 0.09, 0.008, cxp + ox, headTop + 0.005, czp + oz, -ang));
				}
				g.add(mergedMesh(silhouettes, fisherDark, { name: 'breakwater-fishers', cast: true, receive: true }));
				if (coatGeos.length) g.add(mergedMesh(coatGeos, fisherCoat, { name: 'breakwater-coats', cast: true }));
				g.add(mergedMesh(rods, fisherDark, { name: 'fishing-rods', cast: false, receive: false }));
				g.add(mergedMesh(lineGeos, M.painted('#d8d2c2', { roughness: 0.6 }), { name: 'fishing-lines', cast: false, receive: false }));
				g.add(mergedMesh(cratesBw, woodLight, { name: 'bw-crate', cast: true, receive: true }));
				g.add(mergedMesh(woodBits, woodDark, { name: 'bw-barrel', cast: true, receive: true }));
				g.add(mergedMesh(chairs, woodLight, { name: 'head-chairs', cast: true, receive: true }));
				// draped fishing net over the harbour railing
				const netC = U.createCanvas(64);
				const nctx = netC.getContext('2d');
				nctx.clearRect(0, 0, 64, 64);
				nctx.strokeStyle = 'rgba(232,226,208,0.9)';
				nctx.lineWidth = 1;
				for (let i = -64; i < 128; i += 8) {
					nctx.beginPath();
					nctx.moveTo(i, 0);
					nctx.lineTo(i + 64, 64);
					nctx.stroke();
					nctx.beginPath();
					nctx.moveTo(i + 64, 0);
					nctx.lineTo(i, 64);
					nctx.stroke();
				}
				const netTex = U.canvasTex(netC, { srgb: true, cacheKey: 't2net64' });
				const netMat = new THREE.MeshBasicMaterial({ map: netTex, transparent: true, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
				const np = pointAt(BW, 4.15);
				const net = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.2), netMat);
				net.position.set(np.x + np.nx * 0.55, walkTop - 0.06, np.z + np.nz * 0.55);
				net.rotation.y = Math.atan2(np.nx, np.nz);
				net.rotation.z = 0.12;
				g.add(net);
				// lifebuoy on a post near the fishermen
				const lp2 = pointAt(BW, 6.4);
				steelGeos.push(cylG(0.014, 0.014, 0.5, 5, lp2.x + lp2.nx * 0.1, walkTop + 0.25, lp2.z + lp2.nz * 0.1));
				buoyRed.push([lp2.x + lp2.nx * 0.1, walkTop + 0.36, lp2.z + lp2.nz * 0.1, Math.atan2(lp2.nx, lp2.nz)]);
				for (let k = 0; k < 4; k++) {
					const a = (k / 4) * TAU + PI / 4;
					buoyWhite.push([lp2.x + lp2.nx * 0.1 + Math.cos(a) * 0.075, walkTop + 0.36 + Math.sin(a) * 0.075, lp2.z + lp2.nz * 0.1 + 0.01, Math.atan2(lp2.nx, lp2.nz)]);
				}
			}

			// ==========================================================
			// 4. FINALISE INSTANCED FURNITURE
			// ==========================================================
			instanced(g, U.merge([cylG(0.05, 0.062, 0.17, 10, 0, 0.085, 0), cylG(0.072, 0.072, 0.028, 10, 0, 0.178, 0), new THREE.TorusGeometry(0.05, 0.012, 4, 8).rotateX(PI / 2).translate(0, 0.16, 0)]), M.painted('#4b4640', { roughness: 0.78, metalness: 0.35 }), ironBollards, { cast: false, receive: true, name: 'bollards-iron' });
			instanced(g, U.merge([cylG(0.075, 0.095, 0.2, 8, 0, 0.1, 0), cylG(0.1, 0.1, 0.04, 8, 0, 0.21, 0)]), stoneDark, stoneBollards, { cast: false, receive: true, name: 'bollards-stone' });
			instanced(g, U.merge([cylG(0.018, 0.018, 0.11, 6, 0, 0.02, 0, 0, 0, PI / 2), cylG(0.02, 0.02, 0.05, 6, 0, 0.045, 0)]), brass, cleats, { cast: false, receive: false, name: 'cleats' });
			instanced(g, new THREE.TorusGeometry(0.1, 0.032, 6, 12), rubber, tires, { cast: false, receive: false, name: 'fender-tires' });
			instanced(g, new THREE.TorusGeometry(0.075, 0.016, 5, 10), iron, rings, { cast: false, receive: false, name: 'mooring-rings' });
			{
				const lg = [];
				for (const x of [-0.09, 0.09]) lg.push(cylG(0.014, 0.014, 1.4, 5, x, -0.55, 0));
				for (let i = 0; i < 7; i++) lg.push(cylG(0.011, 0.011, 0.18, 4, 0, -1.15 + i * 0.19, 0, 0, 0, PI / 2));
				instanced(g, U.merge(lg), M.painted('#6b5a47', { roughness: 0.8, metalness: 0.22 }), ladders, { cast: false, receive: false, name: 'ladders' });
			}
			instanced(g, U.merge([cylG(0.02, 0.028, 0.5, 6, 0, 0.25, 0), cylG(0.045, 0.045, 0.03, 6, 0, 0.015, 0), cylG(0.03, 0.03, 0.03, 6, 0, 0.5, 0)]), paintGreen, lampPosts, { cast: false, receive: false, name: 'lamp-posts' });
			instanced(g, new THREE.CylinderGeometry(0.055, 0.04, 0.11, 6), lampMat, lampHeads, { cast: false, receive: false, name: 'lamp-heads' });
			instanced(g, new THREE.TorusGeometry(0.095, 0.026, 5, 12), paintRed, buoyRed, { cast: false, receive: false, name: 'lifebuoys' });
			instanced(g, new THREE.BoxGeometry(0.035, 0.045, 0.02), paintWhite, buoyWhite, { cast: false, receive: false, name: 'lifebuoy-bands' });
			instanced(g, new THREE.BoxGeometry(0.24, 0.16, 0.17), woodLight, crates, { cast: true, receive: true, name: 'crates' });
			instanced(g, new THREE.CylinderGeometry(0.075, 0.075, 0.18, 10), iron, drums, { cast: true, receive: true, name: 'drums' });
			if (pileConcrete.length) {
				const pileGeo = new THREE.CylinderGeometry(0.075, 0.09, 1, 7);
				instanced(g, pileGeo, concreteDark, pileConcrete, { cast: true, receive: true, name: 'piles-concrete' });
			}
			if (pileTimber.length) {
				const pileGeo = new THREE.CylinderGeometry(0.055, 0.07, 1, 7);
				instanced(g, pileGeo, woodDark, pileTimber, { cast: true, receive: true, name: 'piles-timber' });
			}
			if (steelGeos.length) g.add(mergedMesh(steelGeos, steel, { name: 'quay-steel', cast: true, receive: true }));
			if (ironGeos.length) g.add(mergedMesh(ironGeos, iron, { name: 'quay-iron', cast: false, receive: true }));
			if (woodGeos.length) g.add(mergedMesh(woodGeos, woodDark, { name: 'quay-timber', cast: false, receive: true }));
			if (ropeGeos.length) g.add(mergedMesh(ropeGeos, ropeMat, { name: 'quay-rope', cast: false, receive: false }));

			// ==========================================================
			// 5. NIGHT LIGHTS
			// ==========================================================
			const pointLights = [];
			for (const p of lampsPoint) {
				const pl = new THREE.PointLight(0xffcf96, 0, 5.5, 2);
				pl.position.set(p[0], p[1], p[2]);
				pl.userData.base = 2.0;
				g.add(pl);
				pointLights.push(pl);
			}
			function onEnv(state) {
				const n = state.night || 0;
				lampMat.emissiveIntensity = 0.12 + n * 3.4;
				for (const pl of pointLights) pl.intensity = n * (pl.userData.base || 2);
			}
			if (ctx.env && ctx.env.onEnv) ctx.env.onEnv(onEnv);

			// ---------------- publish shared geometry ----------------
			ctx.world.quay = {
				edge: EDGE.slice(),
				deckY: DECK,
				paveY: PAVE,
				piers: L.PIERS.map((p) => ({ id: p.id, start: p.start.slice(), dir: p.dir.slice(), length: p.length, width: p.width, deck: p.deck, style: p.style })),
			};
			ctx.world.breakwater = { path: BW.slice(), crestY: bwY, head: head.slice(), width: bw.width };

			return {
				update(dt, t) {
					for (const b of pontoonBobbers) {
						b.obj.position.y = Math.sin(t * 0.9 + b.seed) * 0.018;
						b.obj.rotation.z = Math.sin(t * 0.7 + b.seed) * 0.006;
						b.obj.rotation.x = Math.cos(t * 0.63 + b.seed) * 0.005;
					}
				},
				onEnv,
			};
		},
	});
})(window.HARBOR);
