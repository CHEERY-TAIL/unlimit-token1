# QA / 视觉审片 / 性能 / 离线验证报告 — 微型港口 MINIATURE HARBOUR

> 角色：t6-qa（独立 QA，不改产品代码）
> 最后更新：2026-10-27 11:05 · **ROUND 3 FINAL 终检完成**
> 数据源：`qa/rounds/round3-final/report.json`（56 用例）· `qa/latest/report.json`（同一份拷贝）· 基线 `qa/rounds/round1-baseline/`
> Contact sheet：`qa/latest/sheet-hero-hero.png`（9 宫格主图）· `sheet-views-views-p1/p2/p3.png`（21 张）· `sheet-orbit-orbit.png`（360°）· `sheet-isolation-isolation.png` · `sheet-mixed-mixed.png`
> 源码快照：**10:41:59–10:52:18 冻结版**；终检全量复跑于 **11:04–11:16**（期间 `changedDuringRun: none`，即所有用例跑在同一份冻结源码上）

---

## 0. 终检结论：✅ PASS（无 P0；性能与离线均达标；仅余 P1/P2 观感项）

| # | 验收项 | 结果 | 证据 |
| --- | --- | --- | --- |
| 1 | 首屏加载（loader 淡出、ready） | ✅ PASS（ready ≈3–5s，boot_ready check pass） | `report.json` → uiAudit |
| 2 | **file:// 双击离线打开** | ✅ PASS（10 模块全加载、0 错误、正常出图） | `qa/shots/qa-r3-final-file-offline.png`、`qa/results/qa-r3-final-file-offline.json`、`qa/latest/offline-static.md` |
| 3 | 7 视角 × 黄昏/正午/夜晚 全出图 | ✅ PASS 21/21 | `qa/latest/sheet-views-views-p1/p2/p3.png` |
| 4 | **360° 环视 8 方位**（硬性交付项） | ✅ PASS 8/8，无黑块/无空白背面 | `qa/latest/sheet-orbit-orbit.png`、`qa/latest/qc-shots.json` |
| 5 | UI 交互（视角/时间/画质/自动旋转/重置/截图/全屏） | ✅ PASS 18/18 | `report.json` → uiAudit |
| 6 | 键盘 1–7 / R / A / H / S / F | ✅ PASS | 同上 |
| 7 | 移动端 390×780 | ✅ PASS（HUD 布局正常） | `qa/shots/qa-r3-final-mobile-*.png` |
| 8 | 页面错误 / 模块错误 / console 错误 = 0 | ✅ PASS（56 用例全部 0） | `report.json` → summary |
| 9 | draw calls ≤ 550 | ✅ PASS（**最大 498**；主视角 250–395） | §2 |
| 10 | triangles ≤ 2.5M | ✅ PASS（最大 **953K**，仅 38%） | §2 |
| 11 | 黑块/断片/全黑帧 | ✅ PASS（qc-shots.py 检查 40 张，0 命中） | `qa/latest/qc-shots.json` |
| 12 | `?freeze=1` 可复现 | ✅ PASS（平均像素差 0.16/255；>8 的像素仅 0.74%，视觉一致） | `qa/shots/qa-r3-final-freeze-1/2.png` |
| 13 | high 画质 fps ≥ 55（真机） | ⏳ 待 Lead 真 GPU 实测；无头 daemon 数据见 §2.4 | — |
| 14 | 视觉反例清单（浮空/穿模/死黑/白曝/比例） | ⚠ 无 P0；余 P1/P2 观感项，见 §4 | 见 §4 |

**P0 问题清单：无。** 测试期间发现并已修复/复验的 P0：① 相机绕东/北侧时 atmosphere 灯塔光束 shader 产生大面积黑色断片（t5 修复，8 方位复验通过）；② 水盘边缘荧光青环（t1 修复）；③ 浮空岩石（t1 修复）；④ 海鸥白弧（t5 修复）。终检全部复验通过。

---

## 1. 测试方法与环境

| 项 | 说明 |
| --- | --- |
| 被测页面 | `index.html`（http daemon）+ `file:///D:/AICODE2/AITEST/ds1/miniature-harbor/index.html` |
| 浏览器 | Lead 常驻截图服务 `tools/shoot-daemon.mjs` v3（无头 Chrome；页面每 18 张回收、崩溃自恢复、90s 硬超时、失败也写 result） |
| 截图口径 | 场景图 = **WebGL canvas 原像素**（1600×1000 @1.5 DPR → **2400×1500**，无 HUD）；HUD/移动端/交互 = 整页截图 |
| 可复现 | 全部 `freeze=1&t=12` + `autorotate=0`；`run-qa.mjs` 等源码 15s 静默后开拍；失败用例自动重试 1 次 |
| 预算 | draw calls ≤ 550，triangles ≤ 2.5M，high 画质 fps ≥ 55（ARCHITECTURE §7） |
| 终检用例数 | **56**：42 主矩阵 + 8 环视 + 6 真实 fps |

### 1.1 一键复跑

```powershell
node qa/run-qa.mjs --round 3-final --name "final-acceptance"                 # 42 用例主矩阵
node qa/run-qa.mjs --round 3-final --merge --groups orbit,fps                # 360° + 真实 fps
node qa/run-qa.mjs --round 3-final --regen                                   # 重生成 REPORT.md
node qa/offline-static-audit.mjs                                             # file:// 静态审计
& $py qa/qc-shots.py --manifest qa/rounds/round3-final/contact-qc.json --out qa/latest/qc-shots.json   # 黑块/断片检测
& $py qa/contact-sheet.py --manifest qa/rounds/round3-final/contact-hero.json --out-prefix qa/latest/sheet-hero --cols 3 --rows 3 --cell 560
```

---

## 2. 终检性能数据（源码冻结版，1600×1000，high，canvas 2400×1500）

### 2.1 主矩阵（7 视角 × 3 时段，fps 为无头 daemon 噪音值，仅参考）

| 视角 | 黄昏 fps / calls / tri | 正午 fps / calls / tri | 夜晚 fps / calls / tri |
| --- | --- | --- | --- |
| overview 总览 | 60 / 394 / 623K | 56 / 388 / 623K | 34 / 395 / 622K |
| harbor 港湾 | 45 / 356 / 608K | 49 / 354 / 608K | 26 / 357 / 607K |
| town 老城 | 73 / 256 / 543K | 47 / 256 / 543K | 34 / 257 / 542K |
| lighthouse 灯塔 | 55 / 336 / 608K | 58 / 332 / 608K | 42 / 337 / 607K |
| marina 码头 | 49 / 312 / 579K | 48 / 312 / 579K | 42 / 313 / 578K |
| quay 作业区 | 30 / 282 / 572K | 57 / 282 / 572K | 40 / 284 / 571K |
| top 鸟瞰 | 32 / 369 / 613K | 43 / 367 / 613K | 31 / 370 / 612K |

**预算判定：draw calls 最大 395（主视角）/ 498（quality-low）≤ 550 ✓；triangles 最大 953K ≤ 2.5M ✓。**

### 2.2 画质档位

| 画质 | draw calls | triangles | 像素比 |
| --- | --- | --- | --- |
| high | 394 | 623K | 1.5 |
| medium | 394 | 623K | 1.15 |
| low | 498 | 953K | 1.0 |

> low 的 triangles 反而更高：水面在低画质走非平面反射的波浪网格路径（模块内部实现差异），仍在预算内。

### 2.3 单模块归因（`?only=`，overview 黄昏，全景 394 calls 参照）

| 模块 | calls | triangles | owner |
| --- | --- | --- | --- |
| industrial | 138 | 16K | t2 |
| quay | 115 | 181K | t2 |
| vessels | 92 | 112K | t4 |
| lighthouse | 72 | 12K | t2 |
| props | 67 | 119K | t4 |
| street | 58 | 66K | t3 |
| town | 51 | 104K | t3 |
| terrain | 34 | 301K | t1 |
| atmosphere | 33 | 6K | t5 |
| water | 20 | 61K | t1 |

### 2.4 真实稳态 fps（`capture=none`，无像素读回；wait 3.5s，freeze=0 动画运行）

| 用例 | draw calls | triangles | fps |
| --- | --- | --- | --- |
| overview 黄昏 high | 394 | 623K | **36** |
| overview 夜晚 high | 395 | 622K | **56** |
| overview 正午 high | 388 | 623K | **49** |
| harbor 黄昏 high | 356 | 608K | **45** |
| overview 黄昏 medium | 394 | 623K | **58** |
| overview 黄昏 low | 498 | 953K | **99** |

> ⚠ 以上是无头 Chrome（共享 daemon、可能软件渲染/SwiftShader）的数字，**低于真机**。交付 README 请以 Lead 的 RTX 2070S 真机数据为准；本表用于版本间相对比较（medium 相对 high 提升 1.6×、low 2.7×，符合预期）。

### 2.5 其他用例

| 用例 | draw calls | triangles | 说明 |
| --- | --- | --- | --- |
| mobile 黄昏 390×780 | 287 | 576K | HUD 正常 |
| mobile 夜晚 390×780 | 288 | 575K | HUD 正常 |
| HUD 整页 / 纯场景 | 394 | 623K | HUD 与场景渲染一致 |
| freeze ×2 | 356 | 608K | 平均像素差 0.08，视觉可复现 |
| skip=atmosphere | 378 | 619K | 容错正常 |
| **file:// 离线** | 394 | 623K | 10 模块、0 错误 |
| 360° 环视 ×8 | 394 | 623K | 8 方位一致，无黑块 |

---

## 3. 360° 环视（硬性交付项）

`qa/latest/sheet-orbit-orbit.png`：方位角 0/45/90/135/180/225/270/315°，相机 `r=44, h=21` 看向中心。

- 8 个方位**全部有剪影可读**：南侧防波堤+灯塔+外海、西侧沙滩湾、北侧老城+山丘、东侧 Fort Point/marina；
- 无空白背面、无黑块/断片（`qa/latest/qc-shots.json`：40 张 all checked，0 flagged）；
- 朝向太阳一侧天空暖金、背向太阳一侧偏深蓝，符合 17:35 低角度太阳的物理表现。

---

## 4. 遗留问题（终检版）

> P0 = 阻塞交付；P1 = 应修但可带病交付；P2 = 锦上添花。终检**无 P0**。

### P1（重要，建议下一版修）

| # | 问题 | 证据 | owner |
| --- | --- | --- | --- |
| P1-01 | 黄金时刻整体仍偏"乳白/雾感"，天空与暗部对比可以再拉开（ART 要求"对比要够，不能灰蒙蒙"） | `qa/shots/qa-r3-final-view-overview-dusk.png` | lead（env/render core） |
| P1-02 | 正午（12:00）画面偏白、水色偏亮青，阳光直射区饱和度偏高 | `qa/shots/qa-r3-final-view-overview-day.png` | lead + t1 |
| P1-03 | 街面排水篦/井盖等小件是**纯黑**（ART 禁止纯黑），近景像黑洞 | `qa/shots/qa-r3-final-view-town-dusk.png` 前景道路 | t3 |
| P1-04 | 路面仍有白色虚线车道线，1:220 微缩尺度下偏"现代公路" | 同上 | t3 |
| P1-05 | 码头近景中部疑似有一块半透明面片/光柱（quay 视角可见，边缘可辨） | `qa/shots/qa-r3-final-view-quay-dusk.png` 中央 | t2 / t5 |
| P1-06 | 窗玻璃近景仍是深色平面，缺天空反光（远景可接受） | `qa/shots/qa-r3-final-view-town-dusk.png` | t3 |

### P2（锦上添花）

| # | 建议 | owner |
| --- | --- | --- |
| P2-01 | 防波堤外坡岩石块面偏大、金边高光偏强，可再打散 2–3 个尺度并降低湿面镜面 | t2 |
| P2-02 | 广场/街道局部仍有平坦感，可再加花箱/摊位/自行车/行人密度 | t3 |
| P2-03 | 夜间灯罩光晕略大（bloom+halo），可再收一档 | t5 / lead |
| P2-04 | 云层在 tilt-shift 上缘仍有轻微糊成块状，可把近处云再推远 | t5 |
| P2-05 | 教堂塔尖/山墙细节、挡土墙水渍爬藤 | t3 |
| P2-06 | `freeze=1` 时 env 过渡首帧 settle（进一步保证逐像素一致） | lead |

---

## 5. 轮次记录

| 轮次 | 时间 | 用例 | 结果 |
| --- | --- | --- | --- |
| Round 1 基线 | 09:04–09:08 | 41 | blockout 体块；draw calls **1521**（超预算 2.8×）、tri 324K、0 错误（存档 `qa/rounds/round1-baseline/`） |
| Round 2 MID | 09:47–10:07 | 42 | 模块成型；calls ≤393 ✓、tri ≤602K ✓、file:// ✓、UI 18/18 ✓；发现 3 个阻塞观感项（均已修） |
| Round 2 复查 | 10:20–10:31 | 16 | 修复验证 + 首次 360° 环视（发现 atmosphere 黑块 P0） |
| **Round 3 FINAL** | 11:04–11:16 | **56** | **0 错误 / 0 黑块 / calls ≤498 / tri ≤953K / file:// ✓ / UI 18/18 ✓ / 360° ✓**（源码冻结版：layout.js 10:52:18 / env+render 10:47:19） |

---

## 6. 交付产物索引

| 产物 | 路径 |
| --- | --- |
| 终检数据 | `qa/rounds/round3-final/report.json`、`REPORT.md`、`qa/latest/report.json` |
| 主图 9 宫格 | `qa/latest/sheet-hero-hero.png` |
| 7 视角 × 3 时段（21 张） | `qa/latest/sheet-views-views-p1/p2/p3.png` |
| 360° 环视（8 方位） | `qa/latest/sheet-orbit-orbit.png` |
| 单模块隔离（10 张） | `qa/latest/sheet-isolation-isolation.png` |
| 画质/移动端/HUD/冻结（9 张） | `qa/latest/sheet-mixed-mixed.png` |
| 单张原图（2400×1500） | `qa/shots/qa-r3-final-*.png` |
| 黑块/断片检测 | `qa/latest/qc-shots.json` |
| 离线静态审计 | `qa/latest/offline-static.md` |
| 问题特写 | `qa/latest/issue-*.png` |

**最佳 3 张图（建议用于 README/交付展示）**
1. `qa/latest/sheet-hero-hero.png` — 9 宫格总览（黄昏/正午/夜晚 + 6 视角）
2. `qa/shots/qa-r3-final-view-overview-dusk.png` — 黄金时刻全景（2400×1500，无 HUD）
3. `qa/shots/qa-r3-final-view-overview-night.png` — 夜景（暖窗光 + 灯塔 + 船只灯光反射）

---

## 7. 协作记录（本轮已发出的问题与结果）

- t1-terrain：水色/树脂霓虹环/泡沫白带/浮空岩石/死黑阴影 → 已修复，终检复验通过。
- t2-structures：浮空岩石自查（非其归属）、防波堤体量收窄/白石压暗/删可见光束/爬梯改色 → 已修复。
- t3-town：6 张自检图逐条 review（浮空/屋顶/窗玻璃/镜像招牌/比例尺/空广场/阴影）→ 已修大部分，余 P1-03/04/06。
- t4-vessels：浮空树修（553 株 0 悬空）、黑矩形非其归属、船吃水/缆绳/道具/夜景灯光 → 已修复。
- t5-atmosphere：海鸥 V 形/炊烟/光束/云/星星 → 已修；终检前 P0 黑块（beam shader）已修复并 8 方位复验。
- lead：Round2 MID 汇总、P0 黑块定位与修复授权、终检启动信号 → 已闭环。
