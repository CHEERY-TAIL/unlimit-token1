﻿/**
 * 31-street.js 鈥?roads, kerbs, pavements, street furniture, lamps,
 * pedestrians and small life.  OWNER: t3 town-life.
 *
 * Roads are built by sampling layout.groundHeight along the ROADS polylines
 * (never from road.level directly) so they climb the harbour bluff with the
 * terrain.  Everything repetitive is merged or instanced.
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const L = H.layout;
	const PI = Math.PI;
	const TAU = PI * 2;

	const WARM_LAMP = new THREE.Color('#ffd9a0');

	H.register('street', {
		create(ctx) {
			const g = ctx.group('street');
			const M = ctx.materials;
			const r = U.rng(31337);

			// ==========================================================
			// materials (shared with town where possible)
			// ==========================================================
			const matCobble = M.get('cobble');
			const matAsphalt = M.get('asphalt');
			const matStone = new THREE.MeshStandardMaterial({
				color: 0x9a9186,
				roughness: 0.94,
				metalness: 0.0,
				vertexColors: true,
			});
			const matConcrete = new THREE.MeshStandardMaterial({ color: 0x9a958b, roughness: 0.9, metalness: 0.02, vertexColors: true });
			const matTrim = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.55, metalness: 0.1 });
			const matMetal = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.45, metalness: 0.72 });
			const matWood = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.78, metalness: 0.02 });
			const matLeaf = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, metalness: 0.0 });
			const matFabric = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.88, metalness: 0.0, side: THREE.DoubleSide });
			const matTar = new THREE.MeshStandardMaterial({ color: 0x2b2c2d, roughness: 0.92, metalness: 0.02 });
			const matMark = new THREE.MeshStandardMaterial({ color: 0x6a655c, roughness: 0.95, metalness: 0.0, transparent: true, opacity: 0.25 });
			const matGrate = new THREE.MeshStandardMaterial({ color: 0x4a4a46, roughness: 0.8, metalness: 0.4 });
			const matGlassLit = new THREE.MeshStandardMaterial({
				color: 0x2a2218,
				emissive: new THREE.Color('#ffc27a'),
				emissiveIntensity: 0.0,
				roughness: 0.3,
				metalness: 0.2,
			});
			const matSkin = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.7, metalness: 0.0 });

			// ==========================================================
			// merge/instancing buckets
			// ==========================================================
			const merged = new Map();
			const batch = new Map();
			function bucket(key, mat) {
				let b = merged.get(key);
				if (!b) {
					b = { mat, geos: [] };
					merged.set(key, b);
				}
				return b;
			}
			function ensureIndexed(geo) {
				if (geo.index) return geo;
				const n = geo.attributes.position.count;
				const idx = new Uint16Array(n);
				for (let i = 0; i < n; i++) idx[i] = i;
				geo.setIndex(new THREE.BufferAttribute(idx, 1));
				return geo;
			}
			function paint(geo, color) {
				const n = geo.attributes.position.count;
				const arr = new Float32Array(n * 3);
				const c = color instanceof THREE.Color ? color : U.color(color || '#ffffff');
				for (let i = 0; i < n; i++) {
					arr[i * 3] = c.r;
					arr[i * 3 + 1] = c.g;
					arr[i * 3 + 2] = c.b;
				}
				geo.setAttribute('color', new THREE.BufferAttribute(arr, 3));
			}
			const DEF_MAT = {
				fabric: matFabric,
				'bench-wood': matWood,
				'bench-iron': matMetal,
				'cat-body': matWood,
				'lamp-iron': matMetal,
				'kerb-stone': matStone,
				'kerb-concrete': matConcrete,
				walk: matStone,
				gutter: matTar,
				mark: matMark,
				bike: matMetal,
			};
			function mGeo(key, color, geo, mat, lm) {
				const cfg = merged.get(key);
				const useMat = mat || (cfg && cfg.mat) || DEF_MAT[key] || matStone;
				if (lm) geo.applyMatrix4(lm);
				ensureIndexed(geo);
				paint(geo, color);
				bucket(key, useMat).geos.push(geo);
			}
			const _q = new THREE.Quaternion();
			const _e = new THREE.Euler();
			const _p = new THREE.Vector3();
			const _s = new THREE.Vector3();
			function locM(x, y, z, rx, ry, rz, sx, sy, sz) {
				_e.set(rx || 0, ry || 0, rz || 0, 'YXZ');
				_q.setFromEuler(_e);
				_p.set(x || 0, y || 0, z || 0);
				_s.set(sx == null ? 1 : sx, sy == null ? 1 : sy, sz == null ? 1 : sz);
				return new THREE.Matrix4().compose(_p, _q, _s);
			}
			function mBox(key, color, w, h, d, x, y, z, o) {
				mGeo(key, color, new THREE.BoxGeometry(w, h, d), (o && o.mat) || null, locM(x, y, z, o && o.rx, o && o.ry, o && o.rz));
			}
			function mCyl(key, color, rt, rb, h, seg, x, y, z, o) {
				mGeo(key, color, new THREE.CylinderGeometry(rt, rb, h, seg), (o && o.mat) || null, locM(x, y, z, o && o.rx, o && o.ry, o && o.rz));
			}
			function inst(key, geo, mat, color, lm) {
				let b = batch.get(key);
				if (!b) {
					b = { geo, mat, list: [], colors: [] };
					batch.set(key, b);
				}
				b.list.push(lm);
				b.colors.push(color ? (color.isColor ? color : U.color(color)) : null);
			}
			// shared instanced geometries
			const GEO_MANHOLE = new THREE.CylinderGeometry(0.5, 0.5, 1, 12);
			const GEO_GRATE = new THREE.BoxGeometry(0.36, 0.1, 0.6);
			const GEO_LAMPGLASS = new THREE.CylinderGeometry(0.045, 0.05, 0.075, 6);
			const GEO_LEAF = new THREE.IcosahedronGeometry(1, 0);
			const GEO_FLOWER = new THREE.IcosahedronGeometry(1, 0);
			const furniturePoints = [];
			function noteFurniture(x, z, r) {
				furniturePoints.push([+x.toFixed(2), +z.toFixed(2), r || 0.25]);
			}

			// custom indexed quad/ribbon accumulator
			function ribbonGeo(rows) {
				// rows: [{left:[x,y,z], right:[x,y,z], u0,u1, v}]
				const pos = [];
				const uv = [];
				const idx = [];
				for (let i = 0; i < rows.length; i++) {
					const r0 = rows[i];
					pos.push(r0.left[0], r0.left[1], r0.left[2]);
					pos.push(r0.right[0], r0.right[1], r0.right[2]);
					uv.push(0, r0.v);
					uv.push(r0.u, r0.v);
					if (i > 0) {
						const a = i * 2;
						idx.push(a - 2, a, a - 1, a - 1, a, a + 1);
					}
				}
				const geo = new THREE.BufferGeometry();
				geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
				geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
				geo.setIndex(idx);
				geo.computeVertexNormals();
				return geo;
			}

			// ==========================================================
			// 1. road profiles (sampled from the terrain!)
			// ==========================================================
			const profiles = {};
			function sampleRoad(road) {
				const pts = road.points;
				const total = L.polylineLength(pts);
				const step = 0.11;
				const n = Math.max(5, Math.round(total / step));
				const list = [];
				for (let i = 0; i <= n; i++) {
					const s2 = (i / n) * total;
					const p = L.pointAlong(pts, s2);
					list.push({
						s: s2,
						x: p.x,
						z: p.z,
						dx: p.dirX,
						dz: p.dirZ,
						y: L.groundHeight(p.x, p.z),
						h: 0,
					});
				}
				// smooth the terrain profile for the gentle road surface
				for (let pass = 0; pass < 3; pass++) {
					const out = list.map((p) => p.y);
					const win = 3;
					for (let i = 0; i < list.length; i++) {
						let sum = 0,
							cnt = 0;
						for (let k = -win; k <= win; k++) {
							const j = i + k;
							if (j < 0 || j >= list.length) continue;
							sum += list[j].y;
							cnt++;
						}
						out[i] = sum / cnt;
					}
					for (let i = 0; i < list.length; i++) list[i].y = out[i];
				}
				for (const p of list) p.y = Math.max(p.y, L.WATER_Y + 0.12);
				// classify steep stretches -> they become stair streets
				const steepFlags = [];
				for (let i = 0; i < list.length; i++) {
					const a = list[Math.max(0, i - 1)],
						b = list[Math.min(list.length - 1, i + 1)];
					const ds = Math.hypot(b.x - a.x, b.z - a.z) || 1e-6;
					steepFlags.push(Math.abs(b.y - a.y) / ds > 0.42);
				}
				const segs = [];
				let curSeg = null;
				for (let i = 0; i < list.length; i++) {
					if (steepFlags[i]) {
						if (!curSeg) curSeg = { i0: i, i1: i };
						else curSeg.i1 = i;
					} else if (curSeg) {
						segs.push(curSeg);
						curSeg = null;
					}
				}
				if (curSeg) segs.push(curSeg);
				for (const seg of segs) {
					const a = list[seg.i0],
						b = list[seg.i1];
					seg.s0 = a.s;
					seg.s1 = b.s;
					const run = Math.max(0.15, b.s - a.s);
					const rise = b.y - a.y;
					seg.rise = rise / Math.max(2, Math.round(Math.abs(rise) / 0.105)) || 0.001;
					seg.n = Math.max(2, Math.round(Math.abs(rise) / Math.abs(seg.rise)));
					seg.y0 = a.y;
					seg.midY = (a.y + b.y) / 2;
				}
				// walking / road height per sample: gentle = smooth terrain,
				// steep = quantised stair treads
				for (let i = 0; i < list.length; i++) {
					const p = list[i];
					let inSeg = null;
					for (const seg of segs) {
						if (p.s >= seg.s0 - 0.02 && p.s <= seg.s1 + 0.02) {
							inSeg = seg;
							break;
						}
					}
					if (inSeg) {
						const t = U.clamp((p.s - inSeg.s0) / Math.max(0.01, inSeg.s1 - inSeg.s0), 0, 0.9999);
						const k = Math.floor(t * inSeg.n);
						p.h = inSeg.y0 + (k + 1) * inSeg.rise + 0.045;
						p.stair = true;
					} else {
						p.h = p.y + 0.072;
						p.stair = false;
					}
				}
				const prof = {
					road,
					total,
					list,
					segs,
					at(s2) {
						const t = U.clamp(s2, 0, total);
						const f = (t / total) * (list.length - 1);
						const i = Math.min(list.length - 2, Math.max(0, Math.floor(f)));
						const k = U.clamp(f - i, 0, 1);
						const a = list[i],
							b = list[i + 1];
						return {
							x: U.lerp(a.x, b.x, k),
							z: U.lerp(a.z, b.z, k),
							dx: U.lerp(a.dx, b.dx, k),
							dz: U.lerp(a.dz, b.dz, k),
							y: U.lerp(a.h, b.h, k),
							terrain: U.lerp(a.y, b.y, k),
							stair: a.stair || b.stair,
							nx: -U.lerp(a.dz, b.dz, k),
							nz: U.lerp(a.dx, b.dx, k),
						};
					},
					slopeAt(s2) {
						const a = prof.at(Math.max(0, s2 - 0.2)),
							b = prof.at(Math.min(total, s2 + 0.2));
						return Math.abs(b.y - a.y) / Math.max(0.001, Math.hypot(b.x - a.x, b.z - a.z));
					},
					isStair(s2) {
						for (const seg of segs) if (s2 >= seg.s0 && s2 <= seg.s1) return true;
						return false;
					},
				};
				profiles[road.id] = prof;
				return prof;
			}
			for (const road of L.ROADS) sampleRoad(road);

			// ==========================================================
			// 2. road surfaces
			// ==========================================================
			const ROAD_STYLE = {
				mainStreet: { mat: matCobble, uv: 0.5, kerb: 'stone', walk: true, widthScale: 1.0 },
				hillLane: { mat: matCobble, uv: 0.42, kerb: 'stone', walk: true, widthScale: 1.0 },
				quayRoad: { mat: matAsphalt, uv: 0.72, kerb: 'concrete', walk: true, widthScale: 1.0 },
				fortRoad: { mat: matCobble, uv: 0.45, kerb: 'stone', walk: true, widthScale: 1.0 },
				beachLane: { mat: matCobble, uv: 0.36, kerb: 'stone', walk: false, widthScale: 1.0 },
			};
			function buildRoad(road) {
				const prof = profiles[road.id];
				const style = ROAD_STYLE[road.id] || ROAD_STYLE.mainStreet;
				const halfW = (road.width * style.widthScale) / 2;
				const kerbKey = style.kerb === 'concrete' ? 'kerb-concrete' : 'kerb-stone';
				const list = prof.list;
				// ---- split the centreline into gentle runs (ribbon) and stairs ----
				let runStart = 0;
				const runs = [];
				for (let i = 0; i < list.length; i++) {
					if (list[i].stair) {
						if (i > runStart) runs.push([runStart, i]);
						while (i < list.length && list[i].stair) i++;
						runStart = Math.max(0, i);
						i--;
					}
				}
				if (list.length - 1 > runStart) runs.push([runStart, list.length - 1]);
				// pavement ribbon for each gentle run
				for (const [i0, i1] of runs) {
					if (i1 - i0 < 1) continue;
					const rows = [];
					for (let i = i0; i <= i1; i++) {
						const p = list[i];
						const crown = 0.01;
						rows.push({
							left: [p.x + p.dx * -halfW, p.h + crown, p.z + p.dz * halfW],
							right: [p.x + p.dx * halfW, p.h + crown, p.z - p.dz * halfW],
							u: (halfW * 2) / style.uv,
							v: p.s / style.uv,
						});
					}
					// fix: left/right computed with the normal, not the tangent
					const rows2 = [];
					for (let i = i0; i <= i1; i++) {
						const p = list[i];
						const nx = -p.dz,
							nz = p.dx;
						rows2.push({
							left: [p.x + nx * halfW, p.h + 0.01, p.z + nz * halfW],
							right: [p.x - nx * halfW, p.h + 0.01, p.z - nz * halfW],
							u: (halfW * 2) / style.uv,
							v: p.s / style.uv,
						});
					}
					mGeo('road-' + road.id, null, ribbonGeo(rows2), style.mat);
					// ---- kerbs / pavements for this gentle run ----
					for (let i = i0; i < i1; i++) {
						const pa = list[i],
							pb = list[i + 1];
						const mx = (pa.x + pb.x) / 2,
							mz = (pa.z + pb.z) / 2;
						const nx = -(pa.dz + pb.dz) / 2,
							nz = (pa.dx + pb.dx) / 2;
						const len = Math.hypot(pb.x - pa.x, pb.z - pa.z) + 0.03;
						const ang = Math.atan2(pb.x - pa.x, pb.z - pa.z);
						const gy2 = (pa.h + pb.h) / 2;
						for (let side = -1; side <= 1; side += 2) {
							mBox(kerbKey, null, 0.055, 0.11, len, mx + nx * side * (halfW + 0.025), gy2 + 0.03, mz + nz * side * (halfW + 0.025), { ry: ang });
							mBox('gutter', '#26282a', 0.07, 0.004, len, mx + nx * side * (halfW - 0.035), gy2 + 0.008, mz + nz * side * (halfW - 0.035), { ry: ang, mat: matTar });
							if (style.walk) {
								mBox('walk', null, 0.13, 0.05, len, mx + nx * side * (halfW + 0.1), gy2 + 0.05, mz + nz * side * (halfW + 0.1), { ry: ang });
							}
						}
					}
				}
				// ---- stair streets ----
				for (const seg of prof.segs) {
					const run = Math.max(0.1, seg.s1 - seg.s0);
					const n = Math.max(2, seg.n);
					const stepRun = run / n;
					for (let k = 0; k < n; k++) {
						const sc = seg.s0 + (k + 0.5) * stepRun;
						const p = prof.at(sc);
						const topY = seg.y0 + (k + 1) * seg.rise;
						const ang = Math.atan2(p.dx, p.dz);
						// tread block (extends below the visible tread)
						mBox(kerbKey, '#8f877c', road.width + 0.04, 0.22, stepRun + 0.025, p.x, topY - 0.11, p.z, { ry: ang });
						// darker nosing strip
						mBox('gutter', '#2a2622', road.width + 0.04, 0.006, 0.03, p.x + p.dx * (stepRun / 2 - 0.012), topY + 0.001, p.z + p.dz * (stepRun / 2 - 0.012), { ry: ang, mat: matTar });
					}
					// side cheek walls + handrail
					for (let side = -1; side <= 1; side += 2) {
						for (let k = 0; k < n; k++) {
							const sc = seg.s0 + (k + 0.5) * stepRun;
							const p = prof.at(sc);
							const topY = seg.y0 + (k + 1) * seg.rise;
							const ang = Math.atan2(p.dx, p.dz);
							const cx = p.x + p.nx * side * (halfW + 0.055);
							const cz = p.z + p.nz * side * (halfW + 0.055);
							mBox(kerbKey, '#9a9186', 0.09, 0.34, stepRun + 0.03, cx, topY + 0.06, cz, { ry: ang });
							// iron handrail
							mBox('bench-iron', '#2f3336', 0.014, 0.014, stepRun + 0.03, cx, topY + 0.28, cz, { ry: ang });
							if (k % 2 === 0) mBox('bench-iron', '#2f3336', 0.018, 0.22, 0.018, cx, topY + 0.17, cz, { ry: ang });
						}
					}
				}
				// ---- faint stone wear seams instead of modern road paint ----
				if (style.mat === matAsphalt) {
					for (let s2 = 0.8; s2 < prof.total - 0.5; s2 += 1.7) {
						if (prof.isStair(s2)) continue;
						const p = prof.at(s2);
						const ang = Math.atan2(p.dx, p.dz);
						const off = (r.chance(0.5) ? 1 : -1) * r.range(0.05, halfW - 0.08);
						mBox('mark', null, r.range(0.03, 0.055), 0.002, r.range(0.24, 0.46), p.x + p.nx * off, p.y + 0.0105, p.z + p.nz * off, { ry: ang + r.range(-0.18, 0.18), mat: matMark });
					}
				}
				// ---- manholes + drains ----
				for (let s2 = 0.7; s2 < prof.total - 0.5; s2 += 1.9) {
					if (prof.isStair(s2)) continue;
					const p = prof.at(s2);
					const off = r.chance(0.5) ? 0.12 : -0.12;
					inst('manhole', GEO_MANHOLE, matMetal, '#5a5348', locM(p.x + p.nx * off, p.y + 0.014, p.z + p.nz * off, 0, 0, 0, 0.09, 0.01, 0.09));
					inst('grate', GEO_GRATE, matGrate, null, locM(p.x - p.nx * (halfW - 0.09), p.y + 0.012, p.z - p.nz * (halfW - 0.09), 0, Math.atan2(p.dx, p.dz), 0, 0.224, 1, 0.24));
				}
				ctx.log('street: ' + road.id + ' paved ' + prof.total.toFixed(1) + 'u, stairs ' + prof.segs.length);
			}
			for (const road of L.ROADS) buildRoad(road);

			// ==========================================================
			// 3. street lamps
			// ==========================================================
			const lampPositions = [];
			function addLamp(x, z, y, ry, scale) {
				noteFurniture(x, z, 0.14);
				scale = scale || 1;
				const h = 0.52 * scale;
				mCyl('lamp-iron', '#2f3336', 0.016 * scale, 0.024 * scale, 0.06 * scale, 6, x, y + 0.03 * scale, z);
				mCyl('lamp-iron', '#2f3336', 0.011 * scale, 0.017 * scale, h, 6, x, y + 0.06 * scale + h / 2, z);
				// arm + lamp head
				const ax = x + Math.cos(ry) * 0.1 * scale;
				const az = z - Math.sin(ry) * 0.1 * scale;
				mBox('lamp-iron', '#2f3336', 0.02 * scale, 0.015 * scale, 0.18 * scale, x + Math.cos(ry) * 0.05 * scale, y + 0.06 * scale + h - 0.01, z - Math.sin(ry) * 0.05 * scale, { ry });
				mCyl('lamp-iron', '#2f3336', 0.052 * scale, 0.058 * scale, 0.012 * scale, 6, ax, y + 0.06 * scale + h - 0.012, az);
				inst('lampGlass', GEO_LAMPGLASS, matGlassLit, null, locM(ax, y + 0.06 * scale + h - 0.05, az, 0, ry, 0, scale, scale * 1.06, scale));
				mCyl('lamp-iron', '#2f3336', 0.012 * scale, 0.055 * scale, 0.02 * scale, 6, ax, y + 0.06 * scale + h + 0.002, az);
				mCyl('lamp-iron', '#2f3336', 0.056 * scale, 0.056 * scale, 0.012 * scale, 6, ax, y + 0.06 * scale + h - 0.095, az);
				lampPositions.push([ax, y + 0.06 * scale + h - 0.06, az]);
			}
			function lampsAlong(roadId, spacing, side, scale) {
				const road = L.ROADS.find((rr) => rr.id === roadId);
				const prof = profiles[roadId];
				const halfW = road.width / 2;
				const st = ROAD_STYLE[roadId];
				const walkOff = st.walk ? 0.105 : 0.0;
				for (let s = 0.6; s < prof.total - 0.4; s += spacing) {
					if (prof.isStair(s)) continue;
					const p = prof.at(s);
					const x = p.x + p.nx * side * (halfW + walkOff + 0.02);
					const z = p.z + p.nz * side * (halfW + walkOff + 0.02);
					const faceIn = side > 0 ? 0 : PI;
					addLamp(x, z, p.y + 0.1, Math.atan2(p.dx, p.dz) + faceIn, scale);
				}
			}
			lampsAlong('mainStreet', 1.5, 1, 1);
			lampsAlong('mainStreet', 1.5, -1, 1);
			lampsAlong('quayRoad', 1.7, 1, 1.05);
			lampsAlong('hillLane', 1.4, 1, 0.92);
			lampsAlong('beachLane', 1.6, 1, 0.9);
			// two lamps at the plaza corners (town module has its own)
			const paneX = L.ANCHORS.plaza.pos[0];
			const paneZ = L.ANCHORS.plaza.pos[1];
			addLamp(paneX + 1.62, paneZ + 0.62, L.groundHeight(paneX, paneZ) + 0.03, -PI / 2, 1);
			addLamp(paneX - 1.62, paneZ - 0.5, L.groundHeight(paneX, paneZ) + 0.03, PI / 2, 1);

			// warm point lights that switch on at night
			const lights = [];
			const lightSpots = [
				[paneX - 0.2, 2.7, paneZ],
				[0.6, 2.75, -5.0],
				[-3.4, 1.9, 1.5],
			];
			for (const [lx, ly, lz] of lightSpots) {
				const pl = new THREE.PointLight(0xffb877, 0, 3.2, 2);
				pl.position.set(lx, ly, lz);
				g.add(pl);
				lights.push(pl);
			}
			// glow billboards on top of the glass heads (cheap bloom spots)
			{
				const c = U.createCanvas(64);
				const cc = c.getContext('2d');
				const grad = cc.createRadialGradient(32, 32, 0, 32, 32, 32);
				grad.addColorStop(0, 'rgba(255,230,180,1)');
				grad.addColorStop(0.4, 'rgba(255,190,110,0.55)');
				grad.addColorStop(1, 'rgba(255,160,70,0)');
				cc.fillStyle = grad;
				cc.fillRect(0, 0, 64, 64);
				const tex = U.canvasTex(c, { cacheKey: 'street-lampglow' });
				const geo = new THREE.BufferGeometry();
				const arr = new Float32Array(lampPositions.length * 3);
				for (let i = 0; i < lampPositions.length; i++) {
					arr[i * 3] = lampPositions[i][0];
					arr[i * 3 + 1] = lampPositions[i][1];
					arr[i * 3 + 2] = lampPositions[i][2];
				}
				geo.setAttribute('position', new THREE.BufferAttribute(arr, 3));
				const glowMat = new THREE.PointsMaterial({
					map: tex,
					size: 0.36,
					sizeAttenuation: true,
					transparent: true,
					opacity: 0,
					depthWrite: false,
					blending: THREE.AdditiveBlending,
					toneMapped: false,
				});
				const pts = new THREE.Points(geo, glowMat);
				pts.name = 'lamp-glow';
				pts.frustumCulled = false;
				g.add(pts);
				g.userData.lampGlow = glowMat;
			}

			// ==========================================================
			// 4. street furniture
			// ==========================================================
			function streetPoint(roadId, s, side, extra) {
				const road = L.ROADS.find((rr) => rr.id === roadId);
				const prof = profiles[roadId];
				const p = prof.at(s);
				const off = road.width / 2 + (extra == null ? 0.16 : extra);
				return {
					x: p.x + p.nx * side * off,
					z: p.z + p.nz * side * off,
					y: p.y + 0.1,
					ang: Math.atan2(p.dx, p.dz),
					nx: p.nx * side,
					nz: p.nz * side,
				};
			}
			function addBench(x, y, z, ry) {
				noteFurniture(x, z, 0.3);
				const c = Math.cos(ry),
					s = Math.sin(ry);
				const pos = (lx, lz) => [x + lx * c + lz * s, z - lx * s + lz * c];
				for (let i = 0; i < 3; i++) {
					const p = pos(0, -0.045 + i * 0.045);
					mBox('bench-wood', '#9a7a52', 0.44, 0.016, 0.036, p[0], y + 0.1, p[1], { ry });
				}
				for (let i = 0; i < 2; i++) {
					const p = pos(0, 0.075);
					mBox('bench-wood', '#8a6746', 0.44, 0.03, 0.014, p[0], y + 0.15 + i * 0.04, p[1], { ry, rx: -0.12 });
				}
				for (const lx of [-0.17, 0.17]) {
					const p = pos(lx, 0.01);
					mBox('bench-iron', '#2f3336', 0.026, 0.1, 0.06, p[0], y + 0.05, p[1], { ry });
					const p2 = pos(lx, 0.075);
					mBox('bench-iron', '#2f3336', 0.014, 0.13, 0.014, p2[0], y + 0.1, p2[1], { ry, rx: -0.12 });
				}
			}
			function addPlanter(x, y, z, ry) {
				noteFurniture(x, z, 0.24);
				mBox('kerb-stone', null, 0.3, 0.14, 0.2, x, y + 0.07, z, { ry });
				for (let i = 0; i < 5; i++) {
					inst('leaf', GEO_LEAF, matLeaf, U.color(r.pick(['#6f8248', '#7d8f57', '#8a9a5c', '#5f7544'])), locM(x + r.range(-0.1, 0.1), y + 0.17, z + r.range(-0.06, 0.06), r.range(0, 3), r.range(0, 3), 0, r.range(0.045, 0.07), r.range(0.04, 0.06), r.range(0.045, 0.07)));
				}
				for (let i = 0; i < 4; i++) {
					inst('leaf', GEO_FLOWER, matLeaf, U.color(r.pick(['#d96a56', '#e0a24b', '#d67ba1', '#e8d06b'])), locM(x + r.range(-0.1, 0.1), y + 0.2, z + r.range(-0.06, 0.06), 0, 0, 0, 0.022, 0.02, 0.022));
				}
			}
			function addBin(x, y, z) {
				noteFurniture(x, z, 0.16);
				mCyl('bench-iron', '#55604f', 0.05, 0.045, 0.16, 8, x, y + 0.08, z);
				mCyl('bench-iron', '#3d443c', 0.056, 0.056, 0.02, 8, x, y + 0.17, z);
				for (let i = 0; i < 3; i++) mBox('bench-iron', '#2f3336', 0.09, 0.006, 0.09, x, y + 0.04 + i * 0.05, z, { ry: 0.4 });
			}
			function addBike(x, y, z, ry) {
				noteFurniture(x, z, 0.26);
				const c = Math.cos(ry),
					s = Math.sin(ry);
				const pos = (lx, lz) => [x + lx * c + lz * s, z - lx * s + lz * c];
				const wheel = new THREE.TorusGeometry(0.055, 0.007, 4, 10);
				const p1 = pos(-0.14, 0);
				const p2 = pos(0.14, 0);
				mGeo('bench-iron', '#2a2c2e', new THREE.TorusGeometry(0.055, 0.007, 4, 10), null, locM(p1[0], y + 0.056, p1[1], 0, ry + PI / 2, 0));
				mGeo('bench-iron', '#2a2c2e', new THREE.TorusGeometry(0.055, 0.007, 4, 10), null, locM(p2[0], y + 0.056, p2[1], 0, ry + PI / 2, 0));
				const p3 = pos(0, 0.01);
				mBox('bench-iron', '#6d7a86', 0.13, 0.012, 0.012, p3[0], y + 0.09, p3[1], { ry });
				const p4 = pos(-0.02, 0);
				mBox('bench-iron', '#6d7a86', 0.012, 0.09, 0.012, p4[0], y + 0.1, p4[1], { ry, rz: 0.3 });
				const p5 = pos(0.13, 0);
				mBox('bench-iron', '#3a3a36', 0.06, 0.012, 0.012, p5[0], y + 0.15, p5[1], { ry });
				const p6 = pos(-0.13, 0);
				mBox('bench-iron', '#3a3a36', 0.06, 0.012, 0.012, p6[0], y + 0.15, p6[1], { ry });
			}
			function addNoticeBoard(x, y, z, ry) {
				noteFurniture(x, z, 0.3);
				for (const lx of [-0.22, 0.22]) {
					const c = Math.cos(ry),
						s = Math.sin(ry);
					mBox('bench-wood', '#5b4028', 0.04, 0.46, 0.04, x + lx * c, y + 0.23, z - lx * s);
				}
				mBox('bench-wood', '#5b4028', 0.5, 0.3, 0.03, x, y + 0.32, z, { ry });
			}
			// benches + planters + bins along main street
			for (const [roadId, s, side] of [
				['mainStreet', 8.0, 1],
				['mainStreet', 11.4, -1],
				['mainStreet', 14.9, 1],
				['mainStreet', 17.6, -1],
				['quayRoad', 5.2, -1],
				['quayRoad', 9.8, -1],
			]) {
				const p = streetPoint(roadId, s, side, 0.13);
				addBench(p.x, p.y, p.z, p.ang + (side > 0 ? -PI / 2 : PI / 2));
			}
			for (const [roadId, s, side] of [
				['mainStreet', 7.0, -1],
				['mainStreet', 10.6, 1],
				['mainStreet', 12.9, -1],
				['mainStreet', 16.1, 1],
				['quayRoad', 7.4, 1],
			]) {
				const p = streetPoint(roadId, s, side, 0.1);
				addPlanter(p.x, p.y, p.z, p.ang);
			}
			for (const [roadId, s, side] of [
				['mainStreet', 9.1, -1],
				['mainStreet', 15.8, 1],
				['quayRoad', 11.4, 1],
				['mainStreet', 6.4, 1],
			]) {
				const p = streetPoint(roadId, s, side, 0.12);
				addBin(p.x, p.y, p.z);
			}
			for (const [roadId, s, side] of [
				['mainStreet', 9.9, 1],
				['mainStreet', 13.2, -1],
				['quayRoad', 4.3, 1],
			]) {
				const p = streetPoint(roadId, s, side, 0.12);
				addBike(p.x, p.y, p.z, p.ang + 0.2);
			}
			{
				const p = streetPoint('mainStreet', 12.2, 1, 0.14);
				addNoticeBoard(p.x, p.y, p.z, p.ang + PI / 2);
			}

			// ==========================================================
			// 5. bunting + cables across the main street
			// ==========================================================
			function bunting(roadId, s) {
				const road = L.ROADS.find((rr) => rr.id === roadId);
				const prof = profiles[roadId];
				const p = prof.at(s);
				const a = streetPoint(roadId, s, 1, 0.18);
				const b = streetPoint(roadId, s, -1, 0.18);
				const top = p.y + 1.35;
				const sag = 0.22;
				const N = 9;
				let prev = null;
				for (let i = 0; i <= N; i++) {
					const t = i / N;
					const x = U.lerp(a.x, b.x, t);
					const z = U.lerp(a.z, b.z, t);
					const y = top - Math.sin(t * PI) * sag;
					if (prev) {
						const dx = x - prev[0],
							dy = y - prev[1],
							dz = z - prev[2];
						const len = Math.hypot(dx, dy, dz);
						mBox('bench-iron', '#3a3833', 0.008, 0.008, len, (x + prev[0]) / 2, (y + prev[1]) / 2, (z + prev[2]) / 2, {
							ry: Math.atan2(dx, dz),
							rx: -Math.atan2(dy, Math.hypot(dx, dz)),
						});
					}
					if (i > 0 && i < N) {
						const ax = x - a.x,
							az = z - a.z;
						const ang = Math.atan2(ax, az);
						const geo = new THREE.BufferGeometry();
						geo.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, 0, 0.055, 0, 0, 0.0275, -0.07, 0], 3));
						geo.setAttribute('uv', new THREE.Float32BufferAttribute([0, 0, 1, 0, 0.5, 1], 2));
						geo.setIndex([0, 1, 2]);
						geo.computeVertexNormals();
						mGeo('fabric', i % 2 ? '#b3453b' : '#efe6d2', geo, null, locM(x, y - 0.02, z, 0, ang + PI / 2, 0));
					}
					prev = [x, y, z];
				}
			}
			bunting('mainStreet', 10.4);
			bunting('mainStreet', 15.2);
			bunting('quayRoad', 6.6);

			// utility poles + wires along the quay road
			{
				const prof = profiles.quayRoad;
				const road = L.ROADS.find((rr) => rr.id === 'quayRoad');
				const polePts = [];
				for (let s = 1.6; s < prof.total - 1.2; s += 2.6) {
					const p = prof.at(s);
					const x = p.x - p.nx * (road.width / 2 + 0.3);
					const z = p.z - p.nz * (road.width / 2 + 0.3);
					mCyl('bench-wood', '#5a4632', 0.016, 0.028, 0.96, 6, x, p.y + 0.48, z);
					noteFurniture(x, z, 0.16);
					mBox('bench-wood', '#5a4632', 0.26, 0.02, 0.02, x, p.y + 0.9, z, { ry: Math.atan2(p.dx, p.dz) + PI / 2 });
					polePts.push([x, p.y + 0.92, z]);
				}
				if (polePts.length > 1) {
					const positions = [];
					for (let i = 1; i < polePts.length; i++) {
						const a = polePts[i - 1],
							b = polePts[i];
						const N = 6;
						for (let k = 0; k < N; k++) {
							const t0 = k / N,
								t1 = (k + 1) / N;
							const y0 = a[1] - Math.sin(t0 * PI) * 0.06,
								y1 = b[1] - Math.sin(t1 * PI) * 0.06;
							positions.push(U.lerp(a[0], b[0], t0), y0, U.lerp(a[2], b[2], t0));
							positions.push(U.lerp(a[0], b[0], t1), y1, U.lerp(a[2], b[2], t1));
						}
					}
					const wgeo = new THREE.BufferGeometry();
					wgeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
					const wireMat = new THREE.LineBasicMaterial({ color: 0x24262a, transparent: true, opacity: 0.85 });
					const wires = new THREE.LineSegments(wgeo, wireMat);
					wires.name = 'street-wires';
					g.add(wires);
				}
			}

			// ==========================================================
			// 6. cats / dogs / pigeons
			// ==========================================================
			function addCat(x, y, z, ry, color) {
				mBox('cat-body', color, 0.05, 0.028, 0.1, x, y + 0.026, z, { ry });
				mBox('cat-body', color, 0.034, 0.03, 0.032, x + Math.sin(ry) * 0.055, y + 0.042, z + Math.cos(ry) * 0.055, { ry });
				// ears
				mBox('cat-body', color, 0.008, 0.014, 0.008, x + Math.sin(ry) * 0.058 + Math.cos(ry) * 0.01, y + 0.062, z + Math.cos(ry) * 0.058 - Math.sin(ry) * 0.01, { ry });
				mBox('cat-body', color, 0.008, 0.014, 0.008, x + Math.sin(ry) * 0.058 - Math.cos(ry) * 0.01, y + 0.062, z + Math.cos(ry) * 0.058 + Math.sin(ry) * 0.01, { ry });
				// tail
				mBox('cat-body', color, 0.008, 0.008, 0.07, x - Math.sin(ry) * 0.07, y + 0.045, z - Math.cos(ry) * 0.07, { ry: ry + 0.5, rx: -0.4 });
			}
			function addDog(x, y, z, ry, color) {
				mBox('cat-body', color, 0.06, 0.04, 0.14, x, y + 0.035, z, { ry });
				mBox('cat-body', color, 0.04, 0.04, 0.045, x + Math.sin(ry) * 0.08, y + 0.06, z + Math.cos(ry) * 0.08, { ry });
				for (const s2 of [-1, 1]) {
					mBox('cat-body', color, 0.012, 0.05, 0.012, x + Math.cos(ry) * s2 * 0.022 + Math.sin(ry) * 0.045, y + 0.015, z - Math.sin(ry) * s2 * 0.022 + Math.cos(ry) * 0.045);
					mBox('cat-body', color, 0.012, 0.05, 0.012, x + Math.cos(ry) * s2 * 0.022 - Math.sin(ry) * 0.045, y + 0.015, z - Math.sin(ry) * s2 * 0.022 - Math.cos(ry) * 0.045);
				}
			}
			addCat(-2.6, 2.165, -2.9, 0.6, '#4a4440');
			addCat(1.2, 2.165, -6.2, -1.2, '#c8b8a0');
			addDog(-7.6, 2.165, -3.4, 2.1, '#8a6a4a');
			// pigeons near the plaza
			for (let i = 0; i < 5; i++) {
				const px = paneX + r.range(-0.9, 0.9),
					pz = paneZ + r.range(-0.9, 0.9);
				const py = L.groundHeight(px, pz) + 0.02;
				mBox('cat-body', '#9a9a98', 0.03, 0.022, 0.05, px, py + 0.02, pz, { ry: r.range(0, TAU) });
				mBox('cat-body', '#7c7c7a', 0.018, 0.018, 0.02, px + 0.03, py + 0.035, pz, {});
			}

			// ==========================================================
			// 7. pedestrians
			// ==========================================================
			const PEOPLE_HEIGHT = 0.09;
			const people = [];
			function addPerson(roadId, s, dir, speed, color, opts) {
				people.push({
					roadId,
					s,
					dir,
					speed,
					color,
					phase: r.range(0, TAU),
					off: (opts && opts.off) || 0.18,
					walking: (opts && opts.walking) !== false,
				});
			}
			// walkers along the main street
			const cloth = ['#8a5a3a', '#3f6688', '#7d8f57', '#b3453b', '#efe6d2', '#4a4440', '#c39a4a', '#5c6b73'];
			for (let i = 0; i < 6; i++) {
				addPerson('mainStreet', 6.5 + i * 1.7, i % 2 ? 1 : -1, r.range(0.045, 0.075), r.pick(cloth), { off: (i % 2 ? 1 : -1) * r.range(0.12, 0.26) });
			}
			for (let i = 0; i < 3; i++) {
				addPerson('quayRoad', 3.2 + i * 2.3, i % 2 ? 1 : -1, r.range(0.045, 0.07), r.pick(cloth), { off: (i % 2 ? 1 : -1) * 0.2 });
			}
			addPerson('hillLane', 2.2, 1, 0.05, '#5c6b73', { off: 0.12 });
			addPerson('hillLane', 5.0, -1, 0.045, '#8a5a3a', { off: -0.12 });
			// people standing on the plaza
			const plazaStands = [
				[-1.5, -6.5, PI],
				[-2.6, -7.4, 0.3],
				[-3.3, -6.6, -PI / 2],
				[-1.1, -7.2, PI / 2],
			];
			for (const [px, pz, ry] of plazaStands) {
				people.push({
					fixed: [px, pz],
					ry,
					speed: 0,
					color: r.pick(cloth),
					phase: r.range(0, TAU),
					walking: false,
				});
			}
			// instanced person parts
			const GEO_BODY = new THREE.CylinderGeometry(0.55, 0.75, 1, 6);
			const GEO_HEAD = new THREE.SphereGeometry(1, 7, 6);
			const GEO_LEG = new THREE.BoxGeometry(1, 1, 1);
			const bodyColors = people.map((p) => U.color(p.color));
			const bodyMesh = new THREE.InstancedMesh(GEO_BODY, new THREE.MeshStandardMaterial({ roughness: 0.85, metalness: 0.0 }), people.length);
			const headMesh = new THREE.InstancedMesh(GEO_HEAD, new THREE.MeshStandardMaterial({ roughness: 0.7, metalness: 0.0 }), people.length);
			const legMesh = new THREE.InstancedMesh(GEO_LEG, new THREE.MeshStandardMaterial({ roughness: 0.85, metalness: 0.0 }), people.length * 2);
			bodyMesh.name = 'street-people-bodies';
			headMesh.name = 'street-people-heads';
			legMesh.name = 'street-people-legs';
			for (let i = 0; i < people.length; i++) bodyMesh.setColorAt(i, bodyColors[i]);
			const skin = ['#c89a78', '#a87c5c', '#e0c0a0', '#8a6048'];
			const headColors = people.map(() => U.color(r.pick(skin)));
			for (let i = 0; i < people.length; i++) headMesh.setColorAt(i, headColors[i]);
			const legColor = U.color('#3a3630');
			for (let i = 0; i < people.length * 2; i++) legMesh.setColorAt(i, legColor);
			bodyMesh.castShadow = false;
			headMesh.castShadow = false;
			legMesh.castShadow = false;
			g.add(bodyMesh);
			g.add(headMesh);
			g.add(legMesh);
			const _dummy = new THREE.Object3D();
			function personPose(p, time) {
				let x, z, y, ang;
				if (p.fixed) {
					x = p.fixed[0];
					z = p.fixed[1];
					y = L.groundHeight(x, z) + 0.03;
					ang = p.ry;
				} else {
					const prof = profiles[p.roadId];
					const s = U.mod(p.s + (p.walking ? p.speed * p.dir * time * 0.06 : 0), prof.total);
					const q = prof.at(s);
					x = q.x + q.nx * p.off;
					z = q.z + q.nz * p.off;
					y = q.y + 0.075;
					ang = Math.atan2(q.dx * p.dir, q.dz * p.dir);
				}
				// footfall bob
				const bob = p.walking ? Math.abs(Math.sin((time * 2.2 + p.phase) * 2.6)) * 0.006 : 0;
				const legSwing = p.walking ? Math.sin((time * 2.4 + p.phase) * 3.2) * 0.35 : 0;
				return { x, y: y + bob, z, ang, legSwing };
			}
			const _m = new THREE.Matrix4();
			function setPose(time) {
				for (let i = 0; i < people.length; i++) {
					const p = people[i];
					const pose = personPose(p, time);
					const c = Math.cos(pose.ang),
						s = Math.sin(pose.ang);
					// body (tapered cylinder, local y = body)
					_dummy.position.set(pose.x, pose.y + 0.032, pose.z);
					_dummy.rotation.set(0, pose.ang, 0);
					_dummy.scale.set(0.024, 0.05, 0.024);
					_dummy.updateMatrix();
					bodyMesh.setMatrixAt(i, _dummy.matrix);
					// head
					_dummy.position.set(pose.x, pose.y + 0.076, pose.z);
					_dummy.rotation.set(0, pose.ang, 0);
					_dummy.scale.set(0.016, 0.019, 0.016);
					_dummy.updateMatrix();
					headMesh.setMatrixAt(i, _dummy.matrix);
					// legs
					for (let k = 0; k < 2; k++) {
						const swing = pose.legSwing * (k ? 1 : -1);
						const lx = c * (k ? 0.013 : -0.013) + s * Math.sin(swing) * 0.03;
						const lz = -s * (k ? 0.013 : -0.013) + c * Math.sin(swing) * 0.03;
						_dummy.position.set(pose.x + lx, pose.y + 0.008, pose.z + lz);
						_dummy.rotation.set(Math.cos(pose.ang) * swing * 0.5, pose.ang, Math.sin(pose.ang) * swing * 0.5);
						_dummy.scale.set(0.009, 0.024, 0.012);
						_dummy.updateMatrix();
						legMesh.setMatrixAt(i * 2 + k, _dummy.matrix);
					}
				}
				bodyMesh.instanceMatrix.needsUpdate = true;
				headMesh.instanceMatrix.needsUpdate = true;
				legMesh.instanceMatrix.needsUpdate = true;
			}
			bodyMesh.instanceColor.needsUpdate = true;
			headMesh.instanceColor.needsUpdate = true;
			legMesh.instanceColor.needsUpdate = true;
			setPose(0);

			// ==========================================================
			// 8. street name signs (canvas text, no external assets)
			// ==========================================================
			const signMatCache = {};
			function streetSign(text, x, y, z, ry, w, h, groundY) {
				let mat = signMatCache[text];
				if (!mat) {
					const tx = U.textTexture(text, {
						size: 40,
						font: '600 40px Georgia, "Times New Roman", serif',
						color: '#efe6d2',
						background: '#3a4a44',
						padding: 14,
						cacheKey: 'street-sign-' + text.replace(/[^a-z0-9]+/gi, '-'),
					});
					mat = new THREE.MeshStandardMaterial({ map: tx.texture, roughness: 0.7, metalness: 0.05, side: THREE.DoubleSide });
					signMatCache[text] = mat;
				}
				const geo2 = new THREE.PlaneGeometry(w, h);
				const mesh = new THREE.Mesh(geo2, mat);
				mesh.position.set(x, y, z);
				mesh.rotation.y = ry;
				mesh.receiveShadow = true;
				g.add(mesh);
				const meshB = new THREE.Mesh(geo2, mat);
				meshB.position.set(x + Math.sin(ry) * 0.004, y, z + Math.cos(ry) * 0.004);
				meshB.rotation.y = ry + PI;
				g.add(meshB);
				// iron post down to the pavement
				const gy = groundY != null ? groundY : y - 0.42;
				mCyl('bench-iron', '#2f3336', 0.014, 0.018, Math.max(0.1, y - h / 2 - gy), 6, x, (y - h / 2 + gy) / 2, z);
				mBox('bench-iron', '#2f3336', 0.02, 0.02, 0.05, x, y + h / 2, z, { ry });
			}
			{
				const p = streetPoint('mainStreet', 12.3, 1, 0.13);
				streetSign('RUA DA RIBEIRA', p.x, p.y + 0.44, p.z, p.ang, 0.34, 0.13, p.y);
			}
			{
				const p = streetPoint('mainStreet', 2.2, 1, 0.13);
				streetSign('TRAVESSA DO PORTO', p.x, p.y + 0.44, p.z, p.ang + PI, 0.34, 0.13, p.y);
			}
			{
				const p = streetPoint('hillLane', 2.4, 1, 0.12);
				streetSign('CAL脟ADA ALTA', p.x, p.y + 0.42, p.z, p.ang, 0.3, 0.12, p.y);
			}
			{
				const p = streetPoint('quayRoad', 8.6, 1, 0.13);
				streetSign('CAIS DO PEIXE', p.x, p.y + 0.44, p.z, p.ang, 0.34, 0.13, p.y);
			}

			// ==========================================================
			// finalize
			// ==========================================================
			const meshes = [];
			for (const [key, b] of merged) {
				if (!b.geos.length) continue;
				const geo = U.merge(b.geos);
				if (!geo) {
					console.warn('[street] merge failed: ' + key);
					continue;
				}
				geo.computeBoundingSphere();
				const mesh = new THREE.Mesh(geo, b.mat);
				mesh.name = 'street-' + key;
				mesh.castShadow = key.indexOf('road') !== 0 && (key === 'kerb-stone' || key === 'kerb-concrete' || key === 'bench-wood' || key === 'bench-iron' || key === 'cat-body');
				mesh.receiveShadow = true;
				g.add(mesh);
				meshes.push(mesh);
			}
			for (const [key, b] of batch) {
				if (!b.list.length) continue;
				const im = new THREE.InstancedMesh(b.geo, b.mat, b.list.length);
				im.name = 'street-' + key;
				for (let i = 0; i < b.list.length; i++) im.setMatrixAt(i, b.list[i]);
				im.instanceMatrix.needsUpdate = true;
				let hasColor = false;
				for (let i = 0; i < b.colors.length; i++)
					if (b.colors[i]) {
						hasColor = true;
						break;
					}
				if (hasColor) {
					const white = new THREE.Color(1, 1, 1);
					for (let i = 0; i < b.list.length; i++) im.setColorAt(i, b.colors[i] || white);
					im.instanceColor.needsUpdate = true;
				}
				im.castShadow = key === 'leaf' || key === 'lampGlass';
				im.receiveShadow = true;
				g.add(im);
				meshes.push(im);
			}

			// ==========================================================
			// night response
			// ==========================================================
			function applyNight(night) {
				matGlassLit.emissiveIntensity = night * 2.6;
				for (const pl of lights) pl.intensity = night * 2.4;
				if (g.userData.lampGlow) g.userData.lampGlow.opacity = night * 0.9;
			}
			applyNight(0.03);

			// publish for other modules (cars must not drive into benches etc.)
			ctx.world.street = {
				lamps: lampPositions.length,
				people: people.length,
				// keep-out points for prop/vehicle modules (x,z,radius)
				furniture: furniturePoints,
			};

			return {
				update(dt, time) {
					setPose(time);
				},
				onEnv(state) {
					applyNight(state.night || 0);
				},
			};
		},
	});
})(window.HARBOR);
