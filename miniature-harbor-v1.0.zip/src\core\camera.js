/**
 * camera.js — perspective camera, orbit controls, cinematic view presets.
 * ==================================================================
 * The harbour can be rotated a full 360 degrees. Orbit uses damping and
 * generous polar limits so the diorama can be inspected from above and
 * from a low waterline angle. Auto-rotate starts on, stops on first
 * user interaction.
 *
 * Exposed:
 *   H.camera.init(ctx) / camera / controls
 *   H.camera.setView('overview'|'harbor'|'town'|'lighthouse'|'marina'|'quay'|'top', opts)
 *   H.camera.setAutoRotate(bool)
 *   H.camera.update(dt)
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const ADDONS = H.ADDONS;

	let camera = null;
	let controls = null;
	let canvas = null;
	let tween = null;
	let autoRotate = true;
	let lastInteraction = 0;
	let currentView = 'overview';
	const listeners = [];

	function init(ctx) {
		canvas = ctx.canvas;
		camera = new THREE.PerspectiveCamera(32, window.innerWidth / window.innerHeight, 0.08, 1600);
		const view = H.layout.VIEWS.overview;
		camera.position.fromArray(view.pos);
		camera.lookAt(new THREE.Vector3().fromArray(view.target));

		controls = new ADDONS.OrbitControls(camera, canvas);
		controls.target.fromArray(view.target);
		controls.enableDamping = true;
		controls.dampingFactor = 0.075;
		controls.rotateSpeed = 0.62;
		controls.zoomSpeed = 0.85;
		controls.panSpeed = 0.55;
		controls.enablePan = true;
		controls.screenSpacePanning = false;
		controls.minDistance = 6.5;
		controls.maxDistance = 62;
		controls.minPolarAngle = 0.02;
		controls.maxPolarAngle = 1.46;
		controls.autoRotate = autoRotate;
		controls.autoRotateSpeed = 0.22;
		controls.zoomToCursor = false;
		controls.target.set(view.target[0], view.target[1], view.target[2]);
		controls.update();

		canvas.addEventListener('pointerdown', () => {
			lastInteraction = performance.now();
			if (autoRotate) {
				autoRotate = false;
				controls.autoRotate = false;
				emit();
			}
		});
		canvas.addEventListener('wheel', () => {
			lastInteraction = performance.now();
			if (autoRotate) {
				autoRotate = false;
				controls.autoRotate = false;
				emit();
			}
		}, { passive: true });

		// optional mouse parallax head-room: none, orbit is enough.
		window.addEventListener('resize', () => {
			camera.aspect = window.innerWidth / window.innerHeight;
			camera.updateProjectionMatrix();
		});
		return camera;
	}

	function emit() {
		for (const cb of listeners) {
			try {
				cb({ autoRotate, view: currentView });
			} catch (err) {
				console.error(err);
			}
		}
	}

	function setAutoRotate(on) {
		autoRotate = !!on;
		if (controls) controls.autoRotate = autoRotate;
		emit();
	}

	function setView(name, opts = {}) {
		const view = H.layout.VIEWS[name] || H.layout.VIEWS.overview;
		currentView = H.layout.VIEWS[name] ? name : 'overview';
		const duration = opts.instant ? 0 : opts.duration != null ? opts.duration : 1.35;
		const fromPos = camera.position.clone();
		const fromTarget = controls.target.clone();
		const toPos = new THREE.Vector3().fromArray(view.pos);
		const toTarget = new THREE.Vector3().fromArray(view.target);
		if (view.fov && view.fov !== camera.fov) {
			camera.fov = view.fov;
			camera.updateProjectionMatrix();
		}
		if (duration <= 0) {
			camera.position.copy(toPos);
			controls.target.copy(toTarget);
			controls.update();
			tween = null;
		} else {
			tween = { t: 0, duration, fromPos, fromTarget, toPos, toTarget, arc: opts.arc != null ? opts.arc : 0.0, startPos: fromPos.clone() };
		}
		if (opts.autoRotate != null) setAutoRotate(opts.autoRotate);
		emit();
		return view;
	}

	function update(dt) {
		if (tween) {
			tween.t += dt;
			const k = U.clamp(tween.t / tween.duration);
			// ease in-out with a touch of extra smoothing
			const e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
			camera.position.lerpVectors(tween.fromPos, tween.toPos, e);
			controls.target.lerpVectors(tween.fromTarget, tween.toTarget, e);
			// small vertical arc for a cinematic feel
			camera.position.y += Math.sin(e * Math.PI) * tween.arc;
			if (k >= 1) {
				camera.position.copy(tween.toPos);
				controls.target.copy(tween.toTarget);
				tween = null;
			}
		}
		if (controls) controls.update(dt);
	}

	function stopAutoRotateSoon() {
		return lastInteraction;
	}

	H.camera = {
		init,
		update,
		setView,
		setAutoRotate,
		onChange: (cb) => {
			listeners.push(cb);
			return () => {
				const i = listeners.indexOf(cb);
				if (i >= 0) listeners.splice(i, 1);
			};
		},
		get autoRotate() {
			return autoRotate;
		},
		get view() {
			return currentView;
		},
		get camera() {
			return camera;
		},
		get controls() {
			return controls;
		},
		get isAnimating() {
			return !!tween;
		},
		stopAutoRotateSoon,
	};
})(window.HARBOR);
