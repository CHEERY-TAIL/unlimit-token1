import fs from 'node:fs';

function patch(file, pairs) {
	let s = fs.readFileSync(file, 'utf8');
	for (const [a, b] of pairs) {
		if (!s.includes(a)) console.warn('[patch] missing: ' + a.slice(0, 70));
		s = s.split(a).join(b);
	}
	fs.writeFileSync(file, s);
	console.log('[patch] ' + file);
}

// Low-angle preset views were showing a near-black backdrop because the
// below-horizon haze had been reduced too far. Bring back a controlled warm
// haze curtain and lift the ground tint slightly.
patch('src/core/env.js', [
	['vec3 below = uGround + uHorizon * (0.042 * exp(-max(-h, 0.0) * 5.5));', 'vec3 below = uGround + uHorizon * (0.105 * exp(-max(-h, 0.0) * 4.0));'],
	["sky = mix(below, sky * 0.9, smoothstep(-0.30, 0.03, h));", "sky = mix(below, sky * 0.9, smoothstep(-0.26, 0.04, h));"],
	["ground: '#181614', sun: '#ffc077'", "ground: '#2a231c', sun: '#ffc077'"],
	["ground: '#141210', sun: '#ff8b4a'", "ground: '#241a15', sun: '#ff8b4a'"],
]);
