# ARCHITECTURE — 微型港口工程说明

> **先读 `docs/ART-DIRECTION.md` 和 `src/core/layout.js`，再动代码。**

工程位置：`D:\AICODE2\AITEST\ds1\miniature-harbor`
交付物：双击 `index.html` 即可在浏览器里打开的离线 3D 微缩港口（无需服务器、无需网络）。

---

## 1. 技术栈与约束

- **Three.js r170**，预编译为 `vendor/harbor-lib.js`（classic script，暴露 `window.THREE` 和
  `window.HARBOR_ADDONS`）。这是唯一允许的第三方库。
- **没有 bundler**：所有文件都是普通 `<script>`，按 `index.html` 里的顺序加载，各模块通过
  `window.HARBOR` 命名空间协作。这样也能直接从 `file://` 打开。
- **零外部资源**：不加载任何图片/模型/字体/音频。所有纹理用 canvas 程序化生成，
  几何全部用代码构建。**禁止联网下载资产**，禁止新增 npm 依赖。
- 兼容：Chrome/Edge 最新版即可；分辨率 1280–2560 宽。

启动方式：
- 人看：双击 `index.html`
- QA/截图：见第 6 节

---

## 2. 文件地图与写入权（严格遵守）

| 文件 | 归属 | 说明 |
| --- | --- | --- |
| `index.html`, `src/ui.css`, `src/core/*.js`, `vendor/*` | **Lead** | 不要改；有需求发消息给 Lead |
| `tools/*` | **Lead** | 截图/构建工具 |
| `src/world/00-terrain.js` | t1 terrain-water | 圆形底座、树脂海侧壁、岛屿地形、沙滩、礁石、海床 |
| `src/world/10-water.js` | t1 terrain-water | 水面（平面反射、波浪、泡沫、深浅色） |
| `src/world/20-quay.js` | t2 structures | 码头岸壁、栈桥、防波堤主体、系船柱、梯子 |
| `src/world/21-industrial.js` | t2 structures | 龙门吊、集装箱、仓库、油罐、铁轨/小火车 |
| `src/world/22-lighthouse.js` | t2 structures | 灯塔、绿标、Fort Point 信号塔、瞭望塔废墟、灯束 |
| `src/world/30-town.js` | t3 town-life | 老城建筑群、教堂、广场、市场、市政厅、招牌 |
| `src/world/31-street.js` | t3 town-life | 道路、石板、路灯、长椅、花箱、招牌、行人 |
| `src/world/40-vessels.js` | t4 vessels-props | 各类船只、系泊、浮标、外海帆船 |
| `src/world/41-props.js` | t4 vessels-props | 货物/木箱/桶/渔网/树/植被/汽车/杂物 |
| `src/world/50-atmosphere.js` | t5 atmosphere-fx | 云、海鸥、烟、旗、浪花飞沫、粒子、远景氛围 |
| `qa/**`, `docs/QA-REPORT.md` | t6 qa-visual | QA 脚本、截图、报告 |
| `docs/*`（除 QA 报告） | Lead | |

**不同模块之间不要互相改文件。** 需要跨模块配合（例如码头位置）时改 `layout.js` 只能由 Lead 做，
发消息给 Lead 说明需求。可以在自己的文件里 `ctx.world.<key> = ...` 发布共享数据，或读取
`HARBOR.world` / `ctx.world` / `HARBOR.layout.ANCHORS`。

---

## 3. 坐标系与布局

```
y 向上，海平面 y = 0
-z 北（老城、山丘）    +z 南（外海、默认相机方向）
-x 西（沙滩湾、岬角）   +x 东（防波堤尖、外海）
圆盘中心 (0,0)，半径 R = 14
```

- 所有"必须对齐"的坐标都在 `src/core/layout.js`：海岸线多边形 `COAST`、分区 `DISTRICTS`、
  高度场 `groundHeight(x,z)`、防波堤 `BREAKWATER`、栈桥 `PIERS`、泊位 `berths`、
  道路 `ROADS`、地标 `ANCHORS`、相机 `VIEWS`、城镇地块 `townLots`、等级 `LEVEL`。
- **地形平整约定**：district 范围内的地面必须平整到 `LEVEL` 指定高度（±0.06），
  因为建筑/道路/道具都按这个高度落位。
- 水面以下：海床 `SEA_FLOOR = -3.2`。底座顶部 `PLINTH_TOP = -1.55`（树脂海侧壁底）。
- 可用工具：`layout.groundHeight(x,z)`、`layout.waterDepth(x,z)`、`layout.isWater(x,z)`、
  `layout.districtAt(x,z)`、`layout.pointAlong(points,d)`、`layout.pointInPoly(...)`。

---

## 4. 模块注册与 ctx API

每个模块在自己的文件里注册：

```js
HARBOR.register('water', {
  create(ctx) {
    const g = ctx.group('water');          // 自动挂到 scene 的 Group
    // ... build meshes into g ...
    return {
      update(dt, time) { /* 每帧动画，可选 */ },
      onEnv(state)     { /* 时间/光照变化，可选 */ },
    };
  },
});
```

`ctx` 提供：

| 字段 | 说明 |
| --- | --- |
| `ctx.THREE` / `ctx.ADDONS` | three.js / addons（OrbitControls 等） |
| `ctx.util` | 工具库：随机、噪声、canvas 纹理、几何 helper（见 `src/core/util.js`） |
| `ctx.layout` | 空间总平面（见 `src/core/layout.js`） |
| `ctx.materials` | 共享程序化材质库（见 `src/core/materials.js`） |
| `ctx.env` | 天空/太阳/雾/环境光；`ctx.env.state` / `ctx.env.onEnv(cb)` |
| `ctx.render` | renderer / composer / quality；`ctx.render.quality` / `ctx.render.onQuality(cb)` |
| `ctx.camera` / `ctx.controls` | 相机与轨道控制 |
| `ctx.scene` / `ctx.renderer` / `ctx.canvas` | three 对象 |
| `ctx.group(name, parent?)` | 建 Group 并挂到场景（推荐每个模块一个） |
| `ctx.add(obj)` | 直接加场景根 |
| `ctx.update(fn)` | 注册一个额外的每帧回调（一般用返回对象的 update 即可） |
| `ctx.anchor(name)` | 取 `layout.ANCHORS[name]` |
| `ctx.groundHeight(x,z)` / `ctx.waterLevel` | 便捷访问 |
| `ctx.rng` | 已按全局 seed 播种的随机数生成器 |
| `ctx.state` | 共享状态：`time, hour, quality, freeze, view, ...` |
| `ctx.world` / `HARBOR.world` | 模块间共享数据的空对象 |
| `ctx.debug` | URL `?debug=1` |

每帧：先 `env.update`，再各模块 `update(dt, time)`，再 `camera.update`，最后渲染。
动画请用 `time`（秒）而不是 Date；`?freeze=1` 时 time 固定，用于可复现截图。

---

## 5. 现有 API 速查

### util（`src/core/util.js`）
- 数学：`clamp lerp invLerp smoothstep smootherstep remap damp mod pingPong angleLerp`
- 随机：`util.rng(seed)` → `{next, range(a,b), int(a,b), pick(arr), chance(p), shuffle, rand}`
- 噪声：`util.noise2(x,y,seed)`、`noise3`、`fbm(x,y,{octaves,freq,gain,seed})`、`ridged`、
  `tileableNoise(size,{period,octaves,seed})`
- 纹理：`util.surface({size, seed, repeat, cacheKey, normalStrength, color(ctx,s,r), height(ctx,s,r)})`
  → `{map, normalMap, roughnessMap}`（自动生成法线/粗糙度，会缓存）
- `util.noiseTexture(...)`、`util.canvasTex(canvas,{repeat,srgb,cacheKey})`、
  `util.textTexture(text,{font,size,color,background})`、`util.textDecal(...)`
- 几何：`util.box(w,h,d,mat,x,y,z,{cast,receive,rot,scale})`、`util.cyl(rt,rb,h,seg,mat,...)`、
  `util.mesh(geo,mat,...)`、`util.group(parent,name)`、`util.instances(geo,mat,[[x,y,z,rotY,scale]],{})`、
  `util.merge([geos])`、`util.cachedGeo(key,factory)`、`util.applyShadow(root)`
- 颜色：`util.color('#...')`、`util.hsl(h,s,l)`、`util.PALETTE`（统一 palette，见 ART-DIRECTION）

### materials（`src/core/materials.js`）
- `ctx.materials.get('concrete'|'concreteDark'|'asphalt'|'cobble'|'stoneWall'|'brick'|'rock'|
  'sand'|'grass'|'wood'|'woodLight'|'woodDark'|'steel'|'steelDark'|'rusted'|'copper'|'brass'|
  'glass'|'glassSky'|'rope'|'rubber'|'tar')` → 共享 `MeshStandardMaterial`
- `materials.painted('#hex', {roughness, metalness})` → 纯色漆面（缓存）
- `materials.roofTile('#hex')` → 瓦片（缓存）
- `materials.emissive('#hex', intensity)` → 自发光（窗户/灯）
- `materials.unique(key, overrides)` → 克隆后微调（少用）
- 需要自定义材质时用 `ctx.util.surface(...)` + `new THREE.MeshStandardMaterial(...)`

### env（`src/core/env.js`）
- `env.state`：`{hour, night(0..1), sunDir, moonDir, colors:{zenith,horizon,...}, sunI, hemiI, fogD, exposure, envI}`
- `env.onEnv(cb)`，`cb(state)` 在时间变化时调用；返回取消函数。**夜晚灯光必须响应它**
- `env.sunLight` / `env.hemiLight`

### render（`src/core/render.js`）
- `render.quality` → `{id, pixelRatio, shadowMap, bloom, tilt, reflection, ...}`（水面反射分辨率用 `reflection`）
- `render.onQuality(cb)`：切换画质时回调（低画质关反射/关 bloom）
- `render.renderer` / `render.composer`

---

## 6. 截图 / 视觉迭代流程（必须用！）

无头 Chrome 由 Lead 启动的常驻服务提供（**不要自己启动浏览器**）：

```powershell
# 在自己的 shell 里（cwd = 工程根目录）：
node tools/shot.mjs --id t1-01 --url "/index.html?only=terrain,water&view=overview&hour=17.35" --w 1600 --h 1000 --wait 1200
```

输出最后一行给出 `image=qa/shots/t1-01.png`，然后用 `read_image` 读它、观察、继续改。

规则：
- **id 必须以自己的代号开头**（`t1-`、`t2-`、...、`qa-`），避免冲突
- `--url` 里用 `?only=<你的模块>` 隔离自己的模块，`?skip=` 排除别人的；最终集成时不要带
- 可用 URL 参数：`view=overview|harbor|town|lighthouse|marina|quay|top`、`hour=0..24`、
  `quality=high|medium|low`、`ui=0`、`freeze=1&t=12`、`pr=1.5`
- `--jsfile qa/scripts/<name>.js`：截图前在页面里执行一段 JS（例如用
  `window.__harbor.setView(...)`、`window.__harbor.ctx()` 检查场景），适合精确取景
- 结果 JSON 在 `qa/results/<id>.json`（包含 pageErrors / console / diagnostics），截图在 `qa/shots/<id>.png`
- 每个模块完成后至少自检：3 个不同角度 + 黄昏/夜景/白天各一张 + 关闭 UI 一张
- **先看截图再交活**。没截图验证就等于没做。

如果截图服务挂了，告诉 Lead（Lead 负责重启 `node tools/shoot-daemon.mjs`）。

---

## 7. 性能预算（high 画质，1600×1000，RTX 2070S）

- 目标 ≥ 55 fps（截图服务实测 100+ 都没问题；不要让集成后掉到 40 以下）
- 整场景 draw calls ≤ 550，三角形 ≤ 2.5M
- 用 `util.instances` 批量重复物件（集装箱、系船柱、窗、树、砖块装饰）
- 同材质尽量合并几何（`util.merge`）；不要每个小物件一个 material
- 阴影：只让重要物件 `castShadow`；小物件不要投影
- 水面反射只渲染一次/帧，分辨率用 `ctx.render.quality.reflection`
- 生成贴图注意缓存（`cacheKey`），不要每个 mesh 生成一张纹理

---

## 8. 纪律

- 只改自己负责的文件；不要动 `index.html`、`src/core/*`、`layout.js`、`vendor/`、别人的模块
- 不联网、不新增依赖、不加载外部资产
- 每个文件保持可独立运行：出错时被 app 捕获，但不能拖垮别人
- 命名：`Group` 名字用英文；材质/变量风格跟随现有代码（tab 缩进）
- 交付前：`node --check <file>` 通过、控制台无 error、无 z-fighting/浮空/穿模
- 完成后用 `team_task_update` 标记任务完成，并给 Lead 发一条简洁的进度消息（含最佳截图路径）

---

## 9. 附录：截图服务 v5 与最终出图

常驻服务 `tools/shoot-daemon.mjs` 由 Lead 启动（需要 Chrome），能力：

| 模式 | 说明 |
| --- | --- |
| `capture=canvas`（默认） | 用 `gl.readPixels` 直接读 WebGL 帧缓冲 + 自编码 PNG，**无黑块、无 HUD**，分辨率为视口 × pixelRatio（默认 1.5） |
| `capture=both` | 额外输出透明背景 HUD 图层 `<id>.ui.png`，用 `python qa/composite.py <scene> <ui> <out>` 合成带 UI 的成片 |
| `capture=page` | 整页截图（含 HUD，但可能偶发 Chrome 合成器黑块，仅用于快速看 UI 布局） |
| `capture=none` | 不出图，只测 `diagnostics`（真实 fps / draw calls），用于性能标定 |

```powershell
# 性能标定（稳定 3.5s 后读数）
node tools/shot.mjs --id perf --url "/index.html?view=overview&autorotate=0" --capture none --wait 3500

# 最终展示图（scene-only，超采样）
node tools/shots-final.mjs --pr 2
```

`gl.readPixels` 截图会额外触发一次 render + 回读，因此单张耗时比 page 截图多 1–2 秒；
`diagnostics.fps` 在截图后等待 650ms 再读取，已剔除截图抖动。
