/**
 * 00-terrain.js —walnut plinth, resin sea cross-section, island landform.
 * OWNER: t1-terrain (exclusive write: this file + 10-water.js).
 *
 * The whole diorama sits on a turned walnut base:
 *
 *      y =  0.00   water surface (10-water.js owns the reflective surface)
 *      y = -1.50   visible sea bed / resin floor (painted, above the base)
 *      y = -1.55   plinth top face (resin sea cross-section starts here)
 *      y = -2.45   plinth bottom
 *      r = 14.00   model disc / island cut face
 *      r = 14.65   outer walnut edge + brass inlay
 *
 * Contract with layout.js:
 *  - terrain follows layout.groundHeight() exactly inside district pads and
 *    roads (+-0.06) —the pad shield below guarantees that;
 *  - the harbour quay apron is a flat 1.0 terrace (layout owns it);
 *  - outside the built waterfront the coastline is reshaped into natural
 *    cliffs / a gentle sandy cove; terrain never rises above y=0 seaward of
 *    COAST (except the beach cove, per art direction);
 *  - land is clipped exactly at r = 14 and closed by a geological cut face.
 *
 * Published for other modules (read only):
 *      HARBOR._t1.height(x, z)      final terrain height
 *      HARBOR._t1.coastQuery(x, z)  { d, s } signed distance / arc length
 *      HARBOR._t1.seabed            visible sea-bed level (-1.5)
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const L = H.layout;
	const PAL = U.PALETTE;
	const TAU = Math.PI * 2;
	const clamp = U.clamp;
	const lerp = U.lerp;
	const smoothstep = U.smoothstep;

	// ------------------------------------------------------------------
	// diorama constants
	// ------------------------------------------------------------------
	const DISC_R = L.DISC_RADIUS; // 14.0  model disc
	const PLINTH_R = L.PLINTH_RADIUS; // 14.65 outer walnut edge
	const PLINTH_TOP = L.PLINTH_TOP; // -1.55
	const PLINTH_BOT = L.PLINTH_BOTTOM; // -2.45
	const WATER_Y = L.WATER_Y; // 0
	const SEABED = -1.5; // painted resin floor, just above the base
	const RIM = DISC_R;
	const RIM_WALL_UV_H = 6.2; // world height covered by the strata texture

	// ------------------------------------------------------------------
	// coastline table + arc-length zone lookup
	// ------------------------------------------------------------------
	const COAST = L.COAST;
	const CSEG = [];
	let COAST_LEN = 0;
	const CCUM = [0];
	for (let i = 1; i < COAST.length; i++) {
		const ax = COAST[i - 1][0],
			az = COAST[i - 1][1];
		const bx = COAST[i][0],
			bz = COAST[i][1];
		const dx = bx - ax,
			dz = bz - az;
		const len = Math.hypot(dx, dz);
		CSEG.push({ ax, az, dx, dz, nxs: dx / len, nzs: dz / len, len2: dx * dx + dz * dz, len });
		COAST_LEN += len;
		CCUM.push(COAST_LEN);
	}

	/** nearest point on the coastline: signed distance (+ land) + arc length */
	function coastQuery(x, z, out) {
		let best = Infinity,
			bi = 0,
			bt = 0,
			bpx = 0,
			bpz = 0;
		for (let i = 0; i < CSEG.length; i++) {
			const s = CSEG[i];
			const wx = x - s.ax,
				wz = z - s.az;
			let t = (wx * s.dx + wz * s.dz) / s.len2;
			t = t < 0 ? 0 : t > 1 ? 1 : t;
			const px = s.ax + s.dx * t,
				pz = s.az + s.dz * t;
			const d2 = (x - px) * (x - px) + (z - pz) * (z - pz);
			if (d2 < best) {
				best = d2;
				bi = i;
				bt = t;
				bpx = px;
				bpz = pz;
			}
		}
		const dist = Math.sqrt(best);
		const r = out || {};
		r.d = L.pointInPoly(x, z, COAST) ? dist : -dist;
		r.s = CCUM[bi] + bt * CSEG[bi].len;
		r.px = bpx;
		r.pz = bpz;
		r.seg = bi;
		return r;
	}
	const _cq = {};
	const _cqB = {};

	/** coastal zones by arc length (measured from the far NW end of COAST) */
	const ZONES = {
		cliffN: { a: 13.6, b: 25.6, f: 1.8 }, // north coast + north-east cliffs
		cliffE: { a: 25.6, b: 33.2, f: 1.6 }, // east headland cliffs
		fort: { a: 33.2, b: 39.6, f: 1.1 }, // fort point
		quay: { a: 39.6, b: 56.2, f: 1.0 }, // built harbour waterfront
		beach: { a: 56.2, b: 60.6, f: 1.5 }, // sandy cove at the west end
	};
	function zoneWeights(s) {
		const w = {};
		let tot = 0;
		for (const k in ZONES) {
			const z = ZONES[k];
			const v = smoothstep(z.a - z.f, z.a, s) * (1 - smoothstep(z.b, z.b + z.f, s));
			w[k] = v;
			tot += v;
		}
		if (tot < 1e-4) {
			w.cliffN = w.cliffE = w.fort = w.beach = 0;
			w.quay = 1;
			return w;
		}
		for (const k in w) w[k] /= tot;
		return w;
	}
	const _zw = { cliffN: 0, cliffE: 0, fort: 0, quay: 0, beach: 0 };
	function zoneWeightsInto(s, out) {
		let tot = 0;
		for (const k in ZONES) {
			const z = ZONES[k];
			const v = smoothstep(z.a - z.f, z.a, s) * (1 - smoothstep(z.b, z.b + z.f, s));
			out[k] = v;
			tot += v;
		}
		if (tot < 1e-4) {
			out.cliffN = out.cliffE = out.fort = out.beach = 0;
			out.quay = 1;
			return out;
		}
		const inv = 1 / tot;
		for (const k in ZONES) out[k] *= inv;
		return out;
	}

	// reusable noise option objects (avoid per-sample allocations in the build)
	const NB = {
		sea: { octaves: 3, seed: 5 },
		cliff1: { octaves: 3, seed: 61 },
		cliff2: { octaves: 3, seed: 43 },
		cliff3: { octaves: 2, seed: 89 },
		fort: { octaves: 2, seed: 77 },
		beach: { octaves: 2, seed: 123 },
		det1: { octaves: 3, seed: 31 },
		det2: { octaves: 2, seed: 57 },
	};
	let _lastPadCode = 0; // 0 wild, 1 quay/yard hard flat, 2 fort, 3 town/upper/other pad

	// ------------------------------------------------------------------
	// district pads (used as a shield: pads stay exactly as layout says)
	// ------------------------------------------------------------------
	const DPADS = [];
	for (const d of L.DISTRICTS) {
		let minX = Infinity,
			maxX = -Infinity,
			minZ = Infinity,
			maxZ = -Infinity;
		for (const p of d.poly) {
			minX = Math.min(minX, p[0]);
			maxX = Math.max(maxX, p[0]);
			minZ = Math.min(minZ, p[1]);
			maxZ = Math.max(maxZ, p[1]);
		}
		const m = d.blend + 0.35;
		DPADS.push({ id: d.id, level: d.level, blend: d.blend, poly: d.poly, minX: minX - m, maxX: maxX + m, minZ: minZ - m, maxZ: maxZ + m });
	}

	// ------------------------------------------------------------------
	// height field
	// ------------------------------------------------------------------
	// local copy of layout.naturalLandHeight (same maths, no allocations)
	const NB_NAT1 = { octaves: 4, seed: 11 };
	const NB_NAT2 = { octaves: 3, seed: 21 };
	function naturalHeight(x, z) {
		let h = 2.05;
		h += 1.75 * smoothstep(-3.5, -11.5, z);
		h += 0.9 * smoothstep(2.0, 8.0, x) * smoothstep(0.5, -7.0, z);
		const hillness = smoothstep(-2.0, -9.0, z);
		h += U.fbm(x * 0.16, z * 0.16, NB_NAT1) * (0.55 + hillness * 0.85);
		h += U.fbm(x * 0.6, z * 0.6, NB_NAT2) * 0.12;
		return h;
	}
	/** steep rock coast: wave-cut shelf, cliff face, ragged rim */
	function cliffProfile(x, z, d, top) {
		const n1 = U.fbm(x * 0.85, z * 0.85, NB.cliff1);
		const n2 = U.fbm(x * 0.3, z * 0.3, NB.cliff2);
		const n3 = U.fbm(x * 3.1, z * 3.1, NB.cliff3);
		// the whole face is pushed slightly inland so terrain never rises out
		// of the water seaward of the COAST line (rocks cover the waterline)
		const de = d - 0.12 - 0.22 * (n1 * 0.5 + 0.5) - 0.1 * (n2 * 0.5 + 0.5);
		let h = lerp(SEABED, -0.55, smoothstep(-1.5, -0.55, de));
		h = lerp(h, 0.05, smoothstep(-0.55, 0.08, de));
		h = lerp(h, top + n2 * 0.32, smoothstep(0.08, 0.58 + 0.22 * (n1 * 0.5 + 0.5), de));
		// broken ledges / fractured rock on the visible face
		const face = smoothstep(0.0, 0.5, de) * (1 - smoothstep(0.58, 1.15, de));
		h += n1 * 0.34 * face + n3 * 0.16 * face;
		return h;
	}

	/** sandy cove: 0.25 pad easing into a shallow sandy slope */
	function beachProfile(x, z, d) {
		if (d >= 0.16) return 0.25;
		let h = 0.25 + (d - 0.16) * 0.42;
		const n = U.fbm(x * 1.5, z * 1.5, NB.beach);
		h += n * 0.035 * smoothstep(0.3, -1.2, d);
		return Math.max(h, SEABED);
	}

	/** final terrain height used by the mesh, water and props */
	function terrainHeight(x, z, qIn) {
		const q = qIn || coastQuery(x, z);
		const d = q.d;
		// --- replica of layout.groundHeight (bit-exact pads, plus a pad shield)
		const landW = smoothstep(-0.55, 0.45, d);
		const sea = L.SEA_FLOOR + U.fbm(x * 0.14, z * 0.14, NB.sea) * 0.5;
		const nat = naturalHeight(x, z);
		let h = lerp(sea, nat, landW);
		// --- district pads. The built waterfront apron (quay + yard) is a
		// hard flat 1.0 terrace: the town retaining-wall blend must not creep
		// into it (T2/T3 place walls, rails and warehouses at exactly 1.0).
		let pad = 0;
		let padCode = 0;
		let flatIdx = -1;
		for (let i = 0; i < DPADS.length; i++) {
			const D = DPADS[i];
			if (D.id !== 'quay' && D.id !== 'yard') continue;
			if (x < D.minX || x > D.maxX || z < D.minZ || z > D.maxZ) continue;
			if (L.pointInPoly(x, z, D.poly)) {
				flatIdx = i;
				break;
			}
		}
		if (flatIdx >= 0) {
			h = DPADS[flatIdx].level;
			pad = 1;
			padCode = 1;
		} else {
			let lastInside = -1;
			for (let i = 0; i < DPADS.length; i++) {
				const D = DPADS[i];
				if (x < D.minX || x > D.maxX || z < D.minZ || z > D.maxZ) continue;
				if (L.pointInPoly(x, z, D.poly)) lastInside = i;
			}
			if (lastInside >= 0) {
				const D = DPADS[lastInside];
				h = D.level;
				pad = D.id === 'beach' ? 0 : 1;
				padCode = D.id === 'fort' ? 2 : D.id === 'beach' ? 0 : 3;
				// later districts may still blend over the pad (layout order)
				for (let i = lastInside + 1; i < DPADS.length; i++) {
					const D2 = DPADS[i];
					if (x < D2.minX || x > D2.maxX || z < D2.minZ || z > D2.maxZ) continue;
					const dd = L.signedDistToPoly(x, z, D2.poly);
					if (dd > -D2.blend) h = lerp(h, D2.level, smoothstep(-D2.blend, 0, dd));
				}
			} else {
				for (let i = 0; i < DPADS.length; i++) {
					const D = DPADS[i];
					if (x < D.minX || x > D.maxX || z < D.minZ || z > D.maxZ) continue;
					const dd = L.signedDistToPoly(x, z, D.poly);
					if (dd > -D.blend) h = lerp(h, D.level, smoothstep(-D.blend, 0, dd));
					// the beach cove is intentionally sloped, not a pad
					if (D.id !== 'beach') pad = Math.max(pad, smoothstep(-D.blend * 0.45, 0, dd));
				}
			}
		}
		_lastPadCode = padCode;
		const zw = zoneWeightsInto(q.s, _zw);
		// --- wild coastline: replace the raw ramp with cliffs / cove
		const wCoast = 1 - smoothstep(1.7, 3.1, Math.abs(d));
		if (wCoast > 0.002 && pad < 0.999) {
			let p = 0;
			const wc = zw.cliffN + zw.cliffE;
			if (wc > 0.001) p += wc * cliffProfile(x, z, d, nat);
			if (zw.fort > 0.001) p += zw.fort * cliffProfile(x, z, d, 1.52 + 0.16 * U.fbm(x * 0.7, z * 0.7, { octaves: 2, seed: 77 }));
			if (zw.quay > 0.001) p += zw.quay * h;
			if (zw.beach > 0.001) p += zw.beach * beachProfile(x, z, d);
			h = lerp(h, p, wCoast * (1 - pad));
		}
		// --- sandy cove keeps sloping even inside its flat district pad
		if (zw.beach > 0.001) {
			const k = zw.beach * (1 - smoothstep(0.18, 0.62, d)) * (1 - pad);
			if (k > 0.001) h = lerp(h, beachProfile(x, z, d), k);
		}
		// --- land detail: rolling hillocks, rocky roughness, only above water
		const dry = smoothstep(-0.22, 0.4, d) * (1 - pad);
		if (dry > 0.001) {
			const hillness = smoothstep(-2.0, -9.0, z);
			const amp = (0.055 + 0.2 * hillness) * (0.5 + 0.5 * smoothstep(1.2, 3.6, nat));
			const dn = U.fbm(x * 0.42, z * 0.42, { octaves: 3, seed: 31 }) + 0.45 * U.fbm(x * 1.15, z * 1.15, { octaves: 2, seed: 57 });
			h += dn * amp * dry;
		}
		if (h < SEABED) h = SEABED;
		if (h > 5.6) h = 5.6;
		return h;
	}

	function terrainSlope(x, z, e = 0.16) {
		const hx = terrainHeight(x + e, z) - terrainHeight(x - e, z);
		const hz = terrainHeight(x, z + e) - terrainHeight(x, z - e);
		return Math.hypot(hx, hz) / (2 * e);
	}

	// ------------------------------------------------------------------
	// procedural textures
	// ------------------------------------------------------------------
	function makeWoodTextures() {
		return U.surface({
			size: 768,
			seed: 421,
			repeat: [7, 1],
			cacheKey: 't1-walnut768',
			normalStrength: 2.1,
			color(c, s, r) {
				// dark walnut
				c.fillStyle = '#3a2a1e';
				c.fillRect(0, 0, s, s);
				// long cathedral grain, running around the base
				for (let i = 0; i < 120; i++) {
					const y0 = r.range(-20, s + 20);
					const hgt = r.range(2, 16);
					const col = new THREE.Color('#4a3423').offsetHSL(r.range(-0.015, 0.02), r.range(-0.08, 0.12), r.range(-0.1, 0.13));
					c.fillStyle = '#' + col.getHexString();
					c.globalAlpha = r.range(0.18, 0.6);
					const amp = r.range(1, 4);
					const ph = r.range(0, 6.28);
					const fq = r.range(0.008, 0.03);
					c.beginPath();
					c.moveTo(0, y0);
					for (let x = 0; x <= s; x += 24) c.lineTo(x, y0 + Math.sin(x * fq + ph) * amp);
					for (let x = s; x >= 0; x -= 24) c.lineTo(x, y0 + hgt + Math.sin(x * fq + ph) * amp);
					c.closePath();
					c.fill();
				}
				c.globalAlpha = 1;
				// darker pores / streaks
				for (let i = 0; i < 2600; i++) {
					c.fillStyle = `rgba(20,13,8,${r.range(0.05, 0.28)})`;
					c.fillRect(r.range(0, s), r.range(0, s), r.range(1, 7), r.range(0.6, 1.8));
				}
				// a few knots
				for (let i = 0; i < 6; i++) {
					const kx = r.range(0, s),
						ky = r.range(0, s);
					for (let k = 7; k > 0; k--) {
						c.strokeStyle = `rgba(18,11,6,${0.06 + k * 0.03})`;
						c.lineWidth = 1.4;
						c.beginPath();
						c.ellipse(kx, ky, k * r.range(2.5, 4), k * r.range(1.2, 2.2), 0.2, 0, TAU);
						c.stroke();
					}
				}
				// satin sheen bands
				for (let i = 0; i < 8; i++) {
					const gy = r.range(0, s);
					const g = c.createLinearGradient(0, gy - 30, 0, gy + 30);
					g.addColorStop(0, 'rgba(255,235,210,0)');
					g.addColorStop(0.5, 'rgba(255,230,195,0.05)');
					g.addColorStop(1, 'rgba(255,235,210,0)');
					c.fillStyle = g;
					c.fillRect(0, gy - 30, s, 60);
				}
			},
			height(c, s, r) {
				c.fillStyle = '#8a8a8a';
				c.fillRect(0, 0, s, s);
				for (let i = 0; i < 150; i++) {
					const y0 = r.range(-20, s + 20);
					const hgt = r.range(2, 12);
					const v = Math.floor(r.range(105, 165));
					c.fillStyle = `rgba(${v},${v},${v},0.5)`;
					const amp = r.range(1, 3);
					const ph = r.range(0, 6.28);
					const fq = r.range(0.008, 0.03);
					c.beginPath();
					c.moveTo(0, y0);
					for (let x = 0; x <= s; x += 24) c.lineTo(x, y0 + Math.sin(x * fq + ph) * amp);
					for (let x = s; x >= 0; x -= 24) c.lineTo(x, y0 + hgt + Math.sin(x * fq + ph) * amp);
					c.closePath();
					c.fill();
				}
				for (let i = 0; i < 2200; i++) {
					const v = Math.floor(r.range(90, 180));
					c.fillStyle = `rgb(${v},${v},${v})`;
					c.fillRect(r.range(0, s), r.range(0, s), r.range(1, 5), r.range(0.6, 1.8));
				}
			},
		});
	}

	/** geological cross-section of the island at the rim (horizontal strata) */
	function makeStrataTexture() {
		const W = 2048,
			Hh = 1024;
		const canvas = U.createCanvas(W, Hh);
		const c = canvas.getContext('2d');
		const r = U.rng(9191);
		// canvas y = 0 is the top of the section (world y = wallMax)
		const wallMax = RIM_WALL_UV_H;
		const yOf = (worldY) => (1 - worldY / wallMax) * Hh;
		// rock column: colour bands by world height
		const bands = [
			{ y0: 0.0, y1: 0.62, col: '#2f2b26', jitter: 0.1 }, // wet base rock
			{ y0: 0.62, y1: 1.45, col: '#54483b', jitter: 0.1 },
			{ y0: 1.45, y1: 2.15, col: '#6b5a45', jitter: 0.12 },
			{ y0: 2.15, y1: 2.55, col: '#7d6a50', jitter: 0.08 },
			{ y0: 2.55, y1: 3.2, col: '#665c50', jitter: 0.12 },
			{ y0: 3.2, y1: 3.6, col: '#7a6a56', jitter: 0.1 },
			{ y0: 3.6, y1: 4.3, col: '#5f5548', jitter: 0.12 },
			{ y0: 4.3, y1: 5.0, col: '#6e6152', jitter: 0.1 },
			{ y0: 5.0, y1: wallMax, col: '#645846', jitter: 0.1 },
		];
		c.fillStyle = '#4c443d';
		c.fillRect(0, 0, W, Hh);
		for (const b of bands) {
			const ya = yOf(b.y1),
				yb = yOf(b.y0);
			const base = new THREE.Color(b.col);
			const steps = 6;
			for (let k = 0; k < steps; k++) {
				const col = base.clone().offsetHSL(r.range(-0.02, 0.02), r.range(-0.06, 0.06), r.range(-0.05, 0.05));
				c.fillStyle = '#' + col.getHexString();
				const yTop = ya + ((yb - ya) * k) / steps;
				const yBot = ya + ((yb - ya) * (k + 1)) / steps + 1;
				// wavy band edge
				c.beginPath();
				c.moveTo(0, yTop);
				for (let x = 0; x <= W; x += 42) c.lineTo(x, yTop + Math.sin(x * 0.006 + k * 1.7) * 3.2);
				c.lineTo(W, yBot);
				for (let x = W; x >= 0; x -= 42) c.lineTo(x, yBot + Math.sin(x * 0.006 + k * 2.3) * 3.2);
				c.closePath();
				c.fill();
			}
			// band boundary shadow + highlight
			c.strokeStyle = 'rgba(24,20,17,0.5)';
			c.lineWidth = 2.5;
			c.beginPath();
			for (let x = 0; x <= W; x += 42) {
				const yy = ya + Math.sin(x * 0.006 + b.y0 * 3) * 3;
				x === 0 ? c.moveTo(x, yy) : c.lineTo(x, yy);
			}
			c.stroke();
			c.strokeStyle = 'rgba(225,208,180,0.14)';
			c.lineWidth = 1.6;
			c.beginPath();
			for (let x = 0; x <= W; x += 42) {
				const yy = ya + 3 + Math.sin(x * 0.006 + b.y0 * 3) * 3;
				x === 0 ? c.moveTo(x, yy) : c.lineTo(x, yy);
			}
			c.stroke();
		}
		// embedded pebbles / concretions
		const pebCols = ['#4a4136', '#5d5344', '#6f6252', '#3c352d', '#77664f'];
		for (let i = 0; i < 2400; i++) {
			const x = r.range(0, W);
			const worldY = Math.pow(r.range(0, 1), 1.6) * 4.4 + 0.15;
			const y = yOf(worldY) + r.range(-6, 6);
			const rad = r.range(1.5, 7.5);
			c.fillStyle = pebCols[Math.floor(r.range(0, pebCols.length))];
			c.globalAlpha = r.range(0.25, 0.85);
			c.beginPath();
			c.ellipse(x, y, rad, rad * r.range(0.5, 0.85), r.range(-0.4, 0.4), 0, TAU);
			c.fill();
			c.globalAlpha = 1;
		}
		// vertical cracks
		for (let i = 0; i < 42; i++) {
			let x = r.range(0, W);
			let y = r.range(yOf(4.2), yOf(0.2));
			c.strokeStyle = `rgba(20,17,14,${r.range(0.18, 0.5)})`;
			c.lineWidth = r.range(0.8, 2.2);
			c.beginPath();
			c.moveTo(x, y);
			const steps = Math.floor(r.range(4, 14));
			for (let k = 0; k < steps; k++) {
				x += r.range(-16, 16);
				y += r.range(8, 30);
				c.lineTo(x, y);
			}
			c.stroke();
		}
		// wet darkening at the base + faint light near the top
		const gBot = c.createLinearGradient(0, yOf(0.55), 0, Hh);
		gBot.addColorStop(0, 'rgba(12,16,18,0)');
		gBot.addColorStop(1, 'rgba(8,14,16,0.55)');
		c.fillStyle = gBot;
		c.fillRect(0, yOf(0.55), W, Hh - yOf(0.55));
		const gTop = c.createLinearGradient(0, 0, 0, yOf(4.4));
		gTop.addColorStop(0, 'rgba(255,236,200,0.10)');
		gTop.addColorStop(1, 'rgba(255,236,200,0)');
		c.fillStyle = gTop;
		c.fillRect(0, 0, W, yOf(4.4));
		const tex = U.canvasTex(canvas, { repeat: [1, 1], cacheKey: 't1-strata' });
		return tex;
	}

	/** painted resin sea cross-section (visible through the round side) */
	function makeResinTexture() {
		const W = 4096,
			Hh = 512;
		const canvas = U.createCanvas(W, Hh);
		const c = canvas.getContext('2d');
		const r = U.rng(4242);
		// v=1 top (waterline) / v=0 bottom (plinth top)
		const yOf = (v) => (1 - v) * Hh;
		// deep water gradient
		const grad = c.createLinearGradient(0, 0, 0, Hh);
		grad.addColorStop(0, '#2f8794');
		grad.addColorStop(0.06, '#1d6b78');
		grad.addColorStop(0.22, '#104955');
		grad.addColorStop(0.55, '#0a2e37');
		grad.addColorStop(0.8, '#08242b');
		grad.addColorStop(1, '#1b1b18');
		c.fillStyle = grad;
		c.fillRect(0, 0, W, Hh);
		// sediment layers near the base
		const layers = [
			{ v: 0.0, h: 0.16, col: '#2e2a21' },
			{ v: 0.16, h: 0.12, col: '#423a2c' },
			{ v: 0.28, h: 0.1, col: '#3a3428' },
			{ v: 0.38, h: 0.07, col: '#2b2a24' },
		];
		for (const ly of layers) {
			const y0 = yOf(ly.v + ly.h),
				y1 = yOf(ly.v);
			const g = c.createLinearGradient(0, y0, 0, y1);
			g.addColorStop(0, ly.col);
			g.addColorStop(0.5, new THREE.Color(ly.col).offsetHSL(0, 0.02, 0.04).getStyle());
			g.addColorStop(1, new THREE.Color(ly.col).offsetHSL(0, 0, -0.03).getStyle());
			c.fillStyle = g;
			c.beginPath();
			c.moveTo(0, y0 + 4);
			for (let x = 0; x <= W; x += 64) c.lineTo(x, y0 + Math.sin(x * 0.005 + ly.v * 20) * 3);
			c.lineTo(W, y1);
			c.lineTo(0, y1);
			c.closePath();
			c.fill();
		}
		// sand grains / shell fragments in the sediment
		for (let i = 0; i < 9000; i++) {
			const v = Math.pow(r.range(0, 1), 2.1) * 0.5;
			const x = r.range(0, W);
			const y = yOf(v);
			const warm = r.chance(0.5);
			c.fillStyle = warm ? `rgba(150,132,100,${r.range(0.12, 0.5)})` : `rgba(200,192,168,${r.range(0.08, 0.3)})`;
			c.beginPath();
			c.ellipse(x, y, r.range(0.8, 4.5), r.range(0.6, 2.4), r.range(0, 3.14), 0, TAU);
			c.fill();
		}
		// darker pebble bed
		for (let i = 0; i < 1600; i++) {
			const v = Math.pow(r.range(0, 1), 2.6) * 0.34;
			const x = r.range(0, W);
			const y = yOf(v);
			const g = r.range(0.1, 0.3);
			c.fillStyle = `rgba(${Math.floor(60 * g * 3)},${Math.floor(56 * g * 3)},${Math.floor(48 * g * 3)},0.8)`;
			c.beginPath();
			c.ellipse(x, y, r.range(2, 9), r.range(1.2, 4), r.range(0, 3), 0, TAU);
			c.fill();
			c.fillStyle = `rgba(190,180,150,${r.range(0.03, 0.12)})`;
			c.beginPath();
			c.ellipse(x - 1, y - 1, r.range(1, 5), r.range(0.6, 2), 0, 0, TAU);
			c.fill();
		}
		// faint horizontal pour lines through the resin
		for (let i = 0; i < 16; i++) {
			const v = r.range(0.35, 0.985);
			const y = yOf(v);
			c.strokeStyle = `rgba(190,235,240,${r.range(0.02, 0.07)})`;
			c.lineWidth = r.range(1, 3.5);
			c.beginPath();
			for (let x = 0; x <= W; x += 64) {
				const yy = y + Math.sin(x * 0.003 + i) * 2.4;
				x === 0 ? c.moveTo(x, yy) : c.lineTo(x, yy);
			}
			c.stroke();
		}
		// bubbles
		for (let i = 0; i < 500; i++) {
			const v = r.range(0.2, 0.98);
			const x = r.range(0, W),
				y = yOf(v);
			const rad = r.range(0.8, 3.4);
			c.strokeStyle = `rgba(210,245,250,${r.range(0.07, 0.24)})`;
			c.lineWidth = 1;
			c.beginPath();
			c.arc(x, y, rad, 0, TAU);
			c.stroke();
			c.fillStyle = `rgba(230,255,255,${r.range(0.02, 0.07)})`;
			c.beginPath();
			c.arc(x - rad * 0.3, y - rad * 0.3, rad * 0.5, 0, TAU);
			c.fill();
		}
		// a few tiny fish silhhouettes suspended in the resin
		const fishCol = 'rgba(9,20,22,0.55)';
		for (let i = 0; i < 26; i++) {
			const x = r.range(0, W),
				y = yOf(r.range(0.2, 0.72));
			const dir = r.chance(0.5) ? 1 : -1;
			const len = r.range(9, 22);
			c.fillStyle = fishCol;
			c.beginPath();
			c.ellipse(x, y, len * 0.5, len * 0.16, 0, 0, TAU);
			c.fill();
			c.beginPath();
			c.moveTo(x - dir * len * 0.45, y);
			c.lineTo(x - dir * len * 0.72, y - len * 0.22);
			c.lineTo(x - dir * len * 0.72, y + len * 0.22);
			c.closePath();
			c.fill();
		}
		// bright waterline at the top + light shafts
		const topG = c.createLinearGradient(0, 0, 0, yOf(0.86));
		topG.addColorStop(0, 'rgba(110,205,215,0.34)');
		topG.addColorStop(0.35, 'rgba(90,190,200,0.1)');
		topG.addColorStop(1, 'rgba(90,190,200,0)');
		c.fillStyle = topG;
		c.fillRect(0, 0, W, yOf(0.86));
		for (let i = 0; i < 70; i++) {
			const x = r.range(0, W);
			const w = r.range(10, 44);
			const g = c.createLinearGradient(0, 0, 0, yOf(0.4));
			g.addColorStop(0, `rgba(150,225,232,${r.range(0.02, 0.06)})`);
			g.addColorStop(1, 'rgba(150,225,232,0)');
			c.fillStyle = g;
			c.fillRect(x, 0, w, yOf(0.4));
		}
		// dark poured-resin edge line (kills the neon halo at the rim)
		c.fillStyle = 'rgba(8,26,30,0.85)';
		c.fillRect(0, 0, W, 3.5);
		return U.canvasTex(canvas, { repeat: [1, 1], cacheKey: 't1-resin' });
	}

	/** engraved brass nameplate */
	function makeNameplateTexture() {
		const W = 2048,
			H = 512;
		const canvas = U.createCanvas(W, H);
		const c = canvas.getContext('2d');
		const r = U.rng(303);
		const g = c.createLinearGradient(0, 0, 0, H);
		g.addColorStop(0, '#d9b664');
		g.addColorStop(0.42, '#c09a45');
		g.addColorStop(0.55, '#a9853a');
		g.addColorStop(1, '#8c6a2c');
		c.fillStyle = g;
		c.fillRect(0, 0, W, H);
		// brushed metal
		for (let i = 0; i < 2600; i++) {
			c.fillStyle = r.chance(0.5) ? `rgba(255,240,200,${r.range(0.02, 0.08)})` : `rgba(50,34,12,${r.range(0.02, 0.07)})`;
			c.fillRect(r.range(0, W), r.range(0, H), r.range(10, 120), r.range(0.6, 1.6));
		}
		// inset border
		c.strokeStyle = 'rgba(58,40,15,0.85)';
		c.lineWidth = 6;
		c.strokeRect(26, 26, W - 52, H - 52);
		c.strokeStyle = 'rgba(255,238,190,0.5)';
		c.lineWidth = 2;
		c.strokeRect(32, 32, W - 64, H - 64);
		// engraved text: dark cut + light lower edge
		const drawText = (txt, font, y, alpha) => {
			c.font = font;
			c.textAlign = 'center';
			c.textBaseline = 'middle';
			c.fillStyle = `rgba(40,26,8,${alpha})`;
			c.fillText(txt, W / 2 + 2, y + 2);
			c.fillStyle = `rgba(30,20,6,${alpha})`;
			c.fillText(txt, W / 2, y);
			c.fillStyle = 'rgba(255,240,200,0.35)';
			c.fillText(txt, W / 2 - 1.2, y + 3);
		};
		drawText('MINIATURE HARBOUR', '600 112px Georgia, "Times New Roman", serif', 186, 0.92);
		drawText('D I O R A M A   ·   N o . 0 1', '400 54px Georgia, "Times New Roman", serif', 300, 0.85);
		drawText('1 : 2 2 0       ·       P R O C E D U R A L', '400 38px Georgia, "Times New Roman", serif', 382, 0.7);
		// rivets
		for (const [x, y] of [
			[70, 70],
			[W - 70, 70],
			[70, H - 70],
			[W - 70, H - 70],
		]) {
			const rg = c.createRadialGradient(x - 3, y - 3, 1, x, y, 11);
			rg.addColorStop(0, '#f0d79a');
			rg.addColorStop(0.5, '#b8944a');
			rg.addColorStop(1, '#6b4f20');
			c.fillStyle = rg;
			c.beginPath();
			c.arc(x, y, 10, 0, TAU);
			c.fill();
		}
		return U.canvasTex(canvas, { cacheKey: 't1-nameplate' });
	}

	// ------------------------------------------------------------------
	// terrain material: vertex-colour + 3 triplanar maps + detail normals
	// ------------------------------------------------------------------
	function makeTerrainMaterial(M, opts) {
		opts = opts || {};
		const sand = M.get('sand');
		const grass = M.get('grass');
		const rock = M.get('rock');
		const mat = new THREE.MeshStandardMaterial({
			color: 0xffffff,
			vertexColors: true,
			roughness: 0.94,
			metalness: 0.0,
			envMapIntensity: opts.env != null ? opts.env : 0.62,
		});
		const uniforms = {
			tSand: { value: sand.map },
			tGrass: { value: grass.map },
			tRock: { value: rock.map },
			tDetail: { value: rock.normalMap },
			uRockRough: { value: opts.rockRough != null ? opts.rockRough : 0.86 },
			uDetailK: { value: opts.detail != null ? opts.detail : 0.62 },
		};
		mat.onBeforeCompile = (shader) => {
			Object.assign(shader.uniforms, uniforms);
			shader.vertexShader = shader.vertexShader
				.replace(
					'#include <common>',
					`#include <common>
					attribute vec4 aBlend;
					varying vec4 vBlend;
					varying vec3 vWorldPos;
					varying vec3 vWorldNormal;
					#ifdef USE_INSTANCING
					varying vec3 vInstTint;
					#endif`
				)
				.replace(
					'#include <begin_vertex>',
					`#include <begin_vertex>
					vBlend = aBlend;
					vec4 tWP4 = vec4(transformed, 1.0);
					vec3 tWN3 = objectNormal;
					#ifdef USE_INSTANCING
						tWP4 = instanceMatrix * tWP4;
						tWN3 = mat3(instanceMatrix) * tWN3;
					#endif
					vWorldPos = (modelMatrix * tWP4).xyz;
					vWorldNormal = normalize(mat3(modelMatrix) * tWN3);`
				);
			shader.fragmentShader = shader.fragmentShader
				.replace(
					'#include <common>',
					`#include <common>
					uniform sampler2D tSand;
					uniform sampler2D tGrass;
					uniform sampler2D tRock;
					uniform sampler2D tDetail;
					uniform float uRockRough;
					uniform float uDetailK;
					varying vec4 vBlend;
					varying vec3 vWorldPos;
					varying vec3 vWorldNormal;`
				)
				.replace(
					'#include <map_fragment>',
					`vec2 tWp = vWorldPos.xz;
					vec3 tNw = normalize(vWorldNormal);
					vec3 tBw = pow(abs(tNw), vec3(3.0));
					tBw /= max(tBw.x + tBw.y + tBw.z, 1e-4);
					float tRockS = 1.12;
					vec3 tRockC = texture2D(tRock, vWorldPos.zy * tRockS).rgb * tBw.x
					            + texture2D(tRock, tWp * tRockS).rgb * tBw.y
					            + texture2D(tRock, vWorldPos.xy * tRockS).rgb * tBw.z;
					// macro variation kills texture tiling, adds weathering
					float tMacro = texture2D(tRock, tWp * 0.075).g;
					float tMacro2 = texture2D(tRock, tWp * 0.27 + 0.31).r;
					vec3 tSandC = texture2D(tSand, tWp * 1.5).rgb;
					tSandC *= 0.55 + 0.85 * texture2D(tSand, tWp * 0.28 + 0.17).g;
					vec3 tGrassC = texture2D(tGrass, tWp * 1.05).rgb * vec3(0.78, 0.8, 0.62);
					tGrassC *= 0.5 + 0.95 * texture2D(tGrass, tWp * 0.23 + 0.53).g;
					float tSum = max(vBlend.x + vBlend.y + vBlend.z, 1e-4);
					float tRockW = vBlend.z / tSum;
					vec3 tAlb = (tSandC * vBlend.x + tGrassC * vBlend.y + tRockC * vBlend.z) / tSum;
					float tStrata = 0.5 + 0.5 * sin(vWorldPos.y * 6.2 + 1.7 + tRockC.r * 1.6);
					tAlb *= mix(1.0, mix(0.82, 1.14, tStrata), tRockW * 0.7);
					tAlb *= mix(vec3(1.0), vec3(0.6, 0.69, 0.72), vBlend.w);
					tAlb *= 0.84 + 0.3 * tMacro;
					tAlb *= 0.93 + 0.14 * tMacro2;
					tAlb *= vec3(1.03, 1.0, 0.94);
					diffuseColor.rgb = tAlb;`
				)
				.replace(
					'#include <roughnessmap_fragment>',
					`float tSum2 = max(vBlend.x + vBlend.y + vBlend.z, 1e-4);
					float roughnessFactor = mix(0.97, uRockRough, vBlend.z / tSum2);
					roughnessFactor = mix(roughnessFactor, 0.36, vBlend.w);`
				)
				.replace(
					'#include <normal_fragment_maps>',
					`vec3 tN2 = normalize(vWorldNormal);
					vec3 tB2 = pow(abs(tN2), vec3(2.0));
					tB2 /= max(tB2.x + tB2.y + tB2.z, 1e-4);
					vec3 tNX = texture2D(tDetail, vWorldPos.zy * 3.4).xyz * 2.0 - 1.0;
					vec3 tNY = texture2D(tDetail, vWorldPos.xz * 3.4).xyz * 2.0 - 1.0;
					vec3 tNZ = texture2D(tDetail, vWorldPos.xy * 3.4).xyz * 2.0 - 1.0;
					vec3 tPx = vec3(tNX.z, tNX.y, tNX.x);
					vec3 tPy = vec3(tNY.x, tNY.z, tNY.y);
					vec3 tPz = vec3(tNZ.x, tNZ.y, tNZ.z);
					vec3 tPert = (tPx * tB2.x + tPy * tB2.y + tPz * tB2.z) * uDetailK;
					vec3 tWn = normalize(tN2 + tPert);
					normal = normalize((viewMatrix * vec4(tWn, 0.0)).xyz);`
				);
		};
		mat.customProgramCacheKey = () => 't1-terrain-' + (opts.key || 'land');
		return mat;
	}

	// ------------------------------------------------------------------
	// rock geometry (shares the terrain material)
	// ------------------------------------------------------------------
	function rockGeometry(detail, seed, squash) {
		let geo = new THREE.IcosahedronGeometry(1, detail);
		try {
			geo = H.ADDONS.mergeVertices(geo);
		} catch (err) {
			/* keep non-indexed fallback */
		}
		const pos = geo.attributes.position;
		const v = new THREE.Vector3();
		for (let i = 0; i < pos.count; i++) {
			v.fromBufferAttribute(pos, i);
			const n1 = U.noise3(v.x * 1.5 + seed * 0.13, v.y * 1.5, v.z * 1.5, 3);
			const n2 = U.noise3(v.x * 3.3, v.y * 3.3 + seed * 0.21, v.z * 3.3, 7);
			const rad = 1 + 0.34 * n1 + 0.13 * n2;
			v.multiplyScalar(rad);
			v.y *= squash;
			// flatten the underside so it beds into the ground instead of balancing
			if (v.y < -0.35) v.y = -0.35 - (v.y + 0.35) * 0.22;
			pos.setXYZ(i, v.x, v.y, v.z);
		}
		// normalise the pivot: after this the lowest point sits at y = -1 in
		// local space, so placement can rely on (terrain, scale, sink)
		geo.computeBoundingBox();
		const bb = geo.boundingBox;
		const minY = bb.min.y;
		geo.translate(0, -1 - minY, 0);
		geo.computeBoundingBox();
		geo.computeVertexNormals();
		const n = pos.count;
		const col = new Float32Array(n * 3);
		const blend = new Float32Array(n * 4);
		for (let i = 0; i < n; i++) {
			// warm grey-brown boulders (never black coal): a touch of sand albedo
			const b = 0.95 + 0.3 * (U.noise2(pos.getX(i) * 2.1 + seed, pos.getZ(i) * 2.1, 5) * 0.5 + 0.5);
			col[i * 3] = b * 1.12;
			col[i * 3 + 1] = b * 1.04;
			col[i * 3 + 2] = b * 0.88;
			blend[i * 4] = 0.32;
			blend[i * 4 + 1] = 0.05;
			blend[i * 4 + 2] = 0.63;
			blend[i * 4 + 3] = 0.0;
		}
		geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
		geo.setAttribute('aBlend', new THREE.BufferAttribute(blend, 4));
		return geo;
	}

	// ------------------------------------------------------------------
	// plinth: turned walnut base + brass inlay + nameplate
	// ------------------------------------------------------------------
	function buildPlinth(ctx, parent, tex) {
		const M = ctx.materials;
		const g = U.group(parent, 'plinth');
		const woodMat = new THREE.MeshStandardMaterial({
			map: tex.wood.map,
			normalMap: tex.wood.normalMap,
			roughnessMap: tex.wood.roughnessMap,
			roughness: 0.62,
			metalness: 0.02,
			normalScale: new THREE.Vector2(0.7, 0.7),
			envMapIntensity: 0.7,
		});
		woodMat.userData.procedural = true;
		// turned profile: bottom -> bead -> barrel -> top lip
		const prof = [
			[PLINTH_R - 0.52, PLINTH_BOT],
			[PLINTH_R - 0.2, PLINTH_BOT + 0.02],
			[PLINTH_R - 0.03, PLINTH_BOT + 0.1],
			[PLINTH_R + 0.02, PLINTH_BOT + 0.24],
			[PLINTH_R + 0.05, PLINTH_BOT + 0.42],
			[PLINTH_R + 0.045, PLINTH_BOT + 0.58],
			[PLINTH_R + 0.01, PLINTH_BOT + 0.7],
			[PLINTH_R - 0.02, PLINTH_BOT + 0.78],
			[PLINTH_R - 0.005, PLINTH_BOT + 0.84],
			[PLINTH_R + 0.02, PLINTH_BOT + 0.89],
			[PLINTH_R + 0.005, PLINTH_TOP - 0.05],
			[PLINTH_R - 0.015, PLINTH_TOP - 0.012],
			[PLINTH_R - 0.06, PLINTH_TOP + 0.006],
			[PLINTH_R - 0.12, PLINTH_TOP + 0.012],
		];
		const pts = prof.map((p) => new THREE.Vector2(p[0], p[1]));
		const lathe = new THREE.LatheGeometry(pts, 220);
		const side = new THREE.Mesh(lathe, woodMat);
		side.name = 'plinth-side';
		side.receiveShadow = true;
		side.castShadow = false;
		g.add(side);
		// top face (wood shoulder around the resin inset)
		const topGeo = new THREE.CircleGeometry(PLINTH_R - 0.1, 200);
		const top = U.mesh(topGeo, woodMat, 0, PLINTH_TOP + 0.004, 0, { rot: [-Math.PI / 2, 0, 0], receive: true });
		top.name = 'plinth-top';
		g.add(top);
		// brass inlay ring floating in the wood shoulder (aged, low-gloss:
		// a mirror finish here reads as a hard white ring against the dark set)
		const brass = new THREE.MeshStandardMaterial({ color: 0xb08c3f, roughness: 0.45, metalness: 0.8, envMapIntensity: 0.55 });
		brass.userData.procedural = true;
		const ringGeo = new THREE.RingGeometry(PLINTH_R - 0.5, PLINTH_R - 0.4, 220, 1);
		const inlay = U.mesh(ringGeo, brass, 0, PLINTH_TOP + 0.013, 0, { rot: [-Math.PI / 2, 0, 0], receive: true });
		inlay.name = 'brass-inlay';
		g.add(inlay);
		// thin brass line around the barrel
		const bead = new THREE.Mesh(new THREE.TorusGeometry(PLINTH_R + 0.012, 0.016, 6, 240), brass);
		bead.rotation.x = -Math.PI / 2;
		bead.position.y = PLINTH_TOP - 0.36;
		bead.name = 'brass-bead';
		g.add(bead);
		// nameplate (curved, faces +z = default camera side)
		const plateMat = new THREE.MeshStandardMaterial({
			map: tex.nameplate,
			metalness: 0.82,
			roughness: 0.34,
			envMapIntensity: 1.0,
		});
		plateMat.userData.procedural = true;
		const arc = 0.36; // radians
		const plateGeo = new THREE.CylinderGeometry(PLINTH_R - 0.28, PLINTH_R - 0.28, 0.4, 40, 1, true, -arc / 2, arc);
		const plate = new THREE.Mesh(plateGeo, plateMat);
		plate.position.set(0, -2.02, 0);
		plate.name = 'nameplate';
		g.add(plate);
		return { group: g, woodMat, brass };
	}

	// ------------------------------------------------------------------
	// terrain mesh (polar fan, jittered) + vertex attributes
	// ------------------------------------------------------------------
	function buildTerrainMesh(ctx, parent, mat) {
		const NS = 512; // angular segments (rim resolution = 0.17 world units)
		const NR = 120; // radial rings
		const count = NS * (NR + 1);
		const positions = new Float32Array(count * 3);
		const heights = new Float32Array(count);
		const beachW = new Float32Array(count);
		const dArr = new Float32Array(count);
		const padCodeArr = new Uint8Array(count);
		const _q2 = {};
		let p3 = 0;
		for (let ri = 0; ri <= NR; ri++) {
			const f = ri / NR;
			for (let si = 0; si < NS; si++) {
				const a0 = (si / NS) * TAU;
				const ca = Math.cos(a0),
					sa = Math.sin(a0);
				// organic jitter, coherent between rings, zero at the rim
				const ja = U.noise2(ca * 2.3 + f * 0.75, sa * 2.3 - f * 0.55, 9);
				const jr = U.noise2(ca * 3.1 - f * 0.95, sa * 3.1 + f * 0.65, 17);
				const ang = a0 + (ja * 0.42 * TAU) / NS;
				const rad = (ri + (ri === 0 || ri === NR ? 0 : jr * 0.34)) / NR * RIM;
				const x = Math.cos(ang) * rad;
				const z = Math.sin(ang) * rad;
				const q = coastQuery(x, z, _cq);
				const h = terrainHeight(x, z, q);
				const idx = ri * NS + si;
				positions[p3++] = x;
				positions[p3++] = h;
				positions[p3++] = z;
				heights[idx] = h;
				dArr[idx] = q.d;
				beachW[idx] = _zw.beach;
				padCodeArr[idx] = _lastPadCode;
			}
		}
		const triCount = NR * NS * 2;
		const indices = new Uint32Array(triCount * 3);
		let ii = 0;
		for (let ri = 0; ri < NR; ri++) {
			for (let si = 0; si < NS; si++) {
				const sn = (si + 1) % NS;
				const a = ri * NS + si;
				const b = ri * NS + sn;
				const c = (ri + 1) * NS + si;
				const d = (ri + 1) * NS + sn;
				indices[ii++] = a;
				indices[ii++] = b;
				indices[ii++] = c;
				indices[ii++] = b;
				indices[ii++] = d;
				indices[ii++] = c;
			}
		}
		const geo = new THREE.BufferGeometry();
		geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
		geo.setIndex(new THREE.BufferAttribute(indices, 1));
		// ---- normals: grid normals everywhere, analytic coast gradient near the
		// waterline (a discrete polar grid otherwise breaks steep coastal bands
		// into radial shading stripes)
		const smoothN = new Float32Array(count * 3);
		const P = positions;
		for (let ri = 0; ri <= NR; ri++) {
			const r0 = Math.max(0, ri - 2);
			const r1 = Math.min(NR, ri + 2);
			for (let si = 0; si < NS; si++) {
				const k = ri * NS + si;
				const iA = (ri * NS + ((si - 1 + NS) % NS)) * 3;
				const iB = (ri * NS + ((si + 1) % NS)) * 3;
				const tx = P[iB] - P[iA],
					ty = P[iB + 1] - P[iA + 1],
					tz = P[iB + 2] - P[iA + 2];
				const iC = (r0 * NS + si) * 3;
				const iD = (r1 * NS + si) * 3;
				const rx = P[iD] - P[iC],
					ry = P[iD + 1] - P[iC + 1],
					rz = P[iD + 2] - P[iC + 2];
				let nx = ty * rz - tz * ry;
				let ny = tz * rx - tx * rz;
				let nz = tx * ry - ty * rx;
				if (ny < 0) {
					nx = -nx;
					ny = -ny;
					nz = -nz;
				}
				const len = Math.hypot(nx, ny, nz);
				if (len < 1e-9) {
					nx = 0;
					ny = 1;
					nz = 0;
				} else {
					nx /= len;
					ny /= len;
					nz /= len;
				}
				// ---- analytic coastal normal ----
				const d = dArr[k];
				const ad = Math.abs(d);
				if (ad < 1.9) {
					const x = P[k * 3],
						y = P[k * 3 + 1],
						z = P[k * 3 + 2];
					const cq = coastQuery(x, z, _q2);
					// smoothed inward direction from the coast tangent: the raw
					// nearest-point direction jumps at polyline vertices and would
					// stripe the cliff band into vertical facets
					const pa = L.pointAlong(COAST, cq.s - 0.5);
					const pb = L.pointAlong(COAST, cq.s + 0.5);
					let tx = pb.x - pa.x,
						tz = pb.z - pa.z;
					const tl = Math.hypot(tx, tz) || 1;
					tx /= tl;
					tz /= tl;
					let ix = tz,
						iz = -tx;
					if ((x - cq.px) * ix + (z - cq.pz) * iz < 0) {
						ix = -ix;
						iz = -iz;
					}
					const hin = terrainHeight(x + ix * 0.16, z + iz * 0.16);
					const slope = (hin - y) / 0.16;
					let ax = -slope * ix,
						ay = 1,
						az = -slope * iz;
					const al = Math.hypot(ax, ay, az) || 1;
					ax /= al;
					ay /= al;
					az /= al;
					const m = 1 - smoothstep(1.2, 1.9, ad);
					nx = lerp(nx, ax, m);
					ny = lerp(ny, ay, m);
					nz = lerp(nz, az, m);
					const nl = Math.hypot(nx, ny, nz) || 1;
					nx /= nl;
					ny /= nl;
					nz /= nl;
				}
				smoothN[k * 3] = nx;
				smoothN[k * 3 + 1] = ny;
				smoothN[k * 3 + 2] = nz;
			}
		}
		geo.setAttribute('normal', new THREE.BufferAttribute(smoothN, 3));
		// ---- vertex colour + material blend ----
		const normals = geo.attributes.normal;
		const colors = new Float32Array(count * 3);
		const blends = new Float32Array(count * 4);
		for (let ri = 0; ri <= NR; ri++) {
			for (let si = 0; si < NS; si++) {
				const k = ri * NS + si;
				const x = positions[k * 3];
				const y = positions[k * 3 + 1];
				const z = positions[k * 3 + 2];
				const ny = normals.getY(k);
				const slope = 1 - clamp(ny, -1, 1);
				const zwBeach = beachW[k];
				const padCode = padCodeArr[k];
				let sand = 0,
					grass = 0,
					rock = 0,
					wet = 0;
				if (y < -0.02) {
					const depth = clamp(-y / 1.15, 0, 1);
					sand = lerp(0.9, 0.42, depth);
					sand = lerp(sand, 0.94, zwBeach);
					rock = 1 - sand;
					wet = 1;
				} else {
					rock = smoothstep(0.3, 0.62, slope);
					rock = Math.max(rock, smoothstep(3.1, 4.0, y) * smoothstep(0.2, 0.46, slope) * 0.75);
					const lowland = 1 - smoothstep(0.15, 0.8, y);
					sand = zwBeach * (1 - rock) + (1 - zwBeach) * (1 - rock) * lowland * 0.5;
					sand = Math.min(sand, 1 - rock);
					grass = Math.max(0, 1 - rock - sand);
					wet = smoothstep(0.34, 0.02, y) * (0.4 + 0.6 * (1 - rock)) * (0.55 + 0.45 * zwBeach);
					wet = clamp(wet, 0, 1);
					// built waterfront: compacted gravel / dirt instead of lawn
					if (padCode === 1 || padCode === 2) {
						const padK = 1 - smoothstep(0.12, 0.34, slope);
						rock = lerp(rock, 0.44, padK * 0.85);
						sand = lerp(sand, 0.4, padK * 0.8);
						grass = Math.max(0, 1 - rock - sand);
					} else if (padCode === 3) {
						// town terraces: worn warm soil / paving dust between buildings
						sand += 0.2 * (1 - rock);
						grass = Math.max(0, 1 - rock - sand);
					}
				}
				const sum = sand + grass + rock || 1;
				blends[k * 4] = sand / sum;
				blends[k * 4 + 1] = grass / sum;
				blends[k * 4 + 2] = rock / sum;
				blends[k * 4 + 3] = wet;
				// ---- tint / AO ----
				let ao = 0.78 + 0.22 * clamp(ny, 0, 1);
				if (ri > 2 && ri < NR - 2) {
					const hPrev = heights[k - NS];
					const hNext = heights[k + NS];
					const lap = (hPrev + hNext) * 0.5 - y;
					ao *= clamp(1 - lap * 1.05, 0.68, 1.05);
				}
				const m1 = U.noise2(x * 0.17, z * 0.17, 71) * 0.65 + U.noise2(x * 0.48, z * 0.48, 93) * 0.35;
				const m2 = U.noise2(x * 0.7, z * 0.7, 17);
				const bright = (0.84 + 0.2 * (m1 * 0.5 + 0.5)) * ao;
				let cr = bright,
					cg = bright,
					cb = bright;
				// grass: dry olive vs. lush, a little hue variation to break tiling
				const grassW = blends[k * 4 + 1];
				const dry = m2 * 0.5 + 0.5;
				cr *= 1 + 0.12 * dry * grassW + 0.05 * blends[k * 4 + 2];
				cg *= 1 + 0.02 * (m1 * 0.5 + 0.5);
				cb *= 1 - 0.16 * dry * grassW - 0.04 * blends[k * 4 + 2];
				// wet sand / rock darkens and cools
				cr *= 1 - 0.3 * wet;
				cg *= 1 - 0.22 * wet;
				cb *= 1 - 0.12 * wet;
				// hard-standing waterfront: neutral grey concrete/gravel, oil stains
				let hardK = 0;
				if (padCode === 1) hardK = 1;
				else if (padCode === 2) hardK = 0.7;
				if (hardK > 0) {
					const oil = smoothstep(0.58, 0.86, U.noise2(x * 0.5 + 3.1, z * 0.5 - 2.3, 141) * 0.5 + 0.5);
					cr *= 1 - 0.2 * oil * hardK;
					cg *= 1 - 0.19 * oil * hardK;
					cb *= 1 - 0.16 * oil * hardK;
					const lum = (cr + cg + cb) / 3;
					cr = lerp(cr, lum * 1.02, 0.4 * hardK);
					cg = lerp(cg, lum * 0.99, 0.4 * hardK);
					cb = lerp(cb, lum * 0.98, 0.4 * hardK);
				}
				if (y < 0) {
					const dk = 0.22 + 0.34 * clamp(1 + y / 1.8, 0, 1);
					cr *= dk;
					cg *= dk;
					cb *= dk;
				}
				colors[k * 3] = clamp(cr, 0.25, 1.6);
				colors[k * 3 + 1] = clamp(cg, 0.25, 1.6);
				colors[k * 3 + 2] = clamp(cb, 0.25, 1.6);
			}
		}
		geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
		geo.setAttribute('aBlend', new THREE.BufferAttribute(blends, 4));
		const mesh = new THREE.Mesh(geo, mat);
		mesh.name = 'island-terrain';
		mesh.receiveShadow = true;
		mesh.castShadow = true;
		parent.add(mesh);
		// outer ring (exact rim) for the cut face
		const outer = new Array(NS);
		for (let si = 0; si < NS; si++) {
			const k = NR * NS + si;
			outer[si] = { x: positions[k * 3], y: positions[k * 3 + 1], z: positions[k * 3 + 2], ang: Math.atan2(positions[k * 3 + 2], positions[k * 3]) };
		}
		return { mesh, outer, NS, heights };
	}

	// ------------------------------------------------------------------
	// island cut face at the disc rim + topsoil ribbon
	// ------------------------------------------------------------------
	function buildRimWall(ctx, parent, terrain, mat, tex) {
		const NS = terrain.NS;
		const outer = terrain.outer;
		const M = ctx.materials;
		const map = tex.strata;
		const wallMat = new THREE.MeshStandardMaterial({
			map,
			vertexColors: true,
			roughness: 0.95,
			metalness: 0.0,
			envMapIntensity: 0.35,
		});
		wallMat.userData.procedural = true;
		const pos = [];
		const uv = [];
		const col = [];
		const idx = [];
		const ribbon = { pos: [], uv: [], col: [], blend: [], idx: [] };
		const cTmp = new THREE.Color();
		const pushVert = (x, y, z, u, v, cr, cg, cb) => {
			pos.push(x, y, z);
			uv.push(u, v);
			col.push(cr, cg, cb);
			return pos.length / 3 - 1;
		};
		for (let si = 0; si < NS; si++) {
			const a = outer[si];
			const b = outer[(si + 1) % NS];
			if (a.y < PLINTH_TOP + 0.08 || b.y < PLINTH_TOP + 0.08) continue;
			const uA = (si / NS) * 3;
			const uB = ((si + 1) / NS) * 3;
			const shadeA = 0.72 + 0.28 * (U.noise2(a.x * 0.7, a.z * 0.7, 33) * 0.5 + 0.5);
			const shadeB = 0.72 + 0.28 * (U.noise2(b.x * 0.7, b.z * 0.7, 33) * 0.5 + 0.5);
			const wetA = smoothstep(1.2, -0.4, a.y);
			const wetB = smoothstep(1.2, -0.4, b.y);
			const topA = clamp(0.82 + 0.18 * smoothstep(1.5, 4.2, a.y), 0.7, 1.1);
			const topB = clamp(0.82 + 0.18 * smoothstep(1.5, 4.2, b.y), 0.7, 1.1);
			// top vertices (slightly below the surface so the grass overhangs)
			const ta = [
				a.x * 0.9995,
				a.y - 0.01,
				a.z * 0.9995,
				uA,
				clamp((a.y - PLINTH_TOP) / RIM_WALL_UV_H, 0, 1),
				shadeA * topA * 0.92,
				shadeA * topA * 0.9,
				shadeA * topA * 0.86,
			];
			const tb = [
				b.x * 0.9995,
				b.y - 0.01,
				b.z * 0.9995,
				uB,
				clamp((b.y - PLINTH_TOP) / RIM_WALL_UV_H, 0, 1),
				shadeB * topB * 0.92,
				shadeB * topB * 0.9,
				shadeB * topB * 0.86,
			];
			const ba = [a.x * 0.9985, PLINTH_TOP, a.z * 0.9985, uA, 0, shadeA * 0.78 * (1 - 0.3 * wetA), shadeA * 0.68 * (1 - 0.3 * wetA), shadeA * 0.6 * (1 - 0.3 * wetA)];
			const bb = [b.x * 0.9985, PLINTH_TOP, b.z * 0.9985, uB, 0, shadeB * 0.78 * (1 - 0.3 * wetB), shadeB * 0.68 * (1 - 0.3 * wetB), shadeB * 0.6 * (1 - 0.3 * wetB)];
			const i0 = pushVert(...ta);
			const i1 = pushVert(...tb);
			const i2 = pushVert(...ba);
			const i3 = pushVert(...bb);
			idx.push(i0, i1, i3, i0, i3, i2);
			// ---- topsoil ribbon: 0.22 world units of soil/grass at the cut top
			const th = 0.22;
			const ra = [a.x * 0.9995, Math.max(a.y - 0.01, PLINTH_TOP + 0.02), a.z * 0.9995];
			const rb = [b.x * 0.9995, Math.max(b.y - 0.01, PLINTH_TOP + 0.02), b.z * 0.9995];
			const ra2 = [a.x * 0.9998, ra[1] - th, a.z * 0.9998];
			const rb2 = [b.x * 0.9998, rb[1] - th, b.z * 0.9998];
			const base = ribbon.pos.length / 3;
			const pushR = (p, top) => {
				ribbon.pos.push(p[0], p[1], p[2]);
				ribbon.uv.push(top ? uA : uA, top ? 1 : 0);
				const soil = top ? [0.62, 0.66, 0.42] : [0.5, 0.42, 0.31];
				ribbon.col.push(soil[0], soil[1], soil[2]);
				ribbon.blend.push(top ? 0.22 : 0.3, top ? 0.62 : 0.28, top ? 0.16 : 0.42, 0.15);
			};
			pushR(ra, true);
			pushR(rb, true);
			pushR(ra2, false);
			pushR(rb2, false);
			ribbon.idx.push(base, base + 1, base + 3, base, base + 3, base + 2);
		}
		const geo = new THREE.BufferGeometry();
		geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
		geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
		geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
		geo.setIndex(idx);
		geo.computeVertexNormals();
		const wall = new THREE.Mesh(geo, wallMat);
		wall.name = 'island-cut-face';
		wall.receiveShadow = true;
		wall.castShadow = false;
		parent.add(wall);
		// topsoil strip uses the terrain material (triplanar rock/soil)
		const rgeo = new THREE.BufferGeometry();
		rgeo.setAttribute('position', new THREE.Float32BufferAttribute(ribbon.pos, 3));
		rgeo.setAttribute('uv', new THREE.Float32BufferAttribute(ribbon.uv, 2));
		rgeo.setAttribute('color', new THREE.Float32BufferAttribute(ribbon.col, 3));
		rgeo.setAttribute('aBlend', new THREE.Float32BufferAttribute(ribbon.blend, 4));
		rgeo.setIndex(ribbon.idx);
		rgeo.computeVertexNormals();
		const topsoil = new THREE.Mesh(rgeo, mat);
		topsoil.name = 'island-topsoil';
		topsoil.receiveShadow = true;
		parent.add(topsoil);
		return { wall, topsoil };
	}

	// ------------------------------------------------------------------
	// wild-coast cliff skirt: a proper strata-faced cliff along the north /
	// east coast and Fort Point. It covers the height-field's coastal ramp
	// (which a discrete polar grid can only render as shaded stripes) and
	// gives the cliffs the geological layering the art direction asks for.
	// ------------------------------------------------------------------
	function buildCoastCliff(ctx, parent, tex) {
		const g = U.group(parent, 'coast-cliffs');
		const mat = new THREE.MeshStandardMaterial({
			map: tex.strata,
			vertexColors: true,
			roughness: 0.94,
			metalness: 0.0,
			envMapIntensity: 0.3,
		});
		mat.userData.procedural = true;
		const S0 = 15.55;
		const S1 = 39.35;
		const STEP = 0.13;
		const nSeg = Math.ceil((S1 - S0) / STEP);
		const ROWS = 4;
		const positions = [];
		const uvs = [];
		const colors = [];
		const idx = [];
		const H = (x, z) => terrainHeight(x, z);
		for (let i = 0; i <= nSeg; i++) {
			const s = S0 + (i / nSeg) * (S1 - S0);
			const c = L.pointAlong(COAST, s);
			const inlX = c.dirZ,
				inlZ = -c.dirX; // inland
			const seaX = -inlX,
				seaZ = -inlZ;
			const n1 = U.fbm(c.x * 1.25, c.z * 1.25, { octaves: 2, seed: 211 });
			const n2 = U.fbm(c.x * 0.42, c.z * 0.42, { octaves: 2, seed: 233 });
			// jagged clifftop: the top edge is set slightly inland and follows
			// the real terrain height so it merges into the plateau
			const topOff = 0.42 + 0.16 * (n2 * 0.5 + 0.5);
			const tx = c.x + inlX * topOff;
			const tz = c.z + inlZ * topOff;
			const topY = Math.max(0.1, H(tx, tz) + 0.02);
			const hgt = topY + 1.15;
			// rows: [offset (inland +), height fraction, extra outward bulge]
			const rowDef = [
				[0.0, 1.0, 0.0],
				[0.34 + 0.2 * (n1 * 0.5 + 0.5), 0.62, 0.02],
				[0.14 + 0.16 * (n2 * 0.5 + 0.5), 0.3, 0.02],
				[-0.16, 0.0, 0.0],
			];
			for (let r = 0; r < ROWS; r++) {
				const rd = rowDef[r];
				const off = topOff - rd[0] + rd[2];
				const x = c.x + inlX * off + seaX * (r === 3 ? 0.08 : 0.0);
				const z = c.z + inlZ * off + seaZ * (r === 3 ? 0.08 : 0.0);
				const y = lerp(-1.15, topY, rd[1]);
				positions.push(x, y, z);
				uvs.push(s / 3.1, clamp((y + 1.15) / 6.0, 0, 1));
				// shading: warm sunlit top, damp dark base, some vertical mottling
				const wet = smoothstep(0.4, -0.5, y);
				const shade = 0.82 + 0.22 * (U.noise2(x * 0.9, z * 0.9, 307) * 0.5 + 0.5);
				const top = 0.9 + 0.16 * rd[1];
				colors.push(shade * top * (1 - 0.62 * wet), shade * top * (1 - 0.58 * wet), shade * top * (1 - 0.5 * wet));
			}
			if (i > 0) {
				const a = (i - 1) * ROWS;
				const b = i * ROWS;
				for (let r = 0; r < ROWS - 1; r++) {
					idx.push(a + r, b + r, b + r + 1, a + r, b + r + 1, a + r + 1);
				}
			}
		}
		const geo = new THREE.BufferGeometry();
		geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
		geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
		geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
		geo.setIndex(idx);
		geo.computeVertexNormals();
		const mesh = new THREE.Mesh(geo, mat);
		mesh.name = 'coast-cliffs';
		mesh.receiveShadow = true;
		mesh.castShadow = false;
		g.add(mesh);
		return { group: g, mesh };
	}

	// ------------------------------------------------------------------
	// resin sea: painted cross-section + meniscus lip on the water rim
	// ------------------------------------------------------------------
	function buildResinSea(ctx, parent, terrain, tex) {
		const NS = terrain.NS;
		const outer = terrain.outer;
		const RESIN_R = DISC_R + 0.02;
		const g = U.group(parent, 'resin-sea');
		const resinMat = new THREE.MeshPhysicalMaterial({
			map: tex.resin,
			color: 0x16323a,
			roughness: 0.36,
			metalness: 0.0,
			clearcoat: 0.4,
			clearcoatRoughness: 0.3,
			envMapIntensity: 0.26,
			side: THREE.DoubleSide,
		});
		resinMat.userData.procedural = true;
		const pos = [];
		const uv = [];
		const idx = [];
		const lipPos = [];
		const lipIdx = [];
		for (let si = 0; si < NS; si++) {
			const a = outer[si];
			const b = outer[(si + 1) % NS];
			const waterA = a.y < WATER_Y - 0.02;
			const waterB = b.y < WATER_Y - 0.02;
			if (!waterA || !waterB) continue;
			const uA = si / NS;
			const uB = (si + 1) / NS;
			const topY = WATER_Y + 0.012;
			const base = pos.length / 3;
			// two verts per side: bottom + top
			const ax = Math.cos(a.ang) * RESIN_R,
				az = Math.sin(a.ang) * RESIN_R;
			const bx = Math.cos(b.ang) * RESIN_R,
				bz = Math.sin(b.ang) * RESIN_R;
			pos.push(ax, PLINTH_TOP, az);
			uv.push(uA, 0);
			pos.push(ax, topY, az);
			uv.push(uA, 1);
			pos.push(bx, PLINTH_TOP, bz);
			uv.push(uB, 0);
			pos.push(bx, topY, bz);
			uv.push(uB, 1);
			idx.push(base, base + 2, base + 1, base + 1, base + 2, base + 3);
			// meniscus lip: flat-ish strip from just inside the wall to a bit outside
			const lipBase = lipPos.length / 3;
			const inner = RESIN_R - 0.1,
				out = RESIN_R + 0.045;
			lipPos.push(Math.cos(a.ang) * inner, WATER_Y + 0.012, Math.sin(a.ang) * inner);
			lipPos.push(Math.cos(a.ang) * out, WATER_Y + 0.03, Math.sin(a.ang) * out);
			lipPos.push(Math.cos(b.ang) * inner, WATER_Y + 0.012, Math.sin(b.ang) * inner);
			lipPos.push(Math.cos(b.ang) * out, WATER_Y + 0.03, Math.sin(b.ang) * out);
			lipIdx.push(lipBase, lipBase + 2, lipBase + 1, lipBase + 1, lipBase + 2, lipBase + 3);
		}
		if (!pos.length) return { group: g };
		const geo = new THREE.BufferGeometry();
		geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
		geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
		geo.setIndex(idx);
		geo.computeVertexNormals();
		const wall = new THREE.Mesh(geo, resinMat);
		wall.name = 'resin-sea-cut';
		wall.receiveShadow = false;
		wall.castShadow = false;
		g.add(wall);
		// glossy lip: a wet-glass edge, not a neon ring. It reads as a hard
		// bright hairline in the final 3200px render, so it is hidden outright.
		const lipMat = new THREE.MeshPhysicalMaterial({
			color: 0x16323a,
			roughness: 1.0,
			metalness: 0.0,
			clearcoat: 0.0,
			envMapIntensity: 0.0,
		});
		lipMat.userData.procedural = true;
		const lgeo = new THREE.BufferGeometry();
		lgeo.setAttribute('position', new THREE.Float32BufferAttribute(lipPos, 3));
		lgeo.setIndex(lipIdx);
		lgeo.computeVertexNormals();
		const lip = new THREE.Mesh(lgeo, lipMat);
		lip.name = 'resin-meniscus';
		lip.userData.noReflect = true;
		lip.visible = false;
		g.add(lip);
		return { group: g, wall, lip, material: resinMat };
	}

	// ------------------------------------------------------------------
	// rocks: coastal boulders, cliff scree, beach pebbles, sea stacks
	// ------------------------------------------------------------------
	function buildRocks(ctx, parent, mat) {
		const g = U.group(parent, 'terrain-rocks');
		const r = U.rng(5150);
		const med = [];
		const small = [];
		const peb = [];
		const pushRock = (list, x, y, z, s, opts = {}) => {
			const c = opts.col || 1;
			const SC = 0.78; // art review: boulders one notch smaller
			const under = y < 0 ? 0.75 : 1.0; // submerged part reads 25% darker
			list.push({
				x,
				y,
				z,
				sx: s * SC * (opts.sx || 1),
				sy: s * SC * (opts.sy || 0.78),
				sz: s * SC * (opts.sz || 1),
				rx: r.range(-0.45, 0.45),
				ry: r.range(0, TAU),
				rz: r.range(-0.45, 0.45),
				// warm grey-brown boulders: #6b6156 / #7a7164 / #5d554c range
				c: [under * c * r.range(1.06, 1.24), under * c * r.range(0.98, 1.14), under * c * r.range(0.82, 0.98)],
			});
		};
		const placeAt = (x, z, size, list, sink = 0.3, opts) => {
			// nothing may float outside the round base
			if (x * x + z * z > 13.68 * 13.68) return;
			const h = terrainHeight(x, z);
			const sy = opts && opts.sy ? opts.sy : 0.75;
			pushRock(list, x, h + size * (sy - sink), z, size, Object.assign({ sy }, opts || {}));
		};
		// ---- walk the coast: boulders, cliff scree, surf rocks, pebbles
		const step = 0.22;
		for (let s = 14.6; s < 60.2; s += step) {
			const p = L.pointAlong(COAST, s);
			const nx = -p.dirZ,
				nz = p.dirX; // seaward normal
			const zw = zoneWeights(s);
			const beach = zw.beach;
			const quay = zw.quay;
			const wild = (x, z) => L.districtAt(x, z) === 'wild';
			// skip the built waterfront (T2 owns the wall) except near the beach
			if (quay > 0.7) {
				// a few mooring boulders at the foot of the quay wall
				if (r.chance(0.22)) {
					const off = r.range(0.28, 0.55);
					const x = p.x + nx * off,
						z = p.z + nz * off;
					if (wild(x, z)) placeAt(x, z, r.range(0.1, 0.24), small, 0.45, { sy: 0.7 });
				}
				continue;
			}
			if (beach > 0.55) {
				// sandy cove: pebbles + a couple of boulders, no cliff rocks
				const n = r.int(0, 2);
				for (let k = 0; k < n; k++) {
					const off = r.range(0.05, 1.7);
					const x = p.x + nx * off + r.range(-0.12, 0.12);
					const z = p.z + nz * off + r.range(-0.12, 0.12);
					placeAt(x, z, r.range(0.035, 0.11), peb, 0.4, { sy: r.range(0.4, 0.7) });
				}
				if (r.chance(0.12)) {
					const off = r.range(0.2, 0.8);
					const x = p.x + nx * off,
						z = p.z + nz * off;
					if (wild(x, z)) placeAt(x, z, r.range(0.16, 0.32), small, 0.35, { sy: 0.75 });
				}
				continue;
			}
			// cliffs / fort: surf boulders + scree (only on wild ground)
			if (r.chance(0.7)) {
				const off = r.range(0.12, 0.85);
				const x = p.x + nx * off + r.range(-0.1, 0.1);
				const z = p.z + nz * off + r.range(-0.1, 0.1);
				if (wild(x, z)) {
					const size = r.chance(0.35) ? r.range(0.34, 0.68) : r.range(0.16, 0.36);
					placeAt(x, z, size, size > 0.32 ? med : small, r.range(0.2, 0.55), { sy: r.range(0.65, 0.95) });
				}
			}
			if (r.chance(0.5)) {
				const off = -r.range(0.25, 1.5);
				const x = p.x + nx * off + r.range(-0.15, 0.15);
				const z = p.z + nz * off + r.range(-0.15, 0.15);
				if (wild(x, z)) placeAt(x, z, r.range(0.14, 0.42), r.chance(0.4) ? med : small, r.range(0.25, 0.55), { sy: r.range(0.6, 0.95) });
			}
			// submerged reef rocks, visible through the shallow water
			if (r.chance(0.2)) {
				const off = r.range(0.9, 2.3);
				const x = p.x + nx * off + r.range(-0.2, 0.2);
				const z = p.z + nz * off + r.range(-0.2, 0.2);
				if (wild(x, z)) placeAt(x, z, r.range(0.18, 0.5), small, 0.25, { sy: r.range(0.6, 0.9) });
			}
		}
		// ---- cairns / boulders scattered on the wild hills
		const rndR = U.rng(771);
		for (let i = 0; i < 190; i++) {
			const ang = rndR.range(0, TAU);
			const rad = Math.sqrt(rndR.range(0.05, 1)) * 13.6;
			const x = Math.cos(ang) * rad,
				z = Math.sin(ang) * rad;
			const q = coastQuery(x, z);
			if (q.d < 0.6) continue; // stay inland
			const zw = zoneWeights(q.s);
			const h = terrainHeight(x, z);
			if (h < 0.5) continue;
			if (L.districtAt(x, z) !== 'wild') continue;
			const slope = terrainSlope(x, z, 0.3);
			if (slope < 0.25 && rndR.chance(0.7)) continue;
			const size = rndR.range(0.16, 0.6);
			placeAt(x, z, size, size > 0.3 ? med : small, rndR.range(0.2, 0.5), { sy: rndR.range(0.55, 0.9) });
		}
		// ---- sea stack landmark (eastern sea, inside the rim)
		const stack = L.ANCHORS.seaStack.pos;
		for (let i = 0; i < 9; i++) {
			const aa = r.range(0, TAU);
			const rr = r.range(0, 0.55);
			const x = stack[0] + Math.cos(aa) * rr;
			const z = stack[1] + Math.sin(aa) * rr;
			const size = r.range(0.42, 0.95);
			pushRock(med, x, -0.6 + size * 0.55 + r.range(0, 0.3), z, size, { sy: r.range(0.9, 1.4), sx: r.range(0.75, 1.05), sz: r.range(0.75, 1.05) });
		}
		// ---- lighthouse rock outcrop
		const lr = L.ANCHORS.lighthouseRock.pos;
		for (let i = 0; i < 6; i++) {
			const aa = r.range(0, TAU);
			const rr = r.range(0, 0.8);
			const size = r.range(0.35, 0.8);
			pushRock(med, lr[0] + Math.cos(aa) * rr, -0.5 + size * 0.4, lr[1] + Math.sin(aa) * rr, size, { sy: r.range(0.8, 1.2) });
		}
		// ---- ship rock cluster on the west
		// build the instanced meshes
		const geoMed = rockGeometry(2, 3.1, 0.85);
		const geoSmall = rockGeometry(1, 7.3, 0.72);
		const geoPeb = rockGeometry(1, 11.7, 0.42);
		const makeInst = (geo, list, name, cast) => {
			if (!list.length) return null;
			const m = new THREE.InstancedMesh(geo, mat, list.length);
			const dummy = new THREE.Object3D();
			const col = new THREE.Color();
			for (let i = 0; i < list.length; i++) {
				const t = list[i];
				dummy.position.set(t.x, t.y, t.z);
				dummy.rotation.set(t.rx, t.ry, t.rz);
				dummy.scale.set(t.sx, t.sy, t.sz);
				dummy.updateMatrix();
				m.setMatrixAt(i, dummy.matrix);
				col.setRGB(t.c[0], t.c[1], t.c[2]);
				m.setColorAt(i, col);
			}
			m.instanceMatrix.needsUpdate = true;
			if (m.instanceColor) m.instanceColor.needsUpdate = true;
			m.castShadow = cast;
			m.receiveShadow = true;
			m.name = name;
			g.add(m);
			return m;
		};
		makeInst(geoMed, med, 'rocks-boulder', true);
		makeInst(geoSmall, small, 'rocks-small', false);
		makeInst(geoPeb, peb, 'rocks-pebble', false);
		return g;
	}

	// ------------------------------------------------------------------
	// height field is pure (layout only) —publish early so water/props and
	// offline QA tools can sample it even if the mesh build fails.
	// ------------------------------------------------------------------
	H._t1 = {
		height: terrainHeight,
		slope: terrainSlope,
		coastQuery,
		zoneWeights,
		seabed: SEABED,
		rim: RIM,
		plinth: PLINTH_R,
	};

	// ------------------------------------------------------------------
	// module registration
	// ------------------------------------------------------------------
	H.register('terrain', {
		create(ctx) {
			const t0 = performance.now();
			const g = ctx.group('terrain');
			const M = ctx.materials;
			// textures
			const tex = {
				wood: makeWoodTextures(),
				strata: makeStrataTexture(),
				resin: makeResinTexture(),
				nameplate: makeNameplateTexture(),
			};
			const tTex = performance.now();
			const terrainMat = makeTerrainMaterial(M);
			// boulders get their own shader variant: matte, warm, no specular dots
			const rocksMat = makeTerrainMaterial(M, { key: 'rocks', rockRough: 0.96, detail: 0.22, env: 0.3 });
			// builds
			const plinth = buildPlinth(ctx, g, tex);
			const terrain = buildTerrainMesh(ctx, g, terrainMat);
			const tMesh = performance.now();
			buildRimWall(ctx, g, terrain, terrainMat, tex);
			buildCoastCliff(ctx, g, tex);
			const resin = buildResinSea(ctx, g, terrain, tex);
			buildRocks(ctx, g, rocksMat);
			// height field is published at module scope (HARBOR._t1)
			if (resin.wall) resin.wall.userData.noReflect = true;
			console.log(
				'[terrain] built in ' +
					Math.round(performance.now() - t0) +
					'ms (tex ' +
					Math.round(tTex - t0) +
					', mesh ' +
					Math.round(tMesh - tTex) +
					', dressing ' +
					Math.round(performance.now() - tMesh) +
					')'
			);
			return {
				update() {},
			};
		},
	});
})(window.HARBOR);
