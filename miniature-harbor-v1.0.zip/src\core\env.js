/**
 * env.js — sky, sun/moon, time of day, fog and image based lighting.
 * ==================================================================
 * The whole scene answers to one clock: env.setHour(h) (0..24) moves the
 * sun, recolours the sky and water, changes fog and exposure, and fires
 * onEnv listeners so world modules can switch their night lights on.
 *
 * Exposed:
 *   H.env.init(ctx)
 *   H.env.setHour(h)          set time of day
 *   H.env.hour                current hour
 *   H.env.state               { hour, night, sunDir, moonDir, ... }
 *   H.env.onEnv(cb)           cb(state) whenever the light changes
 *   H.env.update(dt)
 *   H.env.sunLight / fillLight / hemiLight
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const clamp = U.clamp;
	const lerp = U.lerp;

	// ------------------------------------------------------------------
	// key frames: colours are authored in sRGB hex, interpolated in linear
	// ------------------------------------------------------------------
	const KEYS = [
		{ h: 0.0, zenith: '#0b1730', horizon: '#1d3150', ground: '#0a0b0e', sun: '#a9c6ff', sunI: 0.6, hemiSky: '#22314d', hemiGround: '#0b0d12', hemiI: 0.72, fog: '#101b2b', fogD: 0.008, night: 1.0, exposure: 1.3, envI: 0.62, sunSize: 0.0 },
		{ h: 4.3, zenith: '#0c1832', horizon: '#203452', ground: '#0a0b0e', sun: '#a9c6ff', sunI: 0.55, hemiSky: '#243350', hemiGround: '#0b0d12', hemiI: 0.72, fog: '#111c2c', fogD: 0.0085, night: 1.0, exposure: 1.3, envI: 0.62, sunSize: 0.0 },
		{ h: 5.5, zenith: '#1d2c4a', horizon: '#6a5468', ground: '#0d0e11', sun: '#ffb27a', sunI: 0.35, hemiSky: '#3d4d6b', hemiGround: '#241c18', hemiI: 0.55, fog: '#3e3a4c', fogD: 0.0095, night: 0.82, exposure: 1.16, envI: 0.55, sunSize: 0.35 },
		{ h: 6.4, zenith: '#3e6f9f', horizon: '#ffbe86', ground: '#171717', sun: '#ffb072', sunI: 2.2, hemiSky: '#a9c1dd', hemiGround: '#5a4a3a', hemiI: 0.95, fog: '#e3c4a6', fogD: 0.008, night: 0.12, exposure: 1.06, envI: 0.95, sunSize: 1.0 },
		{ h: 8.2, zenith: '#3f7fbe', horizon: '#d3e5ea', ground: '#1b1b19', sun: '#fff0d4', sunI: 3.0, hemiSky: '#c6ddf0', hemiGround: '#736c58', hemiI: 1.1, fog: '#d6e4e8', fogD: 0.0068, night: 0.0, exposure: 1.0, envI: 1.12, sunSize: 1.0 },
		{ h: 12.5, zenith: '#2e7bc0', horizon: '#d9ecf2', ground: '#1c1c1a', sun: '#fff7e8', sunI: 4.1, hemiSky: '#cfe6f7', hemiGround: '#7b7460', hemiI: 0.92, fog: '#d6e6ee', fogD: 0.0042, night: 0.0, exposure: 0.94, envI: 1.06, sunSize: 1.0 },
		{ h: 15.4, zenith: '#3d80b8', horizon: '#e9e2cb', ground: '#1b1a18', sun: '#ffefcd', sunI: 3.7, hemiSky: '#c9dced', hemiGround: '#7a6f56', hemiI: 0.92, fog: '#e3e1d0', fogD: 0.0062, night: 0.0, exposure: 1.0, envI: 1.15, sunSize: 1.0 },
		{ h: 17.35, zenith: '#35688f', horizon: '#ffc27a', ground: '#2a231c', sun: '#ffc077', sunI: 5.2, hemiSky: '#a7bfd4', hemiGround: '#7c6146', hemiI: 0.70, fog: '#e3bd92', fogD: 0.0042, night: 0.03, exposure: 1.02, envI: 0.84, sunSize: 1.15 },
		{ h: 18.55, zenith: '#2f4a74', horizon: '#ff9358', ground: '#241a15', sun: '#ff8b4a', sunI: 2.9, hemiSky: '#8b9ac0', hemiGround: '#5c3e30', hemiI: 0.68, fog: '#e5a07a', fogD: 0.0078, night: 0.28, exposure: 1.06, envI: 0.8, sunSize: 1.1 },
		{ h: 19.5, zenith: '#22355a', horizon: '#a86668', ground: '#101010', sun: '#e0794c', sunI: 0.7, hemiSky: '#4a5a7d', hemiGround: '#261d18', hemiI: 0.55, fog: '#7d5055', fogD: 0.0102, night: 0.66, exposure: 1.12, envI: 0.6, sunSize: 0.6 },
		{ h: 20.6, zenith: '#131f3a', horizon: '#453a52', ground: '#0c0c10', sun: '#b9c9ff', sunI: 0.6, hemiSky: '#2b3853', hemiGround: '#131116', hemiI: 0.66, fog: '#1c1d2b', fogD: 0.0095, night: 0.9, exposure: 1.24, envI: 0.6, sunSize: 0.15 },
		{ h: 22.0, zenith: '#0b1730', horizon: '#1d3150', ground: '#0a0b0e', sun: '#a9c6ff', sunI: 0.6, hemiSky: '#22314d', hemiGround: '#0b0d12', hemiI: 0.72, fog: '#101b2b', fogD: 0.008, night: 1.0, exposure: 1.3, envI: 0.62, sunSize: 0.0 },
		{ h: 24.0, zenith: '#0b1730', horizon: '#1d3150', ground: '#0a0b0e', sun: '#a9c6ff', sunI: 0.6, hemiSky: '#22314d', hemiGround: '#0b0d12', hemiI: 0.72, fog: '#101b2b', fogD: 0.008, night: 1.0, exposure: 1.3, envI: 0.62, sunSize: 0.0 },
	];
	// precompute colours once
	for (const k of KEYS) {
		for (const prop of ['zenith', 'horizon', 'ground', 'sun', 'hemiSky', 'hemiGround', 'fog']) {
			k[prop + 'C'] = new THREE.Color(k[prop]);
		}
	}

	function sampleKeys(hour) {
		const h = ((hour % 24) + 24) % 24;
		let a = KEYS[0],
			b = KEYS[KEYS.length - 1];
		for (let i = 0; i < KEYS.length - 1; i++) {
			if (h >= KEYS[i].h && h <= KEYS[i + 1].h) {
				a = KEYS[i];
				b = KEYS[i + 1];
				break;
			}
		}
		const t = U.smoothstep(a.h, b.h, h);
		const out = { hour: h };
		const num = (p) => lerp(a[p], b[p], t);
		for (const prop of ['zenith', 'horizon', 'ground', 'sun', 'hemiSky', 'hemiGround', 'fog']) {
			out[prop] = a[prop + 'C'].clone().lerp(b[prop + 'C'], t);
		}
		out.sunI = num('sunI');
		out.hemiI = num('hemiI');
		out.fogD = num('fogD');
		out.night = num('night');
		out.exposure = num('exposure');
		out.envI = num('envI');
		out.sunSize = num('sunSize');
		return out;
	}

	// ------------------------------------------------------------------
	// sun / moon directions
	// ------------------------------------------------------------------
	const _sunDir = new THREE.Vector3();
	const _moonDir = new THREE.Vector3();
	function celestial(hour, out) {
		// day arc: sunrise 06:00 east (+x), noon high in the south (+z)
		const t = (hour - 6) / 12;
		const th = Math.PI * t;
		out.set(Math.cos(th), Math.sin(th) * 0.92, 0.4 + 0.25 * Math.sin(th));
		out.normalize();
		return out;
	}
	function sunDirection(hour, out = _sunDir) {
		return celestial(hour, out);
	}
	function moonDirection(hour, out = _moonDir) {
		return celestial(((hour + 12) % 24), out);
	}

	// ------------------------------------------------------------------
	// sky shader
	// ------------------------------------------------------------------
	const SKY_VERT = `
		varying vec3 vWorldDir;
		void main() {
			vec4 wp = modelMatrix * vec4(position, 1.0);
			vWorldDir = wp.xyz;
			gl_Position = projectionMatrix * viewMatrix * wp;
		}
	`;
	const SKY_FRAG = `
		uniform vec3 uZenith;
		uniform vec3 uHorizon;
		uniform vec3 uGround;
		uniform vec3 uSunColor;
		uniform vec3 uSunDir;
		uniform float uSunSize;
		uniform float uNight;
		uniform float uMoonGlow;
		varying vec3 vWorldDir;

		float hash21(vec2 p) {
			p = fract(p * vec2(123.34, 456.21));
			p += dot(p, p + 45.32);
			return fract(p.x * p.y);
		}

		void main() {
			vec3 dir = normalize(vWorldDir);
			float h = dir.y;
			// sky gradient (pow curve keeps the horizon band tight)
			vec3 sky = mix(uHorizon, uZenith, pow(clamp(h, 0.0, 1.0), 0.52));
			// Below the horizon: a soft, warm photographic haze curtain. The
			// diorama floats in a bright studio sweep at golden hour; the
			// curtain is slightly dimmed so the model still pops.
			vec3 below = uGround + uHorizon * (0.105 * exp(-max(-h, 0.0) * 4.0));
			sky = mix(below, sky * 0.9, smoothstep(-0.26, 0.04, h));
			// warm scattering around the sun
			float sd = max(dot(dir, uSunDir), 0.0);
			sky += uSunColor * pow(sd, 5.0) * 0.10 * uSunSize;
			sky += uSunColor * pow(sd, 40.0) * 0.22 * uSunSize;
			// sun disc
			float disc = smoothstep(0.99955, 0.99985, sd);
			sky += uSunColor * disc * 26.0 * uSunSize;
			// horizon warm band on the sun side
			float band = exp(-abs(h) * 16.0) * pow(max(dot(normalize(vec3(dir.x, 0.0, dir.z)), normalize(vec3(uSunDir.x, 0.0, uSunDir.z))), 0.0), 2.0);
			sky += uSunColor * band * 0.16 * uSunSize;
			// stars
			if (uNight > 0.02) {
				vec2 sp = vec2(atan(dir.z, dir.x), asin(clamp(dir.y, -1.0, 1.0)));
				vec2 cell = floor(sp * vec2(140.0, 90.0));
				float star = hash21(cell);
				float spark = smoothstep(0.9955, 1.0, star) * smoothstep(0.02, 0.25, h);
				float twinkle = 0.65 + 0.35 * sin(star * 500.0 + uSunDir.x * 12.0);
				sky += vec3(0.85, 0.92, 1.0) * spark * twinkle * uNight * 1.8;
			}
			gl_FragColor = vec4(sky, 1.0);
		}
	`;

	// ------------------------------------------------------------------
	// module state
	// ------------------------------------------------------------------
	const listeners = [];
	const state = {
		hour: 17.35,
		night: 0,
		sunDir: new THREE.Vector3(0, 1, 0),
		moonDir: new THREE.Vector3(0, 1, 0),
		sunLightDir: new THREE.Vector3(0, 1, 0),
		colors: null,
		sunI: 0,
		hemiI: 0,
		fogD: 0,
		exposure: 1,
		envI: 1,
	};

	let ctx = null;
	let skyMat = null;
	let envScene = null;
	let pmrem = null;
	let envRT = null;
	let sunLight = null;
	let hemiLight = null;
	let fillLight = null;
	let stars = null;
	let moonSprite = null;
	let sunSprite = null;
	let lastEnvHour = -999;
	let envDirty = true;
	let envCooldown = 0;

	function makeGlowTexture(inner, outer) {
		const c = U.createCanvas(128);
		const g = c.getContext('2d');
		const grad = g.createRadialGradient(64, 64, 0, 64, 64, 64);
		grad.addColorStop(0, inner);
		grad.addColorStop(0.35, outer);
		grad.addColorStop(1, 'rgba(255,255,255,0)');
		g.fillStyle = grad;
		g.fillRect(0, 0, 128, 128);
		return U.canvasTex(c, { srgb: true });
	}

	function init(c) {
		ctx = c;
		const scene = c.scene;

		// sky dome
		skyMat = new THREE.ShaderMaterial({
			uniforms: {
				uZenith: { value: new THREE.Color('#2e7bc0') },
				uHorizon: { value: new THREE.Color('#d9ecf2') },
				uGround: { value: new THREE.Color('#6e6a5c') },
				uSunColor: { value: new THREE.Color('#fff7e8') },
				uSunDir: { value: sunDirection(state.hour) },
				uSunSize: { value: 1 },
				uNight: { value: 0 },
				uMoonGlow: { value: 0 },
			},
			vertexShader: SKY_VERT,
			fragmentShader: SKY_FRAG,
			side: THREE.BackSide,
			depthWrite: false,
			fog: false,
			toneMapped: false,
		});
		const sky = new THREE.Mesh(new THREE.SphereGeometry(400, 48, 32), skyMat);
		sky.name = 'sky';
		sky.frustumCulled = false;
		sky.renderOrder = -100;
		scene.add(sky);

		// lights
		sunLight = new THREE.DirectionalLight(0xffffff, 3);
		sunLight.castShadow = true;
		sunLight.shadow.mapSize.set(2048, 2048);
		const sc = sunLight.shadow.camera;
		sc.left = -17;
		sc.right = 17;
		sc.top = 17;
		sc.bottom = -17;
		sc.near = 2;
		sc.far = 90;
		sunLight.shadow.bias = -0.0016;
		sunLight.shadow.normalBias = 0.022;
		sunLight.shadow.radius = 3;
		sunLight.target.position.set(0, 0, 0);
		scene.add(sunLight);
		scene.add(sunLight.target);

		// ---- museum display floor: a dark matte disc that floats the
		// diorama against the void and catches the long golden shadow ----
		const floorC = U.createCanvas(512);
		const fctx = floorC.getContext('2d');
		const fg = fctx.createRadialGradient(256, 256, 20, 256, 256, 256);
		fg.addColorStop(0, '#1b1c21');
		fg.addColorStop(0.26, '#111216');
		fg.addColorStop(0.6, '#08090c');
		fg.addColorStop(1, '#040406');
		fctx.fillStyle = fg;
		fctx.fillRect(0, 0, 512, 512);
		const floorTex = U.canvasTex(floorC, { srgb: true });
		floorTex.wrapS = floorTex.wrapT = THREE.ClampToEdgeWrapping;
		const floorMat = new THREE.MeshStandardMaterial({ map: floorTex, color: 0xffffff, roughness: 0.6, metalness: 0.12 });
		const displayFloor = new THREE.Mesh(new THREE.CircleGeometry(58, 96), floorMat);
		displayFloor.rotation.x = -Math.PI / 2;
		displayFloor.position.y = -2.47;
		displayFloor.receiveShadow = true;
		displayFloor.name = 'display-floor';
		// The floor is intentionally disabled: the diorama reads better as a
		// floating museum piece against the dark void. Kept here (hidden) so
		// the lighting rig / shadow catcher can be re-enabled with one line.
		displayFloor.visible = false;
		scene.add(displayFloor);

		// subtle warm rim light from behind the diorama (studio backlight)
		const rimLight = new THREE.DirectionalLight(0xffb478, 0.42);
		rimLight.position.set(-24, 11, -30);
		rimLight.target.position.set(0, 1.5, 0);
		scene.add(rimLight);
		scene.add(rimLight.target);
		state.rimLight = rimLight;

		hemiLight = new THREE.HemisphereLight(0xcfe6f7, 0x7b7460, 1.0);
		scene.add(hemiLight);

		// soft sky-fill from the seaward side: keeps the golden-hour shadow
		// side readable without flattening the key light
		fillLight = new THREE.DirectionalLight(0xb9cbe4, 0.32);
		fillLight.position.set(26, 10, 16);
		fillLight.target.position.set(0, 1.2, 0);
		scene.add(fillLight);
		scene.add(fillLight.target);

		// stars
		const starGeo = new THREE.BufferGeometry();
		const starCount = 2200;
		const pos = new Float32Array(starCount * 3);
		const col = new Float32Array(starCount * 3);
		const r = U.rng(4242);
		for (let i = 0; i < starCount; i++) {
			const theta = r.range(0, Math.PI * 2);
			const y = r.range(0.03, 1);
			const rr = Math.sqrt(1 - y * y);
			pos[i * 3] = Math.cos(theta) * rr * 360;
			pos[i * 3 + 1] = y * 360;
			pos[i * 3 + 2] = Math.sin(theta) * rr * 360;
			const tint = r.range(0.72, 1.0);
			col[i * 3] = tint;
			col[i * 3 + 1] = tint * r.range(0.9, 1.0);
			col[i * 3 + 2] = 1.0;
		}
		starGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
		starGeo.setAttribute('color', new THREE.BufferAttribute(col, 3));
		const starMat = new THREE.PointsMaterial({
			size: 2.1,
			sizeAttenuation: false,
			transparent: true,
			opacity: 0,
			vertexColors: true,
			depthWrite: false,
			fog: false,
			blending: THREE.AdditiveBlending,
			toneMapped: false,
		});
		stars = new THREE.Points(starGeo, starMat);
		stars.name = 'stars';
		stars.frustumCulled = false;
		stars.renderOrder = -90;
		scene.add(stars);

		// moon billboard
		const moonMat = new THREE.SpriteMaterial({
			map: makeGlowTexture('rgba(255,255,255,1)', 'rgba(200,220,255,0.55)'),
			transparent: true,
			depthWrite: false,
			fog: false,
			blending: THREE.AdditiveBlending,
			toneMapped: false,
			opacity: 0,
		});
		moonSprite = new THREE.Sprite(moonMat);
		moonSprite.scale.setScalar(34);
		moonSprite.frustumCulled = false;
		moonSprite.renderOrder = -80;
		scene.add(moonSprite);

		// sun billboard (soft glow, tiny disc handled by sky shader)
		const sunMat = new THREE.SpriteMaterial({
			map: makeGlowTexture('rgba(255,240,210,1)', 'rgba(255,180,110,0.35)'),
			transparent: true,
			depthWrite: false,
			fog: false,
			blending: THREE.AdditiveBlending,
			toneMapped: false,
			opacity: 0.9,
		});
		sunSprite = new THREE.Sprite(sunMat);
		sunSprite.scale.setScalar(70);
		sunSprite.frustumCulled = false;
		sunSprite.renderOrder = -85;
		scene.add(sunSprite);

		// environment scene for PMREM (sky + dark ground bounce)
		envScene = new THREE.Scene();
		const envSky = new THREE.Mesh(new THREE.SphereGeometry(300, 32, 24), skyMat);
		envScene.add(envSky);
		const envGround = new THREE.Mesh(
			new THREE.CircleGeometry(280, 48).rotateX(-Math.PI / 2),
			new THREE.MeshBasicMaterial({ color: 0x3a352c, toneMapped: false })
		);
		envGround.position.y = -1.5;
		envScene.add(envGround);

		pmrem = new THREE.PMREMGenerator(c.renderer);
		pmrem.compileEquirectangularShader();

		scene.fog = new THREE.FogExp2(0xdde6ea, 0.006);
		setHour(state.hour, true);
		refreshEnvironment(true);
	}

	function refreshEnvironment(force = false) {
		if (!force && (state.hour === lastEnvHour || envCooldown > 0)) return;
		lastEnvHour = state.hour;
		envCooldown = 0.16;
		try {
			const rt = pmrem.fromScene(envScene, 0.035, 0.5, 500);
			if (envRT) envRT.dispose();
			envRT = rt;
			ctx.scene.environment = rt.texture;
			ctx.scene.environmentIntensity = state.envI;
		} catch (err) {
			console.warn('[env] PMREM failed', err);
		}
	}

	function notify() {
		for (const cb of listeners) {
			try {
				cb(state);
			} catch (err) {
				console.error('[env] listener failed', err);
			}
		}
	}

	function setHour(h, silent = false) {
		state.hour = ((h % 24) + 24) % 24;
		const k = sampleKeys(state.hour);
		state.night = k.night;
		state.colors = k;
		state.sunI = k.sunI;
		state.hemiI = k.hemiI;
		state.fogD = k.fogD;
		state.exposure = k.exposure;
		state.envI = k.envI;
		const sunDir = sunDirection(state.hour);
		const moonDir = moonDirection(state.hour);
		state.sunDir.copy(sunDir);
		state.moonDir.copy(moonDir);

		// light: sun by day, moon by night. Both fade through zero at the
		// swap so the change is invisible.
		const dayDir = k.night < 0.55 ? sunDir : moonDir;
		state.sunLightDir.copy(dayDir);
		sunLight.position.copy(dayDir).multiplyScalar(55);
		sunLight.target.position.set(0, 0.5, 1);
		const moonMix = U.smoothstep(0.25, 0.95, k.night);
		sunLight.color.copy(k.sun);
		sunLight.intensity = k.sunI * (1 - moonMix) + (0.6 + 0.8 * k.night) * moonMix;
		hemiLight.color.copy(k.hemiSky);
		hemiLight.groundColor.copy(k.hemiGround);
		hemiLight.intensity = k.hemiI;
		if (fillLight) {
			fillLight.intensity = 0.3 + 0.16 * (1 - k.night) - k.night * 0.14;
			fillLight.color.copy(k.hemiSky).lerp(new THREE.Color(0xffd6ae), 0.18);
		}
		if (state.rimLight) state.rimLight.intensity = 0.3 + 0.22 * (1 - k.night) - k.night * 0.12;
		if (state.rimLight) state.rimLight.color.copy(k.sun).lerp(new THREE.Color(0x9fb6de), 0.45);

		if (skyMat) {
			const u = skyMat.uniforms;
			u.uZenith.value.copy(k.zenith);
			u.uHorizon.value.copy(k.horizon);
			u.uGround.value.copy(k.ground);
			u.uSunColor.value.copy(k.sun);
			u.uSunDir.value.copy(sunDir);
			u.uSunSize.value = k.sunSize;
			u.uNight.value = k.night;
		}
		if (ctx) {
			ctx.scene.fog.color.copy(k.fog);
			ctx.scene.fog.density = k.fogD;
			ctx.renderer.toneMappingExposure = k.exposure;
			if (ctx.scene.environmentIntensity !== undefined) ctx.scene.environmentIntensity = k.envI;
		}
		if (stars) stars.material.opacity = U.smoothstep(0.12, 0.85, k.night);
		if (moonSprite) {
			const md = moonDirection(state.hour).clone().multiplyScalar(300);
			moonSprite.position.copy(md);
			moonSprite.material.opacity = U.smoothstep(0.3, 0.95, k.night) * 0.95;
			const s = 26 + (1 - k.night) * 8;
			moonSprite.scale.setScalar(s);
		}
		if (sunSprite) {
			const sd = sunDirection(state.hour).clone().multiplyScalar(320);
			sunSprite.position.copy(sd);
			sunSprite.material.opacity = k.sunSize * 0.85;
			sunSprite.material.color.copy(k.sun).multiplyScalar(0.6);
		}
		envDirty = true;
		if (!silent) notify();
	}

	function update(dt) {
		envCooldown = Math.max(0, envCooldown - dt);
		if (envDirty && envCooldown <= 0) {
			envDirty = false;
			refreshEnvironment();
		}
		// very slow celestial drift? keep static: the slider owns the sky.
	}

	H.env = {
		init,
		setHour,
		hour: () => state.hour,
		state,
		onEnv: (cb) => {
			listeners.push(cb);
			try {
				cb(state);
			} catch (err) {
				console.error('[env] listener failed', err);
			}
			return () => {
				const i = listeners.indexOf(cb);
				if (i >= 0) listeners.splice(i, 1);
			};
		},
		update,
		sunDirection,
		moonDirection,
		get sunLight() {
			return sunLight;
		},
		get hemiLight() {
			return hemiLight;
		},
		get skyMaterial() {
			return skyMat;
		},
		refreshEnvironment: () => refreshEnvironment(true),
	};
})(window.HARBOR);
