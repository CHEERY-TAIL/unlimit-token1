/**
 * shoot-daemon.mjs  (v2 — crash resilient)
 * ------------------------------------------------------------------
 * Long-lived visual QA service for the miniature harbor project.
 *
 * Why a daemon: this Windows sandbox blocks named-pipe / child-process
 * spawning, so Chrome cannot start under restricted permissions. This
 * process is launched ONCE with full access, then stays alive and serves
 * every screenshot request from all agents (and from the Lead).
 *
 * It does two jobs:
 *   1. Serves the project over http://127.0.0.1:17321  (static files)
 *   2. Drives headless Chrome through playwright-core
 *
 * v2 hardening:
 *   - page crash / browser disconnect detection and automatic recovery
 *   - page recycled every N requests (GPU context hygiene)
 *   - per-request hard timeout, ALWAYS writes qa/results/<id>.json
 *   - absolute URLs pass through (file:// offline verification)
 *   - continuous heartbeat in qa/daemon-status.json
 *
 * Request protocol (file based, no sockets to coordinate):
 *   write  qa/requests/<anything>.json
 *   read   qa/results/<id>.json     (status + captured console errors)
 *   image  qa/shots/<id>.png
 *
 * Request fields:
 *   id         required, unique string (also image name)
 *   url        page path relative to project root, OR absolute URL
 *              (e.g. file:///D:/.../index.html) — default /index.html
 *   width      default 1600
 *   height     default 1000
 *   wait       extra settle ms after page ready, default 1000
 *   ready      expression to wait for, default "window.__HARBOR_READY__ === true"
 *   timeout    total ms budget, default 60000
 *   js         string evaluated in page before settling (can be async)
 *   jsfile     file (root relative) whose contents are evaluated instead of js
 *   out        output png path (root relative), default qa/shots/<id>.png
 *   selector   optional CSS selector to screenshot instead of viewport
 *   hideUI     bool, adds ?ui=0 to the url
 *
 * Usage: node tools/shoot-daemon.mjs
 * Stop:  write qa/STOP  (or job_kill the background job)
 */
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import url from 'node:url';
import zlib from 'node:zlib';
import { chromium } from 'playwright-core';

// ------------------------------------------------------------------
// minimal PNG encoder (RGBA, filter 0). Used to write pixels that we
// read straight out of the WebGL framebuffer with gl.readPixels —
// this bypasses Chrome's GPU tile readback entirely and never produces
// the famous black rectangles.
// ------------------------------------------------------------------
const CRC_TABLE = (() => {
	const t = new Int32Array(256);
	for (let n = 0; n < 256; n++) {
		let c = n;
		for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
		t[n] = c;
	}
	return t;
})();
function crc32(buf) {
	let c = -1;
	for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
	return (c ^ -1) >>> 0;
}
function pngChunk(type, data) {
	const len = Buffer.alloc(4);
	len.writeUInt32BE(data.length, 0);
	const typeBuf = Buffer.from(type, 'ascii');
	const crcBuf = Buffer.alloc(4);
	crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
	return Buffer.concat([len, typeBuf, data, crcBuf]);
}
function encodePNG(width, height, rgba, flip = false) {
	const stride = width * 4;
	const raw = Buffer.alloc((stride + 1) * height);
	for (let y = 0; y < height; y++) {
		const srcY = flip ? height - 1 - y : y;
		raw[y * (stride + 1)] = 0; // filter: none
		rgba.copy(raw, y * (stride + 1) + 1, srcY * stride, srcY * stride + stride);
	}
	const ihdr = Buffer.alloc(13);
	ihdr.writeUInt32BE(width, 0);
	ihdr.writeUInt32BE(height, 4);
	ihdr[8] = 8; // bit depth
	ihdr[9] = 6; // color type RGBA
	ihdr[10] = 0;
	ihdr[11] = 0;
	ihdr[12] = 0;
	const sig = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
	return Buffer.concat([sig, pngChunk('IHDR', ihdr), pngChunk('IDAT', zlib.deflateSync(raw, { level: 6 })), pngChunk('IEND', Buffer.alloc(0))]);
}

const ROOT = path.resolve(path.dirname(url.fileURLToPath(import.meta.url)), '..');
const QA = path.join(ROOT, 'qa');
const REQ_DIR = path.join(QA, 'requests');
const RES_DIR = path.join(QA, 'results');
const SHOT_DIR = path.join(QA, 'shots');
const LOG_DIR = path.join(QA, 'logs');
const STOP_FILE = path.join(QA, 'STOP');
const HEARTBEAT = path.join(QA, 'daemon-status.json');
const SERVER_LOG = path.join(QA, 'server.log');

const PORT = Number(process.env.HARBOR_PORT || 17321);
const CHROME =
	process.env.HARBOR_CHROME ||
	'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';

const PAGE_RECYCLE_EVERY = 18;
const REQUEST_HARD_TIMEOUT = 90000;
const READY_TIMEOUT = 25000;

for (const d of [REQ_DIR, RES_DIR, SHOT_DIR, LOG_DIR]) fs.mkdirSync(d, { recursive: true });
if (fs.existsSync(STOP_FILE)) fs.rmSync(STOP_FILE, { force: true });
// clear stale requests from a previous daemon so nobody waits on ghosts
try {
	for (const f of fs.readdirSync(REQ_DIR)) {
		if (!f.endsWith('.json')) continue;
		const p = path.join(REQ_DIR, f);
		const age = Date.now() - fs.statSync(p).mtimeMs;
		if (age > 120000) fs.rmSync(p, { force: true });
	}
} catch {}

const MIME = {
	'.html': 'text/html; charset=utf-8',
	'.js': 'text/javascript; charset=utf-8',
	'.mjs': 'text/javascript; charset=utf-8',
	'.css': 'text/css; charset=utf-8',
	'.json': 'application/json; charset=utf-8',
	'.png': 'image/png',
	'.jpg': 'image/jpeg',
	'.jpeg': 'image/jpeg',
	'.webp': 'image/webp',
	'.svg': 'image/svg+xml',
	'.glb': 'model/gltf-binary',
	'.gltf': 'model/gltf+json',
	'.hdr': 'application/octet-stream',
	'.bin': 'application/octet-stream',
	'.woff2': 'font/woff2',
	'.ico': 'image/x-icon',
	'.map': 'application/json; charset=utf-8',
};

const server = http.createServer((req, res) => {
	try {
		const parsed = url.parse(req.url || '/');
		let pathname = decodeURIComponent(parsed.pathname || '/');
		if (pathname === '/') pathname = '/index.html';
		if (pathname === '/__health') {
			res.writeHead(200, { 'content-type': 'application/json' }).end(JSON.stringify({ ok: true, ts: Date.now(), processed }));
			return;
		}
		const abs = path.resolve(ROOT, '.' + pathname);
		if (!abs.startsWith(ROOT)) {
			res.writeHead(403).end('forbidden');
			return;
		}
		if (!fs.existsSync(abs) || fs.statSync(abs).isDirectory()) {
			res.writeHead(404).end('not found: ' + pathname);
			return;
		}
		const type = MIME[path.extname(abs).toLowerCase()] || 'application/octet-stream';
		const data = fs.readFileSync(abs);
		res.writeHead(200, { 'content-type': type, 'cache-control': 'no-store', 'access-control-allow-origin': '*' }).end(data);
	} catch (err) {
		try {
			res.writeHead(500).end(String(err && err.message));
		} catch {}
	}
});

function log(...args) {
	const line = `[${new Date().toISOString()}] ${args.join(' ')}`;
	console.log(line);
	try {
		fs.appendFileSync(SERVER_LOG, line + '\n');
	} catch {}
}

function writeHeartbeat(state, extra = {}) {
	try {
		fs.writeFileSync(HEARTBEAT, JSON.stringify({ state, ts: Date.now(), pid: process.pid, port: PORT, ...extra }));
	} catch {}
}

async function launchBrowser() {
	const attempts = [
		{ name: 'gpu-default', args: ['--hide-scrollbars', '--force-color-profile=srgb', '--enable-unsafe-swiftshader'] },
		{
			name: 'swiftshader',
			args: ['--hide-scrollbars', '--force-color-profile=srgb', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-gpu-sandbox'],
		},
	];
	let lastErr;
	for (const attempt of attempts) {
		try {
			const browser = await chromium.launch({ executablePath: CHROME, headless: true, args: attempt.args, timeout: 30000 });
			log(`browser launched (${attempt.name})`);
			return browser;
		} catch (err) {
			lastErr = err;
			log(`browser launch failed (${attempt.name}): ${err.message}`);
		}
	}
	throw lastErr;
}

// ------------------------------------------------------------------
// browser / page lifecycle
// ------------------------------------------------------------------
let browser = null;
let context = null;
let page = null;
let pageBroken = false;
let processed = 0;
let sinceRecycle = 0;

async function newPage() {
	if (context) await context.close().catch(() => {});
	if (browser && !browser.isConnected()) {
		log('browser disconnected, relaunching');
		browser = await launchBrowser();
	}
	context = await browser.newContext({
		viewport: { width: 1600, height: 1000 },
		deviceScaleFactor: 1,
		colorScheme: 'light',
	});
	page = await context.newPage();
	pageBroken = false;
	page.on('crash', () => {
		log('PAGE CRASHED');
		pageBroken = true;
	});
	page.on('close', () => {
		pageBroken = true;
	});
	await page.goto(`http://127.0.0.1:${PORT}/qa/_probe/probe.html`, { waitUntil: 'load', timeout: 20000 }).catch(() => {});
	sinceRecycle = 0;
}

async function ensurePage() {
	if (!browser || !browser.isConnected()) {
		browser = await launchBrowser();
		page = null;
	}
	if (!page || page.isClosed() || pageBroken || sinceRecycle >= PAGE_RECYCLE_EVERY) {
		log('(re)creating page');
		await newPage();
	}
}

// ------------------------------------------------------------------
// request processing
// ------------------------------------------------------------------
async function applyRequest(req) {
	const consoleBuffer = [];
	const pageErrors = [];
	const onConsole = (msg) => {
		if (consoleBuffer.length < 300) consoleBuffer.push(`[${msg.type()}] ${msg.text()}`);
	};
	const onPageError = (err) => pageErrors.push(String(err && err.stack ? err.stack : err));

	page.on('console', onConsole);
	page.on('pageerror', onPageError);
	const t0 = Date.now();
	let ready = false;
	let phase = 'navigate';
	try {
		const viewport = { width: Math.round(req.width || 1600), height: Math.round(req.height || 1000) };
		await page.setViewportSize(viewport);

		let target = req.url || '/index.html';
		if (req.hideUI && !/[?&]ui=0/.test(target)) target += (target.includes('?') ? '&' : '?') + 'ui=0';
		const full = /^[a-z][a-z0-9+.-]*:\/\//i.test(target)
			? target
			: `http://127.0.0.1:${PORT}${target.startsWith('/') ? '' : '/'}${target}`;

		await page.goto(full, { waitUntil: 'load', timeout: Math.min(req.timeout || 60000, 45000) });

		phase = 'ready';
		const readyExpr = req.ready || 'window.__HARBOR_READY__ === true';
		try {
			await page.waitForFunction(readyExpr, null, { timeout: Math.min(req.timeout || 60000, READY_TIMEOUT) });
			ready = true;
		} catch (err) {
			log(`[${req.id}] not ready: ${String(err.message).split('\n')[0]}`);
		}

		phase = 'eval';
		if (req.js || req.jsfile) {
			let code = req.js || '';
			if (req.jsfile) code = fs.readFileSync(path.resolve(ROOT, req.jsfile), 'utf8');
			try {
				await page.evaluate(code);
			} catch (err) {
				pageErrors.push('JS EVAL ERROR: ' + (err && err.message ? err.message : String(err)));
				log(`[${req.id}] js eval failed: ${err.message}`);
			}
		}

		phase = 'settle';
		await page.waitForTimeout(Math.max(0, Math.round(req.wait != null ? req.wait : 1000)));
		await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)))).catch(() => {});

		phase = 'capture';
		const out = path.resolve(ROOT, req.out || `qa/shots/${req.id}.png`);
		fs.mkdirSync(path.dirname(out), { recursive: true });
		const captureMode = req.capture || 'canvas';
		let imageWritten = false;
		let uiImage = null;

		// (a) exact framebuffer pixels via gl.readPixels — avoids headless
		//     Chrome's un-composited canvas tiles (black rectangles)
		if (captureMode === 'canvas' || captureMode === 'both') {
			try {
				const shot = await page.evaluate(() => {
					const H = window.HARBOR;
					try {
						if (H && H.render && H.render.render) H.render.render(0, H.state ? H.state.time : 12);
					} catch (err) {}
					const c = document.querySelector('#stage');
					if (!c) return null;
					const gl = c.getContext('webgl2', { preserveDrawingBuffer: true }) || c.getContext('webgl', { preserveDrawingBuffer: true });
					if (!gl) return null;
					const w = c.width,
						h = c.height;
					const pixels = new Uint8Array(w * h * 4);
					gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
					const chunk = 0x8000;
					let binary = '';
					for (let i = 0; i < pixels.length; i += chunk) {
						binary += String.fromCharCode.apply(null, pixels.subarray(i, i + chunk));
					}
					let b64;
					try {
						b64 = btoa(binary);
					} catch (err) {
						return null;
					}
					return { w, h, b64 };
				});
				if (shot && shot.b64) {
					const buf = Buffer.from(shot.b64, 'base64');
					if (buf.length === shot.w * shot.h * 4) {
						fs.writeFileSync(out, encodePNG(shot.w, shot.h, buf, true));
						imageWritten = true;
					} else {
						log(`[${req.id}] readPixels size mismatch ${buf.length} vs ${shot.w * shot.h * 4}`);
					}
				}
				if (!imageWritten) {
					// fallback: canvas.toDataURL (may occasionally show tile artifacts)
					const dataUrl = await page.evaluate(() => {
						const c = document.querySelector('#stage');
						try {
							return c ? c.toDataURL('image/png') : null;
						} catch (err) {
							return null;
						}
					});
					if (dataUrl && dataUrl.startsWith('data:image/png;base64,')) {
						fs.writeFileSync(out, Buffer.from(dataUrl.slice(dataUrl.indexOf(',') + 1), 'base64'));
						imageWritten = true;
					}
				}
				if (!imageWritten) log(`[${req.id}] pixel capture unavailable, falling back to page screenshot`);
			} catch (err) {
				log(`[${req.id}] pixel capture failed: ${err.message}`);
			}
		}

		// (b) DOM/UI layer capture: hide the WebGL canvas so we get the pure
		//     HUD with a transparent background (composite later if wanted)
		if (captureMode === 'both' || captureMode === 'ui') {
			try {
				uiImage = out.replace(/\.png$/i, '') + '.ui.png';
				await page.evaluate(() => {
					const c = document.querySelector('#stage');
					if (c) c.style.visibility = 'hidden';
					document.documentElement.style.background = 'transparent';
					document.body.style.background = 'transparent';
				});
				await page.waitForTimeout(120);
				await page.screenshot({ path: uiImage, omitBackground: true, timeout: 15000 });
				await page.evaluate(() => {
					const c = document.querySelector('#stage');
					if (c) c.style.visibility = '';
					document.documentElement.style.background = '';
					document.body.style.background = '';
				});
				uiImage = path.relative(ROOT, uiImage).replace(/\\/g, '/');
			} catch (err) {
				log(`[${req.id}] ui capture failed: ${err.message}`);
				uiImage = null;
			}
		}

		// (c) legacy full page capture (includes UI, may show canvas tile artifacts)
		if (!imageWritten && captureMode !== 'none') {
			await page.screenshot({ path: out, timeout: 20000 });
			imageWritten = true;
		}
		if (req.selector) {
			const el = await page.$(req.selector);
			if (el) await el.screenshot({ path: out });
		}

		// let the render loop settle after the (synchronous) pixel readback so
		// the reported fps/draw-call diagnostics reflect steady-state rendering
		await page.waitForTimeout(650).catch(() => {});
		const diag = await page.evaluate(() => (window.__harborDiagnostics ? window.__harborDiagnostics() : null)).catch(() => null);
		processed++;
		return {
			ok: true,
			ready,
			elapsed: Date.now() - t0,
			image: path.relative(ROOT, out).replace(/\\/g, '/'),
			uiImage,
			capture: captureMode,
			pageErrors,
			console: consoleBuffer.slice(),
			diagnostics: diag,
		};
	} catch (err) {
		const msg = err && err.message ? err.message : String(err);
		log(`[${req.id}] ERROR during ${phase}: ${msg.split('\n')[0]}`);
		try {
			const out = path.resolve(ROOT, req.out || `qa/shots/${req.id}.png`);
			fs.mkdirSync(path.dirname(out), { recursive: true });
			await page.screenshot({ path: out, timeout: 12000 });
		} catch {}
		if (pageBroken) {
			try {
				await newPage();
			} catch (e) {
				log('page recovery failed: ' + e.message);
			}
		}
		return {
			ok: false,
			ready,
			error: `[${phase}] ${msg}`,
			elapsed: Date.now() - t0,
			image: `qa/shots/${req.id}.png`,
			pageErrors,
			console: consoleBuffer.slice(),
		};
	} finally {
		try {
			page.off('console', onConsole);
			page.off('pageerror', onPageError);
		} catch {}
	}
}

async function processRequest(req) {
	const t0 = Date.now();
	let result;
	try {
		const work = applyRequest(req);
		const watchdog = new Promise((resolve) => setTimeout(() => resolve({ __timeout: true }), REQUEST_HARD_TIMEOUT));
		const raced = await Promise.race([work, watchdog]);
		if (raced && raced.__timeout) {
			log(`[${req.id}] HARD TIMEOUT after ${REQUEST_HARD_TIMEOUT}ms, recycling page`);
			pageBroken = true;
			try {
				await newPage();
			} catch (err) {
				log('recovery after timeout failed: ' + err.message);
			}
			result = { ok: false, error: `hard timeout after ${REQUEST_HARD_TIMEOUT}ms`, image: `qa/shots/${req.id}.png`, console: [], pageErrors: [] };
		} else {
			result = raced;
		}
	} catch (err) {
		result = { ok: false, error: String(err && err.message ? err.message : err), console: [], pageErrors: [] };
	}
	result.id = req.id;
	result.ts = Date.now();
	result.ms = Date.now() - t0;
	try {
		fs.writeFileSync(path.join(RES_DIR, req.id + '.json'), JSON.stringify(result, null, 2));
	} catch (err) {
		log('failed to write result: ' + err.message);
	}
	try {
		fs.writeFileSync(path.join(LOG_DIR, req.id + '.log'), (result.console || []).join('\n') + '\n');
	} catch {}
	sinceRecycle++;
	return result;
}

function claimRequests() {
	const out = [];
	let files = [];
	try {
		files = fs
			.readdirSync(REQ_DIR)
			.filter((f) => f.endsWith('.json'))
			.map((f) => {
				const p = path.join(REQ_DIR, f);
				let mtime = 0;
				try {
					mtime = fs.statSync(p).mtimeMs;
				} catch {}
				return { f, p, mtime };
			})
			.sort((a, b) => a.mtime - b.mtime);
	} catch (err) {
		log('request scan failed: ' + err.message);
		return out;
	}
	for (const item of files) {
		let req = null;
		try {
			req = JSON.parse(fs.readFileSync(item.p, 'utf8'));
		} catch (err) {
			try {
				fs.rmSync(item.p, { force: true });
			} catch {}
			continue;
		}
		try {
			fs.rmSync(item.p, { force: true });
		} catch {}
		if (req && req.id) out.push(req);
	}
	return out;
}

async function main() {
	log('daemon v2 starting, root=' + ROOT);
	await new Promise((resolve, reject) => {
		server.once('error', reject);
		server.listen(PORT, '127.0.0.1', resolve);
	});
	log(`static server http://127.0.0.1:${PORT}`);
	writeHeartbeat('starting');
	browser = await launchBrowser();
	await ensurePage();
	writeHeartbeat('running');
	log('daemon ready');

	let lastBeat = 0;
	while (!fs.existsSync(STOP_FILE)) {
		const pending = claimRequests();
		for (const req of pending) {
			if (fs.existsSync(STOP_FILE)) break;
			req.id = String(req.id).replace(/[^A-Za-z0-9_.-]/g, '_');
			log(`request ${req.id} -> ${req.url || '/index.html'}`);
			try {
				await ensurePage();
				const result = await processRequest(req);
				log(`done ${req.id} ok=${!!result.ok} in ${result.ms}ms`);
				writeHeartbeat('running', { processed, last: req.id, lastOk: !!result.ok, queue: 0 });
			} catch (err) {
				log(`request ${req.id} failed hard: ${err && err.stack ? err.stack : err}`);
			}
			lastBeat = 0;
		}
		const now = Date.now();
		if (now - lastBeat > 1000) {
			lastBeat = now;
			writeHeartbeat('running', { processed });
		}
		await new Promise((r) => setTimeout(r, 220));
	}

	log('STOP file seen, shutting down');
	writeHeartbeat('stopping');
	await context?.close().catch(() => {});
	await browser?.close().catch(() => {});
	server.close();
	writeHeartbeat('stopped');
	process.exit(0);
}

main().catch(async (err) => {
	log('FATAL ' + (err && err.stack ? err.stack : err));
	writeHeartbeat('crashed', { error: String(err && err.message ? err.message : err) });
	process.exit(1);
});
