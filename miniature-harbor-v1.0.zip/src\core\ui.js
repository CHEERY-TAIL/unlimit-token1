/**
 * ui.js — the brass-and-glass HUD over the diorama.
 * ==================================================================
 * Wires the static markup in index.html to the engine:
 *   - loader progress
 *   - view buttons / captions
 *   - time slider / hour readout
 *   - quality segments
 *   - auto-rotate, reset, screenshot, fullscreen
 *   - keyboard shortcuts, mobile hint, error badge
 */
(function (H) {
	'use strict';
	const U = H.util;

	const els = {};
	let api = null;
	let initialized = false;
	let captionTimer = 0;
	let currentView = 'overview';
	let hourValue = 17.35;
	let lastErrorCount = 0;

	function $(id) {
		return document.getElementById(id);
	}

	function init(opts) {
		if (initialized) return;
		initialized = true;
		api = {
			env: opts.env,
			render: opts.render,
			camera: opts.camera,
			state: opts.state,
			params: opts.params || {},
			layout: opts.layout,
		};
		els.fill = $('loader-fill');
		els.label = $('loader-label');
		els.views = $('view-buttons');
		els.caption = $('view-caption');
		els.captionCn = els.caption ? els.caption.querySelector('.caption-cn') : null;
		els.captionEn = els.caption ? els.caption.querySelector('.caption-en') : null;
		els.rotate = $('btn-rotate');
		els.time = $('time-range');
		els.hour = $('hour-value');
		els.qualitySeg = $('quality-seg');
		els.reset = $('btn-reset');
		els.shot = $('btn-shot');
		els.full = $('btn-full');
		els.hint = document.querySelector('#hud-bottom .hint');
		els.statFps = $('stat-fps');
		els.statCalls = $('stat-calls');
		els.statTris = $('stat-tris');
		els.errorChip = $('error-chip');
		els.errorCount = $('error-count');
		buildViewButtons();
		bindEvents();
		updateHour(api.env.hour());
		if (api.params.ui === false) document.body.classList.add('ui-hidden');
	}

	function buildViewButtons() {
		if (!els.views) return;
		const views = api.layout.VIEWS;
		els.views.innerHTML = '';
		Object.keys(views).forEach((key) => {
			if (!views[key].label) return;
			const b = document.createElement('button');
			b.className = 'view-btn';
			b.dataset.view = key;
			b.textContent = views[key].label;
			b.title = `${views[key].label} / ${views[key].labelEn}`;
			b.addEventListener('click', () => {
				if (H.app && H.app.setView) H.app.setView(key);
			});
			els.views.appendChild(b);
		});
		setViewButton('overview');
	}

	function setViewButton(name) {
		if (!els.views) return;
		for (const b of els.views.children) b.classList.toggle('active', b.dataset.view === name);
	}

	function showCaption(name) {
		if (!els.caption) return;
		const view = api.layout.VIEWS[name];
		if (!view) return;
		els.captionCn.textContent = view.label;
		els.captionEn.textContent = view.labelEn;
		els.caption.classList.add('show');
		clearTimeout(captionTimer);
		captionTimer = setTimeout(() => els.caption.classList.remove('show'), 2000);
	}

	function pad2(n) {
		return n < 10 ? '0' + n : '' + n;
	}
	function fmtHour(h) {
		const hh = Math.floor(((h % 24) + 24) % 24);
		const mm = Math.round((((h % 24) + 24) % 24 - hh) * 60);
		return `${pad2(hh)}:${pad2(mm === 60 ? 0 : mm)}`;
	}

	function updateHour(h) {
		hourValue = h;
		if (els.time) els.time.value = String(h);
		if (els.hour) els.hour.textContent = fmtHour(h);
	}

	function setProgress(p, label) {
		if (els.fill) els.fill.style.width = Math.round(U.clamp(p) * 100) + '%';
		if (els.label && label) {
			const names = {
				terrain: '正在抬高海岸台地…',
				water: '正在注入海水…',
				quay: '正在浇筑码头…',
				industrial: '正在吊装集装箱…',
				lighthouse: '正在点亮灯塔…',
				town: '正在盖起老城…',
				street: '正在铺石板路…',
				vessels: '正在放船入港…',
				props: '正在摆放货物…',
				atmosphere: '正在放飞海鸥…',
				sky: '正在调配黄昏…',
				lighting: '正在打光…',
				ready: '完成',
			};
			els.label.textContent = names[label] || `正在装配 ${label}…`;
		}
	}

	function setReady() {
		document.body.classList.add('harbor-ready');
		if (els.fill) els.fill.style.width = '100%';
	}

	function setStats(info) {
		if (!info) return;
		if (els.statFps) els.statFps.textContent = String(Math.round(info.fps || 0));
		const st = info.stats || {};
		if (els.statCalls) els.statCalls.textContent = String(st.calls || 0);
		if (els.statTris) {
			const tris = st.triangles || 0;
			els.statTris.textContent = tris >= 1e6 ? (tris / 1e6).toFixed(2) + 'M' : tris >= 1000 ? (tris / 1000).toFixed(0) + 'K' : String(tris);
		}
		const ec = info.errors || 0;
		if (els.errorChip) {
			els.errorChip.hidden = ec === 0;
			if (els.errorCount) els.errorCount.textContent = String(ec);
			if (ec !== lastErrorCount) {
				lastErrorCount = ec;
				console.warn(`[ui] ${ec} module errors reported`);
			}
		}
	}

	function setHour(h) {
		updateHour(h);
	}

	function setQuality(q) {
		if (!els.qualitySeg) return;
		for (const b of els.qualitySeg.querySelectorAll('button')) b.classList.toggle('active', b.dataset.q === q);
	}

	function setAutoRotate(on) {
		if (els.rotate) els.rotate.classList.toggle('on', !!on);
	}

	function setView(name) {
		currentView = name;
		setViewButton(name);
		showCaption(name);
	}

	function showError(module, err) {
		if (!els.errorChip) return;
		els.errorChip.hidden = false;
		if (els.errorCount) els.errorCount.textContent = String((parseInt(els.errorCount.textContent || '0', 10) || 0) + 1);
		console.error(`[ui] module ${module} error:`, err);
	}

	function toggleUI() {
		document.body.classList.toggle('ui-hidden');
		api.state.uiVisible = !document.body.classList.contains('ui-hidden');
		try {
			localStorage.setItem('harbor.uiHidden', api.state.uiVisible ? '0' : '1');
		} catch (e) {}
	}

	function screenshot() {
		try {
			const url = H.app.capture();
			const a = document.createElement('a');
			const d = new Date();
			const stamp = `${d.getFullYear()}${pad2(d.getMonth() + 1)}${pad2(d.getDate())}-${pad2(d.getHours())}${pad2(d.getMinutes())}${pad2(d.getSeconds())}`;
			a.href = url;
			a.download = `miniature-harbor-${stamp}.png`;
			document.body.appendChild(a);
			a.click();
			a.remove();
			flashHint('已保存截图 · screenshot saved');
		} catch (err) {
			console.error('[ui] screenshot failed', err);
			flashHint('截图失败 · screenshot failed');
		}
	}

	function flashHint(text) {
		if (!els.hint) return;
		const original = els.hint.innerHTML;
		els.hint.innerHTML = text;
		setTimeout(() => {
			if (els.hint) els.hint.innerHTML = original;
		}, 1800);
	}

	function bindEvents() {
		if (els.time) {
			els.time.addEventListener('input', () => {
				const h = parseFloat(els.time.value);
				if (H.app && H.app.setHour) H.app.setHour(h);
				else api.env.setHour(h);
				updateHour(h);
			});
		}
		if (els.rotate) {
			els.rotate.addEventListener('click', () => {
				const on = !api.camera.autoRotate;
				if (H.app && H.app.setAutoRotate) H.app.setAutoRotate(on);
				else api.camera.setAutoRotate(on);
			});
		}
		if (els.reset) {
			els.reset.addEventListener('click', () => {
				if (H.app && H.app.setView) H.app.setView('overview');
				else api.camera.setView('overview');
			});
		}
		if (els.shot) els.shot.addEventListener('click', screenshot);
		if (els.full) {
			els.full.addEventListener('click', () => {
				if (!document.fullscreenElement) {
					document.documentElement.requestFullscreen && document.documentElement.requestFullscreen().catch(() => {});
				} else {
					document.exitFullscreen && document.exitFullscreen().catch(() => {});
				}
			});
		}
		if (els.qualitySeg) {
			els.qualitySeg.addEventListener('click', (e) => {
				const b = e.target.closest('button[data-q]');
				if (!b) return;
				if (H.app && H.app.setQuality) H.app.setQuality(b.dataset.q);
			});
		}
		if (els.errorChip) {
			els.errorChip.addEventListener('click', () => {
				if (!H.app) return;
				const diag = H.app.diagnostics();
				console.table(diag.errors);
				flashHint(diag.errors.length ? '错误已输出到 console' : '没有模块错误');
			});
		}

		// camera state -> UI
		H.camera.onChange((info) => {
			setAutoRotate(info.autoRotate);
			if (info.view && info.view !== currentView) setView(info.view);
		});

		// keyboard
		const viewKeys = Object.keys(api.layout.VIEWS);
		window.addEventListener('keydown', (e) => {
			if (e.target && /input|select|textarea/i.test(e.target.tagName)) return;
			const k = e.key.toLowerCase();
			if (k >= '1' && k <= '9') {
				const idx = parseInt(k, 10) - 1;
				if (idx < viewKeys.length && H.app) H.app.setView(viewKeys[idx]);
			} else if (k === 'a') {
				if (H.app) H.app.setAutoRotate(!api.camera.autoRotate);
			} else if (k === 'r') {
				if (H.app) H.app.setView('overview');
			} else if (k === 'h') {
				toggleUI();
			} else if (k === 's') {
				screenshot();
			} else if (k === 'f') {
				if (els.full) els.full.click();
			}
		});
	}

	H.ui = {
		init,
		setProgress,
		setReady,
		setStats,
		setHour,
		setQuality,
		setAutoRotate,
		setView,
		showError,
		toggleUI,
		screenshot,
	};
})(window.HARBOR);
