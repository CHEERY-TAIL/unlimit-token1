/**
 * 40-vessels.js — THE HARBOUR FLEET.
 * ==================================================================
 * OWNER: vessels-props teammate.
 *
 * Every boat is moored to HARBOR.layout.berths (pos / heading / side) or
 * anchored in the outer harbour. Hulls are lofted from station tables so
 * they have a real sheer line, rocker, raked stem and transom — no boxes.
 *
 * Performance contract: each boat is merged into at most 4 draw calls
 * (paint / glass / canvas / glow) using one vertex-colour material, so
 * the whole fleet stays around 60 draw calls. Prototypes are built once
 * and cloned per berth (scaled uniformly to the berth length).
 *
 * Animation: gentle bob + roll + pitch, staggered frequencies; offshore
 * boats swing more. Night: cabin / porthole warm glow, masthead lights
 * and blinking buoys, driven by ctx.env.state.night every frame.
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const L = H.layout;
	const P = U.PALETTE;

	// ==================================================================
	// small helpers
	// ==================================================================
	function tableSample(tbl, t) {
		if (t <= tbl[0][0]) return tbl[0][1];
		const n = tbl.length;
		if (t >= tbl[n - 1][0]) return tbl[n - 1][1];
		for (let i = 1; i < n; i++) {
			if (t <= tbl[i][0]) {
				const a = tbl[i - 1],
					b = tbl[i];
				const u = U.smoothstep(a[0], b[0], t);
				return a[1] + (b[1] - a[1]) * u;
			}
		}
		return tbl[n - 1][1];
	}

	function hash3(x, y, z) {
		const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
		return s - Math.floor(s);
	}

	/** bake a flat colour into a geometry's vertex colours (drops uv) */
	function tintGeo(geo, color, jitter) {
		// glow geometry is uncoloured (the emissive material owns the colour)
		if (color == null) color = '#ffffff';
		if (geo.index) geo = geo.toNonIndexed();
		if (geo.attributes.uv) geo.deleteAttribute('uv');
		if (geo.attributes.uv1) geo.deleteAttribute('uv1');
		const posAttr = geo.attributes.position;
		const n = posAttr.count;
		const arr = new Float32Array(n * 3);
		const c = color.isColor ? color : new THREE.Color(color);
		const px = posAttr.array;
		for (let i = 0; i < n; i++) {
			let k = 1;
			if (jitter) k = 1 + (hash3(px[i * 3] * 3.1, px[i * 3 + 1] * 3.3, px[i * 3 + 2] * 3.7) - 0.5) * jitter;
			arr[i * 3] = c.r * k;
			arr[i * 3 + 1] = c.g * k;
			arr[i * 3 + 2] = c.b * k;
		}
		geo.setAttribute('color', new THREE.BufferAttribute(arr, 3));
		return geo;
	}

	function mergedMesh(geos, mat, name, cast, receive) {
		if (!geos || !geos.length) return null;
		let geo = geos.length === 1 ? geos[0] : U.merge(geos);
		if (!geo) {
			console.warn('[vessels] geometry merge failed for ' + name);
			return null;
		}
		const mesh = new THREE.Mesh(geo, mat);
		mesh.name = name;
		mesh.castShadow = !!cast;
		mesh.receiveShadow = !!receive;
		return mesh;
	}

	// ==================================================================
	// Paint — collects colour-baked primitives, merged into one mesh
	// ==================================================================
	function Paint() {
		this.geos = [];
	}
	Paint.prototype.raw = function (geo, color, jitter) {
		this.geos.push(tintGeo(geo, color, jitter));
		return this;
	};
	Paint.prototype.box = function (w, h, d, x, y, z, color, rot, jitter) {
		const g = new THREE.BoxGeometry(w, h, d);
		if (rot) {
			if (rot[0]) g.rotateX(rot[0]);
			if (rot[1]) g.rotateY(rot[1]);
			if (rot[2]) g.rotateZ(rot[2]);
		}
		g.translate(x, y, z);
		return this.raw(g, color, jitter);
	};
	Paint.prototype.cyl = function (rt, rb, h, seg, x, y, z, color, rot, jitter) {
		const g = new THREE.CylinderGeometry(rt, rb, h, seg, 1, false);
		if (rot) {
			if (rot[0]) g.rotateX(rot[0]);
			if (rot[1]) g.rotateY(rot[1]);
			if (rot[2]) g.rotateZ(rot[2]);
		}
		g.translate(x, y, z);
		return this.raw(g, color, jitter);
	};
	Paint.prototype.sphere = function (r, x, y, z, color, scale, jitter) {
		const g = new THREE.SphereGeometry(r, 7, 5);
		if (scale) g.scale(scale[0], scale[1], scale[2]);
		g.translate(x, y, z);
		return this.raw(g, color, jitter);
	};
	Paint.prototype.torus = function (r, tube, x, y, z, color, rot, arc) {
		const g = new THREE.TorusGeometry(r, tube, 5, 14, arc != null ? arc : Math.PI * 2);
		if (rot) {
			if (rot[0]) g.rotateX(rot[0]);
			if (rot[1]) g.rotateY(rot[1]);
			if (rot[2]) g.rotateZ(rot[2]);
		}
		g.translate(x, y, z);
		return this.raw(g, color);
	};
	Paint.prototype.tube = function (pts, radius, color, radialSeg) {
		const curve = new THREE.CatmullRomCurve3(pts);
		const g = new THREE.TubeGeometry(curve, Math.max(5, pts.length * 2), radius, radialSeg || 3, false);
		return this.raw(g, color);
	};
	Paint.prototype.geo = function (g, color, jitter) {
		return this.raw(g, color, jitter);
	};

	// ==================================================================
	// lofted hull geometry (hull sides + deck + transom + stem, one mesh)
	// ==================================================================
	const WIDTH_TBL = [
		[0, 0.7],
		[0.1, 0.87],
		[0.26, 0.96],
		[0.45, 1.0],
		[0.64, 0.97],
		[0.8, 0.87],
		[0.9, 0.62],
		[0.97, 0.3],
		[1, 0.035],
	];
	const SHEER_TBL = [
		[0, 0.82],
		[0.12, 0.75],
		[0.32, 0.64],
		[0.56, 0.6],
		[0.76, 0.68],
		[0.9, 0.84],
		[1, 1.0],
	];
	const KEEL_TBL = [
		[0, 0.58],
		[0.08, 0.82],
		[0.2, 0.95],
		[0.42, 1.0],
		[0.66, 1.0],
		[0.83, 0.9],
		[0.94, 0.66],
		[1, 0.42],
	];
	const POW_TBL = [
		[0, 0.95],
		[0.2, 0.64],
		[0.45, 0.54],
		[0.68, 0.7],
		[0.86, 1.05],
		[1, 1.45],
	];

	function hullGeometry(o) {
		const len = o.len;
		const beam = o.beam;
		const free = o.free;
		const draft = o.draft;
		const NS = o.stations || 16;
		const NV = o.levels || 9;
		const widthTbl = o.widthTbl || WIDTH_TBL;
		const sheerTbl = o.sheerTbl || SHEER_TBL;
		const keelTbl = o.keelTbl || KEEL_TBL;
		const powTbl = o.powTbl || POW_TBL;
		const bowRake = o.bowRake != null ? o.bowRake : 0.055;
		const sternRake = o.sternRake != null ? o.sternRake : 0.025;
		const camber = o.camber != null ? o.camber : 0.012;
		const deckWidth = o.deckWidth != null ? o.deckWidth : 0.985;
		const bootY = o.bootY != null ? o.bootY : 0.02;
		const cHull = new THREE.Color(o.hull);
		const cBottom = new THREE.Color(o.bottom || '#6b3226');
		const cBoot = new THREE.Color(o.boot || '#9a4b33');
		const cDeck = new THREE.Color(o.deck || P.woodLight);
		const tmpC = new THREE.Color();

		const stations = [];
		for (let i = 0; i <= NS; i++) {
			const t = i / NS;
			stations.push({
				t,
				hw: (beam / 2) * tableSample(widthTbl, t),
				deckY: free * tableSample(sheerTbl, t),
				keelY: -draft * tableSample(keelTbl, t),
				pw: tableSample(powTbl, t),
				z: -len / 2 + t * len,
				bowShift: bowRake * len * U.smoothstep(0.7, 1, t),
				sternShift: sternRake * len * U.smoothstep(0.3, 0, t),
			});
		}

		const pos = [];
		const col = [];
		const idx = [];
		function pushSideVert(x, y, z, t) {
			pos.push(x, y, z);
			if (y < bootY - 0.016) tmpC.copy(cBottom);
			else if (y < bootY + 0.02) tmpC.copy(cBoot);
			else tmpC.copy(cHull);
			const k = 0.93 + 0.07 * U.noise2(z * 5.1 + t * 2.3, y * 7.7, 3) + (hash3(z * 21, y * 17, t * 9) - 0.5) * 0.05;
			col.push(tmpC.r * k, tmpC.g * k, tmpC.b * k);
		}

		const star = [];
		const port = [];
		for (let i = 0; i <= NS; i++) {
			const st = stations[i];
			const sa = [];
			const pa = [];
			for (let j = 0; j <= NV; j++) {
				const v = j / NV;
				const y = st.keelY + (st.deckY - st.keelY) * v;
				const x = st.hw * Math.pow(v, st.pw);
				const z = st.z - (1 - v) * st.bowShift + (1 - v) * st.sternShift;
				sa.push(pos.length / 3);
				pushSideVert(x, y, z, st.t);
				pa.push(pos.length / 3);
				pushSideVert(-x, y, z, st.t);
			}
			star.push(sa);
			port.push(pa);
		}

		for (let i = 0; i < NS; i++) {
			for (let j = 0; j < NV; j++) {
				let A = star[i][j],
					B = star[i + 1][j],
					C = star[i][j + 1],
					D = star[i + 1][j + 1];
				idx.push(A, C, B, B, C, D);
				A = port[i][j];
				B = port[i + 1][j];
				C = port[i][j + 1];
				D = port[i + 1][j + 1];
				idx.push(A, B, C, B, D, C);
			}
		}
		// transom (-z) and stem cap (+z)
		for (let j = 0; j < NV; j++) {
			let A = star[0][j],
				B = port[0][j],
				C = star[0][j + 1],
				D = port[0][j + 1];
			idx.push(A, B, C, B, D, C);
			A = star[NS][j];
			B = port[NS][j];
			C = star[NS][j + 1];
			D = port[NS][j + 1];
			idx.push(A, C, B, B, C, D);
		}

		// deck (cambered, follows the sheer line)
		const ND = 4;
		const deckStart = pos.length / 3;
		for (let i = 0; i <= NS; i++) {
			const st = stations[i];
			for (let j = 0; j <= ND; j++) {
				const u = -1 + (2 * j) / ND;
				const x = u * st.hw * deckWidth;
				const y = st.deckY + camber * (1 - u * u);
				const z = st.z;
				pos.push(x, y, z);
				const k = 0.9 + 0.1 * hash3(x * 9.1, z * 13.7, 0.5) + 0.05 * u * u;
				col.push(cDeck.r * k, cDeck.g * k, cDeck.b * k);
			}
		}
		for (let i = 0; i < NS; i++) {
			for (let j = 0; j < ND; j++) {
				const A = deckStart + i * (ND + 1) + j;
				const B = A + 1;
				const C = deckStart + (i + 1) * (ND + 1) + j;
				const D = C + 1;
				idx.push(A, C, B, B, C, D);
			}
		}

		const geo = new THREE.BufferGeometry();
		geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
		geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
		geo.setIndex(idx);
		geo.computeVertexNormals();

		return {
			geo,
			len,
			beam,
			free,
			draft,
			NS,
			stations,
			hwAt: (t) => (beam / 2) * tableSample(widthTbl, t),
			deckYAt: (t) => free * tableSample(sheerTbl, t),
			zAt: (t) => -len / 2 + t * len,
		};
	}

	// ==================================================================
	// kit — one boat's four merged buckets
	// ==================================================================
	function BoatKit() {
		this.paint = new Paint();
		this.glass = new Paint();
		this.soft = new Paint();
		this.glow = new Paint();
	}
	BoatKit.prototype.finish = function (MAT, group, cast) {
		const a = mergedMesh(this.paint.geos, MAT.paint, 'paint', cast, true);
		if (a) group.add(a);
		const b = mergedMesh(this.glass.geos, MAT.glass, 'glass', false, false);
		if (b) group.add(b);
		if (this.soft.geos.length) {
			const c = mergedMesh(this.soft.geos, MAT.canvas, 'canvas', false, false);
			if (c) group.add(c);
		}
		if (this.glow.geos.length) {
			const d = mergedMesh(this.glow.geos, MAT.glow, 'glow', false, false);
			if (d) group.add(d);
		}
		return group;
	};

	// ==================================================================
	// generic boat details
	// ==================================================================
	function gunwale(kit, hull, o) {		o = o || {};
		const n = Math.min(hull.NS, o.segs || hull.NS);
		const bul = o.bulwark || 0;
		const bCol = o.bulwarkColor || o.color || '#efe2c9';
		const rCol = o.railColor || '#4e3726';
		for (let side = -1; side <= 1; side += 2) {
			for (let i = 0; i < n; i++) {
				const t0 = i / n;
				const t1 = (i + 1) / n;
				const x0 = side * hull.hwAt(t0);
				const x1 = side * hull.hwAt(t1);
				const y0 = hull.deckYAt(t0);
				const y1 = hull.deckYAt(t1);
				const z0 = hull.zAt(t0);
				const z1 = hull.zAt(t1);
				const mx = (x0 + x1) / 2;
				const my = (y0 + y1) / 2;
				const mz = (z0 + z1) / 2;
				const dx = x1 - x0;
				const dz = z1 - z0;
				const seg = Math.hypot(dx, dz);
				if (seg < 0.004) continue;
				const ang = Math.atan2(dx, dz);
				if (bul) kit.paint.box(0.018, bul, seg * 1.05, mx, my + bul / 2, mz, bCol, [0, ang, 0]);
				kit.paint.box(o.w || 0.034, o.h || 0.012, seg * 1.05, mx, my + bul + 0.005, mz, rCol, [0, ang, 0]);
			}
		}
	}

	/** crisp painted band following the hull side at a given local height —
	 *  this is the boot-top / antifouling waterline stripe. */
	function hullBand(kit, hull, color, y, height) {
		const NS = hull.NS;
		for (let side = -1; side <= 1; side += 2) {
			for (let i = 0; i < NS; i++) {
				const t0 = i / NS;
				const t1 = (i + 1) / NS;
				const st0 = hull.stations[i];
				const st1 = hull.stations[i + 1];
				const v0 = U.clamp((y - st0.keelY) / (st0.deckY - st0.keelY || 1e-6), 0.02, 0.98);
				const v1 = U.clamp((y - st1.keelY) / (st1.deckY - st1.keelY || 1e-6), 0.02, 0.98);
				const x0 = side * (st0.hw * Math.pow(v0, st0.pw) + 0.0035);
				const x1 = side * (st1.hw * Math.pow(v1, st1.pw) + 0.0035);
				if (Math.abs(x0) < 0.01 && Math.abs(x1) < 0.01) continue;
				const z0 = st0.z - (1 - v0) * st0.bowShift + (1 - v0) * st0.sternShift;
				const z1 = st1.z - (1 - v1) * st1.bowShift + (1 - v1) * st1.sternShift;
				const mx = (x0 + x1) / 2;
				const mz = (z0 + z1) / 2;
				const seg = Math.hypot(x1 - x0, z1 - z0);
				if (seg < 0.004) continue;
				kit.paint.box(0.006, height, seg * 1.06, mx, y, mz, color, [0, Math.atan2(x1 - x0, z1 - z0), 0]);
			}
		}
	}

	/** brass-rimmed portholes along both hull sides */
	function portholes(kit, hull, t0, t1, n, yFrac) {
		for (let i = 0; i < n; i++) {
			const t = t0 + ((t1 - t0) * (i + 0.5)) / n;
			const deckY = hull.deckYAt(t);
			const hw = hull.hwAt(t) * 0.995;
			const y = deckY * (yFrac != null ? yFrac : 0.55);
			for (const side of [-1, 1]) {
				const x = side * (hw + 0.002);
				kit.paint.torus(0.012, 0.003, x, y, hull.zAt(t), '#c8a24b', [0, (side * Math.PI) / 2, 0]);
				kit.glass.cyl(0.008, 0.008, 0.004, 8, x + side * 0.002, y, hull.zAt(t), '#3a4a52', [0, 0, Math.PI / 2]);
				kit.glow.sphere(0.005, x + side * 0.003, y, hull.zAt(t));
			}
		}
	}

	/** masthead pennant / small flag */
	function pennant(kit, hull, t, height, color) {
		const z = hull.zAt(t);
		const y = hull.deckYAt(t) + height;
		kit.soft.box(0.004, 0.05, 0.14, 0, y - 0.03, z - 0.075, color, [0, 0, 0]);
		kit.soft.box(0.004, 0.028, 0.05, 0.012, y - 0.045, z - 0.05, color, [0, 0, 0]);
	}

	function railRun(kit, hull, o) {
		o = o || {};
		const h = o.h != null ? o.h : 0.07;
		const color = o.color || '#6d767d';
		const step = o.step || 2;
		for (let side = -1; side <= 1; side += 2) {
			const pts = [];
			for (let i = 1; i < hull.NS; i++) {
				const t = i / hull.NS;
				const x = side * hull.hwAt(t) * 0.985;
				const y = hull.deckYAt(t) + h + (o.dy ? o.dy(t) : 0);
				pts.push(new THREE.Vector3(x, y, hull.zAt(t)));
			}
			if (pts.length > 2) kit.paint.tube(pts, 0.0035, color, 3);
			for (let i = 1; i < hull.NS - 1; i += step) {
				const t = i / hull.NS;
				const x = side * hull.hwAt(t) * 0.985;
				const y = hull.deckYAt(t);
				kit.paint.box(0.006, h, 0.006, x, y + h / 2, hull.zAt(t), color);
			}
		}
		// bow pulpit cross bar
		if (o.bowBar) {
			kit.paint.box(o.bowBar, 0.006, 0.006, 0, hull.deckYAt(0.995) + h, hull.zAt(0.995), color);
		}
	}

	function wheelhouse(kit, o) {
		const w = o.w,
			h = o.h,
			d = o.d,
			x = o.x || 0,
			zb = o.z,
			y0 = o.y;
		const color = o.color || '#f4efe3';
		kit.paint.box(w, h, d, x, y0 + h / 2, zb, color);
		// raked front window band + side windows
		kit.glass.box(w * 0.8, h * 0.26, 0.008, x, y0 + h * 0.7, zb + d / 2, o.glass || '#3a4a52');
		kit.glass.box(0.008, h * 0.24, d * 0.52, x + w / 2, y0 + h * 0.7, zb, o.glass || '#3a4a52');
		kit.glass.box(0.008, h * 0.24, d * 0.52, x - w / 2, y0 + h * 0.7, zb, o.glass || '#3a4a52');
		// roof overhang + hand rail
		kit.paint.box(w * 1.14, 0.02, d * 1.1, x, y0 + h + 0.01, zb, o.roof || '#f4efe3');
		kit.paint.box(w * 1.14, 0.006, 0.006, x, y0 + h + 0.035, zb - d * 0.55, '#6d767d');
		// warm interior glow (night)
		kit.glow.box(w * 0.7, h * 0.19, 0.005, x, y0 + h * 0.7, zb + d / 2 + 0.008);
		kit.glow.box(0.004, h * 0.17, d * 0.42, x + w / 2 + 0.004, y0 + h * 0.7, zb);
		kit.glow.box(0.004, h * 0.17, d * 0.42, x - w / 2 - 0.004, y0 + h * 0.7, zb);
		// door
		if (o.door !== false) kit.paint.box(0.03, h * 0.6, 0.008, x + w * 0.24, y0 + h * 0.3, zb + d / 2 + 0.002, o.doorColor || '#7c5a3c');
	}

	function lifeRing(kit, x, y, z, rotY) {
		kit.paint.torus(0.03, 0.008, x, y, z, '#e8e2d2', [0, rotY || 0, 0]);
		const r = 0.03;
		for (let i = 0; i < 4; i++) {
			const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
			kit.paint.box(0.016, 0.012, 0.008, x + Math.cos(a) * r, y + Math.sin(a) * r, z + 0.001, '#b3453b', [0, rotY || 0, 0]);
		}
	}

	function fenderRow(kit, hull, side, n, kind) {
		for (let i = 0; i < n; i++) {
			const t = 0.28 + (0.52 * i) / Math.max(1, n - 1);
			const hw = hull.hwAt(t);
			const y = hull.deckYAt(t);
			const z = hull.zAt(t);
			const x = side * (hw + 0.01);
			if (kind === 'tire') {
				kit.paint.torus(0.026, 0.01, x, y * 0.45 - 0.01, z, '#2b2b2c', [0, (side * Math.PI) / 2, 0]);
			} else {
				kit.paint.cyl(0.012, 0.012, 0.062, 6, x, y * 0.5, z, '#b9ac96', [0, 0, side * 0.16]);
			}
		}
	}

	function mast(kit, hull, o) {
		o = o || {};
		const t = o.t != null ? o.t : 0.7;
		const h = o.h || hull.len * 0.55;
		const z = hull.zAt(t);
		const y0 = hull.deckYAt(t);
		const color = o.color || '#5b4028';
		kit.paint.cyl(o.rTop || 0.006, o.rBot || 0.011, h, 6, 0, y0 + h / 2, z, color);
		if (o.yard) kit.paint.box(hull.beam * 0.4, 0.008, 0.008, 0, y0 + h * 0.72, z, color);
		if (o.boom) kit.paint.cyl(0.005, 0.006, o.boom, 5, 0, y0 + h * 0.7, z - o.boom / 2, color, [Math.PI / 2, 0, 0]);
		// masthead light + rigging
		kit.glow.sphere(0.016, 0, y0 + h + 0.01, z);
		if (o.stays !== false) {
			kit.paint.tube([new THREE.Vector3(0, y0 + h, z), new THREE.Vector3(0, y0 + 0.015, hull.zAt(0.985))], 0.0022, '#9b8a6a', 3);
			kit.paint.tube([new THREE.Vector3(0, y0 + h, z), new THREE.Vector3(0, y0 + 0.015, hull.zAt(0.04))], 0.0022, '#9b8a6a', 3);
		}
		return { x: 0, y: y0 + h, z };
	}

	function cratesOnDeck(kit, hull, t, n, size) {
		const z = hull.zAt(t);
		const y = hull.deckYAt(t);
		const hw = hull.hwAt(t);
		for (let i = 0; i < n; i++) {
			const x = (i % 2 === 0 ? -1 : 1) * hw * 0.32 + (i > 1 ? 0.03 : 0);
			const zz = z + (i > 1 ? -size * 0.9 : 0);
			kit.paint.box(size, size * 0.8, size, x, y + size * 0.4, zz, i % 3 === 0 ? '#8a6746' : '#a8815a');
		}
	}

	// ==================================================================
	// boat prototypes — built once, cloned per berth
	// ==================================================================
	/** hull geometry is indexed; all merged buckets must be non-indexed */
	function pushHull(kit, hull) {
		kit.paint.geos.push(hull.geo.index ? hull.geo.toNonIndexed() : hull.geo);
	}

	function assemble(MAT, name, builder, opts) {
		opts = opts || {};
		const kit = builder();
		// small boats fold their window glass into the painted mesh (one less
		// draw call); only the bigger hulls keep a separate glossy glass pass
		if (opts.mergeGlass && kit.glass.geos.length) {
			for (let i = 0; i < kit.glass.geos.length; i++) kit.paint.geos.push(kit.glass.geos[i]);
			kit.glass.geos.length = 0;
		}
		const group = new THREE.Group();
		group.name = name;
		kit.finish(MAT, group, true);
		return group;
	}

	// ---- tug: black hull, red boot, white wheelhouse, tires -----------
	function buildTug() {
		const hull = hullGeometry({
			len: 0.95,
			beam: 0.34,
			free: 0.125,
			draft: 0.165,
			hull: '#2e3236',
			bottom: '#8a3a30',
			boot: '#b5654a',
			deck: '#8a6746',
			bowRake: 0.065,
			sternRake: 0.03,
			widthTbl: [
				[0, 0.8],
				[0.1, 0.92],
				[0.3, 0.99],
				[0.52, 1.0],
				[0.72, 0.95],
				[0.86, 0.8],
				[0.94, 0.5],
				[1, 0.06],
			],
			sheerTbl: [
				[0, 0.92],
				[0.2, 0.82],
				[0.5, 0.76],
				[0.76, 0.84],
				[1, 0.98],
			],
			keelTbl: [
				[0, 0.68],
				[0.1, 0.88],
				[0.3, 1.0],
				[0.6, 1.0],
				[0.8, 0.94],
				[1, 0.62],
			],
		});
		return function () {
			const kit = new BoatKit();
			pushHull(kit, hull);
			gunwale(kit, hull, { bulwark: 0.028, railColor: '#efe2c9', color: '#2e3236' });
			hullBand(kit, hull, '#b5654a', 0.055, 0.028);
			portholes(kit, hull, 0.34, 0.7, 3, 0.52);
			pennant(kit, hull, 0.5, 0.315, '#b3453b');
			// wheelhouse forward
			const dx = hull.deckYAt(0.58);
			wheelhouse(kit, { w: 0.185, h: 0.135, d: 0.155, y: dx, z: hull.zAt(0.58), color: '#f4efe3', roof: '#e8e2d2', doorColor: '#8a6746' });
			// second storey / chart house
			kit.paint.box(0.15, 0.085, 0.12, 0, dx + 0.2, hull.zAt(0.58) - 0.01, '#f4efe3');
			kit.glass.box(0.12, 0.024, 0.006, 0, dx + 0.232, hull.zAt(0.58) - 0.01 + 0.061, '#3a4a52');
			kit.paint.box(0.17, 0.016, 0.14, 0, dx + 0.25, hull.zAt(0.58) - 0.01, '#e8e2d2');
			kit.glow.box(0.1, 0.014, 0.003, 0, dx + 0.232, hull.zAt(0.58) + 0.064);
			// funnel
			kit.paint.cyl(0.028, 0.032, 0.13, 8, 0, dx + 0.19, hull.zAt(0.34), '#2e3236');
			kit.paint.cyl(0.033, 0.033, 0.014, 8, 0, dx + 0.258, hull.zAt(0.34), '#b3453b');
			kit.paint.cyl(0.02, 0.02, 0.012, 8, 0, dx + 0.268, hull.zAt(0.34), '#1a1f2b');
			// mast + radar
			const mastTop = mast(kit, hull, { t: 0.5, h: 0.3, boom: 0, color: '#5b4028' });
			kit.paint.box(0.06, 0.008, 0.012, 0, mastTop.y - 0.03, mastTop.z, '#6d767d');
			kit.paint.box(0.02, 0.02, 0.02, 0, mastTop.y - 0.05, mastTop.z, '#c8a24b');
			// aft towing deck: winch, tow hook, bollards
			const ay = hull.deckYAt(0.2);
			const az = hull.zAt(0.2);
			kit.paint.cyl(0.032, 0.032, 0.05, 10, 0, ay + 0.035, az, '#5b4028', [0, 0, Math.PI / 2]);
			kit.paint.box(0.06, 0.03, 0.05, 0, ay + 0.02, az, '#4e3726');
			kit.paint.box(0.05, 0.018, 0.03, 0, ay + 0.014, hull.zAt(0.07), '#c8a24b');
			kit.paint.box(0.014, 0.014, 0.02, 0, ay + 0.028, hull.zAt(0.07), '#c8a24b');
			for (let i = 0; i < 2; i++) {
				kit.paint.cyl(0.01, 0.01, 0.024, 6, (i ? 1 : -1) * hull.hwAt(0.12) * 0.7, ay + 0.012, hull.zAt(0.12), '#c8a24b');
			}
			// rope coil on the aft working deck + spare fender
			kit.paint.torus(0.022, 0.006, 0.05, ay + 0.008, hull.zAt(0.16), '#b9a882', [Math.PI / 2, 0, 0]);
			kit.paint.cyl(0.012, 0.012, 0.05, 6, -0.07, ay + 0.03, hull.zAt(0.18), '#b9ac96', [0, 0, 0.12]);
			// tires both sides
			fenderRow(kit, hull, -1, 3, 'tire');
			fenderRow(kit, hull, 1, 3, 'tire');
			// life ring + fire hose box
			lifeRing(kit, hull.hwAt(0.58) + 0.004, dx + 0.07, hull.zAt(0.58), Math.PI / 2);
			kit.paint.box(0.03, 0.025, 0.02, -hull.hwAt(0.42) * 0.6, dx + 0.02, hull.zAt(0.42), '#b3453b');
			// anchor at bow
			kit.paint.box(0.008, 0.05, 0.006, 0, hull.deckYAt(0.93) + 0.02, hull.zAt(0.93) + 0.006, '#3a3f44');
			kit.paint.box(0.03, 0.008, 0.006, 0, hull.deckYAt(0.93) + 0.005, hull.zAt(0.93) + 0.006, '#3a3f44');
			// bow rail
			railRun(kit, hull, { h: 0.055, step: 3, color: '#6d767d' });
			return kit;
		};
	}

	// ---- fishing trawler (3 paint variants) ---------------------------
	function trawlerHull(v) {
		return hullGeometry({
			len: 1.15,
			beam: 0.4,
			free: 0.12,
			draft: 0.15,
			hull: v.hull,
			bottom: v.bottom || '#6b3226',
			boot: v.boot || '#9a4b33',
			deck: '#8a6746',
			bowRake: 0.06,
			sternRake: 0.035,
			widthTbl: [
				[0, 0.76],
				[0.1, 0.9],
				[0.3, 0.99],
				[0.5, 1.0],
				[0.7, 0.96],
				[0.85, 0.86],
				[0.94, 0.6],
				[1, 0.09],
			],
			sheerTbl: [
				[0, 0.9],
				[0.18, 0.8],
				[0.45, 0.72],
				[0.7, 0.78],
				[0.88, 0.9],
				[1, 1.0],
			],
		});
	}

	function buildTrawler(v) {
		const hull = trawlerHull(v);
		return function () {
			const kit = new BoatKit();
			pushHull(kit, hull);
			gunwale(kit, hull, { bulwark: 0.036, railColor: v.rail || '#efe2c9', color: v.hull });
			hullBand(kit, hull, v.boot || '#9a4b33', 0.045, 0.026);
			portholes(kit, hull, 0.3, 0.52, 2, 0.52);
			pennant(kit, hull, 0.58, 0.35, v.rail || '#d9a13b');
			const dy = hull.deckYAt(0.62);
			const dz = hull.zAt(0.62);
			// forward wheelhouse
			wheelhouse(kit, { w: 0.2, h: 0.15, d: 0.18, y: dy, z: dz, color: v.cabin, roof: v.roof || '#e8e2d2' });
			// deck floodlight + working-deck lamp
			kit.paint.cyl(0.004, 0.005, 0.04, 4, 0.062, dy + 0.17, dz - 0.02, '#3a3f44');
			kit.glow.sphere(0.013, 0.062, dy + 0.195, dz - 0.02);
			// roof mast / radar / exhaust
			const mastTop = mast(kit, hull, { t: 0.58, h: 0.34, color: '#4e3726', boom: 0.56 });
			kit.paint.box(0.07, 0.008, 0.01, 0, mastTop.y - 0.04, mastTop.z, '#6d767d');
			kit.paint.cyl(0.014, 0.016, 0.11, 6, 0.055, dy + 0.2, dz - 0.03, '#3a3f44');
			// foredeck gear: anchor winch, hatch, spare floats
			const fy = hull.deckYAt(0.88);
			kit.paint.cyl(0.026, 0.026, 0.04, 8, 0, fy + 0.02, hull.zAt(0.88), '#4e3726', [0, 0, Math.PI / 2]);
			kit.paint.box(0.1, 0.014, 0.09, 0, hull.deckYAt(0.78) + 0.007, hull.zAt(0.78), '#5b4028');
			for (let i = 0; i < 3; i++) kit.paint.sphere(0.018, (i - 1) * 0.05, fy + 0.018, hull.zAt(0.93), '#d9a13b');
			// working deck aft: hatch, crates, winch, gallows + net
			const ay = hull.deckYAt(0.24);
			const az = hull.zAt(0.24);
			kit.paint.box(0.14, 0.012, 0.1, 0, ay + 0.006, az, '#5b4028');
			// trawl winch
			kit.paint.box(0.05, 0.03, 0.06, -0.08, ay + 0.015, az + 0.05, '#3a3f44');
			kit.paint.cyl(0.026, 0.026, 0.05, 8, -0.08, ay + 0.045, az + 0.05, '#6d767d', [0, 0, Math.PI / 2]);
			// stern gallows (A-frame)
			const gz = hull.zAt(0.06);
			kit.paint.cyl(0.006, 0.008, 0.16, 5, -0.1, ay + 0.08, gz, '#6d767d', [0, 0, -0.32]);
			kit.paint.cyl(0.006, 0.008, 0.16, 5, 0.1, ay + 0.08, gz, '#6d767d', [0, 0, 0.32]);
			kit.paint.box(0.24, 0.012, 0.012, 0, ay + 0.155, gz, '#6d767d');
			kit.paint.cyl(0.018, 0.018, 0.03, 6, 0, ay + 0.14, gz, '#3a3f44', [0, 0, Math.PI / 2]);
			// net bundle + floats
			kit.paint.sphere(0.05, 0.02, ay + 0.04, gz + 0.11, '#4a5548', [1.3, 0.55, 0.8]);
			kit.paint.sphere(0.04, 0.05, ay + 0.03, gz + 0.17, '#414a40', [1.1, 0.5, 0.9]);
			// working lamp on the gallows
			kit.glow.sphere(0.01, 0, ay + 0.162, gz + 0.02);
			for (let i = 0; i < 3; i++) kit.paint.sphere(0.013, -0.06 + i * 0.035, ay + 0.012, gz + 0.15, i === 1 ? '#b3453b' : '#d9a13b');
			// life ring on wheelhouse side + fire extinguisher
			lifeRing(kit, hull.hwAt(0.62) + 0.005, dy + 0.085, dz, Math.PI / 2);
			kit.paint.cyl(0.012, 0.012, 0.06, 6, -hull.hwAt(0.5) * 0.6, dy + 0.06, dz - 0.06, '#b3453b');
			// fish boxes on deck
			cratesOnDeck(kit, hull, 0.42, 3, 0.055);
			// blue tarpaulins over the catch + a red fish crate
			kit.paint.box(0.13, 0.014, 0.1, 0.03, ay + 0.075, az - 0.02, '#3d5f86', [0, 0.15, 0]);
			kit.paint.box(0.055, 0.012, 0.07, -0.08, ay + 0.065, az + 0.06, '#b3453b', [0, -0.2, 0]);
			kit.paint.box(0.1, 0.008, 0.07, 0.02, ay + 0.062, az + 0.16, '#4a5548', [0, 0.4, 0]);
			// fenders
			fenderRow(kit, hull, -1, 3, 'cyl');
			fenderRow(kit, hull, 1, 3, 'cyl');
			// bow rail + anchor
			railRun(kit, hull, { h: 0.06, step: 3, color: '#6d767d' });
			kit.paint.box(0.03, 0.008, 0.008, 0, hull.deckYAt(0.96) + 0.01, hull.zAt(0.96) + 0.008, '#3a3f44');
			kit.paint.box(0.008, 0.055, 0.008, 0, hull.deckYAt(0.96) + 0.02, hull.zAt(0.96) + 0.008, '#3a3f44');
			return kit;
		};
	}

	// ---- small open skiff with outboard --------------------------------
	function buildSkiff() {
		const hull = hullGeometry({
			len: 0.62,
			beam: 0.24,
			free: 0.105,
			draft: 0.075,
			hull: '#efe2c9',
			bottom: '#7a3a2a',
			boot: '#3d5f86',
			deck: '#a8815a',
			bowRake: 0.08,
			widthTbl: [
				[0, 0.82],
				[0.2, 0.94],
				[0.45, 1.0],
				[0.7, 0.9],
				[0.86, 0.7],
				[1, 0.06],
			],
		});
		return function () {
			const kit = new BoatKit();
			pushHull(kit, hull);
			gunwale(kit, hull, { bulwark: 0.025, railColor: '#4e3726', color: '#efe2c9' });
			// thwart seats
			for (let i = 0; i < 3; i++) {
				const t = 0.28 + i * 0.24;
				kit.paint.box(hull.hwAt(t) * 1.75, 0.014, 0.05, 0, hull.deckYAt(t) + 0.03, hull.zAt(t), '#a8815a');
			}
			// console + wheel + outboard
			kit.paint.box(0.06, 0.07, 0.05, 0.01, hull.deckYAt(0.5) + 0.05, hull.zAt(0.38), '#e8e2d2');
			kit.glass.box(0.045, 0.03, 0.006, 0.01, hull.deckYAt(0.5) + 0.075, hull.zAt(0.38) + 0.026, '#3a4a52');
			kit.paint.torus(0.018, 0.004, 0.01, hull.deckYAt(0.5) + 0.07, hull.zAt(0.38) - 0.02, '#2b2b2c', [Math.PI / 2, 0, 0]);
			kit.paint.box(0.05, 0.075, 0.05, 0, hull.deckYAt(0.04) + 0.03, hull.zAt(0.02) - 0.015, '#3a3f44');
			kit.paint.box(0.03, 0.02, 0.03, 0, hull.deckYAt(0.04) - 0.02, hull.zAt(0.02) - 0.015, '#2b2b2c');
			// fishing rod + bucket
			kit.paint.cyl(0.002, 0.002, 0.28, 4, 0.07, hull.deckYAt(0.7) + 0.14, hull.zAt(0.7), '#5b4028', [0.3, 0, 0.2]);
			kit.paint.cyl(0.022, 0.018, 0.035, 7, -0.06, hull.deckYAt(0.35) + 0.018, hull.zAt(0.35), '#6d767d');
			// outboard stowed oar
			kit.paint.cyl(0.003, 0.003, 0.3, 4, -hull.hwAt(0.5) * 0.7, hull.deckYAt(0.5) + 0.02, hull.zAt(0.5), '#c8a24b', [0, 0, 0.15]);
			return kit;
		};
	}

	// ---- clinker rowboat ----------------------------------------------
	function buildRowboat() {
		const hull = hullGeometry({
			len: 0.5,
			beam: 0.2,
			free: 0.095,
			draft: 0.055,
			hull: '#a8815a',
			bottom: '#5b4028',
			boot: '#7a3a2a',
			deck: '#b08a5c',
			bowRake: 0.09,
			sternRake: 0.04,
			widthTbl: [
				[0, 0.86],
				[0.25, 0.98],
				[0.5, 0.95],
				[0.75, 0.78],
				[1, 0.05],
			],
			sheerTbl: [
				[0, 0.9],
				[0.3, 0.8],
				[0.6, 0.78],
				[1, 0.95],
			],
		});
		return function () {
			const kit = new BoatKit();
			pushHull(kit, hull);
			gunwale(kit, hull, { bulwark: 0.022, railColor: '#5b4028', color: '#a8815a' });
			hullBand(kit, hull, '#7a3a2a', 0.04, 0.02);
			for (let i = 0; i < 3; i++) {
				const t = 0.3 + i * 0.22;
				kit.paint.box(hull.hwAt(t) * 1.7, 0.012, 0.04, 0, hull.deckYAt(t) + 0.026, hull.zAt(t), '#5b4028');
			}
			// oars + painter
			kit.paint.cyl(0.004, 0.004, 0.42, 4, 0.02, hull.deckYAt(0.5) + 0.03, hull.zAt(0.5), '#c8a24b', [0, 0, 0.1]);
			kit.paint.cyl(0.004, 0.004, 0.42, 4, -0.03, hull.deckYAt(0.5) + 0.03, hull.zAt(0.5), '#c8a24b', [0, 0, -0.1]);
			kit.paint.tube([new THREE.Vector3(0, hull.deckYAt(0.98) + 0.01, hull.zAt(0.98)), new THREE.Vector3(0, hull.deckYAt(0.98) + 0.05, hull.zAt(1.02))], 0.003, '#9b8a6a', 3);
			return kit;
		};
	}

	// ---- marina sailboat ----------------------------------------------
	function buildSailboat(furled) {
		const hull = hullGeometry({
			len: 0.9,
			beam: 0.3,
			free: 0.115,
			draft: 0.1,
			hull: '#f2ede0',
			bottom: '#3d5f86',
			boot: '#3d5f86',
			deck: '#b08a5c',
			bowRake: 0.13,
			sternRake: 0.02,
			widthTbl: [
				[0, 0.56],
				[0.14, 0.8],
				[0.38, 0.97],
				[0.6, 0.95],
				[0.78, 0.74],
				[0.9, 0.44],
				[1, 0.03],
			],
			sheerTbl: [
				[0, 0.92],
				[0.2, 0.8],
				[0.5, 0.72],
				[0.8, 0.78],
				[1, 0.95],
			],
			keelTbl: [
				[0, 0.75],
				[0.15, 0.95],
				[0.35, 1.0],
				[0.65, 1.0],
				[0.85, 0.8],
				[1, 0.4],
			],
			powTbl: [
				[0, 1.1],
				[0.25, 0.8],
				[0.5, 0.62],
				[0.75, 0.8],
				[1, 1.4],
			],
		});
		return function () {
			const kit = new BoatKit();
			pushHull(kit, hull);
			gunwale(kit, hull, { bulwark: 0.014, railColor: '#c8a24b', color: '#f2ede0' });
			hullBand(kit, hull, '#3d5f86', 0.052, 0.022);
			// fin keel + rudder
			kit.paint.box(0.014, 0.13, 0.16, 0, -0.16, hull.zAt(0.42), '#3a3f44');
			kit.paint.sphere(0.018, 0, -0.225, hull.zAt(0.42), '#c8a24b', [1, 0.7, 2.2]);
			kit.paint.box(0.01, 0.09, 0.05, 0, -0.1, hull.zAt(0.06), '#3a3f44');
			// cockpit + cabin trunk
			const cy = hull.deckYAt(0.42);
			kit.paint.box(0.15, 0.055, 0.3, 0, cy + 0.028, hull.zAt(0.5), '#f4efe3');
			kit.glass.box(0.11, 0.018, 0.006, 0, cy + 0.062, hull.zAt(0.5) + 0.151, '#3a4a52');
			kit.paint.box(0.12, 0.02, 0.2, 0, cy + 0.075, hull.zAt(0.5), '#e8e2d2');
			// cockpit well + tiller
			kit.paint.box(0.12, 0.012, 0.13, 0, cy + 0.01, hull.zAt(0.2), '#5b4028');
			kit.paint.cyl(0.006, 0.006, 0.1, 5, 0, cy + 0.05, hull.zAt(0.12), '#5b4028', [0.5, 0, 0]);
			// winches + cleats
			for (const zz of [0.32, 0.18]) {
				kit.paint.cyl(0.011, 0.011, 0.02, 8, 0.06, cy + 0.016, hull.zAt(zz), '#c8a24b');
				kit.paint.cyl(0.011, 0.011, 0.02, 8, -0.06, cy + 0.016, hull.zAt(zz), '#c8a24b');
			}
			// mast + boom + rigging
			const m = mast(kit, hull, { t: 0.5, h: 0.95, boom: 0.5, color: '#8a5b34', rTop: 0.007, rBot: 0.012 });
			kit.paint.box(0.014, 0.008, 0.16, 0, m.y - 0.08, m.z, '#c8a24b');
			kit.paint.tube([new THREE.Vector3(0, m.y, m.z), new THREE.Vector3(0.1, hull.deckYAt(0.3) + 0.02, hull.zAt(0.3))], 0.0022, '#9b8a6a', 3);
			kit.paint.tube([new THREE.Vector3(0, m.y, m.z), new THREE.Vector3(-0.1, hull.deckYAt(0.3) + 0.02, hull.zAt(0.3))], 0.0022, '#9b8a6a', 3);
			// bow pulpit + lifelines
			railRun(kit, hull, { h: 0.04, step: 3, color: '#6d767d' });
			// canvas: furled main on boom / sail cover, or set sails
			if (furled) {
				const boomY = m.y - 0.31;
				// sail cover laced along the boom
				kit.paint.cyl(0.028, 0.022, 0.42, 6, 0, boomY, m.z - 0.26, '#3f6688', [Math.PI / 2, 0, 0]);
				kit.paint.box(0.034, 0.042, 0.17, 0, boomY - 0.008, m.z - 0.1, '#3f6688');
				// furled jib rolled up along the forestay
				kit.paint.tube(
					[new THREE.Vector3(0, m.y - 0.03, m.z), new THREE.Vector3(0, hull.deckYAt(0.92) + 0.02, hull.zAt(0.92))],
					0.012,
					'#e8e2d2',
					4
				);
			} else {
				// set mainsail + jib (triangles with camber)
				const tack = new THREE.Vector3(0, hull.deckYAt(0.5) + 0.06, hull.zAt(0.5));
				const head = new THREE.Vector3(0, m.y - 0.02, m.z);
				const clew = new THREE.Vector3(0, m.y - 0.42, m.z - 0.46);
				kit.soft.geo(sailGeo(tack, head, clew, 0.05), '#efe6d2');
				const jibTack = new THREE.Vector3(0, hull.deckYAt(0.9) + 0.03, hull.zAt(0.9));
				const jibHead = new THREE.Vector3(0, m.y - 0.1, m.z);
				const jibClew = new THREE.Vector3(0, hull.deckYAt(0.35) + 0.25, hull.zAt(0.35));
				kit.soft.geo(sailGeo(jibTack, jibHead, jibClew, 0.035), '#e8dfc8');
			}
			// life ring on pushpit
			lifeRing(kit, 0, hull.deckYAt(0.07) + 0.04, hull.zAt(0.07), 0);
			return kit;
		};
	}

	/** triangular sail with billow */
	function sailGeo(a, b, c, bulge) {
		const n = 4;
		const pos = [];
		const idx = [];
		const ab = new THREE.Vector3().subVectors(b, a);
		const ac = new THREE.Vector3().subVectors(c, a);
		const nrm = new THREE.Vector3().crossVectors(ab, ac).normalize();
		for (let i = 0; i <= n; i++) {
			for (let j = 0; j <= n - i; j++) {
				const w1 = i / n;
				const w2 = j / n;
				const w0 = 1 - w1 - w2;
				const x = w0 * a.x + w1 * b.x + w2 * c.x;
				const y = w0 * a.y + w1 * b.y + w2 * c.y;
				const z = w0 * a.z + w1 * b.z + w2 * c.z;
				const billow = bulge * (w0 * w1 + w1 * w2 + w0 * w2) * 4;
				pos.push(x + nrm.x * billow, y + nrm.y * billow, z + nrm.z * billow);
			}
		}
		let row = 0;
		for (let i = 0; i < n - 1; i++) {
			const rowLen = n - i + 1;
			for (let j = 0; j < n - i; j++) {
				const A = row + j;
				const B = A + 1;
				const C = row + rowLen + j;
				const D = C + 1;
				idx.push(A, C, B, B, C, D);
			}
			row += rowLen;
		}
		const geo = new THREE.BufferGeometry();
		geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
		geo.setIndex(idx);
		geo.computeVertexNormals();
		return geo;
	}

	// ---- motor yacht ---------------------------------------------------
	function buildYacht(v) {
		const hull = hullGeometry({
			len: 0.78,
			beam: 0.29,
			free: 0.115,
			draft: 0.12,
			hull: v.hull || '#f2ede0',
			bottom: v.bottom || '#3d5f86',
			boot: v.boot || '#c8a24b',
			deck: '#b08a5c',
			bowRake: 0.14,
			sternRake: 0.01,
			widthTbl: [
				[0, 0.6],
				[0.15, 0.84],
				[0.4, 0.98],
				[0.62, 0.94],
				[0.8, 0.72],
				[0.92, 0.4],
				[1, 0.03],
			],
			sheerTbl: [
				[0, 0.94],
				[0.25, 0.8],
				[0.55, 0.74],
				[0.8, 0.82],
				[1, 0.98],
			],
		});
		return function () {
			const kit = new BoatKit();
			pushHull(kit, hull);
			gunwale(kit, hull, { bulwark: 0.012, railColor: '#c8a24b', color: v.hull || '#f2ede0' });
			hullBand(kit, hull, v.boot || '#c8a24b', 0.045, 0.02);
			const cy = hull.deckYAt(0.45);
			// low cabin with raked windshield
			kit.paint.box(0.185, 0.09, 0.36, 0, cy + 0.045, hull.zAt(0.5), '#f4efe3');
			kit.paint.box(0.17, 0.05, 0.12, 0, cy + 0.115, hull.zAt(0.66), '#f4efe3');
			kit.glass.box(0.16, 0.04, 0.008, 0, cy + 0.115, hull.zAt(0.72), '#3a4a52', [0.25, 0, 0]);
			kit.glass.box(0.008, 0.05, 0.24, 0.09, cy + 0.06, hull.zAt(0.52), '#3a4a52');
			kit.glass.box(0.008, 0.05, 0.24, -0.09, cy + 0.06, hull.zAt(0.52), '#3a4a52');
			kit.paint.box(0.2, 0.014, 0.3, 0, cy + 0.155, hull.zAt(0.58), '#e8e2d2');
			kit.glow.box(0.14, 0.026, 0.004, 0, cy + 0.115, hull.zAt(0.73));
			// radar arch + antenna
			kit.paint.box(0.17, 0.012, 0.012, 0, cy + 0.2, hull.zAt(0.42), '#e8e2d2');
			kit.paint.box(0.012, 0.05, 0.012, 0.075, cy + 0.175, hull.zAt(0.42), '#e8e2d2');
			kit.paint.box(0.012, 0.05, 0.012, -0.075, cy + 0.175, hull.zAt(0.42), '#e8e2d2');
			kit.paint.cyl(0.012, 0.012, 0.05, 6, 0, cy + 0.225, hull.zAt(0.42), '#6d767d');
			// sun pad aft + swim platform
			kit.paint.box(0.15, 0.02, 0.12, 0, cy + 0.035, hull.zAt(0.22), '#e8dfc8');
			// bimini canopy over the cockpit: four brass posts + navy canvas
			for (const sx of [-1, 1]) {
				for (const sz of [-1, 1]) {
					kit.paint.cyl(0.004, 0.005, 0.13, 4, sx * 0.072, cy + 0.085, hull.zAt(0.5) + sz * 0.1, '#c8a24b');
				}
			}
			kit.paint.box(0.165, 0.01, 0.22, 0, cy + 0.152, hull.zAt(0.5), '#3f6688', [0.02, 0, 0]);
			kit.paint.box(0.16, 0.005, 0.19, 0, cy + 0.158, hull.zAt(0.5), '#e8e2d2', [0.02, 0, 0]);
			kit.paint.box(0.17, 0.014, 0.07, 0, cy - 0.02, hull.zAt(0.0) - 0.02, '#a8815a');
			// rails + cleats
			railRun(kit, hull, { h: 0.05, step: 2, color: '#c8a24b' });
			// bow navigation light + cockpit courtesy light
			kit.glow.sphere(0.009, 0, cy - 0.004, hull.zAt(0.9));
			kit.glow.box(0.004, 0.012, 0.1, 0.09, cy + 0.04, hull.zAt(0.32));
			// life ring + fenders + flag pole
			lifeRing(kit, 0.09, cy + 0.05, hull.zAt(0.62), Math.PI / 2);
			fenderRow(kit, hull, -1, 2, 'cyl');
			fenderRow(kit, hull, 1, 2, 'cyl');
			kit.paint.cyl(0.004, 0.005, 0.22, 5, 0, hull.deckYAt(0.02) + 0.12, hull.zAt(0.02), '#c8a24b');
			return kit;
		};
	}

	// ---- wooden harbour ferry -----------------------------------------
	function buildFerry() {
		const hull = hullGeometry({
			len: 1.5,
			beam: 0.5,
			free: 0.13,
			draft: 0.13,
			hull: '#8a5b34',
			bottom: '#5b2b24',
			boot: '#e8e2d2',
			deck: '#a8815a',
			bowRake: 0.07,
			sternRake: 0.04,
			widthTbl: [
				[0, 0.8],
				[0.1, 0.92],
				[0.3, 0.99],
				[0.5, 1.0],
				[0.72, 0.94],
				[0.86, 0.78],
				[0.95, 0.44],
				[1, 0.05],
			],
			sheerTbl: [
				[0, 0.9],
				[0.2, 0.8],
				[0.5, 0.74],
				[0.78, 0.84],
				[1, 1.0],
			],
		});
		return function () {
			const kit = new BoatKit();
			pushHull(kit, hull);
			gunwale(kit, hull, { bulwark: 0.032, railColor: '#c8a24b', color: '#8a5b34' });
			hullBand(kit, hull, '#e8e2d2', 0.055, 0.026);
			portholes(kit, hull, 0.25, 0.62, 3, 0.52);
			pennant(kit, hull, 0.92, 0.3, '#b3453b');
			const dy = hull.deckYAt(0.5);
			// canopy on posts
			for (const zz of [0.25, 0.45, 0.65, 0.82]) {
				for (const side of [-1, 1]) {
					kit.paint.cyl(0.006, 0.007, 0.16, 5, side * hull.hwAt(zz) * 0.82, dy + 0.08, hull.zAt(zz), '#8a5b34');
				}
			}
			kit.paint.box(0.36, 0.016, 0.9, 0, dy + 0.17, hull.zAt(0.53), '#efe6d2');
			kit.paint.box(0.34, 0.012, 0.2, 0, dy + 0.18, hull.zAt(0.35), '#b3453b');
			// benches
			for (let i = 0; i < 4; i++) {
				const t = 0.3 + i * 0.14;
				kit.paint.box(hull.hwAt(t) * 1.5, 0.012, 0.045, 0, dy + 0.04, hull.zAt(t), '#8a6746');
			}
			// warm lanterns under the canopy
			for (const zz of [0.34, 0.62]) {
				kit.paint.cyl(0.003, 0.004, 0.03, 4, 0, dy + 0.15, hull.zAt(zz), '#3a3f44');
				kit.glow.sphere(0.012, 0, dy + 0.169, hull.zAt(zz));
			}
			// small wheelhouse + funnel
			wheelhouse(kit, { w: 0.14, h: 0.12, d: 0.14, y: dy, z: hull.zAt(0.72), color: '#e8e2d2', roof: '#efe2c9' });
			kit.paint.cyl(0.02, 0.022, 0.1, 7, 0, dy + 0.2, hull.zAt(0.55), '#3a3f44');
			// life rings, fenders, flag
			lifeRing(kit, hull.hwAt(0.6) + 0.006, dy + 0.07, hull.zAt(0.6), Math.PI / 2);
			lifeRing(kit, -hull.hwAt(0.6) - 0.006, dy + 0.07, hull.zAt(0.6), Math.PI / 2);
			fenderRow(kit, hull, -1, 3, 'cyl');
			fenderRow(kit, hull, 1, 3, 'cyl');
			kit.paint.cyl(0.004, 0.004, 0.3, 4, 0, dy + 0.3, hull.zAt(0.92), '#c8a24b');
			kit.glow.sphere(0.01, 0, dy + 0.45, hull.zAt(0.92));
			return kit;
		};
	}

	// ---- small coastal coaster (cargo pier) --------------------------
	function buildCoaster() {
		const hull = hullGeometry({
			len: 1.9,
			beam: 0.52,
			free: 0.2,
			draft: 0.2,
			hull: '#2f4f63',
			bottom: '#6b3226',
			boot: '#b5654a',
			deck: '#7d7a72',
			bowRake: 0.07,
			sternRake: 0.02,
			widthTbl: [
				[0, 0.84],
				[0.1, 0.93],
				[0.3, 0.99],
				[0.55, 1.0],
				[0.75, 0.96],
				[0.87, 0.84],
				[0.95, 0.56],
				[1, 0.1],
			],
			sheerTbl: [
				[0, 0.92],
				[0.2, 0.82],
				[0.5, 0.78],
				[0.75, 0.82],
				[0.9, 0.92],
				[1, 1.0],
			],
			keelTbl: [
				[0, 0.72],
				[0.1, 0.9],
				[0.3, 1.0],
				[0.65, 1.0],
				[0.85, 0.92],
				[1, 0.55],
			],
		});
		return function () {
			const kit = new BoatKit();
			pushHull(kit, hull);
			gunwale(kit, hull, { bulwark: 0.03, railColor: '#e8e2d2', color: '#2f4f63' });
			hullBand(kit, hull, '#b5654a', 0.06, 0.032);
			portholes(kit, hull, 0.25, 0.72, 4, 0.52);
			pennant(kit, hull, 0.83, 0.42, '#3d5f86');
			// aft deckhouse + bridge + funnel
			const hz = hull.zAt(0.16);
			const hy = hull.deckYAt(0.16);
			kit.paint.box(0.36, 0.18, 0.3, 0, hy + 0.09, hz, '#f4efe3');
			kit.paint.box(0.4, 0.1, 0.18, 0, hy + 0.23, hz + 0.02, '#efe2c9');
			kit.glass.box(0.36, 0.04, 0.008, 0, hy + 0.24, hz + 0.112, '#3a4a52');
			kit.glass.box(0.008, 0.04, 0.12, 0.2, hy + 0.24, hz + 0.02, '#3a4a52');
			kit.glass.box(0.008, 0.04, 0.12, -0.2, hy + 0.24, hz + 0.02, '#3a4a52');
			kit.glow.box(0.3, 0.02, 0.004, 0, hy + 0.24, hz + 0.116);
			kit.paint.box(0.42, 0.016, 0.22, 0, hy + 0.29, hz + 0.02, '#e8e2d2');
			// funnel + steam pipe
			kit.paint.cyl(0.042, 0.046, 0.22, 8, 0, hy + 0.4, hz - 0.16, '#d9a13b');
			kit.paint.cyl(0.047, 0.047, 0.03, 8, 0, hy + 0.51, hz - 0.16, '#2e3236');
			kit.paint.cyl(0.048, 0.048, 0.016, 8, 0, hy + 0.44, hz - 0.16, '#2e3236');
			kit.paint.cyl(0.008, 0.008, 0.2, 5, 0.06, hy + 0.38, hz - 0.06, '#3a3f44');
			// radar mast on bridge
			kit.paint.cyl(0.006, 0.009, 0.24, 5, 0, hy + 0.41, hz + 0.06, '#e8e2d2');
			kit.paint.box(0.08, 0.008, 0.01, 0, hy + 0.5, hz + 0.06, '#6d767d');
			kit.glow.sphere(0.012, 0, hy + 0.54, hz + 0.06);
			// cargo hatches + containers on deck
			for (let i = 0; i < 2; i++) {
				const t = 0.42 + i * 0.2;
				const y = hull.deckYAt(t);
				const z = hull.zAt(t);
				kit.paint.box(0.38, 0.026, 0.28, 0, y + 0.013, z, '#5b4028');
				kit.paint.box(0.34, 0.016, 0.24, 0, y + 0.034, z, '#c39a4a');
			}
			const cz = hull.zAt(0.42);
			const cy = hull.deckYAt(0.42) + 0.045;
			kit.paint.box(0.3, 0.13, 0.13, -0.06, cy + 0.065, cz, '#2f6f73');
			kit.paint.box(0.3, 0.13, 0.13, -0.06, cy + 0.195, cz, '#a64532');
			kit.paint.box(0.3, 0.13, 0.13, 0.24, cy + 0.065, hull.zAt(0.62), '#3d5f86');
			// deck crane between hatches
			const kz = hull.zAt(0.62);
			const ky = hull.deckYAt(0.62);
			kit.paint.cyl(0.022, 0.028, 0.2, 8, 0.09, ky + 0.1, kz, '#d9a13b');
			kit.paint.cyl(0.012, 0.014, 0.42, 6, -0.05, ky + 0.28, kz + 0.02, '#d9a13b', [0, 0, 1.05]);
			kit.paint.cyl(0.004, 0.004, 0.2, 4, -0.28, ky + 0.2, kz + 0.06, '#3a3f44');
			// forecastle: winch, anchor, chain
			const fy = hull.deckYAt(0.9);
			kit.paint.cyl(0.026, 0.026, 0.05, 8, 0, fy + 0.03, hull.zAt(0.9), '#5b4028', [0, 0, Math.PI / 2]);
			kit.paint.box(0.03, 0.008, 0.008, 0, fy + 0.008, hull.zAt(0.97) + 0.02, '#3a3f44');
			kit.paint.box(0.008, 0.06, 0.008, 0, fy + 0.028, hull.zAt(0.97) + 0.02, '#3a3f44');
			kit.paint.tube(
				[new THREE.Vector3(0, fy, hull.zAt(0.97) + 0.015), new THREE.Vector3(0, fy + 0.003, hull.zAt(0.99) + 0.06), new THREE.Vector3(0, -0.02, hull.zAt(0.99) + 0.12)],
				0.006,
				'#3a3f44',
				3
			);
			// foremast with cargo light
			const fm = mast(kit, hull, { t: 0.83, h: 0.42, color: '#e8e2d2', rTop: 0.006, rBot: 0.011 });
			kit.paint.box(0.12, 0.008, 0.008, 0, fm.y - 0.05, fm.z, '#e8e2d2');
			// railings + life rings + bollards
			railRun(kit, hull, { h: 0.08, step: 2, color: '#b9b3a4' });
			lifeRing(kit, hull.hwAt(0.3) + 0.006, hull.deckYAt(0.3) + 0.13, hull.zAt(0.3), Math.PI / 2);
			// name boards at bow and stern (painted plates, no lettering)
			for (const side of [-1, 1]) {
				for (const t of [0.93, 0.1]) {
					kit.paint.box(0.004, 0.034, 0.11, side * (hull.hwAt(t) + 0.002), hull.deckYAt(t) - 0.048, hull.zAt(t), '#f2ede0');
					kit.paint.box(0.004, 0.004, 0.12, side * (hull.hwAt(t) + 0.002), hull.deckYAt(t) - 0.066, hull.zAt(t), '#c8a24b');
				}
			}
			// navigation light on the foredeck
			kit.glow.sphere(0.011, 0, hull.deckYAt(0.96) + 0.03, hull.zAt(0.96));
			for (let i = 0; i < 3; i++) {
				const t = 0.3 + i * 0.22;
				for (const side of [-1, 1]) {
					kit.paint.cyl(0.013, 0.013, 0.035, 6, side * hull.hwAt(t) * 0.86, hull.deckYAt(t) + 0.017, hull.zAt(t), '#3a3f44');
				}
			}
			// rust streaks at the bow
			kit.paint.box(0.05, 0.09, 0.004, 0.14, hull.deckYAt(0.94) - 0.06, hull.zAt(0.95), '#9a4b33', [0.1, -0.2, 0]);
			// fenders
			fenderRow(kit, hull, -1, 3, 'cyl');
			fenderRow(kit, hull, 1, 3, 'cyl');
			return kit;
		};
	}

	// ---- rusty work barge --------------------------------------------
	function buildBarge() {
		const hull = hullGeometry({
			len: 1.4,
			beam: 0.62,
			free: 0.08,
			draft: 0.1,
			hull: '#7a4a36',
			bottom: '#4e3726',
			boot: '#9a4b33',
			deck: '#6d6a60',
			bowRake: 0.03,
			sternRake: 0.02,
			camber: 0.004,
			widthTbl: [
				[0, 0.94],
				[0.1, 0.98],
				[0.5, 1.0],
				[0.85, 0.97],
				[0.95, 0.9],
				[1, 0.7],
			],
			sheerTbl: [
				[0, 1.0],
				[0.5, 0.95],
				[1, 0.98],
			],
			keelTbl: [
				[0, 0.95],
				[0.3, 1.0],
				[0.8, 1.0],
				[1, 0.9],
			],
		});
		return function () {
			const kit = new BoatKit();
			pushHull(kit, hull);
			gunwale(kit, hull, { bulwark: 0.035, railColor: '#5b4028', color: '#7a4a36' });
			hullBand(kit, hull, '#9a4b33', 0.045, 0.028);
			const dy = hull.deckYAt(0.5);
			// gravel pile
			kit.paint.sphere(0.24, 0, dy + 0.06, hull.zAt(0.55), '#6e6258', [1.5, 0.5, 1.05]);
			kit.paint.sphere(0.16, 0.08, dy + 0.12, hull.zAt(0.6), '#7d7166', [1.3, 0.5, 1]);
			// small aft wheelhouse + exhaust
			const hz = hull.zAt(0.14);
			kit.paint.box(0.16, 0.13, 0.16, 0, dy + 0.065, hz, '#cf9a86');
			kit.glass.box(0.11, 0.028, 0.006, 0, dy + 0.1, hz + 0.082, '#3a4a52');
			kit.glow.box(0.08, 0.016, 0.004, 0, dy + 0.1, hz + 0.086);
			kit.paint.box(0.18, 0.014, 0.18, 0, dy + 0.135, hz, '#b9ac96');
			kit.paint.cyl(0.01, 0.012, 0.14, 5, 0.06, dy + 0.2, hz - 0.04, '#3a3f44');
			// pedestal crane over the pile
			kit.paint.cyl(0.03, 0.038, 0.18, 8, 0.16, dy + 0.09, hz + 0.1, '#c39a4a');
			kit.paint.cyl(0.014, 0.016, 0.55, 6, -0.05, dy + 0.28, hz + 0.13, '#c39a4a', [0, 0, 1.15]);
			kit.paint.cyl(0.004, 0.004, 0.3, 4, -0.3, dy + 0.14, hz + 0.12, '#3a3f44');
			kit.paint.box(0.05, 0.04, 0.05, -0.3, dy + 0.0, hz + 0.12, '#3a3f44');
			// bollards + tire fenders + life ring
			for (const p of [
				[-0.22, 0.08],
				[0.22, 0.08],
				[-0.22, 0.9],
				[0.22, 0.9],
			]) {
				const t = p[1];
				kit.paint.cyl(0.014, 0.016, 0.04, 6, p[0] * hull.hwAt(t) * 2.4, hull.deckYAt(t) + 0.02, hull.zAt(t), '#3a3f44');
			}
			fenderRow(kit, hull, -1, 4, 'tire');
			fenderRow(kit, hull, 1, 4, 'tire');
			lifeRing(kit, 0.22, dy + 0.06, hull.zAt(0.25), 0);
			return kit;
		};
	}

	// ==================================================================
	// buoys
	// ==================================================================
	function makeGlowSprite(color) {
		const c = U.createCanvas(64);
		const g2 = c.getContext('2d');
		if (!g2) return new THREE.Sprite(new THREE.SpriteMaterial({ transparent: true, opacity: 0 }));
		const grad = g2.createRadialGradient(32, 32, 0, 32, 32, 32);
		grad.addColorStop(0, 'rgba(255,255,255,1)');
		grad.addColorStop(0.22, color);
		grad.addColorStop(1, 'rgba(255,255,255,0)');
		g2.fillStyle = grad;
		g2.fillRect(0, 0, 64, 64);
		const tex = U.canvasTex(c, { srgb: true });
		const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false, opacity: 0 });
		const sp = new THREE.Sprite(mat);
		sp.scale.setScalar(0.34);
		sp.visible = false;
		return sp;
	}

	function makeBuoy(MAT, kind) {
		const kit = new BoatKit();
		const group = new THREE.Group();
		group.name = 'buoy-' + kind;
		if (kind === 'red') {
			kit.paint.cyl(0.065, 0.075, 0.06, 10, 0, 0.03, 0, '#b3453b');
			kit.paint.cyl(0.055, 0.065, 0.1, 10, 0, 0.11, 0, '#b3453b');
			kit.paint.cyl(0.058, 0.058, 0.025, 10, 0, 0.172, 0, '#efe2c9');
			kit.paint.box(0.008, 0.09, 0.008, 0, 0.23, 0.03, '#3a3f44');
			kit.paint.box(0.008, 0.09, 0.008, 0, 0.23, -0.03, '#3a3f44');
			kit.paint.box(0.06, 0.008, 0.008, 0, 0.275, 0, '#3a3f44');
			kit.glow.sphere(0.038, 0, 0.3, 0);
		} else if (kind === 'green') {
			kit.paint.cyl(0.055, 0.06, 0.16, 8, 0, 0.08, 0, '#2f6b4f');
			kit.paint.cyl(0.06, 0.06, 0.02, 8, 0, 0.17, 0, '#efe2c9');
			kit.paint.cyl(0.012, 0.012, 0.05, 5, 0, 0.2, 0, '#3a3f44');
			kit.glow.sphere(0.032, 0, 0.24, 0);
		} else {
			// small white mooring buoy
			kit.paint.sphere(0.05, 0, 0.05, 0, '#efe2c9', [1, 0.85, 1]);
			kit.paint.cyl(0.02, 0.03, 0.04, 7, 0, 0.1, 0, '#d9a13b');
			kit.paint.torus(0.02, 0.006, 0, 0.115, 0, '#3a3f44', [0, 0, 0]);
			kit.glow.sphere(0.016, 0, 0.128, 0);
		}
		const pmesh = mergedMesh(kit.paint.geos, MAT.paint, 'paint', false, true);
		if (pmesh) group.add(pmesh);
		const lightMat = new THREE.MeshStandardMaterial({
			color: new THREE.Color('#140d08'),
			emissive: new THREE.Color(kind === 'green' ? '#8affb0' : kind === 'red' ? '#ff9f7a' : '#ffd9a0'),
			emissiveIntensity: 0.1,
			roughness: 0.6,
			metalness: 0.0,
		});
		const lmesh = kind === 'mooring' ? null : mergedMesh(kit.glow.geos, lightMat, 'lamp', false, false);
		if (lmesh) group.add(lmesh);
		// night halo sprite so the buoy light reads at a distance
		const sprite = makeGlowSprite(kind === 'green' ? 'rgba(120,255,150,0.85)' : kind === 'red' ? 'rgba(255,130,85,0.85)' : 'rgba(255,215,150,0.8)');
		sprite.position.set(0, kind === 'red' ? 0.34 : kind === 'green' ? 0.28 : 0.16, 0);
		group.add(sprite);
		return { group, lightMat, sprite, spriteMat: sprite.material };
	}

	// ==================================================================
	// module
	// ==================================================================
	H.register('vessels', {
		create(ctx) {
			const g = ctx.group('vessels');
			const M = ctx.materials;
			const r = U.rng(9401);
			const camera = ctx.camera;

			const MAT = {
				paint: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.56, metalness: 0.06 }),
				glass: M.get('glass'),
				canvas: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.93, metalness: 0.0, side: THREE.DoubleSide }),
				glow: new THREE.MeshStandardMaterial({
					color: new THREE.Color('#140d08'),
					emissive: new THREE.Color('#ffcf8a'),
					emissiveIntensity: 0.1,
					roughness: 0.7,
					metalness: 0.0,
				}),
				rope: M.get('rope'),
			};

			// ---- prototype builders ---------------------------------
			// each value is a builder closure: call it to get that boat's kit
			const BUILDERS = {
				tug: buildTug(),
				trawlerA: buildTrawler({ hull: '#2f6f73', rail: '#efe2c9', cabin: '#f4efe3', roof: '#e8e2d2' }),
				trawlerB: buildTrawler({ hull: '#e8e2d2', rail: '#3d5f86', cabin: '#f4efe3', roof: '#b9ac96' }),
				trawlerC: buildTrawler({ hull: '#a9503d', rail: '#f4efe3', cabin: '#efe2c9', roof: '#e8e2d2' }),
				trawlerD: buildTrawler({ hull: '#3d5f86', rail: '#d9a13b', cabin: '#f4efe3', roof: '#e8e2d2' }),
				skiff: buildSkiff(),
				rowboat: buildRowboat(),
				sailFurled: buildSailboat(true),
				sailSet: buildSailboat(false),
				yachtA: buildYacht({ hull: '#f2ede0', boot: '#c8a24b' }),
				yachtB: buildYacht({ hull: '#e8e2d2', boot: '#3f6688' }),
				ferry: buildFerry(),
				coaster: buildCoaster(),
				barge: buildBarge(),
			};
			const LEN = {
				tug: 0.95,
				trawlerA: 1.15,
				trawlerB: 1.15,
				trawlerC: 1.15,
				trawlerD: 1.15,
				skiff: 0.62,
				rowboat: 0.5,
				sailFurled: 0.9,
				sailSet: 0.9,
				yachtA: 0.78,
				yachtB: 0.78,
				ferry: 1.5,
				coaster: 1.9,
				barge: 1.4,
			};
			const FREE = {
				tug: 0.125,
				trawlerA: 0.12,
				trawlerB: 0.12,
				trawlerC: 0.12,
				trawlerD: 0.12,
				skiff: 0.105,
				rowboat: 0.095,
				sailFurled: 0.115,
				sailSet: 0.115,
				yachtA: 0.115,
				yachtB: 0.115,
				ferry: 0.13,
				coaster: 0.2,
				barge: 0.08,
			};
			const BEAM = {
				tug: 0.34,
				trawlerA: 0.4,
				trawlerB: 0.4,
				trawlerC: 0.4,
				trawlerD: 0.4,
				skiff: 0.24,
				rowboat: 0.2,
				sailFurled: 0.3,
				sailSet: 0.3,
				yachtA: 0.29,
				yachtB: 0.29,
				ferry: 0.5,
				coaster: 0.52,
				barge: 0.62,
			};
			const protoCache = {};
			const MERGE_GLASS = { skiff: true, rowboat: true, sailFurled: true, sailSet: true, yachtA: true, yachtB: true, barge: true, tug: true, coaster: true };
			const CAST_SHADOW = { tug: true, trawlerA: true, trawlerB: true, trawlerC: true, trawlerD: true, coaster: true, ferry: true, barge: true };
			function protoOf(key) {
				if (!protoCache[key]) {
					protoCache[key] = {
						group: assemble(MAT, key, BUILDERS[key], { mergeGlass: !!MERGE_GLASS[key] }),
						len: LEN[key],
						free: FREE[key],
					};
				}
				return protoCache[key];
			}

			// ---- boats / animation records --------------------------
			const boats = [];
			const buoys = [];
			const worldPaint = new Paint();
			const worldRope = new Paint();
			const BERTH = {};
			for (const b of L.berths) BERTH[b.id] = b;
			const PIER = {};
			for (const p of L.PIERS) PIER[p.id] = p;

			function place(key, x, z, heading, targetLen, opts) {
				opts = opts || {};
				const proto = protoOf(key);
				const grp = proto.group.clone(true);
				const s = targetLen / proto.len;
				grp.scale.setScalar(s);
				// only the big hulls need a shadow pass
				if (grp.children[0] && grp.children[0].isMesh) grp.children[0].castShadow = !!CAST_SHADOW[key];
				const baseY = opts.baseY != null ? opts.baseY : -0.04;
				grp.position.set(x, baseY, z);
				grp.rotation.y = heading;
				g.add(grp);
				const outside = !!opts.outside;
				const b = {
					g: grp,
					baseY,
					heading,
					phase: r.range(0, Math.PI * 2),
					w: r.range(0.35, 0.62) * (outside ? 0.85 : 1),
					bob: outside ? r.range(0.02, 0.032) : r.range(0.005, 0.011),
					roll: outside ? r.range(0.03, 0.05) : r.range(0.007, 0.016),
					pitch: outside ? r.range(0.018, 0.03) : r.range(0.005, 0.012),
					heel: opts.heel || 0,
					free: proto.free * s,
					scale: s,
					len: targetLen,
				};
				if (key === 'barge') {
					b.bob = 0.006;
					b.roll = 0.006;
					b.pitch = 0.004;
					b.w = 0.24;
				}
				boats.push(b);
				return b;
			}

			// ---- rope helpers ---------------------------------------
			function addRope(a, b, sag) {
				const mid = [(a[0] + b[0]) * 0.5, (a[1] + b[1]) * 0.5 - sag, (a[2] + b[2]) * 0.5];
				worldRope.tube(
					[new THREE.Vector3(a[0], a[1], a[2]), new THREE.Vector3(mid[0], mid[1], mid[2]), new THREE.Vector3(b[0], b[1], b[2])],
					0.006,
					'#b9a882',
					3
				);
			}
			function addCleat(x, z, y) {
				worldPaint.box(0.045, 0.012, 0.014, x, y + 0.006, z, '#c8a24b');
				worldPaint.box(0.012, 0.018, 0.012, x, y + 0.01, z, '#c8a24b');
			}
			function moorToPier(berth, boat) {
				const pier = PIER[berth.pier];
				if (!pier) return;
				const dl = Math.hypot(pier.dir[0], pier.dir[1]);
				const dx = pier.dir[0] / dl;
				const dz = pier.dir[1] / dl;
				const sideSign = berth.side === 'left' ? 1 : -1;
				const sin = Math.sin(berth.heading);
				const cos = Math.cos(berth.heading);
				const half = boat.len * 0.5;
				const bow = [berth.pos[0] + sin * half * 0.86, berth.pos[1] + cos * half * 0.86];
				const stern = [berth.pos[0] - sin * half * 0.8, berth.pos[1] - cos * half * 0.8];
				const yBoat = boat.baseY + boat.free * 0.92 + 0.02;
				// snap the shore end of each line to the cast-iron bollard /
				// pontoon cleat that T2 actually built on that pier edge
				function fitting(px, pz, bias) {
					const ox = px - pier.start[0];
					const oz = pz - pier.start[1];
					let along = ox * dx + oz * dz + bias;
					const LEN = pier.length;
					let a;
					let across;
					let y;
					if (pier.style === 'pontoon') {
						const step = (LEN - 0.6) / 6;
						const idx = U.clamp(Math.round((along - 0.3) / step), 0, 5);
						a = 0.3 + idx * step;
						across = sideSign * (pier.width / 2 - 0.1);
						y = pier.deck + 0.08;
					} else {
						const step = (LEN + 0.1) / 4;
						const idx = U.clamp(Math.round((along + 0.25) / step), 0, 3);
						a = -0.25 + idx * step;
						across = sideSign * (pier.width / 2 - 0.14);
						y = pier.deck + 0.035 + 0.155;
					}
					return [pier.start[0] + dx * a - dz * across, y, pier.start[1] + dz * a + dx * across];
				}
				const eBow = fitting(bow[0], bow[1], 0.42);
				const eStern = fitting(stern[0], stern[1], -0.38);
				addRope([bow[0], yBoat, bow[1]], eBow, 0.05);
				addRope([stern[0], yBoat, stern[1]], eStern, 0.05);
				// spring line from midships to the next bollard aft
				const mid = [berth.pos[0] - sin * half * 0.1, berth.pos[1] - cos * half * 0.1];
				const eMid = fitting(mid[0], mid[1], -0.55);
				addRope([mid[0], yBoat, mid[1]], eMid, 0.06);
			}

			// ---- the fleet at the berths ---------------------------
			const BERTH_FLEET = [
				['pierA-left-0', 'skiff', 0.6, -0.24],
				['pierA-left-1', 'trawlerD', 1.45, 0.2],
				['pierA-right-0', 'tug', 1.05, -0.3],
				['pierA-right-1', 'coaster', 2.0, 0.2],
				['pierB-left-0', 'rowboat', 0.55, -0.12],
				['pierB-left-1', 'trawlerA', 1.5, 0.28],
				['pierB-right-0', 'skiff', 0.7, -0.12],
				['pierB-right-1', 'trawlerB', 1.5, 0.28],
				['pierC-left-1', 'sailFurled', 0.86, -0.05],
				['pierC-left-2', 'yachtA', 0.66, 0.14],
				['pierC-right-1', 'sailFurled', 0.86, -0.05],
				['pierC-right-2', 'yachtB', 0.66, 0.14],
				['pierD-left-0', 'ferry', 1.6, 0.0],
			];
			for (const spec of BERTH_FLEET) {
				const berth = BERTH[spec[0]];
				if (!berth) continue;
				const pier = PIER[berth.pier];
				if (!pier) continue;
				const dl = Math.hypot(pier.dir[0], pier.dir[1]);
				const dx = pier.dir[0] / dl;
				const dz = pier.dir[1] / dl;
				const sideSign = berth.side === 'left' ? 1 : -1;
				const sin = Math.sin(berth.heading);
				const cos = Math.cos(berth.heading);
				// slide the hull in/out from the berth centreline so the
				// fender gap along the pier face stays 0.03-0.06 world units
				const halfBeam = 0.5 * BEAM[spec[1]] * (spec[2] / LEN[spec[1]]);
				const snug = U.clamp(halfBeam - 0.305, -0.24, 0.1);
				const x = berth.pos[0] + sin * spec[3] - dz * sideSign * snug;
				const z = berth.pos[1] + cos * spec[3] + dx * sideSign * snug;
				const boat = place(spec[1], x, z, berth.heading, spec[2], {});
				boat.berth = berth;
				moorToPier(berth, boat);
				// brass mooring cleats on the boat's fore/aft deck edge
				const half = spec[2] * 0.5;
				const cleatY = boat.baseY + boat.free * 0.92 + 0.02;
				for (const sgn of [1, -1]) {
					const cx = x + sin * half * 0.86 * sgn;
					const cz = z + cos * half * 0.86 * sgn;
					worldPaint.box(0.028, 0.008, 0.008, cx, cleatY, cz, '#c8a24b');
					worldPaint.box(0.008, 0.012, 0.008, cx, cleatY + 0.006, cz, '#c8a24b');
				}
			}

			// ---- boats at anchor / on moorings ---------------------
			// fishing trawler swinging on a mooring buoy in the basin
			const tb = place('trawlerC', -6.45, 6.55, 1.15, 1.45, {});
			const tBowX = -6.45 + Math.sin(1.15) * 1.18 * 0.42;
			const tBowZ = 6.55 + Math.cos(1.15) * 1.18 * 0.42;
			const moorBuoyRed = makeBuoy(MAT, 'mooring');
			moorBuoyRed.group.position.set(-5.92, -0.05, 6.88);
			g.add(moorBuoyRed.group);
			buoys.push({ g: moorBuoyRed.group, baseY: -0.05, phase: r.range(0, 6.28), w: 0.7, lightMat: moorBuoyRed.lightMat, sprite: moorBuoyRed.sprite, spriteMat: moorBuoyRed.spriteMat, blink: false });
			addRope([tBowX, tb.baseY + tb.free + 0.02, tBowZ], [-5.92, 0.06, 6.88], 0.03);

			// work barge at anchor in the outer roads
			place('barge', -8.4, 8.25, 1.85, 1.6, { outside: true });
			const anchorBuoy = makeBuoy(MAT, 'mooring');
			anchorBuoy.group.position.set(-7.62, -0.05, 8.0);
			g.add(anchorBuoy.group);
			buoys.push({ g: anchorBuoy.group, baseY: -0.05, phase: r.range(0, 6.28), w: 0.55, lightMat: anchorBuoy.lightMat, sprite: anchorBuoy.sprite, spriteMat: anchorBuoy.spriteMat, blink: false });
			addRope([-7.72, 0.06, 7.98], [-7.62, 0.08, 8.0], 0.02);

			// small coaster waiting at anchor outside the breakwater
			place('coaster', 3.0, 11.5, 2.35, 2.3, { outside: true });
			// sailing yacht offshore with sails set, heeling in the swell
			place('sailSet', -6.0, 10.7, 0.55, 1.5, { outside: true, heel: 0.11 });

			// rowboat hauled up on the beach at the cove
			const rowProto = protoOf('rowboat');
			const bx = -11.28;
			const bz = 5.42;
			const by = ctx.groundHeight(bx, bz);
			if (by > 0.05) {
				const rg = rowProto.group.clone(true);
				rg.position.set(bx, by + 0.02, bz);
				rg.rotation.set(0.05, 1.35, 0.06);
				if (rg.children[0] && rg.children[0].isMesh) rg.children[0].castShadow = false;
				g.add(rg);
			}

			// ---- navigation buoys ---------------------------------
			const channel = [
				['red', -4.9, 8.9, true],
				['green', -6.95, 9.5, true],
				['red', 4.9, 10.8, true],
				['green', 7.15, 9.85, true],
			];
			for (const c of channel) {
				const b = makeBuoy(MAT, c[0]);
				b.group.position.set(c[1], -0.05, c[2]);
				b.group.rotation.y = r.range(0, 6.28);
				g.add(b.group);
				buoys.push({
					g: b.group,
					baseY: -0.05,
					phase: r.range(0, 6.28),
					w: r.range(0.55, 0.8),
					lightMat: b.lightMat,
					sprite: b.sprite,
					spriteMat: b.spriteMat,
					blink: !!c[3],
				});
			}

			// ---- static merged extras: cleats + mooring ropes ------
			if (worldPaint.geos.length) {
				const pm = mergedMesh(worldPaint.geos, MAT.paint, 'mooring-cleats', false, true);
				if (pm) g.add(pm);
			}
			if (worldRope.geos.length) {
				const rm = mergedMesh(worldRope.geos, MAT.rope, 'mooring-ropes', false, false);
				if (rm) g.add(rm);
			}

			// ---- harbour night lights ------------------------------
			const pierLamp = new THREE.PointLight(0xffc98a, 0, 5.0, 2);
			pierLamp.position.set(-3.3, L.LEVEL.quay + 0.6, 3.1);
			g.add(pierLamp);
			const marinaLamp = new THREE.PointLight(0xffd6a0, 0, 4.2, 2);
			marinaLamp.position.set(4.5, L.LEVEL.pontoon + 0.7, 2.6);
			g.add(marinaLamp);

			// publish for other modules (gulls, water foam, etc.)
			ctx.world.vessels = {
				count: boats.length,
				boats: boats.map((b) => ({ x: b.g.position.x, z: b.g.position.z, heading: b.heading, len: b.len })),
			};

			console.log('[vessels] fleet built: ' + boats.length + ' boats, ' + buoys.length + ' buoys');

			return {
				update(dt, t) {
					const night = (ctx.env && ctx.env.state && ctx.env.state.night) || 0;
					MAT.glow.emissiveIntensity = 0.05 + night * 5.4;
					pierLamp.intensity = night * 3.2;
					marinaLamp.intensity = night * 2.6;
					for (let i = 0; i < boats.length; i++) {
						const b = boats[i];
						const k = t * b.w + b.phase;
						b.g.position.y = b.baseY + Math.sin(k) * b.bob + Math.sin(k * 0.41 + 1.3) * b.bob * 0.3;
						b.g.rotation.z = b.heel + Math.sin(k * 0.83 + 0.7) * b.roll;
						b.g.rotation.x = Math.sin(k * 0.61 + 2.1) * b.pitch;
					}
					for (let i = 0; i < buoys.length; i++) {
						const b = buoys[i];
						const k = t * b.w + b.phase;
						b.g.position.y = b.baseY + Math.sin(k) * 0.018;
						b.g.rotation.z = Math.sin(k * 0.77 + 0.4) * 0.06;
						b.g.rotation.x = Math.cos(k * 0.63 + 1.2) * 0.05;
						let glow;
						let flash = 0;
						if (b.blink) {
							const f = Math.max(0, Math.sin(t * 1.9 + b.phase));
							flash = f * f * f * f;
							glow = 0.15 + night * (0.5 + 6.2 * flash);
						} else {
							glow = 0.12 + night * 2.0;
						}
						b.lightMat.emissiveIntensity = glow;
						if (b.spriteMat) {
							// fade the halo out when the camera is close so it can
							// never turn into a huge bloom bokeh in the foreground
							let nearFade = 1;
							if (camera) {
								const dx = camera.position.x - b.g.position.x;
								const dy = camera.position.y - b.g.position.y;
								const dz = camera.position.z - b.g.position.z;
								nearFade = U.smoothstep(3.5, 10, Math.sqrt(dx * dx + dy * dy + dz * dz));
							}
							const on = b.blink ? flash : 0.5;
							const base = b.blink ? Math.min(1.0, night * (0.4 + 1.4 * on)) : Math.min(0.9, night * 0.85);
							b.spriteMat.opacity = base * 0.5 * nearFade;
							b.sprite.visible = night > 0.02 && nearFade > 0.04;
						}
					}
				},
			};
		},
	});
})(window.HARBOR);

