/**
 * 21-industrial.js —working quay: rail-mounted container gantry, container
 * stacks, cargo warehouses, fuel tank, narrow-gauge siding + shunting loco.
 * OWNER: t2 structures.
 * ----------------------------------------------------------------------
 * Everything sits on the flat quay terrace (LEVEL.quay = 1.0) north of the
 * quay road; the road corridor is kept clear. The gantry spans the stacks
 * and cantilevers its boom over the road / quay edge to reach ships.
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const L = H.layout;
	const M = H.materials;
	const PI = Math.PI;
	const TAU = PI * 2;
	const DECK = L.LEVEL.quay;

	// ---------------- small geometry helpers ----------------
	function boxG(w, h, d, x, y, z, ry, rx, rz) {
		const g = new THREE.BoxGeometry(w, h, d);
		if (rx) g.rotateX(rx);
		if (rz) g.rotateZ(rz);
		if (ry) g.rotateY(ry);
		g.translate(x, y, z);
		return g;
	}
	function cylG(rt, rb, h, seg, x, y, z, ry, rx, rz) {
		const g = new THREE.CylinderGeometry(rt, rb, h, seg);
		if (rx) g.rotateX(rx);
		if (rz) g.rotateZ(rz);
		if (ry) g.rotateY(ry);
		g.translate(x, y, z);
		return g;
	}
	function tubeG(a, b, radius, seg) {
		const dx = b[0] - a[0],
			dy = b[1] - a[1],
			dz = b[2] - a[2];
		const len = Math.hypot(dx, dy, dz) || 1e-4;
		const g = new THREE.CylinderGeometry(radius, radius, len, seg || 6, 1, false);
		const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(dx / len, dy / len, dz / len));
		g.applyQuaternion(q);
		g.translate((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2);
		return g;
	}
	/** triangular prism with ridge along local X (base on y=0) */
	function prismG(len, depth, height) {
		const hx = len / 2,
			hz = depth / 2;
		const p = [-hx, 0, -hz, -hx, 0, hz, -hx, height, 0, hx, 0, -hz, hx, 0, hz, hx, height, 0];
		const idx = [0, 2, 1, 3, 4, 5, 0, 1, 4, 0, 4, 3, 2, 0, 3, 2, 3, 5, 1, 2, 5, 1, 5, 4];
		const g = new THREE.BufferGeometry();
		g.setAttribute('position', new THREE.Float32BufferAttribute(p, 3));
		const uv = [];
		for (let i = 0; i < 6; i++) uv.push(p[i * 3] * 0.5, p[i * 3 + 1] * 0.5 + p[i * 3 + 2] * 0.5);
		g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
		g.setIndex(idx);
		g.computeVertexNormals();
		return g;
	}
	function mergedMesh(geos, mat, opts) {
		opts = opts || {};
		const m = new THREE.Mesh(U.merge(geos), mat);
		m.castShadow = opts.cast !== false;
		m.receiveShadow = opts.receive !== false;
		if (opts.name) m.name = opts.name;
		return m;
	}
	function instanced(group, geo, mat, list, opts) {
		opts = opts || {};
		if (!list.length) return null;
		const m = U.instances(geo, mat, list, { cast: opts.cast !== false, receive: opts.receive !== false });
		if (opts.name) m.name = opts.name;
		group.add(m);
		return m;
	}

	H.register('industrial', {
		create(ctx) {
			const g = ctx.group('industrial');
			const rng = U.rng(5150);
			const r2 = U.rng(88112);

			// ---------------- shared materials ----------------
			const brick = M.get('brick');
			const concrete = M.get('concrete');
			const concreteDark = M.get('concreteDark');
			const cobble = M.get('cobble');
			const wood = M.get('wood');
			const woodDark = M.get('woodDark');
			const woodLight = M.get('woodLight');
			const steel = M.get('steel');
			const steelDark = M.get('steelDark');
			const rust = M.get('rusted');
			const brass = M.get('brass');
			const roofRed = M.roofTile('#a9503d');
			const roofBrown = M.roofTile('#6f4a3a');
			const roofSlate = M.roofTile('#4a5560');
			const glass = M.get('glass');
			const craneYellow = M.painted('#e0a92f', { roughness: 0.52, metalness: 0.35 });
			const paintBlack = M.painted('#2c2a26', { roughness: 0.7 });
			const paintRed = M.painted('#a83a2c', { roughness: 0.55 });
			const paintCream = M.painted('#e8ddc4', { roughness: 0.7 });
			const paintGreen = M.painted('#3c5c4a', { roughness: 0.6, metalness: 0.15 });
			const paintGrey = M.painted('#78807f', { roughness: 0.75, metalness: 0.2 });
			const lampMat = M.emissive('#ffd9a0', 0.2);
			const signalMat = M.emissive('#ff5a3c', 0.2);
			const glassDS = M.unique('glass', { color: 0x2d3f47 });

			// ---------------- texture helpers ----------------
			const containerTex = U.surface({
				size: 128,
				seed: 7,
				cacheKey: 't2container128',
				color(c2, s) {
					c2.fillStyle = '#cfcfc8';
					c2.fillRect(0, 0, s, s);
					for (let x = 0; x < s; x += 10) {
						c2.fillStyle = 'rgba(90,90,86,0.35)';
						c2.fillRect(x, 0, 2.5, s);
						c2.fillStyle = 'rgba(255,255,255,0.30)';
						c2.fillRect(x + 3.5, 0, 1.5, s);
					}
					// horizontal top/bottom frame
					c2.fillStyle = 'rgba(70,70,66,0.5)';
					c2.fillRect(0, 0, s, 7);
					c2.fillRect(0, s - 7, s, 7);
					// door seam + handles
					c2.fillStyle = 'rgba(50,50,46,0.65)';
					c2.fillRect(s * 0.68, 8, 2.5, s - 16);
					c2.fillRect(s * 0.84, 8, 2.5, s - 16);
					c2.fillStyle = 'rgba(40,40,36,0.75)';
					c2.fillRect(s * 0.62, s * 0.45, 4, 2.5);
					c2.fillRect(s * 0.90, s * 0.45, 4, 2.5);
				},
			});
			const contMat = new THREE.MeshStandardMaterial({ map: containerTex.map, color: 0xffffff, roughness: 0.62, metalness: 0.3 });
			const contGeo = new THREE.BoxGeometry(0.62, 0.26, 0.26);

			const corrTex = U.surface({
				size: 128,
				seed: 11,
				cacheKey: 't2corrugated128',
				color(c2, s) {
					c2.fillStyle = '#b9b6ad';
					c2.fillRect(0, 0, s, s);
					for (let y = 0; y < s; y += 9) {
						c2.fillStyle = 'rgba(80,78,72,0.35)';
						c2.fillRect(0, y, s, 2);
						c2.fillStyle = 'rgba(255,255,255,0.30)';
						c2.fillRect(0, y + 3, s, 2);
					}
				},
			});
			const shutterMat = new THREE.MeshStandardMaterial({ map: corrTex.map, color: 0x9aa0a3, roughness: 0.55, metalness: 0.5 });

			// hard standing: gravel yard surfaces (so the working quay does not
			// read as a lawn). Kept clear of the quay road corridor.
			const yardTex = U.surface({
				size: 256,
				seed: 23,
				cacheKey: 't2yard256',
				repeat: [1.4, 1.4],
				color(c2, s, r) {
					c2.fillStyle = '#8b857a';
					c2.fillRect(0, 0, s, s);
					for (let i = 0; i < 4200; i++) {
						const v = r.range(0, 1);
						c2.fillStyle = v < 0.5 ? `rgba(66,62,56,${r.range(0.05, 0.18)})` : `rgba(196,190,178,${r.range(0.04, 0.15)})`;
						c2.fillRect(r.range(0, s), r.range(0, s), r.range(0.8, 2.6), r.range(0.8, 2.6));
					}
					for (let i = 0; i < 9; i++) {
						const x = r.range(0, s),
							y = r.range(0, s),
							rad = r.range(14, 62);
						const g = c2.createRadialGradient(x, y, 0, x, y, rad);
						g.addColorStop(0, r.chance(0.35) ? 'rgba(38,34,30,0.32)' : 'rgba(158,152,140,0.18)');
						g.addColorStop(1, 'rgba(0,0,0,0)');
						c2.fillStyle = g;
						c2.fillRect(x - rad, y - rad, rad * 2, rad * 2);
					}
				},
			});
			const yardMat = new THREE.MeshStandardMaterial({ map: yardTex.map, color: 0xa39c8e, roughness: 0.97, metalness: 0.0 });
			{
				const surf = [];
				const addSurf = (w, d, x, z, rot) => surf.push(boxG(w, 0.05, d, x, DECK + 0.0, z, rot || 0));
				addSurf(5.3, 1.75, -0.3, -1.2); // container / gantry working area
				addSurf(3.05, 1.95, -4.6, -1.2, 0.1); // cargo warehouse apron
				addSurf(2.45, 1.75, -7.7, -1.15, 0.08); // boat shed apron
				addSurf(7.2, 0.78, -6.0, 0.13); // trackside strip
				g.add(mergedMesh(surf, yardMat, { name: 'yard-hardstanding', cast: false, receive: true }));
			}

			// sign helper
			function sign(text, worldW, color) {
				const t = U.textTexture(text, { font: '700 96px "Segoe UI", "Microsoft YaHei", sans-serif', padding: 26, color: color || '#26221c', background: 'rgba(0,0,0,0)' });
				const mat = new THREE.MeshBasicMaterial({ map: t.texture, transparent: true, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
				return new THREE.Mesh(new THREE.PlaneGeometry(worldW, worldW / t.aspect), mat);
			}

			// ==================================================================
			// WAREHOUSES
			// ==================================================================
			const whGeos = {};
			const bag = (k) => (whGeos[k] = whGeos[k] || []);
			const detail = { crates: [], barrels: [], pallets: [], lamps: [] };
			const whLights = [];
			const emissiveGeos = [];

			function bake(list, geo, rot, cx, baseY, cz) {
			geo.rotateY(rot);
				geo.translate(cx, baseY, cz);
				list.push(geo);
			}

			/**
			 * buildWarehouse: local coords: x = long axis, z = depth, y up.
			 * south face (+z) faces the road / water.
			 */
			function buildWarehouse(spec) {
				const rot = spec.rot,
					cx = spec.pos[0],
					cz = spec.pos[1],
					baseY = spec.baseY,
					W = spec.w,
					D = spec.d,
					HL = spec.eaves,
					HR = spec.ridge;
				const B = (k, geo) => bake(bag(k), geo, rot, cx, baseY, cz);
				// plinth
				B('concreteDark', boxG(W + 0.18, 0.14, D + 0.18, 0, 0.07, 0));
				// brick body
				const wallT = 0.09;
				B(spec.lowerMat || 'brick', boxG(W, HL, D, 0, 0.14 + HL / 2, 0));
				// corner pilasters
				for (const sx of [-1, 1])
					for (const sz of [-1, 1]) B(spec.lowerMat || 'brick', boxG(0.16, HL, 0.16, sx * (W / 2 - 0.02), 0.14 + HL / 2, sz * (D / 2 - 0.02)));
				// eaves band
				B('paintCream', boxG(W + 0.1, 0.06, D + 0.1, 0, 0.14 + HL - 0.03, 0));
				// gable ends + roof (spec.ridge = extra height of the ridge over the eaves)
				const ridgeY = 0.14 + HL + HR;
				for (const sx of [-1, 1]) {
					const gp = prismG(0.12, D, HR);
					gp.translate(0, 0.14 + HL, 0);
					B(spec.lowerMat || 'brick', gp);
				}
				const slopeAngle = Math.atan2(HR, D / 2);
				const slopeLen = Math.hypot(D / 2, HR) + 0.12;
				for (const sz of [1, -1]) {
					const g = new THREE.BoxGeometry(W + 0.24, 0.07, slopeLen);
					g.rotateX(sz * slopeAngle);
					g.translate(0, 0.14 + HL + HR / 2 + 0.02, (sz * D) / 4);
					B(spec.roof, g);
				}
				B('roofRidge', cylG(0.05, 0.05, W + 0.28, 8, 0, ridgeY + 0.03, 0, 0, 0, PI / 2));
				// roof vents
				for (let i = 0; i < 2; i++) {
					const vx = (i - 0.5) * W * 0.45;
					B('roofRidge', cylG(0.05, 0.07, 0.14, 8, vx, ridgeY + 0.1, 0));
					B('steelDark', cylG(0.09, 0.09, 0.03, 8, vx, ridgeY + 0.18, 0));
				}
				// south facade: loading apron + roller doors
				const doorW = Math.min(0.62, W * 0.34);
				const nDoors = spec.doors || 2;
				// low loading apron along the wall (the rail siding runs past it)
				B('concrete', boxG(W * 0.92, 0.14, 0.16, 0, 0.07, D / 2 + 0.08));
				for (let i = 0; i < nDoors; i++) {
					const dx = nDoors === 1 ? 0 : (i - (nDoors - 1) / 2) * (W * 0.52);
					// door frame
					B('steelDark', boxG(doorW + 0.1, 0.62, 0.05, dx, 0.14 + 0.31, D / 2 + 0.02));
					// roller shutter
					spec._shutters = spec._shutters || [];
					spec._shutters.push({ x: dx, y: 0.14 + 0.3, w: doorW });
					// lintel
					B('paintCream', boxG(doorW + 0.16, 0.07, 0.09, dx, 0.14 + 0.63, D / 2 + 0.03));
					// small canopy
					B('steelDark', boxG(doorW + 0.2, 0.03, 0.22, dx, 0.14 + 0.66, D / 2 + 0.13));
				}
				// windows along the long walls
				for (let i = 0; i < 3; i++) {
					const wx = (i - 1) * W * 0.28;
					for (const sz of [1, -1]) {
						B('paintCream', boxG(0.26, 0.3, 0.05, wx, 0.14 + HL * 0.62, sz * (D / 2 + 0.005)));
						B('glass', boxG(0.18, 0.22, 0.03, wx, 0.14 + HL * 0.62, sz * (D / 2 + 0.03)));
					}
				}
				// high gable windows
				for (const sx of [-1, 1]) B('glass', boxG(0.03, 0.16, 0.3, sx * (W / 2 + 0.005), 0.14 + HL + HR * 0.42, 0));
				// downpipes
				for (const sx of [-1, 1]) B('steelDark', cylG(0.022, 0.022, HL + 0.1, 6, sx * (W / 2 - 0.06), 0.14 + (HL + 0.1) / 2, D / 2 + 0.06));
				// wall lamps above doors
				for (let i = 0; i < nDoors; i++) {
					const dx = nDoors === 1 ? 0 : (i - (nDoors - 1) / 2) * (W * 0.52);
					emissiveGeos.push({ local: [dx, 0.14 + 0.78, D / 2 + 0.12], rot, cx, baseY, cz, w: 0.07 });
				}
				// big sign on the south wall above the doors
				const sg = sign(spec.sign || 'WAREHOUSE', spec.signW || 1.1, spec.signColor);
				const signZ = D / 2 + 0.06;
				sg.position.set(cx + Math.sin(rot) * signZ, baseY + 0.14 + HL * 0.8, cz + Math.cos(rot) * signZ);
				sg.rotation.y = rot;
				g.add(sg);
				// shutters as real meshes
				for (const sh of spec._shutters) {
					const m = new THREE.Mesh(new THREE.BoxGeometry(sh.w, 0.54, 0.03), shutterMat);
					m.position.set(sh.x, sh.y, D / 2 + 0.055);
					m.position.applyAxisAngle(new THREE.Vector3(0, 1, 0), rot);
					m.position.x += cx;
					m.position.z += cz;
					m.position.y += baseY;
					m.rotation.y = rot;
					m.receiveShadow = true;
					g.add(m);
				}
				// exterior ladder on the east gable
				for (let i = 0; i < 8; i++) B('steelDark', boxG(0.03, 0.02, 0.26, W / 2 + 0.08, 0.2 + i * 0.14, 0.2));
				for (const dz of [-0.1, 0.1]) B('steelDark', cylG(0.014, 0.014, 1.1, 5, W / 2 + 0.21, 0.72, dz + 0.2));
				// loading props along the apron / east gable
				for (let i = 0; i < 4; i++) {
					const lx = -W * 0.36 + i * 0.18;
					const lz = D / 2 + 0.22;
					const wx = cx + lx * Math.cos(rot) + lz * Math.sin(rot);
					const wz = cz - lx * Math.sin(rot) + lz * Math.cos(rot);
					if (rng.chance(0.5)) detail.pallets.push({ x: wx, y: baseY + 0.16, z: wz, rot });
					else detail.crates.push({ x: wx, y: baseY + 0.2, z: wz, rot, s: rng.range(0.8, 1.2) });
				}
				for (let i = 0; i < 3; i++) {
					const lx = W / 2 + 0.28 + rng.range(-0.06, 0.06);
					const lz = D * 0.18 + (i - 1) * 0.16;
					detail.barrels.push({ x: cx + lx * Math.cos(rot) + lz * Math.sin(rot), y: baseY + 0.12, z: cz - lx * Math.sin(rot) + lz * Math.cos(rot), rot });
				}
			}

			buildWarehouse({
				pos: [-4.6, -1.2],
				rot: 0.1,
				baseY: DECK,
				w: 2.5,
				d: 1.25,
				eaves: 1.02,
				ridge: 0.5,
				roof: 'roofRed',
				doors: 2,
				sign: 'HARBOUR CO. · WAREHOUSE 3',
				signW: 1.25,
				signColor: '#20242a',
			});
			buildWarehouse({
				pos: [-7.7, -1.15],
				rot: 0.08,
				baseY: DECK,
				w: 1.9,
				d: 1.05,
				eaves: 0.78,
				ridge: 0.36,
				roof: 'roofBrown',
				doors: 1,
				sign: 'BOAT SHED',
				signW: 0.85,
				signColor: '#332a20',
			});

			// merge warehouse material bags
			const whMaterials = {
				brick,
				concrete,
				concreteDark,
				cobble,
				wood,
				woodDark,
				paintCream,
				paintBlack,
				steelDark,
				steel,
				glassDS,
				roofRed,
				roofBrown,
				roofSlate,
				roofRidge: M.painted('#5d4438', { roughness: 0.8 }),
				rust,
			};
			for (const key of Object.keys(whGeos)) {
				const list = whGeos[key];
				if (!list.length) continue;
				const mat = whMaterials[key] || concrete;
				g.add(mergedMesh(list, mat, { name: 'warehouse-' + key }));
			}
			// warehouse wall lamps (emissive)
			{
				const lampGeos = [];
				for (const e of emissiveGeos) {
					const gq = new THREE.BoxGeometry(0.06, 0.06, 0.05);
					gq.translate(e.local[0], e.local[1], e.local[2]);
					gq.rotateY(e.rot);
					gq.translate(e.cx, e.baseY, e.cz);
					lampGeos.push(gq);
				}
				if (lampGeos.length) g.add(mergedMesh(lampGeos, lampMat, { name: 'warehouse-lamps', cast: false, receive: false }));
			}

			// ==================================================================
			// CONTAINER YARD (instanced, per-instance colour)
			// ==================================================================
			const contList = []; // [x,y,z,rotY]
			const contColors = [];
			const CONT_COLORS = ['#2c6469', '#94402f', '#3a5878', '#54683f', '#b08d45', '#7f8487', '#61433a', '#a06238'];
			const rows = [-1.55, -1.2, -0.85];
			const stackXs = [-2.25, -1.55, -0.85, -0.15];
			for (const rz of rows) {
				for (const bx of stackXs) {
					const stack = r2.int(1, 3);
					const rot = r2.chance(0.82) ? 0 : PI / 2;
					for (let s = 0; s < stack; s++) {
						contList.push([bx + r2.range(-0.02, 0.02), DECK + 0.14 + s * 0.27, rz + r2.range(-0.015, 0.015), rot]);
						contColors.push(CONT_COLORS[r2.int(0, CONT_COLORS.length - 1)]);
					}
				}
			}
			// a few containers staged on the west ferry apron
			for (const [bx, bz] of [
				[-9.55, 3.12],
				[-9.0, 3.2],
				[-9.3, 3.38],
			]) {
				for (let s = 0; s < (r2.chance(0.5) ? 2 : 1); s++) {
					contList.push([bx + r2.range(-0.02, 0.02), DECK + 0.14 + s * 0.27, bz, r2.chance(0.5) ? 0 : PI / 2]);
					contColors.push(CONT_COLORS[r2.int(0, CONT_COLORS.length - 1)]);
				}
			}
			{
				const im = new THREE.InstancedMesh(contGeo, contMat, contList.length);
				const dummy = new THREE.Object3D();
				const col = new THREE.Color();
				for (let i = 0; i < contList.length; i++) {
					const t = contList[i];
					dummy.position.set(t[0], t[1], t[2]);
					dummy.rotation.set(0, t[3], 0);
					dummy.scale.set(1, 1, 1);
					dummy.updateMatrix();
					im.setMatrixAt(i, dummy.matrix);
					col.set(contColors[i]);
					im.setColorAt(i, col);
				}
				im.instanceMatrix.needsUpdate = true;
				if (im.instanceColor) im.instanceColor.needsUpdate = true;
				im.castShadow = true;
				im.receiveShadow = true;
				im.name = 'containers';
				g.add(im);
			}
			// lashing rods + corner posts between stacked boxes
			{
				const rods = [];
				for (const t of contList) {
					if (t[1] > DECK + 0.2) continue;
					// vertical lashing bars at the corners of the bottom box
					const s = Math.sin(t[3]),
						c = Math.cos(t[3]);
					for (const lx of [-0.3, 0.3]) {
						for (const lz of [-0.12, 0.12]) {
							const x = t[0] + lx * c + lz * s,
								z = t[2] - lx * s + lz * c;
							rods.push(cylG(0.012, 0.012, 0.56, 4, x, DECK + 0.42, z));
						}
					}
				}
				if (rods.length) g.add(mergedMesh(rods, steelDark, { name: 'container-lashings', cast: false, receive: false }));
			}
			// two partially open containers at the end of the stack rows
			for (const spec of [
				{ x: -0.22, z: -0.88, rot: 0.12 + PI / 2 },
				{ x: -2.2, z: -1.52, rot: -0.15 },
			]) {
				const grp = U.group(g, 'open-container');
				const body = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.26, 0.26), contMat);
				body.castShadow = true;
				grp.add(body);
				const inner = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.2, 0.2), paintBlack);
				inner.position.set(-0.02, 0.02, 0);
				grp.add(inner);
				const door = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.24, 0.24), contMat);
				door.position.set(0.31, 0, 0.14);
				door.rotation.y = 0.9;
				grp.add(door);
				grp.position.set(spec.x, DECK + 0.27, spec.z);
				grp.rotation.y = spec.rot;
			}

			// ==================================================================
			// GANTRY CRANE —portal on rails, cantilever boom over the water
			// ==================================================================
			const crane = U.group(g, 'gantry-crane');
			const craneMovable = U.group(crane, 'travel');
			const RAIL_X0 = -2.85,
				RAIL_X1 = 2.05;
			const RAIL_ZF = -0.6,
				RAIL_ZB = -1.8;
			const GIRDER_Y = DECK + 2.13;
			const PORTAL_HALF = 0.44; // half distance between the two legs along x
			const craneStatic = U.group(crane, 'static');
			const cy = [];
			const cyDark = [];
			const cyRust = [];
			const craneLights = [];
			// rails on the deck
			for (const rz of [RAIL_ZF, RAIL_ZB]) {
				cyDark.push(boxG(RAIL_X1 - RAIL_X0 + 0.5, 0.05, 0.07, (RAIL_X0 + RAIL_X1) / 2, DECK + 0.03, rz));
				// rail ties
				for (let x = RAIL_X0 - 0.2; x <= RAIL_X1 + 0.2; x += 0.24) cyDark.push(boxG(0.06, 0.02, 0.28, x, DECK + 0.01, rz));
			}
			// portal frame (moves along x)
			const lm = U.group(craneMovable, 'frame');
			const frameGeos = [];
			const frameDark = [];
			for (const rz of [RAIL_ZF, RAIL_ZB]) {
				for (const sx of [-1, 1]) {
					const lx = sx * PORTAL_HALF;
					frameGeos.push(boxG(0.1, GIRDER_Y - DECK, 0.1, lx, DECK + (GIRDER_Y - DECK) / 2, rz));
					// leg foot
					frameDark.push(boxG(0.22, 0.08, 0.22, lx, DECK + 0.06, rz));
					// warning stripes on the lower leg
					for (let k = 0; k < 4; k++) frameDark.push(boxG(0.115, 0.09, 0.115, lx, DECK + 0.16 + k * 0.17, rz));
				}
				// portal cross beam (z direction at the top)
				frameGeos.push(boxG(0.1, 0.14, Math.abs(RAIL_ZF - RAIL_ZB), 0, GIRDER_Y - 0.18, rz));
			}
			// longitudinal top beams (z rails for the trolley)
			for (const sx of [-1, 1]) frameGeos.push(boxG(0.12, 0.18, Math.abs(RAIL_ZF - RAIL_ZB) + 2.6, sx * PORTAL_HALF, GIRDER_Y - 0.18, -0.2));
			// diagonal bracing on the portals
			for (const rz of [RAIL_ZF, RAIL_ZB]) {
				frameGeos.push(tubeG([-PORTAL_HALF, DECK + 0.3, rz], [PORTAL_HALF, GIRDER_Y - 0.35, rz], 0.026, 5));
				frameGeos.push(tubeG([PORTAL_HALF, DECK + 0.3, rz], [-PORTAL_HALF, GIRDER_Y - 0.35, rz], 0.026, 5));
			}
			// main girder box (spans z over the quay + cantilever)
			const GIRDER_Z0 = -2.25,
				GIRDER_Z1 = 2.3;
			frameGeos.push(boxG(0.3, 0.24, GIRDER_Z1 - GIRDER_Z0, 0, GIRDER_Y, (GIRDER_Z0 + GIRDER_Z1) / 2));
			frameGeos.push(boxG(0.1, 0.1, GIRDER_Z1 - GIRDER_Z0, 0.16, GIRDER_Y - 0.2, (GIRDER_Z0 + GIRDER_Z1) / 2));
			frameGeos.push(boxG(0.1, 0.1, GIRDER_Z1 - GIRDER_Z0, -0.16, GIRDER_Y - 0.2, (GIRDER_Z0 + GIRDER_Z1) / 2));
			// boom tip block + sheave pack
			frameGeos.push(boxG(0.2, 0.26, 0.26, 0, GIRDER_Y + 0.04, GIRDER_Z1 - 0.12));
			frameDark.push(boxG(0.4, 0.22, 0.34, 0, GIRDER_Y - 0.4, GIRDER_Z1 - 0.14));
			for (const sx of [-0.11, 0.11]) frameDark.push(cylG(0.09, 0.09, 0.05, 10, sx, GIRDER_Y - 0.4, GIRDER_Z1 - 0.14, 0, 0, PI / 2));
			// tip sheave + hook cable
			frameDark.push(cylG(0.05, 0.05, 0.06, 8, 0, GIRDER_Y - 0.16, GIRDER_Z1 - 0.3, 0, 0, PI / 2));
			frameDark.push(tubeG([0, GIRDER_Y - 0.2, GIRDER_Z1 - 0.3], [0, GIRDER_Y - 0.72, GIRDER_Z1 - 0.3], 0.007, 3));
			frameDark.push(boxG(0.09, 0.12, 0.05, 0, GIRDER_Y - 0.8, GIRDER_Z1 - 0.3));
			// A-frame mast over the rear portal + tie rods to the boom
			frameGeos.push(boxG(0.07, 0.5, 0.07, -0.3, GIRDER_Y + 0.24, RAIL_ZB - 0.15, 0, 0, -0.16));
			frameGeos.push(boxG(0.07, 0.5, 0.07, 0.3, GIRDER_Y + 0.24, RAIL_ZB - 0.15, 0, 0, 0.16));
			frameGeos.push(boxG(0.66, 0.06, 0.06, 0, GIRDER_Y + 0.49, RAIL_ZB - 0.15));
			frameDark.push(tubeG([-0.3, GIRDER_Y + 0.5, RAIL_ZB - 0.15], [0, GIRDER_Y + 0.04, GIRDER_Z1 - 0.12], 0.008, 3));
			frameDark.push(tubeG([0.3, GIRDER_Y + 0.5, RAIL_ZB - 0.15], [0, GIRDER_Y + 0.04, GIRDER_Z1 - 0.12], 0.008, 3));
			// machinery house on the back of the girder
			frameGeos.push(boxG(0.34, 0.3, 0.46, 0, GIRDER_Y + 0.06, RAIL_ZB + 0.28));
			// operator cabin under the girder near the front leg
			const cab = [];
			cab.push(boxG(0.3, 0.26, 0.34, 0.42, GIRDER_Y - 0.55, -0.15));
			const cabMesh = mergedMesh(cab, paintCream, { cast: true, receive: true, name: 'crane-cab' });
			lm.add(cabMesh);
			const cabGlass = [];
			cabGlass.push(boxG(0.02, 0.16, 0.3, 0.575, GIRDER_Y - 0.54, -0.15));
			cabGlass.push(boxG(0.28, 0.16, 0.02, 0.42, GIRDER_Y - 0.54, -0.325));
			lm.add(mergedMesh(cabGlass, glass));
			// access ladder on the rear leg
			for (let k = 0; k < 12; k++) frameDark.push(boxG(0.19, 0.02, 0.03, -PORTAL_HALF, DECK + 0.25 + k * 0.18, RAIL_ZB - 0.08));
			for (const sx of [-1, 1]) frameDark.push(cylG(0.012, 0.012, 2.2, 5, -PORTAL_HALF + sx * 0.1, DECK + 1.25, RAIL_ZB - 0.08));
			// small worn rust plates
			for (let i = 0; i < 6; i++) cyRust.push(boxG(0.12, 0.16, 0.012, -PORTAL_HALF + rng.range(-0.02, 0.02), DECK + 0.6 + rng.range(0, 1.4), RAIL_ZF + 0.055));
			lm.add(mergedMesh(frameGeos, craneYellow, { name: 'crane-frame', cast: true, receive: true }));
			lm.add(mergedMesh(frameDark, paintBlack, { name: 'crane-dark', cast: false, receive: true }));
			lm.add(mergedMesh(cyRust, rust, { name: 'crane-rust', cast: false, receive: false }));
			if (cyDark.length) craneStatic.add(mergedMesh(cyDark, steelDark, { name: 'crane-rails', cast: false, receive: true }));

			// trolley + hoist + hanging load
			const trolley = U.group(craneMovable, 'trolley');
			{
				const tg = [];
				const td = [];
				tg.push(boxG(0.34, 0.12, 0.3, 0, GIRDER_Y - 0.32, 0));
				td.push(boxG(0.4, 0.06, 0.36, 0, GIRDER_Y - 0.24, 0));
				// wheels
				for (const sx of [-1, 1]) for (const sz of [-1, 1]) td.push(cylG(0.055, 0.055, 0.04, 8, sx * 0.15, GIRDER_Y - 0.2, sz * 0.1, 0, 0, PI / 2));
				// hoist drum + sheave pack + side guard rails
				tg.push(cylG(0.09, 0.09, 0.26, 10, 0, GIRDER_Y - 0.42, 0, 0, 0, PI / 2));
				td.push(cylG(0.05, 0.05, 0.06, 8, 0.12, GIRDER_Y - 0.46, 0, 0, 0, PI / 2));
				td.push(cylG(0.05, 0.05, 0.06, 8, -0.12, GIRDER_Y - 0.46, 0, 0, 0, PI / 2));
				for (const sx of [-1, 1]) td.push(boxG(0.03, 0.22, 0.28, sx * 0.2, GIRDER_Y - 0.36, 0));
				trolley.add(mergedMesh(tg, craneYellow, { name: 'trolley-body', cast: true, receive: true }));
				trolley.add(mergedMesh(td, paintBlack, { name: 'trolley-dark', cast: false, receive: true }));
				// cable + spreader as a small group that swings gently
				const hoist = U.group(trolley, 'hoist');
				const cableGeos = [];
				for (const sx of [-0.12, 0.12]) cableGeos.push(cylG(0.007, 0.007, 0.56, 4, sx, GIRDER_Y - 0.72, 0));
				hoist.add(mergedMesh(cableGeos, steelDark, { name: 'hoist-cable', cast: false, receive: false }));
				const spreadGeos = [boxG(0.62, 0.05, 0.07, 0, GIRDER_Y - 1.02, 0), boxG(0.56, 0.07, 0.05, 0, GIRDER_Y - 1.16, 0)];
				for (const sx of [-0.25, 0.25]) for (const sz of [-0.1, 0.1]) spreadGeos.push(boxG(0.05, 0.1, 0.04, sx, GIRDER_Y - 1.22, sz));
				spreadGeos.push(tubeG([-0.3, GIRDER_Y - 0.98, 0], [0, GIRDER_Y - 0.86, 0], 0.01, 3));
				spreadGeos.push(tubeG([0.3, GIRDER_Y - 0.98, 0], [0, GIRDER_Y - 0.86, 0], 0.01, 3));
				const spread = mergedMesh(spreadGeos, paintRed, { name: 'spreader', cast: true });
				hoist.add(spread);
				const load = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.25, 0.24), contMat.clone());
				load.material.color = new THREE.Color('#a64532');
				load.position.set(0, GIRDER_Y - 1.34, 0);
				load.castShadow = true;
				hoist.add(load);
				trolley.userData.hoist = hoist;
				trolley.userData.load = load;
			}
			// red aircraft warning light + crane point light
			{
				const s = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), signalMat);
				s.position.set(0, GIRDER_Y + 0.2, GIRDER_Z1 - 0.05);
				craneMovable.add(s);
				const pl = new THREE.PointLight(0xff7a4a, 0, 4.5, 2);
				pl.position.set(0, GIRDER_Y + 0.2, GIRDER_Z1 - 0.05);
				craneMovable.add(pl);
				craneLights.push({ light: pl, base: 1.2, mat: signalMat, blink: true });
				const lamp = new THREE.PointLight(0xffd9a0, 0, 6, 2);
				lamp.position.set(0, GIRDER_Y - 0.4, 1.2);
				craneMovable.add(lamp);
				craneLights.push({ light: lamp, base: 4.0, mat: lampMat, blink: false });
			}

			// ==================================================================
			// FUEL TANK + bund
			// ==================================================================
			const fuel = U.group(g, 'fuel-depot');
			{
				const fx = 2.75,
					fz = -1.05;
				const pad = [boxG(1.24, 0.12, 1.24, fx, DECK + 0.06, fz)];
				fuel.add(mergedMesh(pad, concreteDark, { name: 'fuel-pad', cast: true, receive: true }));
				// bund wall (1.05 x 1.05 so it stays clear of the quay road)
				const bund = [];
				for (const [w, d, ox, oz] of [
					[1.05, 0.08, 0, 0.485],
					[1.05, 0.08, 0, -0.485],
					[0.08, 1.05, 0.485, 0],
					[0.08, 1.05, -0.485, 0],
				]) bund.push(boxG(w, 0.28, d, fx + ox, DECK + 0.2, fz + oz));
				fuel.add(mergedMesh(bund, concrete, { name: 'fuel-bund', cast: true, receive: true }));
				// tank
				const tank = new THREE.Mesh(new THREE.CylinderGeometry(0.33, 0.33, 0.7, 20), paintGreen);
				tank.position.set(fx, DECK + 0.47, fz);
				tank.castShadow = true;
				tank.receiveShadow = true;
				fuel.add(tank);
				const dome = new THREE.Mesh(new THREE.SphereGeometry(0.33, 20, 10, 0, TAU, 0, PI / 2), paintGreen);
				dome.position.set(fx, DECK + 0.82, fz);
				dome.castShadow = true;
				fuel.add(dome);
				// bands + ladder + pipes
				const tb = [];
				for (const hy of [0.24, 0.5, 0.75]) tb.push(cylG(0.335, 0.335, 0.035, 20, fx, DECK + hy, fz));
				fuel.add(mergedMesh(tb, rust, { name: 'fuel-bands', cast: false, receive: true }));
				const pipes = [];
				pipes.push(cylG(0.03, 0.03, 0.5, 6, fx + 0.34, DECK + 0.32, fz, 0, 0, 0.06));
				pipes.push(cylG(0.022, 0.022, 0.4, 6, fx + 0.4, DECK + 0.58, fz + 0.1, 0, PI / 2));
				pipes.push(new THREE.TorusGeometry(0.05, 0.011, 4, 10).translate(fx + 0.4, DECK + 0.38, fz + 0.26));
				fuel.add(mergedMesh(pipes, steel, { name: 'fuel-pipes', cast: false, receive: true }));
				// ladder
				for (let k = 0; k < 7; k++) tb.push(boxG(0.14, 0.02, 0.03, fx - 0.09, DECK + 0.18 + k * 0.1, fz - 0.34));
				for (const sx of [-1, 1]) tb.push(cylG(0.01, 0.01, 0.75, 4, fx - 0.09 + sx * 0.07, DECK + 0.5, fz - 0.34));
				fuel.add(mergedMesh(tb, rust, { name: 'fuel-ladder', cast: false, receive: true }));
				// warning sign
				const fsg = sign('FUEL', 0.2, '#f0e6cf');
				fsg.material.map = U.textTexture('FUEL', { font: '800 64px sans-serif', padding: 18, color: '#efe6d2', background: '#8a2f24' }).texture;
				fsg.position.set(fx, DECK + 0.4, fz + 0.5);
				fuel.add(fsg);
				// lamp
				const fl = new THREE.PointLight(0xffd9a0, 0, 4, 2);
				fl.position.set(fx, DECK + 1.1, fz + 0.5);
				fuel.add(fl);
				craneLights.push({ light: fl, base: 1.4, mat: lampMat, blink: false });
				const flm = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.06, 0.05), lampMat);
				flm.position.set(fx, DECK + 1.0, fz + 0.55);
				fuel.add(flm);
			}

			// ==================================================================
			// NARROW GAUGE RAILWAY + SHUNTING LOCO
			// ==================================================================
			const rail = U.group(g, 'railway');
			// curved siding: out of the engine shed, round the boat shed, then
			// straight along the front of the warehouses to the quay
			const TRACK = [
				[-8.83, -1.5],
				[-8.86, -0.95],
				[-8.8, -0.45],
				[-8.48, -0.12],
				[-7.95, 0.06],
				[-7.3, 0.14],
				[-2.55, 0.14],
			];
			const TRACK_Z = 0.14;
			const TRACK_X0 = -7.9,
				TRACK_X1 = -2.55;
			// sample the track polyline
			function trackLen() {
				let s = 0;
				for (let i = 1; i < TRACK.length; i++) s += Math.hypot(TRACK[i][0] - TRACK[i - 1][0], TRACK[i][1] - TRACK[i - 1][1]);
				return s;
			}
			const TRACK_LEN = trackLen();
			function trackAt(s) {
				let acc = 0;
				for (let i = 1; i < TRACK.length; i++) {
					const a = TRACK[i - 1],
						b = TRACK[i];
					const seg = Math.hypot(b[0] - a[0], b[1] - a[1]);
					if (s <= acc + seg || i === TRACK.length - 1) {
						const f = U.clamp((s - acc) / seg, 0, 1);
						const tx = (b[0] - a[0]) / seg,
							tz = (b[1] - a[1]) / seg;
						return { x: U.lerp(a[0], b[0], f), z: U.lerp(a[1], b[1], f), tx, tz, ang: Math.atan2(tx, tz) };
					}
					acc += seg;
				}
				return { x: TRACK[0][0], z: TRACK[0][1], tx: 1, tz: 0, ang: PI / 2 };
			}
			{
				// ballast bed (one merged ribbon)
				const ballast = [];
				const railG = [];
				for (let i = 1; i < TRACK.length; i++) {
					const a = TRACK[i - 1],
						b = TRACK[i];
					const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
					const ang = Math.atan2(b[0] - a[0], b[1] - a[1]);
					const nx = -Math.cos(ang),
						nz = Math.sin(ang);
					ballast.push(boxG(0.46, 0.1, len + 0.06, (a[0] + b[0]) / 2, DECK + 0.05, (a[1] + b[1]) / 2, ang));
					for (const off of [-0.115, 0.115]) railG.push(boxG(0.03, 0.03, len + 0.04, (a[0] + b[0]) / 2 + nx * off, DECK + 0.14, (a[1] + b[1]) / 2 + nz * off, ang));
				}
				rail.add(mergedMesh(ballast, concreteDark, { name: 'rail-ballast', cast: false, receive: true }));
				rail.add(mergedMesh(railG, steel, { name: 'rail-rails', cast: false, receive: true }));
				// sleepers
				const sleepers = [];
				for (let s = 0.1; s < TRACK_LEN; s += 0.17) {
					const p = trackAt(s);
					sleepers.push([p.x, DECK + 0.105, p.z, p.ang]);
				}
				instanced(g, new THREE.BoxGeometry(0.055, 0.028, 0.34), woodDark, sleepers, { cast: false, receive: true, name: 'rail-sleepers' });
				// buffer stop at the east end
				const buffers = [];
				buffers.push(boxG(0.07, 0.12, 0.36, TRACK_X1 + 0.16, DECK + 0.16, TRACK_Z));
				buffers.push(boxG(0.16, 0.05, 0.4, TRACK_X1 + 0.2, DECK + 0.1, TRACK_Z));
				for (const dz of [-0.13, 0.13]) buffers.push(boxG(0.05, 0.2, 0.05, TRACK_X1 + 0.02, DECK + 0.2, TRACK_Z + dz));
				rail.add(mergedMesh(buffers, paintRed, { name: 'rail-buffers', cast: true, receive: true }));
				// signal post at the east end
				const sig = [];
				sig.push(cylG(0.018, 0.024, 0.7, 6, TRACK_X1 + 0.32, DECK + 0.35, TRACK_Z + 0.32));
				sig.push(boxG(0.1, 0.1, 0.06, TRACK_X1 + 0.32, DECK + 0.68, TRACK_Z + 0.32));
				rail.add(mergedMesh(sig, paintBlack, { name: 'rail-signal', cast: false, receive: true }));
				const sigLight = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 5), signalMat);
				sigLight.position.set(TRACK_X1 + 0.32, DECK + 0.69, TRACK_Z + 0.36);
				rail.add(sigLight);
			}
			// engine shed (track entrance at the west end, long axis along z)
			{
				const sx = -9.02,
					sz = -1.52;
				const shed = [];
				shed.push(boxG(0.58, 0.62, 0.92, sx, DECK + 0.31, sz));
				shed.push(boxG(0.58, 0.15, 0.92, sx, DECK + 0.69, sz));
				rail.add(mergedMesh(shed, brick, { name: 'engine-shed', cast: true, receive: true }));
				const rf = [];
				for (const side of [-1, 1]) {
					const sg = new THREE.BoxGeometry(0.4, 0.05, 1.04);
					sg.rotateZ(side * 0.62);
					sg.translate(sx + side * 0.15, DECK + 0.84, sz);
					rf.push(sg);
				}
				rail.add(mergedMesh(rf, roofSlate, { name: 'engine-shed-roof', cast: true, receive: true }));
				// south door opening (dark) with frame
				rail.add(mergedMesh([boxG(0.4, 0.36, 0.04, sx, DECK + 0.18, sz + 0.47)], paintBlack, { name: 'shed-door', cast: false, receive: true }));
				const frame = [];
				frame.push(boxG(0.06, 0.42, 0.05, sx + 0.22, DECK + 0.18, sz + 0.48));
				frame.push(boxG(0.06, 0.42, 0.05, sx - 0.22, DECK + 0.18, sz + 0.48));
				frame.push(boxG(0.5, 0.06, 0.05, sx, DECK + 0.41, sz + 0.48));
				rail.add(mergedMesh(frame, paintCream, { name: 'shed-frame', cast: false, receive: true }));
				// chimney + cap
				rail.add(mergedMesh([cylG(0.045, 0.055, 0.45, 8, sx - 0.18, DECK + 0.98, sz - 0.26)], brick, { name: 'shed-chimney', cast: true }));
				rail.add(mergedMesh([cylG(0.07, 0.09, 0.07, 8, sx - 0.18, DECK + 1.22, sz - 0.26)], M.painted('#4a4a48', { roughness: 0.95 }), { name: 'shed-cap', cast: false }));
				// coal heap + drums beside the shed
				const coal = new THREE.Mesh(new THREE.DodecahedronGeometry(0.24, 0), M.painted('#232322', { roughness: 0.95 }));
				coal.position.set(-9.16, DECK + 0.14, -1.05);
				coal.scale.set(1.2, 0.55, 0.9);
				rail.add(coal);
				const drums = [];
				for (let i = 0; i < 3; i++) drums.push(cylG(0.05, 0.05, 0.14, 10, -9.2 + rng.range(-0.06, 0.06), DECK + 0.07, -0.6 + i * 0.14));
				rail.add(mergedMesh(drums, rust, { name: 'shed-drums', cast: true, receive: true }));
			}
			// the train: loco + 2 wagons (animated group)
			const train = U.group(rail, 'train');
			train.position.set(TRACK_X0 + 1.6, 0, TRACK_Z);
			const TRAIN_BASE = DECK + 0.23;
			{
				const loco = [];
				const dark = [];
				const brassG = [];
				// chassis
				loco.push(boxG(0.52, 0.07, 0.2, 0, TRAIN_BASE + 0.03, 0));
				// boiler
				loco.push(cylG(0.085, 0.085, 0.28, 12, 0.08, TRAIN_BASE + 0.16, 0, 0, 0, PI / 2));
				// boiler bands
				dark.push(cylG(0.089, 0.089, 0.02, 12, 0.0, TRAIN_BASE + 0.16, 0, 0, 0, PI / 2));
				dark.push(cylG(0.089, 0.089, 0.02, 12, 0.16, TRAIN_BASE + 0.16, 0, 0, 0, PI / 2));
				// smokebox + chimney
				dark.push(cylG(0.092, 0.092, 0.05, 12, 0.235, TRAIN_BASE + 0.16, 0, 0, 0, PI / 2));
				dark.push(cylG(0.03, 0.045, 0.13, 8, 0.235, TRAIN_BASE + 0.27, 0));
				brassG.push(cylG(0.045, 0.045, 0.02, 8, 0.235, TRAIN_BASE + 0.34, 0));
				// dome
				brassG.push(cylG(0.05, 0.06, 0.06, 8, 0.04, TRAIN_BASE + 0.25, 0));
				// cab
				loco.push(boxG(0.17, 0.2, 0.19, -0.16, TRAIN_BASE + 0.15, 0));
				dark.push(boxG(0.175, 0.03, 0.2, -0.16, TRAIN_BASE + 0.26, 0));
				// cab windows
				dark.push(boxG(0.012, 0.07, 0.13, -0.245, TRAIN_BASE + 0.18, 0));
				// wheels (3 axles) + coupling rods
				for (const wx of [-0.17, -0.02, 0.13]) {
					for (const wz of [-0.09, 0.09]) dark.push(cylG(0.055, 0.055, 0.025, 10, wx, TRAIN_BASE - 0.02, wz, 0, 0, PI / 2));
				}
				// cowcatcher / front beam
				dark.push(boxG(0.04, 0.05, 0.2, 0.28, TRAIN_BASE + 0.01, 0));
				// headlight
				loco.push(boxG(0.05, 0.05, 0.05, 0.26, TRAIN_BASE + 0.11, 0));
				// coal in the bunker
				dark.push(boxG(0.11, 0.03, 0.15, -0.1, TRAIN_BASE + 0.2, 0));
				train.add(mergedMesh(loco, paintRed, { name: 'loco-body', cast: true, receive: true }));
				train.add(mergedMesh(dark, paintBlack, { name: 'loco-dark', cast: false, receive: true }));
				train.add(mergedMesh(brassG, brass, { name: 'loco-brass', cast: false, receive: false }));
				// headlight emissive
				const hl = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.04, 0.04), M.emissive('#ffe6b0', 0.3));
				hl.position.set(0.285, TRAIN_BASE + 0.11, 0);
				train.add(hl);
				const spl = new THREE.PointLight(0xffe0a8, 0, 3.2, 2);
				spl.position.set(0.5, TRAIN_BASE + 0.1, 0);
				train.add(spl);
				craneLights.push({ light: spl, base: 0.9, mat: null, blink: false });
				// wagons: two flatbeds with crates
				for (let w = 0; w < 2; w++) {
					const wg = U.group(train, 'wagon' + w);
					const body = [];
					const wdark = [];
					body.push(boxG(0.4, 0.05, 0.19, 0, TRAIN_BASE + 0.02, 0));
					body.push(boxG(0.4, 0.06, 0.02, 0, TRAIN_BASE + 0.07, 0.095));
					body.push(boxG(0.4, 0.06, 0.02, 0, TRAIN_BASE + 0.07, -0.095));
					for (const wx of [-0.12, 0.12]) for (const wz of [-0.085, 0.085]) wdark.push(cylG(0.042, 0.042, 0.02, 8, wx, TRAIN_BASE - 0.01, wz, 0, 0, PI / 2));
					// crates on the bed
					const crate = [];
					for (let k = 0; k < 3; k++) crate.push([-0.12 + k * 0.12, TRAIN_BASE + 0.12, 0, rng.range(-0.2, 0.2), rng.range(0.8, 1.1)]);
					wg.add(mergedMesh(body, paintGrey, { name: 'wagon-body', cast: true, receive: true }));
					wg.add(mergedMesh(wdark, paintBlack, { name: 'wagon-dark', cast: false, receive: true }));
					wg.add(mergedMesh(crate.map((c) => boxG(0.1 * c[4], 0.1 * c[4], 0.09 * c[4], c[0], c[1], c[2], c[3])), woodLight, { name: 'wagon-cargo', cast: true }));
					wg.position.x = -0.62 - w * 0.5;
				}
			}
			// yard lamps (instanced posts + heads) with warm point lights
			{
				const LAMP_POS = [
					[-2.95, -1.9],
					[-8.4, 0.5],
					[2.15, -1.62],
				];
				const postList = [];
				const headList = [];
				for (const [lx, lz] of LAMP_POS) {
					postList.push([lx, DECK, lz, 0]);
					headList.push([lx, DECK + 0.58, lz, 0]);
					const pl = new THREE.PointLight(0xffd9a0, 0, 4.5, 2);
					pl.position.set(lx, DECK + 0.62, lz);
					g.add(pl);
					craneLights.push({ light: pl, base: 1.8, mat: null, blink: false });
				}
				instanced(g, U.merge([cylG(0.02, 0.028, 0.55, 6, 0, 0.275, 0), cylG(0.045, 0.045, 0.03, 6, 0, 0.015, 0)]), paintGreen, postList, { cast: false, receive: false, name: 'yard-lamp-posts' });
				instanced(g, new THREE.CylinderGeometry(0.05, 0.04, 0.095, 6), lampMat, headList, { cast: false, receive: false, name: 'yard-lamp-heads' });
			}

			// ==================================================================
			// YARD DETAILS: pallets, barrels, cables, harbour office board
			// ==================================================================
			{
				// crates / pallets / barrels collected during warehouse build
				const crateGeos = [];
				for (const c of detail.crates) crateGeos.push(boxG(0.16 * c.s, 0.13 * c.s, 0.14 * c.s, c.x, c.y, c.z, c.rot));
				if (crateGeos.length) g.add(mergedMesh(crateGeos, woodLight, { name: 'warehouse-crates', cast: true, receive: true }));
				const palGeos = [];
				for (const p of detail.pallets) palGeos.push(boxG(0.2, 0.03, 0.16, p.x, p.y, p.z, p.rot));
				if (palGeos.length) g.add(mergedMesh(palGeos, wood, { name: 'warehouse-pallets', cast: true, receive: true }));
				const barrelGeos = [];
				for (const b of detail.barrels) barrelGeos.push(cylG(0.055, 0.055, 0.15, 10, b.x, b.y, b.z));
				if (barrelGeos.length) g.add(mergedMesh(barrelGeos, rust, { name: 'warehouse-barrels', cast: true, receive: true }));
				// pallet stacks beside the container yard
				const pallets = [];
				for (let i = 0; i < 8; i++) pallets.push([-2.45 + rng.range(0, 0.25), DECK + 0.03 + (i % 2) * 0.005, -0.45 + rng.range(0, 0.18), rng.range(0, TAU)]);
				instanced(g, new THREE.BoxGeometry(0.22, 0.035, 0.16), woodLight, pallets, { cast: false, receive: true, name: 'pallet-stack' });
				// cable drums next to the fuel depot
				const drums = [];
				for (let i = 0; i < 4; i++) drums.push([2.05 + rng.range(-0.08, 0.08), DECK + 0.16, -1.7 + rng.range(0, 0.28), rng.range(0, TAU), rng.range(0.8, 1.1)]);
				instanced(g, new THREE.CylinderGeometry(0.16, 0.16, 0.12, 12), wood, drums, { cast: true, receive: true, name: 'cable-drums' });
				// harbour office notice board near the west quay gate
				const bx = -8.2,
					bz = 2.88;
				const board = [];
				board.push(boxG(0.04, 0.36, 0.5, bx, DECK + 0.62, bz));
				board.push(boxG(0.06, 0.06, 0.06, bx, DECK + 0.03, bz));
				board.push(boxG(0.06, 0.5, 0.06, bx, DECK + 0.25, bz - 0.2));
				board.push(boxG(0.06, 0.5, 0.06, bx, DECK + 0.25, bz + 0.2));
				g.add(mergedMesh(board, wood, { name: 'notice-board', cast: true, receive: true }));
				const bsign = sign('HARBOUR', 0.26, '#e6ddc8');
				bsign.position.set(bx + 0.03, DECK + 0.68, bz);
				bsign.rotation.y = PI / 2;
				g.add(bsign);
			}

			// ==================================================================
			// NIGHT
			// ==================================================================
			function onEnv(state) {
				const n = state.night || 0;
				lampMat.emissiveIntensity = 0.15 + n * 3.2;
				if (signalMat) signalMat.emissiveIntensity = 0.4 + n * 2.4;
				for (const c of craneLights) c.light.intensity = n * c.base;
			}
			if (ctx.env && ctx.env.onEnv) ctx.env.onEnv(onEnv);

			ctx.world.industrial = {
				gantry: { x: [RAIL_X0, RAIL_X1], z: [RAIL_ZB, RAIL_ZF], girderY: GIRDER_Y, boomTipZ: 2.3 },
				rail: { z: TRACK_Z, x0: TRACK_X0, x1: TRACK_X1, track: TRACK.map((p) => p.slice()) },
				containers: contList.length,
			};

			const STATE = { blinkMat: signalMat };
			return {
				update(dt, t) {
					// gantry travels slowly along the quay
					const cx = 0.5 + Math.sin(t * 0.045) * 0.8;
					craneMovable.position.x = cx;
					// trolley runs along the girder, the hanging load swings gently
					const tz = 0.5 + Math.sin(t * 0.11 + 0.8) * 1.55;
					trolley.position.z = tz;
					const hoist = trolley.userData.hoist;
					if (hoist) hoist.position.x = Math.sin(t * 0.36 + 2.1) * 0.02;
					// train shuttles along the siding
					const span = 2.6;
					const tt = U.pingPong(t * 0.05, span * 2);
					train.position.x = TRACK_X0 + 1.6 + tt;
					// crane warning beacon blinks slowly at night
					const blink = 0.55 + 0.45 * Math.sin(t * 2.1);
					STATE.blinkMat.emissiveIntensity = (0.4 + (ctx.env.state.night || 0) * 2.4) * blink;
				},
				onEnv,
			};
		},
	});
})(window.HARBOR);
