import fs from 'node:fs';

function patch(file, pairs) {
	let s = fs.readFileSync(file, 'utf8');
	for (const [a, b] of pairs) {
		if (!s.includes(a)) console.warn('[patch] missing in ' + file + ': ' + a.slice(0, 40));
		s = s.split(a).join(b);
	}
	fs.writeFileSync(file, s);
	console.log('[patch] ' + file);
}

patch('src/core/render.js', [
	['uContrast: { value: 1.07 }', 'uContrast: { value: 1.12 }'],
	['uSaturation: { value: 1.22 }', 'uSaturation: { value: 1.27 }'],
	['uVignette: { value: 0.46 }', 'uVignette: { value: 0.5 }'],
	['vec3 shadowTint = vec3(0.92, 1.0, 1.05);', 'vec3 shadowTint = vec3(0.91, 1.0, 1.06);'],
]);
patch('src/core/env.js', [
	["sun: '#ffc077', sunI: 4.5, hemiSky: '#a7bfd4', hemiGround: '#7c6146', hemiI: 0.82", "sun: '#ffc077', sunI: 4.9, hemiSky: '#a7bfd4', hemiGround: '#7c6146', hemiI: 0.76"],
]);
