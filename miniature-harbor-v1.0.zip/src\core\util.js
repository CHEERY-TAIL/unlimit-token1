/**
 * util.js — shared foundation for the miniature harbor.
 * ------------------------------------------------------------------
 * Everything here is namespace-safe (window.HARBOR.util) and dependency
 * free apart from three.js (window.THREE) and the addon bundle
 * (window.HARBOR_ADDONS).
 *
 * Conventions used across the whole project
 * -----------------------------------------
 *  - Units: 1 unit = "a few meters" of the imaginary world, but the scene
 *    is a miniature diorama, so props are tiny: a townhouse is ~1.2 units
 *    tall, a car is ~0.3 units long, a person is ~0.09 units tall.
 *  - Y up, water surface at y = 0, harbour centre at (0, 0).
 *  - +Z is "south" (towards the default camera), -Z is north.
 *  - Everything is procedural: no external images/audio/fonts are loaded.
 *  - All modules register with HARBOR.register(name, {create(ctx)}).
 */
window.HARBOR = window.HARBOR || {};
(function (H) {
	'use strict';

	const THREE = window.THREE;
	const ADDONS = window.HARBOR_ADDONS;
	H.THREE = THREE;
	H.ADDONS = ADDONS;

	const PI = Math.PI;
	const TAU = PI * 2;
	const DEG = PI / 180;

	// ------------------------------------------------------------------
	// math / scalar helpers
	// ------------------------------------------------------------------
	const clamp = (v, a = 0, b = 1) => (v < a ? a : v > b ? b : v);
	const lerp = (a, b, t) => a + (b - a) * t;
	const invLerp = (a, b, v) => (b === a ? 0 : (v - a) / (b - a));
	const smoothstep = (e0, e1, x) => {
		const t = clamp((x - e0) / (e1 - e0 || 1e-6));
		return t * t * (3 - 2 * t);
	};
	const smootherstep = (e0, e1, x) => {
		const t = clamp((x - e0) / (e1 - e0 || 1e-6));
		return t * t * t * (t * (t * 6 - 15) + 10);
	};
	const remap = (v, a, b, c, d) => lerp(c, d, invLerp(a, b, v));
	const damp = (current, target, lambda, dt) => lerp(current, target, 1 - Math.exp(-lambda * dt));
	const mod = (n, m) => ((n % m) + m) % m;
	const fract = (x) => x - Math.floor(x);
	const pingPong = (t, len) => {
		const x = mod(t, len * 2);
		return x < len ? x : len * 2 - x;
	};
	const angleLerp = (a, b, t) => {
		let d = mod(b - a + PI, TAU) - PI;
		return a + d * t;
	};
	const dist2 = (ax, az, bx, bz) => Math.hypot(ax - bx, az - bz);
	const polyArea = (pts) => {
		let a = 0;
		for (let i = 0; i < pts.length; i++) {
			const p = pts[i];
			const q = pts[(i + 1) % pts.length];
			a += p[0] * q[1] - q[0] * p[1];
		}
		return a / 2;
	};

	// deterministic 32-bit prng (mulberry32)
	function mulberry32(seed) {
		let a = seed >>> 0;
		return function () {
			a |= 0;
			a = (a + 0x6d2b79f5) | 0;
			let t = Math.imul(a ^ (a >>> 15), 1 | a);
			t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
			return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
		};
	}

	/**
	 * Seeded random helper with convenience methods.
	 * const r = util.rng(1337); r.range(2,5); r.pick(['a','b']);
	 */
	function rng(seed = 1) {
		const next = mulberry32(seed);
		const api = {
			next,
			range: (a, b) => a + (b - a) * next(),
			int: (a, b) => Math.floor(a + (b - a + 1) * next()),
			pick: (arr) => arr[Math.floor(next() * arr.length)],
			chance: (p) => next() < p,
			sign: () => (next() < 0.5 ? -1 : 1),
			shuffle: (arr) => {
				for (let i = arr.length - 1; i > 0; i--) {
					const j = Math.floor(next() * (i + 1));
					const tmp = arr[i];
					arr[i] = arr[j];
					arr[j] = tmp;
				}
				return arr;
			},
			// gaussian-ish, mean 0, ~[-1..1]
			rand: () => (next() + next() + next()) / 1.5 - 1,
			seed: (s) => {
				seed = s;
				return api;
			},
		};
		return api;
	}

	// ------------------------------------------------------------------
	// noise (ImprovedNoise from three addons, plus helpers)
	// ------------------------------------------------------------------
	const ImprovedNoise = ADDONS.ImprovedNoise;
	const noiseImpl = new ImprovedNoise();
	function noise2(x, y, seed = 0) {
		return noiseImpl.noise(x + seed * 31.7, y - seed * 17.3, 0.5 + seed * 0.013);
	}
	function noise3(x, y, z, seed = 0) {
		return noiseImpl.noise(x + seed * 31.7, y - seed * 17.3, z + seed * 0.013);
	}
	function fbm(x, y, opts = {}) {
		const octaves = opts.octaves != null ? opts.octaves : 4;
		const freq = opts.freq != null ? opts.freq : 1;
		const gain = opts.gain != null ? opts.gain : 0.5;
		const lac = opts.lac != null ? opts.lac : 2;
		const seed = opts.seed || 0;
		let a = 1,
			f = freq,
			sum = 0,
			norm = 0;
		for (let i = 0; i < octaves; i++) {
			sum += a * noise2(x * f, y * f, seed + i * 13.1);
			norm += a;
			a *= gain;
			f *= lac;
		}
		return sum / norm;
	}
	function ridged(x, y, opts = {}) {
		return 1 - Math.abs(fbm(x, y, opts)) * 2;
	}

	/**
	 * Tileable value-noise field in [0,1]. Used by the texture factory so
	 * every generated map wraps seamlessly.
	 */
	function tileableNoise(size, opts = {}) {
		const period = opts.period || 8;
		const octaves = opts.octaves || 4;
		const seed = opts.seed != null ? opts.seed : 1;
		const gain = opts.gain != null ? opts.gain : 0.5;
		const r = rng(seed * 7919 + 13);
		const grids = [];
		let amp = 1,
			norm = 0;
		for (let o = 0; o < octaves; o++) {
			const p = Math.max(2, Math.round(period * Math.pow(2, o)));
			const g = new Float32Array(p * p);
			for (let i = 0; i < g.length; i++) g[i] = r.next();
			grids.push({ p, g, amp });
			norm += amp;
			amp *= gain;
		}
		const out = new Float32Array(size * size);
		const smooth = (t) => t * t * (3 - 2 * t);
		for (let y = 0; y < size; y++) {
			for (let x = 0; x < size; x++) {
				let v = 0;
				for (let o = 0; o < grids.length; o++) {
					const { p, g, amp: a } = grids[o];
					const fx = (x / size) * p;
					const fy = (y / size) * p;
					const x0 = Math.floor(fx) % p;
					const y0 = Math.floor(fy) % p;
					const x1 = (x0 + 1) % p;
					const y1 = (y0 + 1) % p;
					const tx = smooth(fx - Math.floor(fx));
					const ty = smooth(fy - Math.floor(fy));
					const v00 = g[y0 * p + x0];
					const v10 = g[y0 * p + x1];
					const v01 = g[y1 * p + x0];
					const v11 = g[y1 * p + x1];
					v += a * lerp(lerp(v00, v10, tx), lerp(v01, v11, tx), ty);
				}
				out[y * size + x] = v / norm;
			}
		}
		return out;
	}

	// ------------------------------------------------------------------
	// canvas / texture helpers
	// ------------------------------------------------------------------
	function createCanvas(w, h = w) {
		const c = document.createElement('canvas');
		c.width = w;
		c.height = h || w;
		return c;
	}

	const _texCache = new Map();
	function canvasTex(canvas, opts = {}) {
		const key = opts.cacheKey;
		if (key && _texCache.has(key)) return _texCache.get(key);
		const t = new THREE.CanvasTexture(canvas);
		const repeat = opts.repeat || [1, 1];
		t.wrapS = t.wrapT = THREE.RepeatWrapping;
		t.repeat.set(repeat[0], repeat[1]);
		t.anisotropy = opts.anisotropy != null ? opts.anisotropy : 8;
		if (opts.srgb !== false) t.colorSpace = THREE.SRGBColorSpace;
		t.needsUpdate = true;
		if (key) _texCache.set(key, t);
		return t;
	}

	/** grayscale height canvas -> tangent-space normal map canvas */
	function heightToNormalCanvas(heightCanvas, strength = 2) {
		const s = heightCanvas.width;
		const src = heightCanvas.getContext('2d').getImageData(0, 0, s, s).data;
		const out = createCanvas(s);
		const ctx = out.getContext('2d');
		const img = ctx.createImageData(s, s);
		const at = (x, y) => src[((((y % s) + s) % s) * s + ((x % s) + s) % s) * 4] / 255;
		for (let y = 0; y < s; y++) {
			for (let x = 0; x < s; x++) {
				const dx = (at(x + 1, y) - at(x - 1, y)) * strength;
				const dy = (at(x, y + 1) - at(x, y - 1)) * strength;
				// normal = normalize(-dx, -dy, 1)
				const nx = -dx,
					ny = -dy,
					nz = 1;
				const len = Math.hypot(nx, ny, nz) || 1;
				const i = (y * s + x) * 4;
				img.data[i] = ((nx / len) * 0.5 + 0.5) * 255;
				img.data[i + 1] = ((ny / len) * 0.5 + 0.5) * 255;
				img.data[i + 2] = ((nz / len) * 0.5 + 0.5) * 255;
				img.data[i + 3] = 255;
			}
		}
		ctx.putImageData(img, 0, 0);
		return out;
	}

	/** Build a full PBR-ish texture set from drawing callbacks. */
	function surface(opts) {
		const s = opts.size || 512;
		const r = rng(opts.seed || 7);
		const colorCanvas = createCanvas(s);
		const colorCtx = colorCanvas.getContext('2d');
		opts.color(colorCtx, s, r);

		let normalMap = null;
		let roughnessMap = null;
		if (opts.height) {
			const hCanvas = createCanvas(s);
			const hCtx = hCanvas.getContext('2d');
			hCtx.fillStyle = '#808080';
			hCtx.fillRect(0, 0, s, s);
			opts.height(hCtx, s, r);
			normalMap = canvasTex(heightToNormalCanvas(hCanvas, opts.normalStrength != null ? opts.normalStrength : 2.5), {
				repeat: opts.repeat,
				srgb: false,
				cacheKey: opts.cacheKey && opts.cacheKey + ':n',
			});
			if (opts.roughness !== false) {
				const roughCanvas = createCanvas(s);
				const rctx = roughCanvas.getContext('2d');
				rctx.drawImage(hCanvas, 0, 0);
				roughnessMap = canvasTex(roughCanvas, {
					repeat: opts.repeat,
					srgb: false,
					cacheKey: opts.cacheKey && opts.cacheKey + ':r',
				});
			}
		}
		const map = canvasTex(colorCanvas, {
			repeat: opts.repeat,
			cacheKey: opts.cacheKey && opts.cacheKey + ':c',
		});
		return { map, normalMap, roughnessMap };
	}

	/** quick grayscale noise texture */
	function noiseTexture(opts = {}) {
		const s = opts.size || 256;
		const period = opts.period || 6;
		const seed = opts.seed || 3;
		const field = tileableNoise(s, { period, octaves: opts.octaves || 4, seed });
		const c = createCanvas(s);
		const ctx = c.getContext('2d');
		const img = ctx.createImageData(s, s);
		const lo = opts.lo != null ? opts.lo : 0;
		const hi = opts.hi != null ? opts.hi : 255;
		for (let i = 0; i < field.length; i++) {
			const v = lo + (hi - lo) * field[i];
			const j = i * 4;
			img.data[j] = img.data[j + 1] = img.data[j + 2] = v;
			img.data[j + 3] = 255;
		}
		ctx.putImageData(img, 0, 0);
		return canvasTex(c, { repeat: opts.repeat, srgb: opts.srgb !== false, cacheKey: opts.cacheKey });
	}

	/** canvas-drawn text -> texture; handy for shop signs / nameplates */
	function textTexture(text, opts = {}) {
		const font = opts.font || '700 64px "Segoe UI", "Microsoft YaHei", sans-serif';
		const pad = opts.padding != null ? opts.padding : 24;
		const fg = opts.color || '#1d1a16';
		const bg = opts.background || 'rgba(0,0,0,0)';
		const c = createCanvas(8, 8);
		const ctx = c.getContext('2d');
		ctx.font = font;
		const w = Math.ceil(ctx.measureText(text).width) + pad * 2;
		const h = Math.ceil((opts.size || 64) * 1.5) + pad;
		c.width = w;
		c.height = h;
		ctx.font = font;
		ctx.fillStyle = bg;
		ctx.fillRect(0, 0, w, h);
		ctx.fillStyle = fg;
		ctx.textAlign = 'center';
		ctx.textBaseline = 'middle';
		ctx.fillText(text, w / 2, h / 2 + 1);
		const tex = canvasTex(c, { cacheKey: opts.cacheKey });
		return { texture: tex, aspect: w / h, width: w, height: h, canvas: c };
	}

	// ------------------------------------------------------------------
	// geometry helpers
	// ------------------------------------------------------------------
	function mesh(geo, mat, x = 0, y = 0, z = 0, opts = {}) {
		const m = new THREE.Mesh(geo, mat);
		m.position.set(x, y, z);
		if (opts.rot) m.rotation.set(opts.rot[0] || 0, opts.rot[1] || 0, opts.rot[2] || 0);
		if (opts.scale != null) {
			if (Array.isArray(opts.scale)) m.scale.set(opts.scale[0], opts.scale[1], opts.scale[2]);
			else m.scale.setScalar(opts.scale);
		}
		if (opts.cast !== undefined) m.castShadow = opts.cast;
		if (opts.receive !== undefined) m.receiveShadow = opts.receive;
		if (opts.name) m.name = opts.name;
		return m;
	}

	function box(w, h, d, mat, x = 0, y = 0, z = 0, opts = {}) {
		return mesh(new THREE.BoxGeometry(w, h, d), mat, x, y, z, opts);
	}
	function cyl(rt, rb, h, seg, mat, x = 0, y = 0, z = 0, opts = {}) {
		return mesh(new THREE.CylinderGeometry(rt, rb, h, seg), mat, x, y, z, opts);
	}

	function group(parent, name) {
		const g = new THREE.Group();
		if (name) g.name = name;
		if (parent) parent.add(g);
		return g;
	}

	function applyShadow(root, cast = true, receive = true) {
		root.traverse((o) => {
			if (o.isMesh) {
				o.castShadow = cast;
				o.receiveShadow = receive;
			}
		});
		return root;
	}

	/** Build an InstancedMesh from [x,y,z,rotY,scale] tuples. */
	function instances(geo, mat, list, opts = {}) {
		const m = new THREE.InstancedMesh(geo, mat, list.length);
		const dummy = new THREE.Object3D();
		for (let i = 0; i < list.length; i++) {
			const t = list[i];
			dummy.position.set(t[0], t[1], t[2]);
			dummy.rotation.set(0, t[3] || 0, 0);
			const s = t[4] != null ? t[4] : 1;
			dummy.scale.set(t[5] != null ? t[5] : s, t[6] != null ? t[6] : s, t[7] != null ? t[7] : s);
			dummy.updateMatrix();
			m.setMatrixAt(i, dummy.matrix);
		}
		m.instanceMatrix.needsUpdate = true;
		m.castShadow = opts.cast !== false;
		m.receiveShadow = opts.receive !== false;
		if (opts.name) m.name = opts.name;
		return m;
	}

	const _geoCache = new Map();
	function cachedGeo(key, factory) {
		if (!_geoCache.has(key)) _geoCache.set(key, factory());
		return _geoCache.get(key);
	}

	function merge(geos) {
		return ADDONS.mergeGeometries(geos, false);
	}

	// ------------------------------------------------------------------
	// colour helpers
	// ------------------------------------------------------------------
	function color(hex) {
		return new THREE.Color(hex);
	}
	function hsl(h, s, l) {
		return new THREE.Color().setHSL(h, s, l);
	}
	function jitterColor(base, amount, r) {
		const c = new THREE.Color(base);
		const tmp = new THREE.Color();
		tmp.setHSL(Math.random(), 0, 0.5);
		const rr = r ? r : Math.random;
		c.offsetHSL((rr() - 0.5) * amount * 0.15, (rr() - 0.5) * amount * 0.4, (rr() - 0.5) * amount);
		return c;
	}

	/**
	 * Master palette — warm Mediterranean / golden-hour harbour.
	 * Modules should pull colours from here so the whole diorama stays
	 * cohesive; small deviations are welcome, new hues should be rare.
	 */
	const PALETTE = {
		// environment
		skyZenith: '#3f7fb0',
		skyHorizon: '#d9c6a8',
		sun: '#ffd9a0',
		sunLow: '#ff9d5c',
		moon: '#bcd3ff',
		fog: '#cfc3b4',
		waterDeep: '#0d3a45',
		waterShallow: '#2b8ea0',
		waterSurface: '#7fc6c9',
		foam: '#e8f2ef',
		seabed: '#4a5c4e',
		rock: '#6e6258',
		rockDark: '#4c443d',
		rockLight: '#8d8172',
		sand: '#d9c49a',
		sandWet: '#b3a182',
		grass: '#7d8f57',
		grassDark: '#5c6c42',
		soil: '#5a4a3a',
		// built environment
		stone: '#b9ac96',
		concrete: '#a9a49a',
		concreteDark: '#7d7a72',
		asphalt: '#4b4a47',
		cobble: '#8d8477',
		wood: '#7c5a3c',
		woodLight: '#a8815a',
		woodDark: '#4e3726',
		teak: '#8a5b34',
		brass: '#c8a24b',
		copper: '#a4643e',
		roofRed: '#a9503d',
		roofBrown: '#6f4a3a',
		roofSlate: '#4a5560',
		roofOchre: '#c08a52',
		wallCream: '#efe2c9',
		wallSand: '#ddc39a',
		wallOchre: '#d1995a',
		wallRose: '#cf9a86',
		wallSage: '#a8b291',
		wallBlue: '#8aa7b3',
		wallWhite: '#f4efe3',
		wallTerracotta: '#c0765b',
		// industrial
		rust: '#9a4b33',
		steel: '#6d767d',
		steelDark: '#4a5157',
		yellow: '#d9a13b',
		craneYellow: '#e0a92f',
		safetyOrange: '#cf6b2f',
		containerTeal: '#2f6f73',
		containerRed: '#a64532',
		containerBlue: '#3d5f86',
		containerGreen: '#5c7443',
		containerOchre: '#c39a4a',
		// life
		glass: '#9dbcc6',
		glassWarm: '#ffd9a0',
		glassCool: '#b9d6e2',
		fabricRed: '#b3453b',
		fabricBlue: '#3f6688',
		fabricCream: '#efe6d2',
		fabricGreen: '#5d7a4f',
		greenDark: '#3f5c3a',
		flowers: ['#d96a56', '#e0a24b', '#d67ba1', '#e8d06b', '#b96b9c'],
	};

	// ------------------------------------------------------------------
	// misc
	// ------------------------------------------------------------------
	function textDecal(text, opts = {}) {
		// returns a Mesh with a transparent plane carrying canvas text
		const t = textTexture(text, opts);
		const mat = new THREE.MeshBasicMaterial({
			map: t.texture,
			transparent: true,
			depthWrite: false,
			side: THREE.DoubleSide,
			toneMapped: false,
		});
		const w = opts.worldWidth || 1;
		const m = new THREE.Mesh(new THREE.PlaneGeometry(w, w / t.aspect), mat);
		return m;
	}

	function screenShotReady() {
		return true;
	}

	function dispose(obj) {
		obj.traverse((o) => {
			if (o.geometry) o.geometry.dispose();
			if (o.material) {
				const mats = Array.isArray(o.material) ? o.material : [o.material];
				for (const mat of mats) {
					for (const k of Object.keys(mat)) {
						const v = mat[k];
						if (v && v.isTexture) v.dispose();
					}
					mat.dispose();
				}
			}
		});
	}

	const util = {
		PI,
		TAU,
		DEG,
		clamp,
		lerp,
		invLerp,
		smoothstep,
		smootherstep,
		remap,
		damp,
		mod,
		fract,
		pingPong,
		angleLerp,
		dist2,
		polyArea,
		mulberry32,
		rng,
		noise2,
		noise3,
		fbm,
		ridged,
		tileableNoise,
		createCanvas,
		canvasTex,
		heightToNormalCanvas,
		surface,
		noiseTexture,
		textTexture,
		textDecal,
		mesh,
		box,
		cyl,
		group,
		applyShadow,
		instances,
		cachedGeo,
		merge,
		color,
		hsl,
		jitterColor,
		PALETTE,
		dispose,
		screenShotReady,
	};
	H.util = util;
})(window.HARBOR);
