﻿/**
 * 30-town.js 闂?the old town: townhouses, church, plaza, market hall,
 * customs house, fish market.  OWNER: t3 town-life.
 *
 * The town sits on two flat terraces of layout.groundHeight:
 *   town 2.1 / upper 3.1.  Buildings are generated from layout.townLots
 * (frontage along mainStreet + hillLane) plus a few hand placed rows in
 * the upper terrace / east pocket.  Everything is merged or instanced
 * into a handful of draw calls.
 *
 * Local building frame: x = along the frontage, z = depth, front facade
 * faces local -z.  CUR holds the building-to-world matrix.
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const L = H.layout;
	const PI = Math.PI;
	const TAU = PI * 2;

	// ------------------------------------------------------------------
	// palette (colour discipline: warm neutrals dominate, few cold accents)
	// ------------------------------------------------------------------
	const WALL_COLORS = [
		['#efe2c9', 0.20],
		['#ddc39a', 0.17],
		['#f4efe3', 0.11],
		['#d1995a', 0.10],
		['#cf9a86', 0.09],
		['#c0765b', 0.06],
		['#b9ac96', 0.07],
		['#a8b291', 0.06],
		['#8aa7b3', 0.05],
		['#c9b9a0', 0.09],
	];
	const ROOF_COLORS = [
		['#a9503d', 0.34],
		['#6f4a3a', 0.22],
		['#3f4851', 0.24],
		['#c08a52', 0.20],
	];
	const SHUTTER_COLORS = ['#4a6b5e', '#456043', '#3f6688', '#7c5a3c', '#8a4a3a', '#5c6b73', '#6d5a3a'];
	const DOOR_COLORS = ['#5c3d2a', '#3f5a56', '#8a5a3a', '#4e3726', '#33526b', '#7a3f3a'];
	const AWNING_COLORS = ['#b3453b', '#3f6688', '#5d7a4f', '#efe6d2', '#c39a4a', '#9a4b33'];
	const AWNING_COLORS2 = ['#efe6d2', '#e8ddc4', '#ddc39a', '#b3453b'];
	const FLOWER_COLORS = ['#d96a56', '#e0a24b', '#d67ba1', '#e8d06b', '#c0504d'];
	const LEAF_COLORS = ['#6f8248', '#7d8f57', '#8a9a5c', '#5f7544', '#93a265', '#6b8048'];

	// ------------------------------------------------------------------
	// weighted pick helper
	// ------------------------------------------------------------------
	function weighted(r, list) {
		let t = r.next();
		for (const [v, w] of list) {
			t -= w;
			if (t <= 0) return v;
		}
		return list[list.length - 1][0];
	}

	// ------------------------------------------------------------------
	// procedural texture / material kit (created once per module)
	// ------------------------------------------------------------------
	function makeKit() {
		const kit = {};

		// stucco: near white plaster so vertex colours read as the paint
		const stucco = U.surface({
			size: 256,
			seed: 141,
			cacheKey: 't3-stucco',
			normalStrength: 1.1,
			color(c, s, r) {
				c.fillStyle = '#f4efe6';
				c.fillRect(0, 0, s, s);
				for (let i = 0; i < 90; i++) {
					const x = r.range(0, s),
						y = r.range(0, s),
						rad = r.range(8, 60);
					const g = c.createRadialGradient(x, y, 0, x, y, rad);
					g.addColorStop(0, r.chance(0.5) ? 'rgba(120,108,94,0.07)' : 'rgba(255,253,246,0.10)');
					g.addColorStop(1, 'rgba(0,0,0,0)');
					c.fillStyle = g;
					c.fillRect(x - rad, y - rad, rad * 2, rad * 2);
				}
				for (let i = 0; i < 2600; i++) {
					c.fillStyle = `rgba(${r.chance(0.5) ? '150,140,126' : '255,250,240'},${r.range(0.03, 0.1)})`;
					c.fillRect(r.range(0, s), r.range(0, s), r.range(0.5, 2), r.range(0.5, 2));
				}
				// faint horizontal weathering streaks
				for (let i = 0; i < 14; i++) {
					c.strokeStyle = `rgba(110,100,86,${r.range(0.02, 0.06)})`;
					c.lineWidth = r.range(0.5, 1.6);
					const y0 = r.range(0, s);
					c.beginPath();
					c.moveTo(0, y0);
					c.lineTo(s, y0 + r.range(-3, 3));
					c.stroke();
				}
			},
			height(c, s, r) {
				c.fillStyle = '#8a8a8a';
				c.fillRect(0, 0, s, s);
				for (let i = 0; i < 6000; i++) {
					const v = Math.floor(r.range(110, 160));
					c.fillStyle = `rgb(${v},${v},${v})`;
					c.fillRect(r.range(0, s), r.range(0, s), r.range(0.6, 2.2), r.range(0.6, 2.2));
				}
			},
		});
		kit.matWall = new THREE.MeshStandardMaterial({
			map: stucco.map,
			normalMap: stucco.normalMap,
			roughnessMap: stucco.roughnessMap,
			normalScale: new THREE.Vector2(0.55, 0.55),
			vertexColors: true,
			roughness: 0.9,
			metalness: 0.0,
		});

		// brick (shared texture, tinted per instance color is not possible here
		// so keep the library colour; two variants via bucket colours)
		const brickTex = U.surface({
			size: 256,
			seed: 142,
			cacheKey: 't3-brick',
			normalStrength: 2.2,
			color(c, s, r) {
				c.fillStyle = '#b9a894';
				c.fillRect(0, 0, s, s);
				const rowH = 22;
				let row = 0;
				for (let y = 0; y < s; y += rowH) {
					const off = (row % 2) * 22;
					for (let x = -30; x < s + 30; x += 44) {
						c.fillStyle = r.pick(['#b06a52', '#a85c46', '#bb7258', '#9c5540', '#ad6a4e']);
						c.fillRect(x + off + 1.5, y + 1.5, 41, rowH - 3);
						for (let i = 0; i < 4; i++) {
							c.fillStyle = `rgba(255,240,225,${r.range(0.02, 0.06)})`;
							c.fillRect(x + off + r.range(2, 38), y + r.range(2, rowH - 3), r.range(1, 4), 1);
						}
					}
					row++;
				}
				for (let i = 0; i < 26; i++) {
					const x = r.range(0, s),
						y = r.range(0, s),
						rad = r.range(10, 46);
					const g = c.createRadialGradient(x, y, 0, x, y, rad);
					g.addColorStop(0, 'rgba(50,40,34,0.10)');
					g.addColorStop(1, 'rgba(0,0,0,0)');
					c.fillStyle = g;
					c.fillRect(x - rad, y - rad, rad * 2, rad * 2);
				}
			},
			height(c, s, r) {
				c.fillStyle = '#3a3a3a';
				c.fillRect(0, 0, s, s);
				const rowH = 22;
				let row = 0;
				for (let y = 0; y < s; y += rowH) {
					const off = (row % 2) * 22;
					for (let x = -30; x < s + 30; x += 44) {
						const v = Math.floor(r.range(190, 235));
						c.fillStyle = `rgb(${v},${v},${v})`;
						c.fillRect(x + off + 1.5, y + 1.5, 41, rowH - 3);
					}
					row++;
				}
			},
		});
		kit.matBrick = new THREE.MeshStandardMaterial({
			map: brickTex.map,
			normalMap: brickTex.normalMap,
			roughnessMap: brickTex.roughnessMap,
			normalScale: new THREE.Vector2(0.9, 0.9),
			roughness: 0.92,
			metalness: 0.0,
		});

		// stone (foundations, church, retaining walls) 闂?greyer than brick
		const stoneTex = U.surface({
			size: 256,
			seed: 143,
			cacheKey: 't3-stone',
			normalStrength: 2.6,
			color(c, s, r) {
				c.fillStyle = '#82786a';
				c.fillRect(0, 0, s, s);
				const rows = 6;
				let y = 0;
				for (let row = 0; row < rows; row++) {
					const h = s / rows;
					let x = -r.range(0, 30);
					while (x < s + 30) {
						const w = r.range(20, 52);
						const base = r.range(0.42, 0.66);
						const col = new THREE.Color().setHSL(r.range(0.08, 0.11), r.range(0.05, 0.12), base);
						c.fillStyle = '#' + col.getHexString();
						c.fillRect(x + 1.5, y + 1.5, w - 3, h - 3);
						c.strokeStyle = 'rgba(40,36,30,0.4)';
						c.lineWidth = 1.5;
						c.strokeRect(x + 1.5, y + 1.5, w - 3, h - 3);
						if (r.chance(0.3)) {
							c.fillStyle = `rgba(96,116,74,${r.range(0.05, 0.16)})`;
							c.fillRect(x + 3, y + 2, w - 6, r.range(2, 5));
						}
						x += w;
					}
					y += s / rows;
				}
				for (let i = 0; i < 2200; i++) {
					c.fillStyle = `rgba(30,26,22,${r.range(0.02, 0.08)})`;
					c.fillRect(r.range(0, s), r.range(0, s), r.range(1, 4), r.range(1, 3));
				}
			},
			height(c, s, r) {
				c.fillStyle = '#2e2e2e';
				c.fillRect(0, 0, s, s);
				const rows = 6;
				let y = 0;
				for (let row = 0; row < rows; row++) {
					const h = s / rows;
					let x = -r.range(0, 30);
					while (x < s + 30) {
						const w = r.range(20, 52);
						const v = Math.floor(r.range(200, 250));
						c.fillStyle = `rgb(${v},${v},${v})`;
						c.fillRect(x + 2, y + 2, w - 4, h - 4);
						x += w;
					}
					y += s / rows;
				}
			},
		});
		kit.matStone = new THREE.MeshStandardMaterial({
			map: stoneTex.map,
			normalMap: stoneTex.normalMap,
			roughnessMap: stoneTex.roughnessMap,
			normalScale: new THREE.Vector2(1.0, 1.0),
			roughness: 0.94,
			metalness: 0.0,
			color: 0xb9b1a3,
		});

		// roof: neutral light tile so per-vertex tint decides the colour
		const roofTex = U.surface({
			size: 256,
			seed: 144,
			cacheKey: 't3-roof',
			repeat: [1, 1],
			normalStrength: 2.6,
			color(c, s, r) {
				c.fillStyle = '#aea69a';
				c.fillRect(0, 0, s, s);
				const rowH = 26;
				const tileW = 24;
				let row = 0;
				for (let y = -rowH; y < s + rowH; y += rowH) {
					const off = (row % 2) * (tileW / 2);
					for (let x = -tileW; x < s + tileW; x += tileW) {
						const v = r.range(0.5, 0.84);
						c.fillStyle = `rgba(${Math.floor(255 * v)},${Math.floor(250 * v)},${Math.floor(242 * v)},1)`;
						c.beginPath();
						c.moveTo(x + off, y + rowH);
						c.quadraticCurveTo(x + off + tileW / 2, y - rowH * 0.3, x + off + tileW, y + rowH);
						c.closePath();
						c.fill();
						c.strokeStyle = 'rgba(70,60,52,0.12)';
						c.lineWidth = 1.1;
						c.stroke();
					}
					row++;
				}
				// moss / age speckle
				for (let i = 0; i < 700; i++) {
					c.fillStyle = `rgba(90,100,70,${r.range(0.02, 0.07)})`;
					c.fillRect(r.range(0, s), r.range(0, s), r.range(1, 5), r.range(1, 4));
				}
			},
			height(c, s, r) {
				c.fillStyle = '#3c3c3c';
				c.fillRect(0, 0, s, s);
				const rowH = 26;
				const tileW = 24;
				let row = 0;
				for (let y = -rowH; y < s + rowH; y += rowH) {
					const off = (row % 2) * (tileW / 2);
					for (let x = -tileW; x < s + tileW; x += tileW) {
						const g = c.createLinearGradient(x + off, 0, x + off + tileW, 0);
						g.addColorStop(0, '#5c5c5c');
						g.addColorStop(0.5, '#d6d6d6');
						g.addColorStop(1, '#5c5c5c');
						c.fillStyle = g;
						c.beginPath();
						c.moveTo(x + off, y + rowH);
						c.quadraticCurveTo(x + off + tileW / 2, y - rowH * 0.5, x + off + tileW, y + rowH);
						c.closePath();
						c.fill();
					}
					row++;
				}
			},
		});
		kit.matRoof = new THREE.MeshStandardMaterial({
			map: roofTex.map,
			normalMap: roofTex.normalMap,
			roughnessMap: roofTex.roughnessMap,
			normalScale: new THREE.Vector2(1.0, 1.0),
			vertexColors: true,
			roughness: 0.93,
			metalness: 0.0,
		});

		// painted trim / shutters / doors / frames
		kit.matTrim = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.52, metalness: 0.12 });
		kit.matTrimPlain = new THREE.MeshStandardMaterial({ roughness: 0.52, metalness: 0.12 });
		// timber
		kit.matWood = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.78, metalness: 0.02 });
		// wrought iron
		kit.matMetal = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.44, metalness: 0.72 });
		kit.matMetalPlain = new THREE.MeshStandardMaterial({ roughness: 0.44, metalness: 0.72 });
		// dark window glass (day & night)
		kit.matGlassDark = new THREE.MeshStandardMaterial({
			color: 0x3c5865,
			roughness: 0.06,
			metalness: 0.62,
			envMapIntensity: 2.1,
		});
		// thin specular edge inside each window (reads as glazing at close range)
		kit.matGlassHi = new THREE.MeshStandardMaterial({
			color: 0xd6e6ec,
			emissive: new THREE.Color('#8aa7b3'),
			emissiveIntensity: 0.4,
			roughness: 0.12,
			metalness: 0.8,
		});
		// shop windows: warm interior glow that reads both day and night
		kit.matShopGlass = new THREE.MeshStandardMaterial({
			color: new THREE.Color('#4a3826'),
			emissive: new THREE.Color('#ffc27a'),
			emissiveIntensity: 0.22,
			roughness: 0.22,
			metalness: 0.3,
		});
		// lit windows: dark warm glass by day, glowing by night
		kit.matGlassLit = new THREE.MeshStandardMaterial({
			color: 0x2b2118,
			emissive: new THREE.Color('#ffc27a'),
			emissiveIntensity: 0.0,
			roughness: 0.3,
			metalness: 0.25,
		});
		// brass / copper details
		kit.matBrass = new THREE.MeshStandardMaterial({ color: 0xc8a24b, roughness: 0.3, metalness: 0.95 });
		// foliage + flowers (instanced, per-instance colour)
		kit.matLeaf = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, metalness: 0.0 });
		kit.matLeafPlain = new THREE.MeshStandardMaterial({ roughness: 0.92, metalness: 0.0 });

		// striped canvas for awnings / laundry
		const stripeCanvas = U.createCanvas(128);
		{
			const c = stripeCanvas.getContext('2d');
			c.fillStyle = '#f2ead8';
			c.fillRect(0, 0, 128, 128);
			c.fillStyle = '#cfd6d2';
			for (let i = 0; i < 128; i += 32) c.fillRect(i, 0, 16, 128);
			// canvas weave
			const rr = U.rng(77);
			for (let i = 0; i < 900; i++) {
				c.fillStyle = `rgba(255,255,250,${rr.range(0.03, 0.1)})`;
				c.fillRect(rr.range(0, 128), rr.range(0, 128), rr.range(1, 4), 1);
			}
		}
		const stripeTex = U.canvasTex(stripeCanvas, { cacheKey: 't3-stripes', repeat: [1, 1] });
		kit.matFabric = new THREE.MeshStandardMaterial({
			map: stripeTex,
			vertexColors: true,
			roughness: 0.88,
			metalness: 0.0,
			side: THREE.DoubleSide,
		});
		kit.matFabricPlain = new THREE.MeshStandardMaterial({
			map: stripeTex,
			roughness: 0.88,
			metalness: 0.0,
			side: THREE.DoubleSide,
		});

		// sign atlas: 4 x 8 cells of 256 x 128
		kit.signAtlas = makeSignAtlas();
		kit.matSign = new THREE.MeshStandardMaterial({
			map: kit.signAtlas.texture,
			emissiveMap: kit.signAtlas.texture,
			emissive: new THREE.Color('#ffd9a0'),
			emissiveIntensity: 0.0,
			roughness: 0.6,
			metalness: 0.05,
			side: THREE.DoubleSide,
		});
		kit.signTex = kit.signAtlas.texture;

		// fountain water / basin
		kit.matWater = new THREE.MeshStandardMaterial({
			color: 0x2f7d86,
			roughness: 0.06,
			metalness: 0.55,
			transparent: true,
			opacity: 0.82,
			emissive: new THREE.Color('#0d3a45'),
			emissiveIntensity: 0.25,
		});
		return kit;
	}

	// ------------------------------------------------------------------
	// sign atlas (shop signs / clock faces), procedurally drawn
	// ------------------------------------------------------------------
	function makeSignAtlas() {
		const c = U.createCanvas(1024, 1024);
		const ctx = c.getContext('2d');
		ctx.fillStyle = '#1aa';
		ctx.fillRect(0, 0, 1024, 1024);
		const cols = 4,
			rows = 8;
		const cw = 1024 / cols,
			ch = 1024 / rows;
		const signs = [
			['TABERNA', '#2f3a34', '#e8dcc0', '#c8a24b'],
			['CAF闁?DO PORTO', '#3a2b22', '#f2e6ce', '#d1995a'],
			['PESCADO FRESCO', '#1f3a42', '#e9f0ea', '#8aa7b3'],
			['PENS闁煎瓨鈹?RIBA', '#4a2f2a', '#efe2c9', '#cf9a86'],
			['MERCADO', '#2a3a4a', '#e7e0cc', '#8aa7b3'],
			['MERCEARIA', '#3e3a28', '#efe6d2', '#c8a24b'],
			['P闁煎瓨鈹?& VINHO', '#34302a', '#f4efe3', '#d1995a'],
			['FARM闁煎瓨妞€IA', '#24382f', '#e8f0e4', '#7d9c84'],
			['HOTEL RIBEIRA', '#33262e', '#efe2c9', '#cf9a86'],
			['SAPATARIA', '#2c2a26', '#e8dfc8', '#b9ac96'],
			['BARBEIRO', '#3a2c2c', '#efe6d2', '#b3453b'],
			['FLORES', '#2c3a2c', '#eef0dc', '#d67ba1'],
			['TABACO', '#33291c', '#e8dcc0', '#c39a4a'],
			['RESTAURANTE', '#3a241e', '#f4e6ca', '#d1995a'],
			['VINHOS & AGUARDENTE', '#2a2a34', '#e9e2cf', '#8aa7b3'],
			['PADARIA', '#39301f', '#f2e9d2', '#e0a24b'],
			['CASA DO MAR', '#20323a', '#e4eee9', '#7fc6c9'],
			['MARINHEIRO', '#2e3238', '#e8e2d0', '#c8a24b'],
		];
		for (let i = 0; i < cols * rows; i++) {
			const cx = (i % cols) * cw,
				cy = Math.floor(i / cols) * ch;
			ctx.save();
			ctx.translate(cx, cy);
			const sign = signs[i];
			if (sign) {
				const [text, bg, fg, accent] = sign;
				ctx.fillStyle = bg;
				ctx.fillRect(0, 0, cw, ch);
				// border
				ctx.strokeStyle = accent;
				ctx.lineWidth = 8;
				ctx.strokeRect(10, 10, cw - 20, ch - 20);
				ctx.strokeStyle = 'rgba(0,0,0,0.25)';
				ctx.lineWidth = 2;
				ctx.strokeRect(20, 20, cw - 40, ch - 40);
				ctx.fillStyle = fg;
				ctx.textAlign = 'center';
				ctx.textBaseline = 'middle';
				let size = 52;
				ctx.font = `700 ${size}px Georgia, "Times New Roman", serif`;
				while (ctx.measureText(text).width > cw - 46 && size > 20) {
					size -= 2;
					ctx.font = `700 ${size}px Georgia, "Times New Roman", serif`;
				}
				ctx.fillText(text, cw / 2, ch / 2 - 2);
				// patina
				ctx.fillStyle = 'rgba(255,255,255,0.05)';
				for (let k = 0; k < 20; k++) ctx.fillRect(cw * 0.5 - 100 + Math.random() * 200, Math.random() * ch, 30, 2);
			}
			ctx.restore();
		}
		// clock faces in the last two cells (row 7, cols 2 & 3)
		const clockCell = (index) => {
			const cx = (index % cols) * cw,
				cy = Math.floor(index / cols) * ch;
			ctx.save();
			ctx.translate(cx, cy);
			ctx.fillStyle = '#e9e0ca';
			ctx.fillRect(0, 0, cw, ch);
			const r = ch * 0.42;
			ctx.beginPath();
			ctx.arc(cw / 2, ch / 2, r, 0, TAU);
			ctx.fillStyle = '#f4efe0';
			ctx.fill();
			ctx.lineWidth = 7;
			ctx.strokeStyle = '#3a3a36';
			ctx.stroke();
			ctx.strokeStyle = '#2c2c28';
			for (let t = 0; t < 12; t++) {
				const a = (t / 12) * TAU;
				ctx.lineWidth = t % 3 === 0 ? 6 : 3;
				ctx.beginPath();
				ctx.moveTo(cw / 2 + Math.cos(a) * r * 0.8, ch / 2 + Math.sin(a) * r * 0.8);
				ctx.lineTo(cw / 2 + Math.cos(a) * r * 0.92, ch / 2 + Math.sin(a) * r * 0.92);
				ctx.stroke();
			}
			// hands at 17:20
			ctx.lineCap = 'round';
			ctx.lineWidth = 7;
			ctx.beginPath();
			ctx.moveTo(cw / 2, ch / 2);
			ctx.lineTo(cw / 2 + Math.cos(-PI / 2 + 0.62) * r * 0.5, ch / 2 + Math.sin(-PI / 2 + 0.62) * r * 0.5);
			ctx.stroke();
			ctx.lineWidth = 4;
			ctx.beginPath();
			ctx.moveTo(cw / 2, ch / 2);
			ctx.lineTo(cw / 2 + Math.cos(-PI / 2 - 0.35) * r * 0.8, ch / 2 + Math.sin(-PI / 2 - 0.35) * r * 0.8);
			ctx.stroke();
			ctx.restore();
		};
		clockCell(29);
		clockCell(30);
		return { canvas: c, texture: U.canvasTex(c, { cacheKey: 't3-sign-atlas' }) };
	}

	// sign atlas uv rect for cell index
	function signUV(index) {
		const cols = 4,
			rows = 8;
		const cx = index % cols,
			cy = Math.floor(index / cols);
		const pad = 0.004;
		return [cx / cols + pad, 1 - (cy + 1) / rows + pad, (cx + 1) / cols - pad, 1 - cy / rows - pad];
	}

	// ------------------------------------------------------------------
	// geometry helpers
	// ------------------------------------------------------------------
	function ensureIndexed(geo) {
		if (geo.index) return geo;
		const n = geo.attributes.position.count;
		const idx = new Uint16Array(n);
		for (let i = 0; i < n; i++) idx[i] = i;
		geo.setIndex(new THREE.BufferAttribute(idx, 1));
		return geo;
	}

	function scaleBoxUV(geo, w, h, d, s) {
		const uv = geo.attributes.uv;
		const dims = [
			[d, h],
			[d, h],
			[w, d],
			[w, d],
			[w, h],
			[w, h],
		];
		for (let f = 0; f < 6; f++) {
			const su = dims[f][0] / s,
				sv = dims[f][1] / s;
			for (let i = f * 4; i < f * 4 + 4; i++) uv.setXY(i, uv.getX(i) * su, uv.getY(i) * sv);
		}
		uv.needsUpdate = true;
	}

	function paint(geo, color) {
		const n = geo.attributes.position.count;
		const arr = new Float32Array(n * 3);
		const c = color instanceof THREE.Color ? color : U.color(color || '#ffffff');
		for (let i = 0; i < n; i++) {
			arr[i * 3] = c.r;
			arr[i * 3 + 1] = c.g;
			arr[i * 3 + 2] = c.b;
		}
		geo.setAttribute('color', new THREE.BufferAttribute(arr, 3));
	}

	// frame geometry for windows: outer case + sill + lintel, normalised for
	// a 0.16 x 0.215 window (scale ~uniformly when instancing)
	function makeWindowTrimGeo() {
		const W = 0.16,
			Hh = 0.215,
			bar = 0.022,
			dep = 0.05;
		const parts = [];
		const bd = (w, h, d, x, y, z) => {
			const g = new THREE.BoxGeometry(w, h, d);
			scaleBoxUV(g, w, h, d, 0.3);
			g.translate(x, y, z);
			parts.push(g);
		};
		// frame
		bd(W, bar, dep, 0, Hh / 2 - bar / 2, 0);
		bd(W, bar, dep, 0, -Hh / 2 + bar / 2, 0);
		bd(bar, Hh - bar * 2, dep, -W / 2 + bar / 2, 0, 0);
		bd(bar, Hh - bar * 2, dep, W / 2 - bar / 2, 0, 0);
		// sill
		bd(W + 0.055, 0.022, 0.065, 0, -Hh / 2 - 0.012, -0.012);
		// lintel
		bd(W + 0.04, 0.026, 0.058, 0, Hh / 2 + 0.014, -0.008);
		return U.merge(parts);
	}

	function makeShutterGeo() {
		const g = new THREE.BoxGeometry(1, 1, 1);
		scaleBoxUV(g, 1, 1, 1, 0.25);
		return g;
	}

	function makeLeafGeo() {
		return new THREE.IcosahedronGeometry(1, 0);
	}

	function makeTrunkGeo() {
		return new THREE.CylinderGeometry(0.5, 0.62, 1, 6);
	}

	function makePotGeo() {
		return new THREE.CylinderGeometry(0.5, 0.4, 1, 7);
	}

	function makeFlowerGeo() {
		return new THREE.IcosahedronGeometry(1, 0);
	}

	function makeChimneyGeo() {
		const g = new THREE.BoxGeometry(1, 1, 1);
		scaleBoxUV(g, 1, 1, 1, 0.24);
		return g;
	}

	// flat accumulator for custom roof shapes
	function GeoAccum() {
		return { pos: [], uv: [], idx: [], hint: [] };
	}
	function accQuad(A, p0, p1, p2, p3, out, uvs) {
		const base = A.pos.length / 3;
		const pts = [p0, p1, p2, p3];
		for (const p of pts) A.pos.push(p[0], p[1], p[2]);
		const c = new THREE.Vector3().subVectors(new THREE.Vector3().fromArray(p1), new THREE.Vector3().fromArray(p0));
		const e = new THREE.Vector3().subVectors(new THREE.Vector3().fromArray(p2), new THREE.Vector3().fromArray(p0));
		const n = new THREE.Vector3().crossVectors(c, e).normalize();
		const flip = n.dot(new THREE.Vector3().fromArray(out)) < 0;
		if (flip) {
			A.idx.push(base, base + 2, base + 1, base, base + 3, base + 2);
		} else {
			A.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
		}
		if (uvs) {
			for (let i = 0; i < 4; i++) A.uv.push(uvs[i * 2], uvs[i * 2 + 1]);
		} else {
			A.uv.push(0, 0, 1, 0, 1, 1, 0, 1);
		}
	}
	function accTri(A, p0, p1, p2, out) {
		const base = A.pos.length / 3;
		for (const p of [p0, p1, p2]) A.pos.push(p[0], p[1], p[2]);
		const c = new THREE.Vector3().subVectors(new THREE.Vector3().fromArray(p1), new THREE.Vector3().fromArray(p0));
		const e = new THREE.Vector3().subVectors(new THREE.Vector3().fromArray(p2), new THREE.Vector3().fromArray(p0));
		const n = new THREE.Vector3().crossVectors(c, e).normalize();
		const flip = n.dot(new THREE.Vector3().fromArray(out)) < 0;
		if (flip) A.idx.push(base, base + 2, base + 1);
		else A.idx.push(base, base + 1, base + 2);
		A.uv.push(0, 0, 1, 0, 0.5, 1);
	}
	function accumGeo(A) {
		const g = new THREE.BufferGeometry();
		g.setAttribute('position', new THREE.Float32BufferAttribute(A.pos, 3));
		g.setAttribute('uv', new THREE.Float32BufferAttribute(A.uv, 2));
		g.setIndex(A.idx);
		g.computeVertexNormals();
		return g;
	}
	// quad with planar uv scaled by world size
	function accQuadSized(A, p0, p1, p2, p3, out, uvScale) {
		const len = (a, b) => Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]) / (uvScale || 1);
		const u0 = len(p0, p1),
			v0 = len(p1, p2);
		accQuad(A, p0, p1, p2, p3, out, [0, 0, u0, 0, u0, v0, 0, v0]);
	}

	// ------------------------------------------------------------------
	// register the module
	// ------------------------------------------------------------------
	H.register('town', {
		create(ctx) {
			const g = ctx.group('town');
			const M = ctx.materials;
			const kit = makeKit();
			const r = U.rng(7788);

			// ==========================================================
			// scene builder: merged buckets + instanced batches
			// ==========================================================
			const CUR = new THREE.Matrix4(); // current building -> world
			const merged = new Map(); // key -> {mat, geos: []}
			const batch = new Map(); // key -> {geo, mat, list: [], colors: []}
			const worldData = { buildings: [], landmarks: [] };
			ctx.world.town = worldData;

			const MATS = {
				wall: { mat: kit.matWall, vc: true, uv: 0.55 },
				brick: { mat: kit.matBrick, vc: false, uv: 0.34 },
				stone: { mat: kit.matStone, vc: false, uv: 0.5 },
				roof: { mat: kit.matRoof, vc: true, uv: 0.55 },
				trim: { mat: kit.matTrim, vc: true },
				wood: { mat: kit.matWood, vc: true, uv: 0.42 },
				metal: { mat: kit.matMetal, vc: true },
				fabric: { mat: kit.matFabric, vc: true },
				sign: { mat: kit.matSign, vc: false },
				glassDark: { mat: kit.matGlassDark, vc: false },
				glassLit: { mat: kit.matGlassLit, vc: false },
				brass: { mat: kit.matBrass, vc: false },
				water: { mat: kit.matWater, vc: false },
				paving: { mat: M.get('cobble'), vc: false },
				rope: { mat: M.get('rope'), vc: false },
			};

			function bucketOf(key) {
				let b = merged.get(key);
				if (!b) {
					b = { mat: MATS[key].mat, geos: [] };
					merged.set(key, b);
				}
				return b;
			}
			function pushGeo(key, geo, color) {
				const cfg = MATS[key];
				ensureIndexed(geo);
				if (cfg.vc) paint(geo, color || '#ffffff');
				bucketOf(key).geos.push(geo);
			}
			function batchOf(key, geo, mat) {
				let b = batch.get(key);
				if (!b) {
					b = { geo, mat, list: [], colors: [] };
					batch.set(key, b);
				}
				return b;
			}

			// local -> world helpers ----------------------------------
			const _q = new THREE.Quaternion();
			const _e = new THREE.Euler();
			const _p = new THREE.Vector3();
			const _s = new THREE.Vector3();
			const _m = new THREE.Matrix4();
			function locM(x, y, z, rx, ry, rz, sx, sy, sz) {
				_e.set(rx || 0, ry || 0, rz || 0, 'YXZ');
				_q.setFromEuler(_e);
				_p.set(x || 0, y || 0, z || 0);
				_s.set(sx == null ? 1 : sx, sy == null ? 1 : sy, sz == null ? 1 : sz);
				return new THREE.Matrix4().compose(_p, _q, _s);
			}
			function worldM(lm) {
				return new THREE.Matrix4().multiplyMatrices(CUR, lm);
			}
			// merged geometry: local matrix then CUR
			function mGeo(key, color, geo, lm) {
				if (lm) geo.applyMatrix4(lm);
				geo.applyMatrix4(CUR);
				pushGeo(key, geo, color);
			}
			function mBox(key, color, w, h, d, x, y, z, o) {
				const geo = new THREE.BoxGeometry(w, h, d);
				const cfg = MATS[key];
				if (cfg.uv) scaleBoxUV(geo, w, h, d, cfg.uv);
				mGeo(key, color, geo, locM(x, y, z, o && o.rx, o && o.ry, o && o.rz));
			}
			function mCyl(key, color, rt, rb, h, seg, x, y, z, o) {
				const geo = new THREE.CylinderGeometry(rt, rb, h, seg);
				mGeo(key, color, geo, locM(x, y, z, o && o.rx, o && o.ry, o && o.rz));
			}
			// instanced: geometry already local; matrix is CUR * local
			const _bm = new THREE.Matrix4();
			function inst(key, geo, mat, color, lm) {
				const b = batchOf(key, geo, mat);
				b.list.push(worldM(lm));
				b.colors.push(color ? (color.isColor ? color : U.color(color)) : null);
			}
			function instBox(key, geoFactory, mat, color, w, h, d, x, y, z, o) {
				const geo = geoFactory();
				inst(key, geo, mat, color, locM(x, y, z, o && o.rx, o && o.ry, o && o.rz, w, h, d));
			}

			// shared unit geometries for instancing
			const GEO = {
				winTrim: makeWindowTrimGeo(),
				winGlass: new THREE.PlaneGeometry(1, 1),
				shutter: makeShutterGeo(),
				leaf: makeLeafGeo(),
				trunk: makeTrunkGeo(),
				pot: makePotGeo(),
				flower: makeFlowerGeo(),
				chimney: makeChimneyGeo(),
				laundry: new THREE.PlaneGeometry(1, 1),
			};

			// window helper.  Face frame: unit window faces local -z.
			// (x,y,z) = centre on the facade, ry = rotation of the window unit.
			const WIN_W = 0.16,
				WIN_H = 0.215;
			// a glass pane that faces the same way as a window unit (local -z)
			function addGlass(x, y, z, ry, w, h, lit, litMat) {
				const m = lit ? litMat || kit.matGlassLit : litMat || kit.matGlassDark;
				if (lit) inst('glowGlass', GEO.winGlass, m, null, locM(x, y, z, 0, ry + PI, 0, w, h, 1));
				else inst('winGlass', GEO.winGlass, m, null, locM(x, y, z, 0, ry + PI, 0, w, h, 1));
			}
			function addWindow(x, y, z, ry, opts) {
				opts = opts || {};
				const s = opts.scale || 1;
				const color = opts.trim || '#e6dcc6';
				inst('winTrim', GEO.winTrim, kit.matTrimPlain, color, locM(x, y, z, 0, ry, 0, s, s, s));
				const lit = opts.lit;
				addGlass(x, y, z - 0.002, ry, WIN_W * 0.86 * s, WIN_H * 0.86 * s, lit);
				{
					const hw2 = WIN_W * 0.36 * s;
					const hlx = Math.cos(ry) * -hw2;
					const hlz = -Math.sin(ry) * -hw2;
					inst('winGlassHi', GEO.winGlass, kit.matGlassHi, null, locM(x + hlx, y, z - 0.006, 0, ry + PI, 0, 0.011 * s, WIN_H * 0.7 * s, 1));
				}
				if (opts.shutters) {
					const sc = opts.shutterColor || '#4a6b5e';
					const sw = WIN_W * 0.52 * s,
						shh = WIN_H * 0.96 * s;
					const dx = (WIN_W * 0.5 + sw * 0.5 - 0.004) * s;
					// local offsets need rotating into the facade frame
					const cx = Math.cos(ry),
						sx = Math.sin(ry);
					// facade right direction in local building space = (cos(ry), 0, -sin(ry))
					inst('shutter', GEO.shutter, kit.matTrimPlain, sc, locM(x + cx * dx, y, z - sx * dx, 0, ry, 0, sw, shh, 0.018));
					inst('shutter', GEO.shutter, kit.matTrimPlain, sc, locM(x - cx * dx, y, z + sx * dx, 0, ry, 0, sw, shh, 0.018));
				}
				if (opts.flowers) {
					const side = opts.flowers === 2 ? -1 : 1;
					inst('pot', GEO.pot, kit.matTrimPlain, '#a8613e', locM(x + side * WIN_W * 0.35, y - WIN_H * 0.55, z - 0.05, 0, 0, 0, 0.048, 0.05, 0.048));
					const lc = U.color(r.pick(LEAF_COLORS));
					for (let i = 0; i < 3; i++) {
						inst('leaf', GEO.leaf, kit.matLeafPlain, lc, locM(x + side * WIN_W * 0.35 + r.range(-0.03, 0.03), y - WIN_H * 0.55 + 0.04, z - 0.05 + r.range(-0.02, 0.02), r.range(0, 3), r.range(0, 3), 0, 0.035, 0.028, 0.035));
					}
					for (let i = 0; i < 2; i++) {
						inst('flower', GEO.flower, kit.matLeafPlain, U.color(r.pick(FLOWER_COLORS)), locM(x + side * WIN_W * 0.35 + r.range(-0.03, 0.03), y - WIN_H * 0.55 + 0.05, z - 0.055 + r.range(-0.02, 0.02), 0, 0, 0, 0.014, 0.012, 0.014));
					}
				}
			}

			// sign quad: uv rect from the atlas, faces local -z
			function addSign(index, x, y, z, w, h, ry, opts) {
				const rect = signUV(index);
				const A = GeoAccum();
				const hw = w / 2,
					hh = h / 2;
				const p = [
					[-hw, -hh, 0],
					[hw, -hh, 0],
					[hw, hh, 0],
					[-hw, hh, 0],
				].map((q) => [q[0], q[1], q[2]]);
				const base = A.pos.length / 3;
				for (const q of p) A.pos.push(q[0], q[1], q[2]);
				A.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
				A.uv.push(rect[2], rect[1], rect[0], rect[1], rect[0], rect[3], rect[2], rect[3]);
				const geo = accumGeo(A);
				mGeo('sign', null, geo, locM(x, y, z, 0, ry || 0, 0));
				// second face so hanging signs read correctly from both sides
				const B = GeoAccum();
				for (const q of p) B.pos.push(q[0], q[1], q[2]);
				B.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
				B.uv.push(rect[0], rect[1], rect[2], rect[1], rect[2], rect[3], rect[0], rect[3]);
				mGeo('sign', null, accumGeo(B), locM(x, y, z + 0.006, 0, (ry || 0) + PI, 0));
				if (opts && opts.board) {
					// painted wooden board behind the sign face
					mBox('trim', '#2e3230', w + 0.03, h + 0.03, 0.022, x, y, z + 0.016, { ry: ry || 0 });
				}
				if (opts && opts.bracket) {
					mBox('metal', '#2f3336', 0.012, 0.012, 0.09, x, y + h / 2 + 0.02, z + 0.03, { ry: ry || 0 });
				}
			}

			// ==========================================================
			// building generation
			// ==========================================================
			const FLOOR_H = 0.405;
			function groundInfo(cx, cz, ry, fw, d) {
				// sample the four footprint corners + the middle of the front
				const c = Math.cos(ry),
					s = Math.sin(ry);
				let gmin = 1e9,
					gmax = -1e9;
				for (const [sx, sz] of [[1, 1], [-1, 1], [-1, -1], [1, -1]]) {
					const lx = (sx * fw) / 2,
						lz = (sz * d) / 2;
					const wx = cx + lx * c + lz * s,
						wz = cz - lx * s + lz * c;
					const h = L.groundHeight(wx, wz);
					if (h < gmin) gmin = h;
					if (h > gmax) gmax = h;
				}
				const frontH = L.groundHeight(cx - (d / 2) * s, cz - (d / 2) * c);
				return { gmin, gmax, frontH };
			}

			/**
			 * Build one townhouse in the current frame.
			 * opts: {floors, fw, d, seed, base, kind}
			 */
			function buildHouse(cx, cz, ry, opts) {
				const seed = opts.seed || 1;
				const rr = U.rng(seed);
				const fw = opts.fw,
					d = opts.d;
				const floors = opts.floors;
				const gi = groundInfo(cx, cz, ry, fw, d);
				const base = Math.max(gi.frontH, gi.gmin + 0.14) + 0.03;
				const wallColor = weighted(rr, WALL_COLORS);
				const roofColor = weighted(rr, ROOF_COLORS);
				const brick = rr.chance(0.16);
				const stoneWall = !brick && rr.chance(0.1);
				const wallKey = brick ? 'brick' : stoneWall ? 'stone' : 'wall';
				const wallPaint = brick ? null : stoneWall ? null : wallColor;

				CUR.makeRotationY(ry);
				CUR.setPosition(cx, 0, cz);
				worldData.buildings.push({ x: cx, z: cz, r: Math.max(fw, d) * 0.62 + 0.06, h: floors * FLOOR_H + 0.6 });

				// ---------- foundation / plinth ----------
				const foundH = Math.max(0.14, base - gi.gmin + 0.2);
				mBox('stone', null, fw - 0.02, foundH, d - 0.02, 0, base - foundH / 2, 0);
				// plinth band
				mBox('stone', null, fw + 0.035, 0.075, d + 0.035, 0, base + 0.037, 0);

				// ---------- main walls ----------
				const wallH = 0.125 + floors * FLOOR_H + (floors > 1 ? 0.02 : 0);
				const wallY = base + 0.075 + wallH / 2;
				mBox(wallKey, wallPaint, fw, wallH, d, 0, wallY, 0);
				// quoin stones on brick / stone houses
				if (brick || stoneWall) {
					const qn = Math.floor(wallH / 0.16);
					for (let i = 0; i < qn; i++) {
						const qy = base + 0.075 + 0.08 + i * 0.16;
						const qw = i % 2 ? 0.05 : 0.075;
						mBox('stone', null, qw, 0.1, 0.04, -fw / 2 + qw / 2 - 0.005, qy, -d / 2 - 0.012);
						mBox('stone', null, qw, 0.1, 0.04, fw / 2 - qw / 2 + 0.005, qy, -d / 2 - 0.012);
					}
				}
				// string courses between floors
				for (let f = 1; f < floors; f++) {
					const cy = base + 0.075 + 0.1 + f * FLOOR_H;
					mBox('trim', '#e3d7bd', fw + 0.02, 0.018, 0.035, 0, cy, -d / 2 - 0.014);
				}
				// cornice under the roof
				const eaveY = base + 0.075 + wallH;
				mBox('trim', '#e3d7bd', fw + 0.05, 0.03, 0.06, 0, eaveY + 0.005, -d / 2 - 0.02);
				mBox('trim', '#dccfb3', fw + 0.05, 0.028, 0.06, 0, eaveY + 0.005, d / 2 + 0.02);

				// ---------- windows / doors / front ----------
				const frontZ = -d / 2 - 0.005;
				const nWin = Math.max(1, Math.min(3, Math.round(fw / 0.34)));
				const trimColor = rr.chance(0.6) ? '#e6dcc6' : '#d8cbb0';
				// upper floors
				for (let f = 1; f < floors; f++) {
					const wy = base + 0.075 + f * FLOOR_H + FLOOR_H * 0.52;
					for (let i = 0; i < nWin; i++) {
						const wx = ((i + 0.5) / nWin - 0.5) * (fw - 0.16);
						addWindow(wx, wy, frontZ, 0, {
							scale: rr.range(0.92, 1.06),
							trim: trimColor,
							shutters: rr.chance(0.72),
							shutterColor: rr.pick(SHUTTER_COLORS),
							lit: rr.chance(0.42),
							flowers: rr.chance(0.32) ? (rr.chance(0.5) ? 1 : 2) : 0,
						});
					}
					// side windows on both flanks (they read from the neighbouring lane)
					if (fw > 0.62) {
						addWindow(-fw / 2 - 0.005, wy, 0, -PI / 2, { scale: 0.82, trim: trimColor, lit: rr.chance(0.3), shutters: rr.chance(0.4), shutterColor: rr.pick(SHUTTER_COLORS) });
						addWindow(fw / 2 + 0.005, wy, 0, PI / 2, { scale: 0.82, trim: trimColor, lit: rr.chance(0.3), shutters: rr.chance(0.4), shutterColor: rr.pick(SHUTTER_COLORS) });
					}
				}
				// back facade windows (simplified but present on every floor)
				const nBack = Math.max(1, Math.round(fw / 0.4));
				for (let f = 1; f < floors; f++) {
					const wy = base + 0.075 + f * FLOOR_H + FLOOR_H * 0.52;
					for (let i = 0; i < nBack; i++) {
						const wx = ((i + 0.5) / nBack - 0.5) * (fw - 0.2);
						addWindow(wx, wy, d / 2 + 0.005, PI, { scale: 0.82, trim: trimColor, lit: rr.chance(0.3), shutters: rr.chance(0.35), shutterColor: rr.pick(SHUTTER_COLORS), flowers: rr.chance(0.12) ? 1 : 0 });
					}
				}
				// back ground floor: service door / small window / laundry line
				{
					const bwx = rr.range(-fw * 0.3, fw * 0.3);
					addWindow(bwx, base + 0.075 + FLOOR_H * 0.52, d / 2 + 0.005, PI, { scale: rr.range(0.9, 1.0), trim: trimColor, lit: rr.chance(0.3) });
					if (rr.chance(0.45)) {
						const bdx = rr.range(-fw * 0.4, fw * 0.4);
						mBox('trim', '#d8ccb2', 0.13, 0.31, 0.04, bdx, base + 0.075 + 0.16, d / 2 + 0.012);
						mBox('wood', rr.pick(DOOR_COLORS), 0.1, 0.28, 0.03, bdx, base + 0.075 + 0.15, d / 2 + 0.02);
					}
					// clothes line across the back yard
					if (rr.chance(0.3)) {
						const ly = base + 0.075 + FLOOR_H * 1.4;
						mBox('metal', '#7c6a52', fw * 0.8, 0.005, 0.005, 0, ly, d / 2 + 0.12);
						for (let i = 0; i < 3; i++) {
							const cx2 = -fw * 0.28 + i * fw * 0.28;
							inst('laundry', GEO.laundry, kit.matFabricPlain, r.pick(['#efe6d2', '#cfd6d2', '#d8b0a0']), locM(cx2, ly - 0.05, d / 2 + 0.12, 0, 0, 0, 0.06, 0.09, 1));
						}
					}
				}

				// ground floor: door + windows / shop front
				const commercial = opts.commercial;
				const doorSide = rr.chance(0.5) ? -1 : 1;
				const gwY = base + 0.075 + FLOOR_H * 0.5;
				if (commercial) {
					// shop window opening
					const sw = fw * 0.56,
						sh = FLOOR_H * 0.62;
					const sx = -doorSide * fw * 0.14;
					// frame
					const shopTrim = rr.chance(0.5) ? '#3a4a44' : '#5b3a2c';
					mBox('trim', shopTrim, sw + 0.05, 0.03, 0.05, sx, gwY + sh / 2 + 0.015, frontZ - 0.012);
					mBox('trim', shopTrim, sw + 0.05, 0.03, 0.05, sx, gwY - sh / 2 - 0.015, frontZ - 0.012);
					mBox('trim', shopTrim, 0.03, sh, 0.05, sx - sw / 2 - 0.01, gwY, frontZ - 0.012);
					mBox('trim', shopTrim, 0.03, sh, 0.05, sx + sw / 2 + 0.01, gwY, frontZ - 0.012);
					// glass (instanced large plane)
					const lit = rr.chance(0.5);
					addGlass(sx, gwY, frontZ - 0.002, 0, sw, sh, lit);
					// mullion
					mBox('trim', shopTrim, 0.018, sh, 0.03, sx, gwY, frontZ - 0.015);
					// awning
					if (rr.chance(0.72)) {
						const aw = fw * 0.74,
							ad = rr.range(0.16, 0.24);
						const c1 = rr.pick(AWNING_COLORS);
						const ay = gwY + sh / 2 + 0.1;
						const A = GeoAccum();
						accQuadSized(
							A,
							[-aw / 2, 0, 0],
							[aw / 2, 0, 0],
							[aw / 2, -0.09, -ad],
							[-aw / 2, -0.09, -ad],
							[0, 1, 0],
							0.25
						);
						mGeo('fabric', c1, accumGeo(A), locM(0, ay, frontZ - 0.01));
						// valance
						const A2 = GeoAccum();
						accQuadSized(A2, [-aw / 2, 0, 0], [aw / 2, 0, 0], [aw / 2, -0.05, 0], [-aw / 2, -0.05, 0], [0, 0, -1], 0.25);
						mGeo('fabric', c1, accumGeo(A2), locM(0, ay - 0.09, frontZ - 0.01 - ad));
						// support arms
						mBox('metal', '#33373a', 0.012, 0.012, ad + 0.02, -aw / 2 + 0.01, ay, frontZ - 0.01 - ad / 2);
						mBox('metal', '#33373a', 0.012, 0.012, ad + 0.02, aw / 2 - 0.01, ay, frontZ - 0.01 - ad / 2);
					}
					// sign over the shopfront
					const si = rr.int(0, 17);
					addSign(si, 0, gwY + sh / 2 + (rr.chance(0.5) ? 0.2 : 0.3), frontZ - 0.02, fw * 0.62, 0.1, 0, { board: true });
				} else {
					// residential ground floor: door + 1 window
					const nGW = Math.max(1, nWin - 1);
					for (let i = 0; i < nGW; i++) {
						const wx = ((i + 0.5) / nGW - 0.5) * (fw - 0.16) + (doorSide * fw) / 8;
						addWindow(wx, gwY + 0.02, frontZ, 0, {
							scale: rr.range(0.98, 1.12),
							trim: trimColor,
							shutters: rr.chance(0.6),
							shutterColor: rr.pick(SHUTTER_COLORS),
							lit: rr.chance(0.38),
							flowers: rr.chance(0.3) ? 1 : 0,
						});
					}
				}
				// ground floor flank windows (visible from the side lanes)
				if (fw > 0.66) {
					const gwY2 = base + 0.075 + FLOOR_H * 0.5;
					addWindow(-fw / 2 - 0.005, gwY2, -d * 0.12, -PI / 2, { scale: 0.95, trim: trimColor, shutters: rr.chance(0.4), shutterColor: rr.pick(SHUTTER_COLORS), lit: rr.chance(0.35) });
					addWindow(fw / 2 + 0.005, gwY2, d * 0.1, PI / 2, { scale: 0.95, trim: trimColor, lit: rr.chance(0.35) });
				}
				// door
				const doorW = 0.115,
					doorH = Math.min(0.31, FLOOR_H * 0.78);
				const dx = (doorSide * fw) / 2 - doorSide * (doorW / 2 + 0.055);
				mBox('trim', '#d8ccb2', doorW + 0.045, doorH + 0.045, 0.045, dx, base + 0.075 + doorH / 2 + 0.01, frontZ - 0.02);
				mBox('wood', rr.pick(DOOR_COLORS), doorW, doorH, 0.035, dx, base + 0.075 + doorH / 2 + 0.01, frontZ - 0.022);
				// door panels
				mBox('trim', '#2f2a24', doorW * 0.34, doorH * 0.3, 0.008, dx, base + 0.075 + doorH * 0.68, frontZ - 0.042);
				mBox('trim', '#2f2a24', doorW * 0.34, doorH * 0.34, 0.008, dx, base + 0.075 + doorH * 0.27, frontZ - 0.042);
				// handle
				inst('flower', GEO.flower, kit.matBrass, null, locM(dx + doorW * 0.3, base + 0.075 + doorH * 0.48, frontZ - 0.05, 0, 0, 0, 0.014, 0.014, 0.014));
				// steps
				const steps = gi.gmax - gi.gmin > 0.25 ? 2 : 1;
				for (let i = 0; i < steps; i++) {
					mBox('stone', null, doorW + 0.1, 0.045, 0.075 + i * 0.06, dx, base + 0.02 - i * 0.045, frontZ - 0.06 - i * 0.03);
				}
				// little door canopy
				if (rr.chance(0.3)) {
					const A = GeoAccum();
					accQuadSized(A, [-doorW * 0.9, 0.04, 0], [doorW * 0.9, 0.04, 0], [doorW * 0.9, 0, -0.14], [-doorW * 0.9, 0, -0.14], [0, 1, 0], 0.2);
					mGeo('roof', roofColor, accumGeo(A), locM(dx, base + 0.075 + doorH + 0.12, frontZ - 0.01));
					mBox('metal', '#2f3336', 0.01, 0.01, 0.15, dx - doorW * 0.8, base + 0.075 + doorH + 0.11, frontZ - 0.08);
					mBox('metal', '#2f3336', 0.01, 0.01, 0.15, dx + doorW * 0.8, base + 0.075 + doorH + 0.11, frontZ - 0.08);
				}
				// door lamp
				if (rr.chance(0.4)) {
					mBox('metal', '#2f3336', 0.014, 0.014, 0.13, dx + doorW * 0.55, base + 0.075 + doorH + 0.07, frontZ - 0.07);
					mBox('glassLit', null, 0.036, 0.05, 0.05, dx + doorW * 0.55, base + 0.075 + doorH + 0.05, frontZ - 0.14);
				}

				// ---------- roof ----------
				const eave = base + 0.075 + wallH + 0.03;
				const roofH = rr.range(0.2, 0.3) * (floors > 1 ? 1 : 0.85);
				const ov = 0.055;
				const roofType = rr.chance(0.25) ? 'hip' : rr.chance(0.18) ? 'flat' : 'gable';
				if (roofType === 'flat') {
					mBox('roof', roofColor, fw + 0.05, 0.035, d + 0.05, 0, eave + 0.017, 0, { uv: 0.5 });
					// parapet
					mBox('wall', wallPaint, fw + 0.05, 0.1, 0.04, 0, eave + 0.07, -d / 2 - 0.025);
					mBox('wall', wallPaint, fw + 0.05, 0.1, 0.04, 0, eave + 0.07, d / 2 + 0.025);
					mBox('wall', wallPaint, 0.04, 0.1, d + 0.05, -fw / 2 - 0.025, eave + 0.07, 0);
					mBox('wall', wallPaint, 0.04, 0.1, d + 0.05, fw / 2 + 0.025, eave + 0.07, 0);
					roofClutter(true);
				} else if (roofType === 'hip') {
					const A = GeoAccum();
					const hw = fw / 2 + ov,
						hd = d / 2 + ov;
					const ridge = Math.max(0.02, (fw - d) / 2);
					const ry0 = ridge;
					// front slope
					accQuadSized(A, [-hw, 0, -hd], [hw, 0, -hd], [ry0, roofH, 0], [-ry0, roofH, 0], [0, 1, -0.4], 0.55);
					// back slope
					accQuadSized(A, [hw, 0, hd], [-hw, 0, hd], [-ry0, roofH, 0], [ry0, roofH, 0], [0, 1, 0.4], 0.55);
					// left hip
					accTri(A, [-hw, 0, hd], [-hw, 0, -hd], [-ry0, roofH, 0], [-1, 0.4, 0]);
					// right hip
					accTri(A, [hw, 0, -hd], [hw, 0, hd], [ry0, roofH, 0], [1, 0.4, 0]);
					mGeo('roof', roofColor, accumGeo(A), locM(0, eave, 0));
					// eaves fascia
					mBox('trim', '#d8ccb2', fw + ov * 2, 0.03, 0.03, 0, eave - 0.012, -hd);
					mBox('trim', '#d8ccb2', fw + ov * 2, 0.03, 0.03, 0, eave - 0.012, hd);
					mBox('trim', '#d8ccb2', 0.03, 0.03, d + ov * 2, -hw, eave - 0.012, 0);
					mBox('trim', '#d8ccb2', 0.03, 0.03, d + ov * 2, hw, eave - 0.012, 0);
					// ridge cap
					mCyl('roof', roofColor, 0.022, 0.022, ridge * 2 + 0.02, 6, 0, eave + roofH, 0, { rz: PI / 2 });
					roofClutter(false);
				} else {
					// gable ridge along x (parallel to the street)
					const A = GeoAccum();
					const hw = fw / 2 + ov,
						hd = d / 2 + ov;
					accQuadSized(A, [-hw, 0, -hd], [hw, 0, -hd], [hw, roofH, 0], [-hw, roofH, 0], [0, 1, -0.5], 0.55);
					accQuadSized(A, [hw, 0, hd], [-hw, 0, hd], [-hw, roofH, 0], [hw, roofH, 0], [0, 1, 0.5], 0.55);
					mGeo('roof', roofColor, accumGeo(A), locM(0, eave, 0));
					// gable ends (wall material)
					for (const sgn of [-1, 1]) {
						const A2 = GeoAccum();
						const gx = sgn * (fw / 2);
						accTri(A2, [gx, 0, -d / 2], [gx, 0, d / 2], [gx, roofH, 0], [sgn, 0, 0]);
						mGeo('wall', wallPaint, accumGeo(A2), locM(0, eave, 0));
					}
					// eaves fascia
					mBox('trim', '#d8ccb2', fw + ov * 2, 0.03, 0.03, 0, eave - 0.01, -hd);
					mBox('trim', '#d8ccb2', fw + ov * 2, 0.03, 0.03, 0, eave - 0.01, hd);
					// barge boards on the gables
					for (const sgn of [-1, 1]) {
						mBox('trim', '#d8ccb2', 0.03, 0.03, Math.hypot(hd, roofH) + 0.02, sgn * (fw / 2 + 0.005), eave + roofH / 2, -hd / 2, { rx: -Math.atan2(roofH, hd) });
						mBox('trim', '#d8ccb2', 0.03, 0.03, Math.hypot(hd, roofH) + 0.02, sgn * (fw / 2 + 0.005), eave + roofH / 2, hd / 2, { rx: Math.atan2(roofH, hd) });
					}
					// ridge cap
					mCyl('roof', roofColor, 0.024, 0.024, fw + ov * 2, 6, 0, eave + roofH, 0, { rz: PI / 2 });
					roofClutter(false);
				}

				// roof clutter: chimney, dormer, water tank, antenna, laundry
				function roofClutter(flat) {
					const chim = rr.chance(0.85);
					if (chim) {
						const n = rr.chance(0.3) ? 2 : 1;
						for (let i = 0; i < n; i++) {
							const chx = rr.range(-fw * 0.32, fw * 0.32);
							const chz = flat ? rr.range(-d * 0.25, d * 0.25) : rr.range(-d * 0.22, d * 0.22);
							const chH = rr.range(0.16, 0.24);
							const chW = 0.06 + rr.range(0, 0.03);
							const cy = flat ? eave + 0.035 : eave + roofH * (1 - Math.abs(chz) / (d / 2 + 0.1)) * 0.9 + 0.02;
							inst('chimney', GEO.chimney, kit.matBrick, null, locM(chx, cy + chH / 2, chz, 0, 0, 0, chW, chH, chW * 0.85));
							// cap
							mBox('trim', '#8a8175', chW + 0.025, 0.022, chW * 0.85 + 0.025, chx, cy + chH + 0.008, chz);
							// pot
							mCyl('brick', null, 0.02, 0.024, 0.045, 6, chx, cy + chH + 0.035, chz);
						}
					}
					// dormer on the street side for taller houses
					if (!flat && floors >= 3 && rr.chance(0.4)) {
						const dw = 0.16,
							dh = 0.16,
							dd = 0.14;
						const dxp = rr.range(-fw * 0.28, fw * 0.28);
						const dz = -d / 2 + 0.18;
						const dy = eave + roofH * 0.38;
						mBox('wall', wallPaint, dw, dh, dd, dxp, dy + dh / 2, dz);
						// gable
						const A = GeoAccum();
						accTri(A, [-dw / 2, dh, -dd / 2], [dw / 2, dh, -dd / 2], [0, dh + 0.07, 0], [0, 0.5, -1]);
						accTri(A, [dw / 2, dh, dd / 2], [-dw / 2, dh, dd / 2], [0, dh + 0.07, 0], [0, 0.5, 1]);
						mGeo('roof', roofColor, accumGeo(A), locM(dxp, dy, dz));
						addGlass(dxp, dy + dh * 0.55, dz - dd / 2 - 0.005, 0, 0.07, 0.1, rr.chance(0.5));
						mBox('trim', '#d8ccb2', dw + 0.03, 0.022, 0.035, dxp, dy + dh * 0.55 + 0.06, dz - dd / 2 - 0.012);
					}
					// water tank
					if (rr.chance(0.16)) {
						const tx = rr.range(-fw * 0.3, fw * 0.3),
							tz = rr.range(-d * 0.2, d * 0.2);
						const ty = eave + (flat ? 0.04 : roofH * 0.55);
						mCyl('metal', '#4a4038', 0.055, 0.06, 0.1, 10, tx, ty + 0.14, tz);
						mBox('metal', '#3a3530', 0.1, 0.012, 0.1, tx, ty + 0.09, tz);
						for (const s2 of [-1, 1]) mBox('metal', '#3a3530', 0.012, 0.09, 0.012, tx + s2 * 0.04, ty + 0.045, tz);
						inst('pole', GEO.trunk, kit.matMetalPlain, '#3a3530', locM(tx, ty + 0.2, tz, 0, 0, 0, 0.012, 0.06, 0.012));
					}
					// tv antenna
					if (rr.chance(0.2)) {
						const ax = rr.range(-fw * 0.3, fw * 0.3),
							az = rr.range(-d * 0.2, d * 0.2);
						const ay = eave + (flat ? 0.04 : roofH * 0.5);
						inst('pole', GEO.trunk, kit.matMetalPlain, '#2f3336', locM(ax, ay + 0.16, az, 0, 0, 0, 0.008, 0.32, 0.008));
						for (let i = 0; i < 3; i++) {
							mBox('metal', '#2f3336', 0.14 - i * 0.03, 0.006, 0.006, ax, ay + 0.24 + i * 0.03, az);
						}
					}
				}

				// ---------- facade extras ----------
				// balcony on the first upper floor
				const balconyFloor = floors >= 2 && rr.chance(0.42);
				if (balconyFloor) {
					const by = base + 0.075 + FLOOR_H + 0.01;
					const bw = fw * rr.range(0.42, 0.62),
						bd = 0.16;
					const bx = rr.range(-fw * 0.16, fw * 0.16);
					const bz = -d / 2 - bd / 2 - 0.01;
					// slab
					mBox('stone', null, bw, 0.028, bd, bx, by, bz);
					// brackets
					mBox('metal', '#33373a', 0.012, 0.012, bd, bx - bw / 2 + 0.02, by - 0.05, bz);
					mBox('metal', '#33373a', 0.012, 0.012, bd, bx + bw / 2 - 0.02, by - 0.05, bz);
					// railing: uprights instanced
					const nBars = Math.max(4, Math.round(bw / 0.05));
					for (let i = 0; i <= nBars; i++) {
						const bxp = bx - bw / 2 + (i / nBars) * bw;
						inst('pole', GEO.trunk, kit.matMetalPlain, '#2f3336', locM(bxp, by + 0.09, bz - bd / 2 + 0.012, 0, 0, 0, 0.013, 0.17, 0.013));
					}
					// top rail
					mBox('metal', '#2f3336', bw + 0.02, 0.012, 0.012, bx, by + 0.175, bz - bd / 2 + 0.012);
					// side rails
					for (const s2 of [-1, 1]) {
						mBox('metal', '#2f3336', 0.012, 0.012, bd - 0.02, bx + s2 * (bw / 2), by + 0.175, bz);
						inst('pole', GEO.trunk, kit.matMetalPlain, '#2f3336', locM(bx + s2 * (bw / 2), by + 0.09, bz - bd / 2 + 0.012, 0, 0, 0, 0.013, 0.17, 0.013));
					}
					// flower pots on the balcony
					if (rr.chance(0.6)) {
						inst('pot', GEO.pot, kit.matTrimPlain, '#a8613e', locM(bx - bw * 0.3, by + 0.05, bz - bd * 0.3, 0, 0, 0, 0.045, 0.05, 0.045));
						for (let i = 0; i < 2; i++) {
							inst('leaf', GEO.leaf, kit.matLeafPlain, U.color(r.pick(LEAF_COLORS)), locM(bx - bw * 0.3 + r.range(-0.02, 0.02), by + 0.09, bz - bd * 0.3, r.range(0, 3), 0, 0, 0.03, 0.026, 0.03));
							inst('flower', GEO.flower, kit.matLeafPlain, U.color(r.pick(FLOWER_COLORS)), locM(bx - bw * 0.3 + r.range(-0.02, 0.02), by + 0.1, bz - bd * 0.3, 0, 0, 0, 0.012, 0.012, 0.012));
						}
					}
					// laundry line across the balcony
					if (rr.chance(0.35)) {
						const ly = by + 0.24;
						mBox('metal', '#7c6a52', bw * 0.95, 0.005, 0.005, bx, ly, bz - bd * 0.35);
						for (let i = 0; i < 3; i++) {
							const cx2 = bx - bw * 0.32 + i * bw * 0.3;
							const cc = r.pick(['#efe6d2', '#cfd6d2', '#d8b0a0', '#c9d4c0']);
							inst('laundry', GEO.laundry, kit.matFabricPlain, cc, locM(cx2, ly - 0.05, bz - bd * 0.35, 0, 0, 0, 0.07, 0.1, 1));
						}
					}
				}
				// drainpipe at a corner
				if (rr.chance(0.7)) {
					const px = (rr.chance(0.5) ? -1 : 1) * (fw / 2 - 0.03);
					const ph = wallH + 0.1;
					mCyl('metal', '#5a5046', 0.014, 0.014, ph, 6, px, base + 0.075 + ph / 2, -d / 2 - 0.035);
					// brackets
					for (let i = 0; i < 3; i++) mBox('metal', '#5a5046', 0.05, 0.01, 0.03, px, base + 0.1 + i * (ph / 3), -d / 2 - 0.02);
					// downpipe elbow
					mCyl('metal', '#5a5046', 0.014, 0.014, 0.1, 6, px, base + 0.04, -d / 2 - 0.07, { rx: PI / 3 });
				}
				// pot plants next to the door / along the facade
				const pots = rr.int(0, 3);
				for (let i = 0; i < pots; i++) {
					const px = rr.range(-fw * 0.42, fw * 0.42);
					const py = base + 0.02;
					const pz = frontZ - rr.range(0.06, 0.11);
					inst('pot', GEO.pot, kit.matTrimPlain, r.pick(['#a8613e', '#8a4a3a', '#b9ac96']), locM(px, py + 0.03, pz, 0, 0, 0, 0.05, 0.06, 0.05));
					const lc = U.color(r.pick(LEAF_COLORS));
					for (let k = 0; k < 3; k++) {
						inst('leaf', GEO.leaf, kit.matLeafPlain, lc, locM(px + r.range(-0.03, 0.03), py + 0.09 + r.range(0, 0.03), pz + r.range(-0.02, 0.02), r.range(0, 3), r.range(0, 3), 0, 0.036, 0.03, 0.036));
					}
					if (rr.chance(0.6)) {
						for (let k = 0; k < 2; k++) inst('flower', GEO.flower, kit.matLeafPlain, U.color(r.pick(FLOWER_COLORS)), locM(px + r.range(-0.03, 0.03), py + 0.12, pz + r.range(-0.02, 0.02), 0, 0, 0, 0.013, 0.012, 0.013));
					}
				}
				// hanging shop sign
				if (commercial && rr.chance(0.4)) {
					const hx = (rr.chance(0.5) ? -1 : 1) * (fw / 2 - 0.07);
					const hy = base + 0.075 + FLOOR_H + 0.13;
					mBox('metal', '#2f3336', 0.14, 0.01, 0.01, hx, hy + 0.07, frontZ - 0.06);
					addSign(rr.int(0, 17), hx, hy, frontZ - 0.13, 0.16, 0.07, PI / 2, { board: true });
				}
				// roof top flag (rare)
				if (rr.chance(0.08)) {
					const fx = rr.range(-fw * 0.3, fw * 0.3);
					mCyl('metal', '#5a5046', 0.006, 0.008, 0.34, 5, fx, eave + 0.24, 0);
					const A = GeoAccum();
					accQuad(A, [0, 0, 0], [0.13, -0.02, 0.05], [0.13, -0.06, 0.05], [0, -0.08, 0], [1, 0, 0], [0, 0, 1, 0, 1, 1, 0, 1]);
					mGeo('fabric', r.pick(['#b3453b', '#efe6d2', '#3f6688']), accumGeo(A), locM(fx, eave + 0.39, 0));
				}
				return base;
			}

			// ==========================================================
			// 1. frontage rows generated from layout.townLots
			// ==========================================================
			const streetById = {};
			for (const road of L.ROADS) streetById[road.id] = road;
			function projectOnStreet(road, x, z) {
				let best = { d: 1e9, s: 0 };
				let acc = 0;
				for (let i = 1; i < road.points.length; i++) {
					const a = road.points[i - 1],
						b = road.points[i];
					const vx = b[0] - a[0],
						vz = b[1] - a[1];
					const len2 = vx * vx + vz * vz || 1e-9;
					const len = Math.sqrt(len2);
					const t = U.clamp(((x - a[0]) * vx + (z - a[1]) * vz) / len2, 0, 1);
					const px = a[0] + vx * t,
						pz = a[1] + vz * t;
					const d = Math.hypot(x - px, z - pz);
					if (d < best.d) best = { d, s: acc + t * len };
					acc += len;
				}
				return best;
			}
			function obbCorners(o) {
				const out = [];
				for (const [sx, sz] of [[1, 1], [-1, 1], [-1, -1], [1, -1]]) {
					out.push([o.cx + o.ax * o.hw * sx + o.bx * o.hd * sz, o.cz + o.az * o.hw * sx + o.bz * o.hd * sz]);
				}
				return out;
			}
			const keepOuts = [
				{ name: 'plaza', x: L.ANCHORS.plaza.pos[0], z: L.ANCHORS.plaza.pos[1], r: 1.58 },
				{ name: 'church', x: L.ANCHORS.church.pos[0], z: L.ANCHORS.church.pos[1], r: 0.9 },
				{ name: 'marketHall', x: L.ANCHORS.marketHall.pos[0], z: L.ANCHORS.marketHall.pos[1], r: 0.82 },
			];
			const placed = [];
			function canPlace(o, skipRoad, tag) {
				const hs = obbCorners(o).map((p) => L.groundHeight(p[0], p[1]));
				const gmin = Math.min.apply(null, hs),
					gmax = Math.max.apply(null, hs);
				const gmid = L.groundHeight(o.cx, o.cz);
				if (gmid < 1.4) return 'low ground';
				if (gmax - gmin > 1.15) return 'too steep';
				for (const k of keepOuts) {
					const dx = k.x - o.cx,
						dz = k.z - o.cz;
					const lu = dx * o.ax + dz * o.az,
						lv = dx * o.bx + dz * o.bz;
					const du = Math.max(0, Math.abs(lu) - o.hw),
						dv = Math.max(0, Math.abs(lv) - o.hd);
					if (Math.hypot(du, dv) < k.r + 0.02) return 'keepout ' + k.name;
				}
				for (const a of placed) {
					// SAT 2d
					const dx = o.cx - a.o.cx,
						dz = o.cz - a.o.cz;
					let sep = false;
					const axes = [
						[o.ax, o.az],
						[o.bx, o.bz],
						[a.o.ax, a.o.az],
						[a.o.bx, a.o.bz],
					];
					for (const ax of axes) {
						const ra = Math.abs(o.hw * (o.ax * ax[0] + o.az * ax[1])) + Math.abs(o.hd * (o.bx * ax[0] + o.bz * ax[1]));
						const rb = Math.abs(a.o.hw * (a.o.ax * ax[0] + a.o.az * ax[1])) + Math.abs(a.o.hd * (a.o.bx * ax[0] + a.o.bz * ax[1]));
						if (Math.abs(dx * ax[0] + dz * ax[1]) > ra + rb + 0.045) {
							sep = true;
							break;
						}
					}
					if (!sep) return 'overlap ' + a.id;
				}
				if (!skipRoad) {
					for (const road of L.ROADS) {
						for (let i = 1; i < road.points.length; i++) {
							const a = road.points[i - 1],
								b = road.points[i];
							for (let k = 0; k <= 6; k++) {
								const x = a[0] + ((b[0] - a[0]) * k) / 6,
									z = a[1] + ((b[1] - a[1]) * k) / 6;
								const dx = x - o.cx,
									dz = z - o.cz;
								const lu = dx * o.ax + dz * o.az,
									lv = dx * o.bx + dz * o.bz;
								const du = Math.max(0, Math.abs(lu) - o.hw),
									dv = Math.max(0, Math.abs(lv) - o.hd);
								if (Math.hypot(du, dv) < road.width / 2 + 0.055) return 'road ' + road.id;
							}
						}
					}
				}
				return null;
			}

			const rejectLog = {};
			const rejectList = [];
			let idSeq = 0;
			function tryHouse(spec) {
				const front = spec.front; // direction the facade faces
				const n = [-front[0], -front[1]];
				const ry = Math.atan2(n[0], n[1]);
				let cx = spec.cx,
					cz = spec.cz;
				let o = {
					cx,
					cz,
					ax: Math.cos(ry),
					az: -Math.sin(ry),
					bx: n[0],
					bz: n[1],
					hw: spec.fw / 2,
					hd: spec.d / 2,
				};
				let why = canPlace(o, spec.skipRoad, spec.tag);
				// if the front face touches a curving road, step the house back
				for (let attempt = 0; attempt < 2 && why && why.indexOf('road') === 0; attempt++) {
					cx = o.cx + n[0] * 0.16;
					cz = o.cz + n[1] * 0.16;
					o = {
						cx,
						cz,
						ax: o.ax,
						az: o.az,
						bx: n[0],
						bz: n[1],
						hw: o.hw,
						hd: o.hd,
					};
					why = canPlace(o, spec.skipRoad, spec.tag);
				}
				if (why) {
					rejectLog[why.split(' ')[0]] = (rejectLog[why.split(' ')[0]] || 0) + 1;
					return false;
				}
				const base = buildHouse(o.cx, o.cz, ry, {
					fw: spec.fw,
					d: spec.d,
					floors: spec.floors,
					seed: spec.seed,
					commercial: spec.commercial,
				});
				placed.push({ id: spec.id || 'h' + idSeq++, o, base });
				return true;
			}

			const groups = {};
			for (const lot of L.townLots) {
				const key = lot.street + '|' + lot.side;
				(groups[key] = groups[key] || []).push(lot);
			}
			for (const key of Object.keys(groups)) {
				const parts = key.split('|');
				const street = streetById[parts[0]];
				const sideSign = parts[1] === 'left' ? 1 : -1;
				const total = L.polylineLength(street.points);
				const list = groups[key]
					.map((lot) => ({ lot, pr: projectOnStreet(street, lot.pos[0], lot.pos[1]) }))
					.sort((a, b) => a.pr.s - b.pr.s);
				let prevCenter = -1e9,
					prevW = 0;
				for (let i = 0; i < list.length; i++) {
					const lot = list[i].lot;
					const w = lot.width;
					const prS = Math.min(total, Math.max(0, list[i].pr.s));
					const center = Math.max(prS, prevCenter + (prevW + w) / 2 + 0.085);
					if (center > total - 0.15) break;
					const p = L.pointAlong(street.points, center);
					const nx = -p.dirZ * sideSign,
						nz = p.dirX * sideSign;
					const off = street.width / 2 + 0.155 + lot.depth / 2;
					const spec = {
						id: lot.id,
						cx: p.x + nx * off,
						cz: p.z + nz * off,
						fw: w - 0.07,
						d: lot.depth,
						floors: lot.floors,
						seed: lot.styleSeed,
						front: [-nx, -nz],
						commercial: lot.street === 'mainStreet' && lot.floors >= 2 && i % 2 === 0,
						tag: key,
					};
					if (tryHouse(spec)) {
						prevCenter = center;
						prevW = w - 0.07;
					}
				}
			}

			// ==========================================================
			// 2. hand placed extra rows (upper terrace / east pocket)
			// ==========================================================
			const extras = [
				// east pocket lane, facing west into the church square
				{ cx: 1.74, cz: -6.92, front: [-1, 0], fw: 0.95, d: 0.82, floors: 2, seed: 5101, commercial: true },
				{ cx: 1.8, cz: -7.94, front: [-1, 0], fw: 1.0, d: 0.85, floors: 3, seed: 5102, commercial: true },
				{ cx: 1.7, cz: -8.93, front: [-1, 0], fw: 0.88, d: 0.8, floors: 2, seed: 5103 },
				{ cx: 0.52, cz: -7.62, front: [1, 0], fw: 0.82, d: 0.78, floors: 2, seed: 5104 },
				{ cx: 0.48, cz: -8.5, front: [1, 0], fw: 0.9, d: 0.8, floors: 3, seed: 5105 },
				// west upper terrace row
				{ cx: -10.2, cz: -6.95, front: [1, 0], fw: 1.0, d: 0.86, floors: 1, seed: 5201 },
				{ cx: -10.22, cz: -8.05, front: [1, 0], fw: 0.92, d: 0.8, floors: 2, seed: 5202 },
				{ cx: -10.15, cz: -9.0, front: [1, 0], fw: 0.86, d: 0.8, floors: 2, seed: 5203 },
				// a couple of houses closing the north side of the church square
				{ cx: -3.65, cz: -8.35, front: [0, 1], fw: 0.98, d: 0.82, floors: 3, seed: 5401, commercial: true },
				{ cx: -4.62, cz: -8.3, front: [0, 1], fw: 0.86, d: 0.76, floors: 2, seed: 5402 },
				// east pocket, second row facing the lane
				{ cx: 2.36, cz: -6.78, front: [-1, 0], fw: 0.9, d: 0.78, floors: 2, seed: 5501, commercial: true },
				// upper terrace infill
				{ cx: -8.35, cz: -9.2, front: [1, 0], fw: 1.0, d: 0.85, floors: 2, seed: 5502 },
				{ cx: -8.55, cz: -10.4, front: [0, 1], fw: 0.95, d: 0.8, floors: 2, seed: 5503 },
				{ cx: -9.1, cz: -7.45, front: [1, 0], fw: 0.88, d: 0.8, floors: 1, seed: 5504 },
				{ cx: -6.7, cz: -10.95, front: [0, 1], fw: 1.0, d: 0.8, floors: 2, seed: 5505 },
				{ cx: -5.1, cz: -10.6, front: [0, 1], fw: 0.9, d: 0.78, floors: 2, seed: 5506 },
			];
			for (const e of extras) tryHouse(e);

			// ==========================================================
			// 3. landmarks & town furniture
			// ==========================================================
			CUR.identity();

			// --- small shared props -----------------------------------
			function addTree(wx, wy, wz, size, kind) {
				const trunkH = 0.3 * size;
				mCyl('wood', '#59452f', 0.024 * size, 0.036 * size, trunkH, 6, wx, wy + trunkH / 2, wz);
				const cy = wy + trunkH;
				if (kind === 'cypress') {
					for (let i = 0; i < 6; i++) {
						const t = i / 5;
						const sc = size * (0.2 - t * 0.13);
						inst('leaf', GEO.leaf, kit.matLeafPlain, U.color(LEAF_COLORS[i % LEAF_COLORS.length]), locM(wx + r.range(-0.012, 0.012), cy + 0.12 * size + t * 0.42 * size, wz + r.range(-0.012, 0.012), r.range(0, 3), r.range(0, 3), 0, sc, sc * 1.5, sc));
					}
				} else {
					const nBlob = 5;
					for (let i = 0; i < nBlob; i++) {
						const a = r.range(0, TAU);
						const rr2 = r.range(0.02, 0.15) * size;
						const bx = wx + Math.cos(a) * rr2,
							bz = wz + Math.sin(a) * rr2;
						const by = cy + 0.1 * size + r.range(0, 0.22) * size;
						const sc = r.range(0.1, 0.16) * size;
						inst('leaf', GEO.leaf, kit.matLeafPlain, U.color(r.pick(LEAF_COLORS)), locM(bx, by, bz, r.range(0, 3), r.range(0, 3), 0, sc, sc * 0.85, sc));
					}
					// a couple of branches
					mCyl('wood', '#59452f', 0.008, 0.012, 0.14 * size, 4, wx + 0.02, cy + 0.09 * size, wz, { rz: 0.4 });
				}
			}

			function addBench(wx, wy, wz, ry) {
				const c = Math.cos(ry),
					s = Math.sin(ry);
				const pos = (lx, lz) => [wx + lx * c + lz * s, wz - lx * s + lz * c];
				for (let i = 0; i < 3; i++) {
					const p = pos(0, -0.045 + i * 0.045);
					mBox('wood', '#8a6746', 0.44, 0.016, 0.036, p[0], wy + 0.1, p[1], { ry });
				}
				for (let i = 0; i < 2; i++) {
					const p = pos(0, 0.075);
					mBox('wood', '#8a6746', 0.44, 0.03, 0.014, p[0], wy + 0.15 + i * 0.04, p[1], { ry, rx: -0.12 });
				}
				for (const lx of [-0.17, 0.17]) {
					const p = pos(lx, 0.01);
					mBox('metal', '#2f3336', 0.016, 0.1, 0.045, p[0], wy + 0.05, p[1], { ry });
					const p2 = pos(lx, 0.075);
					mBox('metal', '#2f3336', 0.014, 0.13, 0.014, p2[0], wy + 0.1, p2[1], { ry, rx: -0.12 });
				}
			}

			function addLamp(wx, wy, wz, ry) {
				const c = Math.cos(ry),
					s = Math.sin(ry);
				mBox('metal', '#2f3336', 0.06, 0.02, 0.06, wx, wy + 0.01, wz, { ry });
				mCyl('metal', '#2f3336', 0.012, 0.018, 0.5, 6, wx, wy + 0.26, wz);
				mBox('metal', '#2f3336', 0.1, 0.01, 0.01, wx + 0.05 * c, wy + 0.52, wz - 0.05 * s, { ry });
				const hx = wx + 0.1 * c,
					hz = wz - 0.1 * s;
				mBox('glassLit', null, 0.05, 0.07, 0.05, hx, wy + 0.47, hz, { ry });
				mBox('metal', '#2f3336', 0.075, 0.016, 0.075, hx, wy + 0.515, hz, { ry });
				mBox('metal', '#2f3336', 0.02, 0.014, 0.02, hx, wy + 0.445, hz, { ry });
			}

			function addArch(wx, wy, wz, ry, w, h, depth, key, color, o) {
				// dark recess + semi-circular arch head, opening faces local -z
				mBox('trim', '#241f1a', w, h, depth, wx, wy + h / 2, wz, { ry });
				const arc = new THREE.TorusGeometry(w / 2, 0.016, 5, 12, PI);
				mGeo(key, color, arc, locM(wx, wy + h, wz, 0, ry, 0));
				if (o && o.glass) {
					addGlass(wx, wy + h * 0.5, wz + 0.005, ry, w * 0.9, h * 0.9, o.glass !== 'dark');
				}
				if (o && o.sill) mBox(key, color, w + 0.05, 0.02, depth + 0.04, wx, wy - 0.01, wz, { ry });
			}

			function addStall(wx, wy, wz, ry, w) {
				const c = Math.cos(ry),
					s = Math.sin(ry);
				const pos = (lx, lz) => [wx + lx * c + lz * s, wz - lx * s + lz * c];
				// posts
				for (const lx of [-w / 2, w / 2]) {
					for (const lz of [-0.18, 0.18]) {
						const p = pos(lx, lz);
						mCyl('wood', '#7c5a3c', 0.012, 0.014, 0.46, 5, p[0], wy + 0.23, p[1]);
					}
				}
				// table
				const p0 = pos(0, 0);
				mBox('wood', '#8a6746', w + 0.02, 0.03, 0.34, p0[0], wy + 0.2, p0[1], { ry });
				// produce / crates
				for (let i = 0; i < 4; i++) {
					const p = pos(r.range(-w * 0.35, w * 0.35), r.range(-0.09, 0.09));
					mBox('wood', r.pick(['#9a7a52', '#7c5a3c']), 0.1, 0.05, 0.08, p[0], wy + 0.245, p[1], { ry });
					const fruit = r.pick(['#c0504d', '#e0a24b', '#8a9a4a', '#b96b4a']);
					for (let k = 0; k < 3; k++) {
						inst('flower', GEO.flower, kit.matLeafPlain, U.color(fruit), locM(p[0] + r.range(-0.035, 0.035), wy + 0.28, p[1] + r.range(-0.03, 0.03), 0, 0, 0, 0.024, 0.02, 0.024));
					}
				}
				// canvas roof
				const A = GeoAccum();
				accQuadSized(A, [-w / 2 - 0.03, 0.46, 0.22], [w / 2 + 0.03, 0.46, 0.22], [w / 2 + 0.03, 0.38, -0.22], [-w / 2 - 0.03, 0.38, -0.22], [0, 1, 0], 0.3);
				mGeo('fabric', r.pick(['#efe6d2', '#cfd6d2', '#d8b0a0', '#b3453b']), accumGeo(A), locM(wx, wy, wz, 0, ry, 0));
				// valance
				const A2 = GeoAccum();
				accQuadSized(A2, [-w / 2 - 0.03, 0.38, -0.22], [w / 2 + 0.03, 0.38, -0.22], [w / 2 + 0.03, 0.32, -0.22], [-w / 2 - 0.03, 0.32, -0.22], [0, 0, -1], 0.3);
				mGeo('fabric', '#efe6d2', accumGeo(A2), locM(wx, wy, wz, 0, ry, 0));
				// hanging bulb
				inst('glowGlass', GEO.winGlass, kit.matGlassLit, null, locM(p0[0], wy + 0.36, p0[1], 0, 0, 0, 0.035, 0.045, 1));
			}

			function addFlagpole(wx, wy, wz, h, color) {
				mCyl('metal', '#5a5046', 0.008, 0.012, h, 5, wx, wy + h / 2, wz);
				inst('flower', GEO.flower, kit.matBrass, null, locM(wx, wy + h + 0.01, wz, 0, 0, 0, 0.022, 0.022, 0.022));
				const A = GeoAccum();
				accQuad(A, [0, 0, 0], [0.16, -0.025, 0.06], [0.16, -0.07, 0.06], [0, -0.095, 0], [1, 0, 0], [0, 0, 1, 0, 1, 1, 0, 1]);
				mGeo('fabric', color, accumGeo(A), locM(wx, wy + h - 0.03, wz));
			}

			// --- retaining walls --------------------------------------
			function nearRoad(x, z, margin) {
				for (const road of L.ROADS) {
					if (L.distToPolyline(x, z, road.points) < road.width / 2 + margin) return true;
				}
				return false;
			}
			function nearBuilding(x, z, margin) {
				for (const b of placed) {
					const dx = x - b.o.cx,
						dz = z - b.o.cz;
					const lu = dx * b.o.ax + dz * b.o.az,
						lv = dx * b.o.bx + dz * b.o.bz;
					const du = Math.max(0, Math.abs(lu) - b.o.hw),
						dv = Math.max(0, Math.abs(lv) - b.o.hd);
					if (Math.hypot(du, dv) < margin) return true;
				}
				return false;
			}
			function buildRetainingWall(pts, topY, botY, thick, outSign, tag) {
				const step = 0.62;
				for (let i = 1; i < pts.length; i++) {
					const a = pts[i - 1],
						b = pts[i];
					const segLen = Math.hypot(b[0] - a[0], b[1] - a[1]);
					const n = Math.max(1, Math.round(segLen / step));
					for (let k = 0; k < n; k++) {
						const t0 = k / n,
							t1 = (k + 1) / n;
						const x0 = U.lerp(a[0], b[0], t0),
							z0 = U.lerp(a[1], b[1], t0);
						const x1 = U.lerp(a[0], b[0], t1),
							z1 = U.lerp(a[1], b[1], t1);
						const mx = (x0 + x1) / 2,
							mz = (z0 + z1) / 2;
						if (nearRoad(mx, mz, 0.42) || nearBuilding(mx, mz, 0.2)) continue;
						const dx = x1 - x0,
							dz = z1 - z0;
						const len = Math.hypot(dx, dz) + thick * 0.9;
						const ang = Math.atan2(dx, dz);
						const h = topY - botY;
						mBox('stone', null, thick, h, len, mx, (topY + botY) / 2, mz, { ry: ang });
						// coping
						mBox('stone', null, thick + 0.06, 0.055, len, mx, topY + 0.02, mz, { ry: ang });
						// buttress on the downhill side every other block
						if (k % 2 === 0) {
							const nx2 = Math.cos(ang) * outSign,
								nz2 = -Math.sin(ang) * outSign;
							const bx = mx + nx2 * (thick / 2 + 0.05),
								bz = mz + nz2 * (thick / 2 + 0.05);
							mBox('stone', null, 0.14, h * 0.8, 0.16, bx, (topY + botY) / 2 - 0.04, bz, { ry: ang });
						}
						// iron railing on top of the wall: top rail + posts
						const nx3 = Math.cos(ang) * outSign,
							nz3 = -Math.sin(ang) * outSign;
						const rx = mx + nx3 * (thick / 2 - 0.02),
							rz = mz + nz3 * (thick / 2 - 0.02);
						mBox('metal', '#2f3336', 0.018, 0.018, len * 0.94, rx, topY + 0.23, rz, { ry: ang });
						mBox('metal', '#2f3336', 0.012, 0.012, len * 0.94, rx, topY + 0.1, rz, { ry: ang });
						if (k % 2 === 0) {
							mBox('metal', '#2f3336', 0.016, 0.22, 0.016, rx, topY + 0.13, rz, { ry: ang });
						}
						// drainage spout
						if (k === Math.floor(n / 2)) {
							mCyl('metal', '#5a5046', 0.02, 0.02, 0.16, 5, mx + nx3 * (thick / 2 + 0.03), topY - 0.22, mz + nz3 * (thick / 2 + 0.03), { rx: PI / 2 });
						}
					}
				}
				ctx.log('town: retaining wall ' + tag + ' built');
			}
			buildRetainingWall(
				[
					[-8.2, -2.21],
					[-5.6, -2.21],
					[-2.0, -2.21],
					[1.0, -2.6],
					[2.55, -4.1],
				],
				2.14,
				0.72,
				0.3,
				1,
				'quay-side'
			);
			buildRetainingWall(
				[
					[-6.9, -7.0],
					[-5.9, -7.85],
					[-4.9, -8.6],
					[-4.3, -9.6],
					[-4.2, -10.6],
				],
				3.14,
				1.66,
				0.28,
				-1,
				'upper-terrace'
			);

			// ---- quay-side wall dressing: stairs, arched niches, vines ----
			// stone flights from the town terrace down to the quay apron
			function wallStairs(sx) {
				const steps = 9;
				const run = 0.2,
					rise = 0.114;
				const zTop = -2.06;
				const x = sx;
				for (let k = 0; k < steps; k++) {
					const y = 2.14 - (k + 1) * rise;
					const z = zTop + k * run;
					mBox('stone', null, 0.55, 0.13, run + 0.08, x, y - 0.065, z);
					// nosing
					mBox('trim', '#d8ccb2', 0.57, 0.018, 0.04, x, y - 0.004, z - run / 2);
				}
				// cheek walls + handrail
				for (const s2 of [-1, 1]) {
					for (let k = 0; k < steps; k += 2) {
						const y = 2.14 - (k + 1) * rise;
						const z = zTop + k * run;
						mBox('stone', null, 0.1, 0.34, run * 2 + 0.06, x + s2 * 0.33, y + 0.03, z + run / 2);
					}
					const railLen = Math.hypot(steps * run, steps * rise);
					const railTilt = Math.atan2(steps * rise, steps * run);
					mBox('metal', '#2f3336', 0.014, 0.014, railLen + 0.05, x + s2 * 0.33, 2.14 + 0.22 - (steps * rise) / 2, zTop + (steps * run) / 2, { rx: railTilt });
					mBox('metal', '#2f3336', 0.018, 0.22, 0.018, x + s2 * 0.33, 2.14 + 0.11, zTop + 0.02);
					mBox('metal', '#2f3336', 0.018, 0.22, 0.018, x + s2 * 0.33, 2.14 - steps * rise + 0.11, zTop + steps * run - 0.02);
				}
			}
			wallStairs(-6.3);
			wallStairs(-0.6);
			wallStairs(1.55);
			for (const sx2 of [-6.3, -0.6, 1.55]) {
				mBox('stone', null, 0.9, 0.5, 0.55, sx2, 1.02 - 0.22, -2.06 + 9 * 0.2 + 0.12);
				mBox('stone', null, 0.98, 0.1, 0.65, sx2, 1.05, -2.06 + 9 * 0.2 + 0.12);
			}
			// arched niches (blind arches) along the wall face
			for (let x = -7.4; x < 2.2; x += 1.25) {
				if (Math.abs(x - -6.3) < 0.55 || Math.abs(x - -0.6) < 0.55 || Math.abs(x - 1.55) < 0.55) continue;
				const zf = -2.21 + 0.15;
				mBox('stone', '#6c6153', 0.4, 0.62, 0.05, x, 1.6, zf);
				mBox('stone', '#4a4238', 0.26, 0.42, 0.03, x, 1.5, zf - 0.012);
				const arc = new THREE.TorusGeometry(0.2, 0.022, 5, 12, PI);
				mGeo('stone', null, arc, locM(x, 1.91, zf));
				mBox('stone', null, 0.5, 0.06, 0.1, x, 1.26, zf + 0.02);
				// keystone
				mBox('stone', null, 0.07, 0.1, 0.08, x, 2.06, zf + 0.01);
			}
			// wall lamps
			for (const wx of [-7.4, -4.2, -1.4, 1.0]) {
				mBox('metal', '#2f3336', 0.05, 0.02, 0.16, wx, 2.02, -2.21 + 0.2);
				mBox('glassLit', null, 0.06, 0.08, 0.06, wx, 1.94, -2.21 + 0.28);
				mBox('metal', '#2f3336', 0.1, 0.015, 0.1, wx, 2.0, -2.21 + 0.28);
			}
			// climbing vines hanging over the wall top
			for (let x = -7.6; x < 2.4; x += 0.42) {
				if (r.chance(0.55)) continue;
				const lc = U.color(r.pick(LEAF_COLORS));
				const n = r.int(2, 4);
				for (let k = 0; k < n; k++) {
					inst('leaf', GEO.leaf, kit.matLeafPlain, lc, locM(x + r.range(-0.12, 0.12), 2.12 - r.range(0.02, 0.34), -2.06 + r.range(0.02, 0.12), r.range(0, 3), r.range(0, 3), 0, r.range(0.05, 0.1), r.range(0.04, 0.08), r.range(0.05, 0.1)));
				}
			}
			// gate pillars where the main street cuts through the wall
			for (const [gx, gz] of [[-8.18, -2.2], [2.5, -4.05]]) {
				mBox('stone', null, 0.22, 0.62, 0.22, gx, 2.14 - 0.14, gz);
				mBox('stone', null, 0.28, 0.06, 0.28, gx, 2.14 + 0.18, gz);
				mBox('glassLit', null, 0.07, 0.09, 0.07, gx, 2.14 + 0.26, gz);
				mBox('metal', '#2f3336', 0.12, 0.015, 0.12, gx, 2.14 + 0.31, gz);
			}

			// ---- garden / courtyard dressing in the leftover grass ----
			const yards = [];
			function addYard(cx, cz, ry, w, d, kind) {
				// reject if it would sit inside a house / on a road / keep-out
				if (nearBuilding(cx, cz, 0.35) || nearRoad(cx, cz, 0.3)) return false;
				for (const k of keepOuts) {
					if (Math.hypot(cx - k.x, cz - k.z) < k.r + 0.15) return false;
				}
				for (const y of yards) {
					if (Math.hypot(cx - y[0], cz - y[1]) < 0.85) return false;
				}
				const c = Math.cos(ry),
					s = Math.sin(ry);
				const pos = (lx, lz) => [cx + lx * c + lz * s, cz - lx * s + lz * c];
				const hw = w / 2,
					hd = d / 2;
				const gy = L.groundHeight(cx, cz);
				if (gy < 1.4) return false;
				// low stone wall on the three closed sides
				const sides = [
					[0, hd, w, 0.06],
					[-hw, 0, 0.06, d],
					[hw, 0, 0.06, d],
				];
				for (const [lx, lz, sw, sd] of sides) {
					const p = pos(lx, lz);
					mBox('stone', '#a2988a', sw, 0.16, sd, p[0], gy + 0.08, p[1], { ry });
					mBox('stone', '#8f877c', sw + 0.02, 0.03, sd + 0.02, p[0], gy + 0.175, p[1], { ry });
				}
				// soil bed + vegetables / flowers
				mBox('wood', '#4a3527', w - 0.1, 0.03, d - 0.1, cx, gy + 0.05, cz, { ry });
				const rows = kind === 'garden' ? 3 : 2;
				for (let i = 0; i < rows; i++) {
					for (let j = 0; j < 4; j++) {
						const lx = -w / 2 + 0.16 + (j / 3) * (w - 0.32);
						const lz = -d / 2 + 0.16 + (i / Math.max(1, rows - 1)) * (d - 0.32);
						const p = pos(lx, lz);
						const lc = U.color(r.pick(LEAF_COLORS));
						for (let k = 0; k < 2; k++) {
							inst('leaf', GEO.leaf, kit.matLeafPlain, lc, locM(p[0] + r.range(-0.02, 0.02), gy + 0.09 + k * 0.02, p[1] + r.range(-0.02, 0.02), r.range(0, 3), r.range(0, 3), 0, 0.045, 0.035, 0.045));
						}
						if (r.chance(0.4)) inst('flower', GEO.flower, kit.matLeafPlain, U.color(r.pick(FLOWER_COLORS)), locM(p[0], gy + 0.12, p[1], 0, 0, 0, 0.014, 0.013, 0.014));
					}
				}
				// gate posts + little path towards the street
				const gp = pos(0, -hd);
				mBox('stone', '#a2988a', 0.06, 0.22, 0.06, gp[0] - Math.cos(ry) * w * 0.22, gy + 0.11, gp[1] + Math.sin(ry) * w * 0.22, { ry });
				mBox('stone', '#a2988a', 0.06, 0.22, 0.06, gp[0] + Math.cos(ry) * w * 0.22, gy + 0.11, gp[1] - Math.sin(ry) * w * 0.22, { ry });
				for (let i = 0; i < 3; i++) {
					const p = pos(0, -hd - 0.08 - i * 0.1);
					mBox('stone', '#b5ac9e', 0.22, 0.02, 0.09, p[0], gy + 0.04, p[1], { ry });
				}
				// laundry line across the yard
				if (kind !== 'orchard' && r.chance(0.7)) {
					const a = pos(-hw + 0.08, hd - 0.1),
						b = pos(hw - 0.08, hd - 0.1);
					mBox('metal', '#7c6a52', 0.005, 0.005, 0.2, a[0], gy + 0.2, a[1]);
					mBox('metal', '#7c6a52', 0.005, 0.005, 0.2, b[0], gy + 0.2, b[1]);
					mBox('metal', '#7c6a52', Math.hypot(b[0] - a[0], b[1] - a[1]), 0.005, 0.005, (a[0] + b[0]) / 2, gy + 0.29, (a[1] + b[1]) / 2, { ry: Math.atan2(b[0] - a[0], b[1] - a[1]) + PI / 2 });
					const cc = ['#efe6d2', '#cfd6d2', '#d8b0a0', '#c9d4c0'];
					for (let i = 0; i < 3; i++) {
						const t = 0.25 + i * 0.25;
						const p = [U.lerp(a[0], b[0], t), U.lerp(a[1], b[1], t)];
						inst('laundry', GEO.laundry, kit.matFabricPlain, cc[i % 4], locM(p[0], gy + 0.23, p[1], 0, ry, 0, 0.06, 0.1, 1));
					}
				}
				// small garden shed
				if (kind === 'shed') {
					const p = pos(hw - 0.3, hd - 0.28);
					mBox('wood', '#7c5a3c', 0.3, 0.3, 0.24, p[0], gy + 0.19, p[1], { ry });
					const A = GeoAccum();
					accQuadSized(A, [-0.17, 0, -0.14], [0.17, 0, -0.14], [0.17, 0.1, 0], [-0.17, 0.1, 0], [0, 1, -0.5], 0.3);
					accQuadSized(A, [0.17, 0, 0.14], [-0.17, 0, 0.14], [-0.17, 0.1, 0], [0.17, 0.1, 0], [0, 1, 0.5], 0.3);
					mGeo('roof', '#6f4a3a', accumGeo(A), locM(p[0], gy + 0.34, p[1], 0, ry, 0));
					mBox('trim', '#2f2a24', 0.12, 0.2, 0.02, p[0], gy + 0.15, p[1] + 0.13 * Math.cos(ry));
				}
				// tree / hedge corner
				if (kind === 'orchard' || r.chance(0.5)) addTree(cx + r.range(-w * 0.2, w * 0.2), gy, cz + r.range(-d * 0.2, d * 0.2), 0.72);
				// barrel
				if (r.chance(0.6)) {
					const p = pos(-hw + 0.22, -hd + 0.2);
					mCyl('wood', '#7c5a3c', 0.05, 0.056, 0.13, 8, p[0], gy + 0.07, p[1]);
				}
				yards.push([cx, cz]);
				return true;
			}
			addYard(-5.4, -2.95, 0.0, 1.0, 0.55, 'garden');
			addYard(-1.35, -2.9, 0.0, 0.85, 0.5, 'shed');
			addYard(0.75, -3.05, 0.0, 0.7, 0.5, 'garden');
			addYard(-9.2, -8.5, PI / 2, 0.9, 0.6, 'garden');
			addYard(-7.55, -8.15, PI / 2, 0.8, 0.55, 'orchard');
			addYard(-0.95, -9.55, 0.0, 0.9, 0.6, 'shed');
			addYard(-3.45, -7.35, PI / 2, 0.75, 0.55, 'garden');
			addYard(2.15, -7.6, PI / 2, 0.7, 0.5, 'garden');
			addYard(-9.35, -6.3, PI / 2, 0.78, 0.52, 'orchard');
			addYard(-2.2, -9.6, 0.0, 0.9, 0.55, 'garden');
			addYard(-6.2, -9.05, PI / 2, 0.72, 0.5, 'shed');
			ctx.log('town: yards built ' + yards.length);

			// --- church ------------------------------------------------
			function buildChurch() {
				const ax = L.ANCHORS.church.pos[0],
					az = L.ANCHORS.church.pos[1] - 0.6;
				const gy = L.groundHeight(ax, az);
				CUR.makeRotationY(PI);
				CUR.setPosition(ax, 0, az);
				const B = gy + 0.02;
				worldData.landmarks.push({ name: 'church', x: ax, z: az, r: 1.5 });
				const stone = null;
				// ----- tower -----
				const tcx = -0.62,
					tcz = -0.53,
					tw = 0.46;
				const towerH = 2.7;
				mBox('stone', null, tw + 0.08, 0.16, tw + 0.08, tcx, B + 0.08, tcz);
				mBox('stone', null, tw, towerH, tw, tcx, B + 0.16 + towerH / 2, tcz);
				// corner buttresses
				for (const sx of [-1, 1]) {
					for (const sz of [-1, 1]) {
						mBox('stone', null, 0.07, towerH * 0.98, 0.07, tcx + (sx * (tw / 2 + 0.02)), B + 0.16 + towerH / 2, tcz + (sz * (tw / 2 + 0.02)));
					}
				}
				// corner pilasters
				for (const sx of [-1, 1]) {
					for (const sz of [-1, 1]) {
						mBox('stone', null, 0.055, towerH * 0.96, 0.055, tcx + sx * (tw / 2 + 0.008), B + 0.16 + towerH / 2, tcz + sz * (tw / 2 + 0.008));
					}
				}
				// string courses
				for (const hy of [0.5, 1.1, 1.85, 2.52]) mBox('stone', null, tw + 0.07, 0.038, tw + 0.07, tcx, B + 0.16 + hy, tcz);
				// corner pinnacles at the parapet
				for (const sx of [-1, 1]) {
					for (const sz of [-1, 1]) {
						mBox('stone', null, 0.07, 0.14, 0.07, tcx + sx * (tw / 2 + 0.01), B + 0.16 + towerH + 0.04, tcz + sz * (tw / 2 + 0.01));
					}
				}
				// belfry openings (4 faces)
				for (let f = 0; f < 4; f++) {
					const ry = (f * PI) / 2;
					const c = Math.cos(ry),
						s = Math.sin(ry);
					const ox = tcx + s * -(tw / 2 + 0.005),
						oz = tcz + c * -(tw / 2 + 0.005);
					// dark arched opening
					mBox('trim', '#1a1712', 0.2, 0.3, 0.02, ox, B + 0.16 + 2.1, oz, { ry });
					const arc = new THREE.TorusGeometry(0.1, 0.014, 5, 10, PI);
					mGeo('stone', null, arc, locM(ox, B + 0.16 + 2.25, oz, 0, ry, 0));
					// louvres
					for (let i = 0; i < 4; i++) mBox('trim', '#2e2820', 0.17, 0.012, 0.014, ox, B + 0.16 + 1.99 + i * 0.06, oz, { ry });
					// sill
					mBox('stone', null, 0.26, 0.03, 0.06, ox, B + 0.16 + 1.96, oz, { ry });
				}
				// clock faces on the south and east side
				for (const [ry, off] of [
					[0, 0],
					[PI / 2, 0],
				]) {
					const c = Math.cos(ry),
						s = Math.sin(ry);
					const ox = tcx + s * -(tw / 2 + 0.008),
						oz = tcz + c * -(tw / 2 + 0.008);
					const rect = signUV(30);
					const A = GeoAccum();
					const hw2 = 0.15,
						hh2 = 0.15;
					const base = A.pos.length / 3;
					for (const q of [[-hw2, -hh2, 0], [hw2, -hh2, 0], [hw2, hh2, 0], [-hw2, hh2, 0]]) A.pos.push(q[0], q[1], q[2]);
					A.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
					A.uv.push(rect[2], rect[1], rect[0], rect[1], rect[0], rect[3], rect[2], rect[3]);
					mGeo('sign', null, accumGeo(A), locM(ox, B + 0.16 + 2.42, oz, 0, ry, 0));
					mBox('stone', null, 0.37, 0.37, 0.03, ox, B + 0.16 + 2.42, oz + 0.012, { ry });
				}
				// belfry cornice + parapet
				mBox('stone', null, tw + 0.12, 0.06, tw + 0.12, tcx, B + 0.16 + towerH, tcz);
				mBox('stone', null, tw + 0.02, 0.04, tw + 0.02, tcx, B + 0.16 + towerH + 0.03, tcz);
				// corner pinnacles with little pyramid caps
				for (const sx of [-1, 1]) {
					for (const sz of [-1, 1]) {
						const px = tcx + sx * (tw / 2 + 0.005),
							pz = tcz + sz * (tw / 2 + 0.005);
						mBox('stone', null, 0.06, 0.2, 0.06, px, B + 0.16 + towerH + 0.1, pz);
						const pc = new THREE.ConeGeometry(0.045, 0.11, 4);
						mGeo('roof', '#4a5560', pc, locM(px, B + 0.16 + towerH + 0.26, pz, 0, PI / 4, 0));
					}
				}
				// tower buttresses at the base
				for (const sx of [-1, 1]) {
					for (const sz of [-1, 1]) {
						mBox('stone', null, 0.09, 0.9, 0.09, tcx + sx * (tw / 2 + 0.03), B + 0.16 + 0.45, tcz + sz * (tw / 2 + 0.03));
						mBox('stone', null, 0.11, 0.08, 0.11, tcx + sx * (tw / 2 + 0.055), B + 0.16 + 0.08, tcz + sz * (tw / 2 + 0.055));
					}
				}
				// louvre hood moulds over the bell openings
				for (let f = 0; f < 4; f++) {
					const ry2 = (f * PI) / 2;
					const c2 = Math.cos(ry2),
						s2 = Math.sin(ry2);
					const ox2 = tcx + s2 * -(tw / 2 + 0.006),
						oz2 = tcz + c2 * -(tw / 2 + 0.006);
					mBox('stone', null, 0.26, 0.03, 0.08, ox2, B + 0.16 + 2.3, oz2, { ry: ry2 });
				}
				// tower door (west face, towards the street)
				{
					const ox3 = tcx - (tw / 2 + 0.006),
						oz3 = tcz;
					mBox('trim', '#241f1a', 0.05, 0.36, 0.24, ox3, B + 0.16 + 0.2, oz3);
					mBox('wood', '#4e3726', 0.04, 0.33, 0.2, ox3 - 0.01, B + 0.16 + 0.19, oz3);
					const darc2 = new THREE.TorusGeometry(0.1, 0.018, 5, 10, PI);
					mGeo('stone', null, darc2, locM(ox3 - 0.02, B + 0.16 + 0.37, oz3, 0, -PI / 2, 0));
					mBox('stone', null, 0.1, 0.04, 0.32, ox3 - 0.03, B + 0.2, oz3);
				}
				// spire
				const spireH = 1.12;
				const spire = new THREE.ConeGeometry(0.32, spireH, 8);
				mGeo('roof', '#4a5560', spire, locM(tcx, B + 0.16 + towerH + 0.06 + spireH / 2, tcz));
				// lucarnes
				for (let f = 0; f < 4; f++) {
					const ry = (f * PI) / 2 + PI / 8;
					const c = Math.cos(ry),
						s = Math.sin(ry);
					const r0 = 0.2;
					const lx = tcx + s * -r0,
						lz = tcz + c * -r0;
					const ly = B + 0.16 + towerH + 0.06 + 0.16;
					mBox('stone', null, 0.09, 0.13, 0.07, lx, ly, lz, { ry });
					const A = GeoAccum();
					accTri(A, [-0.055, 0.13, -0.04], [0.055, 0.13, -0.04], [0, 0.21, 0], [0, 0.5, -1]);
					accTri(A, [0.055, 0.13, 0.04], [-0.055, 0.13, 0.04], [0, 0.21, 0], [0, 0.5, 1]);
					mGeo('roof', '#4a5560', accumGeo(A), locM(lx, ly, lz, 0, ry, 0));
					addGlass(lx, ly + 0.03, lz + 0.038, ry, 0.05, 0.07, true);
				}
				// finial + cross
				mCyl('metal', '#5a5046', 0.008, 0.012, 0.14, 5, tcx, B + 0.16 + towerH + 0.06 + spireH + 0.05, tcz);
				mBox('brass', null, 0.028, 0.028, 0.028, tcx, B + 0.16 + towerH + 0.06 + spireH + 0.12, tcz, { ry: PI / 4 });
				mBox('brass', null, 0.012, 0.11, 0.012, tcx, B + 0.16 + towerH + 0.06 + spireH + 0.2, tcz);
				mBox('brass', null, 0.065, 0.012, 0.012, tcx, B + 0.16 + towerH + 0.06 + spireH + 0.23, tcz);

				// ----- nave -----
				const nx0 = -0.4,
					nx1 = 0.5,
					nz0 = -0.31,
					nz1 = 1.05;
				const ncx = (nx0 + nx1) / 2,
					ncz = (nz0 + nz1) / 2;
				const nw = nx1 - nx0,
					nd = nz1 - nz0;
				const naveH = 1.22;
				mBox('stone', null, nw + 0.06, 0.14, nd + 0.06, ncx, B + 0.07, ncz);
				mBox('stone', null, nw, naveH, nd, ncx, B + 0.14 + naveH / 2, ncz);
				// buttresses along both long sides
				for (const sx of [-1, 1]) {
					for (let i = 0; i < 4; i++) {
						const bz = nz0 + 0.2 + i * ((nd - 0.4) / 3);
						const bx = ncx + sx * (nw / 2 + 0.03);
						mBox('stone', null, 0.07, naveH * 0.85, 0.1, bx, B + 0.14 + naveH * 0.42, bz);
						mBox('stone', null, 0.06, 0.05, 0.13, bx, B + 0.14 + naveH * 0.85, bz);
					}
				}
				// side windows (lit stained glass)
				for (const sx of [-1, 1]) {
					for (let i = 0; i < 3; i++) {
						const bz = nz0 + 0.35 + i * ((nd - 0.7) / 2);
						const bx = ncx + sx * (nw / 2 + 0.002);
						const ry = sx > 0 ? PI / 2 : -PI / 2;
						mBox('trim', '#241f1a', 0.02, 0.34, 0.13, bx, B + 0.14 + 0.62, bz, { ry });
						addGlass(bx, B + 0.14 + 0.62, bz, PI / 2, 0.11, 0.3, true);
						const arc = new THREE.TorusGeometry(0.065, 0.012, 5, 10, PI);
						mGeo('stone', null, arc, locM(bx + sx * 0.01, B + 0.14 + 0.79, bz, 0, PI / 2, 0));
						mBox('stone', null, 0.05, 0.02, 0.18, bx + sx * 0.012, B + 0.14 + 0.44, bz);
					}
				}
				// front facade: gable + rose window + arched door
				const fz = nz0 - 0.002;
				// gable triangle above the facade
				const A = GeoAccum();
				accTri(A, [nx0, naveH, fz], [nx1, naveH, fz], [ncx, naveH + 0.52, fz], [0, 0, -1]);
				mGeo('stone', null, accumGeo(A), locM(0, B + 0.14, 0));
				// facade buttresses
				for (const sx of [-1, 1]) mBox('stone', null, 0.08, naveH, 0.09, ncx + sx * (nw / 2 - 0.02), B + 0.14 + naveH / 2, fz - 0.03);
				// rose window
				const roseY = B + 0.14 + 0.86;
				const ring = new THREE.TorusGeometry(0.16, 0.022, 6, 18);
				mGeo('stone', null, ring, locM(ncx, roseY, fz - 0.02));
				addGlass(ncx, roseY, fz - 0.012, 0, 0.29, 0.29, true);
				for (let i = 0; i < 8; i++) {
					const a = (i / 8) * TAU;
					mBox('stone', null, 0.014, 0.014, 0.3, ncx + Math.cos(a) * 0.078, roseY + Math.sin(a) * 0.078, fz - 0.03, { rz: a });
				}
				mBox('stone', null, 0.05, 0.05, 0.05, ncx, roseY, fz - 0.045);
				// arched door
				const doorW = 0.2,
					doorH = 0.42;
				mBox('trim', '#241f1a', doorW, doorH, 0.05, ncx, B + 0.14 + doorH / 2, fz - 0.03);
				const darc = new THREE.TorusGeometry(doorW / 2, 0.02, 6, 12, PI);
				mGeo('stone', null, darc, locM(ncx, B + 0.14 + doorH, fz - 0.03, 0, 0, 0));
				mBox('wood', '#4e3726', doorW * 0.86, doorH * 0.94, 0.03, ncx, B + 0.14 + doorH / 2, fz - 0.02);
				// door studs + handle
				for (let i = 0; i < 4; i++) {
					mBox('metal', '#2f3336', 0.02, 0.02, 0.012, ncx - doorW * 0.28 + (i % 2) * doorW * 0.56, B + 0.14 + 0.1 + Math.floor(i / 2) * 0.16, fz - 0.04);
				}
				// steps
				for (let i = 0; i < 3; i++) {
					mBox('stone', null, 0.34 + i * 0.1, 0.05, 0.1, ncx, B + 0.02 - i * 0.05, fz - 0.08 - i * 0.055);
				}
				// facade niches / small statues
				for (const sx of [-1, 1]) {
					const nx2 = ncx + sx * (nw / 2 - 0.16);
					mBox('trim', '#241f1a', 0.07, 0.16, 0.02, nx2, B + 0.14 + 0.42, fz - 0.025);
					mCyl('stone', null, 0.022, 0.026, 0.09, 6, nx2, B + 0.14 + 0.43, fz - 0.035);
				}
				// ---------- nave roof: gable ridge along local z ----------
				const roofH = 0.55;
				const eaveY = B + 0.14 + naveH;
				const ov = 0.07;
				const A2 = GeoAccum();
				// left slope (local -x)
				accQuadSized(A2, [-nw / 2 - ov, 0, nz0 - ov], [-nw / 2 - ov, 0, nz1 + ov], [0, roofH, nz1 + ov], [0, roofH, nz0 - ov], [-0.7, 1, 0], 0.55);
				// right slope
				accQuadSized(A2, [nw / 2 + ov, 0, nz1 + ov], [nw / 2 + ov, 0, nz0 - ov], [0, roofH, nz0 - ov], [0, roofH, nz1 + ov], [0.7, 1, 0], 0.55);
				mGeo('roof', '#4a5560', accumGeo(A2), locM(ncx, eaveY, 0));
				// gable ends
				const A3 = GeoAccum();
				accTri(A3, [nx0, naveH, nz0], [nx1, naveH, nz0], [ncx, naveH + 0.52, nz0], [0, 0, -1]);
				accTri(A3, [nx1, naveH, nz1], [nx0, naveH, nz1], [ncx, naveH + 0.52, nz1], [0, 0, 1]);
				mGeo('stone', null, accumGeo(A3), locM(0, B + 0.14, 0));
				// ridge cap
				mCyl('roof', '#4a5560', 0.026, 0.026, nd + ov * 2, 6, ncx, eaveY + roofH, ncz, { rx: PI / 2 });
				// ridge cross
				mBox('brass', null, 0.012, 0.1, 0.012, ncx, eaveY + roofH + 0.06, nz0 + 0.02);
				mBox('brass', null, 0.05, 0.012, 0.012, ncx, eaveY + roofH + 0.085, nz0 + 0.02);
				// flanking cypresses (local frame: front is local -z)
				CUR.identity();
				addTree(ax - 0.92, gy, az + 0.82, 0.9, 'cypress');
				addTree(ax + 0.92, gy, az + 0.82, 0.82, 'cypress');
				// churchyard wall + railing in front
				for (const sx of [-1, 1]) {
					for (let i = 0; i < 4; i++) {
						const wx = ax + sx * (0.55 + i * 0.22);
						mBox('stone', null, 0.2, 0.14, 0.06, wx, gy + 0.07, az + 0.86);
						mBox('metal', '#2f3336', 0.012, 0.16, 0.012, wx, gy + 0.2, az + 0.86);
					}
					mBox('metal', '#2f3336', 0.66, 0.012, 0.012, ax + sx * 0.88, gy + 0.28, az + 0.86);
				}
				// gate posts
				for (const sx of [-1, 1]) mBox('stone', null, 0.09, 0.34, 0.09, ax + sx * 0.52, gy + 0.17, az + 0.86);
				ctx.log('town: church built');
			}
			buildChurch();

			// --- plaza ------------------------------------------------
			function buildPlaza() {
				const ax = L.ANCHORS.plaza.pos[0],
					az = L.ANCHORS.plaza.pos[1] + 0.05;
				const gy = L.groundHeight(ax, az);
				CUR.identity();
				worldData.landmarks.push({ name: 'plaza', x: ax, z: az, r: 1.45 });
				// paving
				const disc = new THREE.CircleGeometry(1.3, 44);
				disc.rotateX(-PI / 2);
				disc.translate(ax, gy + 0.012, az);
				pushGeo('paving', disc, null);
				const ring = new THREE.RingGeometry(1.3, 1.42, 48);
				ring.rotateX(-PI / 2);
				ring.translate(ax, gy + 0.016, az);
				mGeo('stone', null, ring);
				// radial stone bands
				for (let i = 0; i < 8; i++) {
					const a = (i / 8) * TAU + PI / 8;
					const ca = Math.cos(a),
						sa = Math.sin(a);
					mBox('stone', null, 0.9, 0.02, 0.06, ax + ca * 0.82, gy + 0.02, az + sa * 0.82, { ry: -a });
				}
				// outer ring cobbles (darker)
				const ring2 = new THREE.RingGeometry(1.42, 1.5, 48);
				ring2.rotateX(-PI / 2);
				ring2.translate(ax, gy + 0.01, az);
				pushGeo('paving', ring2, null);

				// fountain
				const fx = ax,
					fz = az - 0.12;
				mCyl('stone', null, 0.46, 0.5, 0.16, 8, fx, gy + 0.08, fz);
				mCyl('stone', null, 0.5, 0.54, 0.05, 8, fx, gy + 0.14, fz);
				const waterDisc = new THREE.CircleGeometry(0.37, 20);
				waterDisc.rotateX(-PI / 2);
				waterDisc.translate(fx, gy + 0.165, fz);
				pushGeo('water', waterDisc, null);
				mCyl('stone', null, 0.1, 0.14, 0.36, 8, fx, gy + 0.34, fz);
				mCyl('stone', null, 0.21, 0.17, 0.07, 8, fx, gy + 0.55, fz);
				const bowl = new THREE.CircleGeometry(0.19, 20);
				bowl.rotateX(-PI / 2);
				bowl.translate(fx, gy + 0.59, fz);
				pushGeo('water', bowl, null);
				mCyl('brass', null, 0.02, 0.03, 0.14, 6, fx, gy + 0.68, fz);
				for (let i = 0; i < 4; i++) {
					const a = (i / 4) * TAU + PI / 4;
					mCyl('brass', null, 0.012, 0.016, 0.08, 5, fx + Math.cos(a) * 0.17, gy + 0.45, fz + Math.sin(a) * 0.17, { rx: 0.4 });
				}
				// benches around the fountain
				addBench(ax - 0.05, gy, az - 0.92, 0.0);
				addBench(ax - 0.05, gy, az + 0.95, PI);
				addBench(ax + 0.98, gy, az + 0.02, -PI / 2);
				addBench(ax - 1.0, gy, az - 0.02, PI / 2);
				// trees
				addTree(ax - 1.02, gy, az - 0.85, 0.92);
				addTree(ax + 1.0, gy, az - 0.78, 0.82);
				addTree(ax + 1.03, gy, az + 0.82, 0.9);
				addTree(ax - 1.05, gy, az + 0.86, 0.78);
				// lamps
				addLamp(ax - 0.62, gy, az + 1.16, 0.3);
				addLamp(ax + 0.66, gy, az + 1.14, -0.3);
				addLamp(ax - 1.2, gy, az - 0.55, PI / 2);
				// market stalls at the west edge of the square
				addStall(ax - 1.05, gy, az + 0.32, PI / 2, 0.5);
				addStall(ax - 1.05, gy, az - 0.38, PI / 2, 0.46);
				// notice board / posters near the market hall
				mBox('wood', '#5b4028', 0.06, 0.05, 0.36, ax - 1.24, gy + 0.02, az - 0.95);
				mBox('wood', '#5b4028', 0.05, 0.4, 0.05, ax - 1.24, gy + 0.2, az - 1.13);
				mBox('wood', '#5b4028', 0.05, 0.4, 0.05, ax - 1.24, gy + 0.2, az - 0.77);
				const rect = signUV(5);
				const A = GeoAccum();
				const base = A.pos.length / 3;
				for (const q of [[-0.13, -0.1, 0], [0.13, -0.1, 0], [0.13, 0.1, 0], [-0.13, 0.1, 0]]) A.pos.push(q[0], q[1], q[2]);
				A.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
				A.uv.push(rect[2], rect[1], rect[0], rect[1], rect[0], rect[3], rect[2], rect[3]);
				mGeo('sign', null, accumGeo(A), locM(ax - 1.21, gy + 0.28, az - 0.95, 0, PI / 2, 0));
				// flower planters
				for (const [px, pz] of [[ax - 1.16, az + 0.72], [ax + 1.14, az - 0.24]]) {
					mBox('stone', null, 0.22, 0.1, 0.22, px, gy + 0.05, pz);
					for (let i = 0; i < 4; i++) inst('leaf', GEO.leaf, kit.matLeafPlain, U.color(r.pick(LEAF_COLORS)), locM(px + r.range(-0.06, 0.06), gy + 0.12, pz + r.range(-0.06, 0.06), r.range(0, 3), r.range(0, 3), 0, 0.05, 0.045, 0.05));
					for (let i = 0; i < 4; i++) inst('flower', GEO.flower, kit.matLeafPlain, U.color(r.pick(FLOWER_COLORS)), locM(px + r.range(-0.07, 0.07), gy + 0.15, pz + r.range(-0.07, 0.07), 0, 0, 0, 0.017, 0.015, 0.017));
				}
				// paved aprons so the square does not end in grass
				const apron = (px, pz, w, d) => {
					const g2 = new THREE.BoxGeometry(w, 0.03, d);
					g2.translate(px, gy + 0.014, pz);
					pushGeo('paving', g2, null);
				};
				apron(ax - 0.2, az + 1.62, 1.9, 0.55);
				apron(ax + 1.62, az + 0.35, 0.66, 1.7);
				apron(ax - 1.7, az + 0.28, 0.6, 1.5);
				apron(ax - 0.15, az - 1.62, 1.5, 0.5);
				// tree pits with stone kerbs on the corners
				for (const [tx, tz] of [
					[ax - 0.28, az + 1.62],
					[ax + 1.7, az - 0.72],
					[ax - 1.78, az - 0.7],
				]) {
					mCyl('stone', '#9a9186', 0.15, 0.16, 0.045, 8, tx, gy + 0.022, tz);
					addTree(tx, gy + 0.03, tz, 0.8);
				}
				// a couple more benches + pots on the paved aprons
				addBench(ax - 0.35, gy, az + 1.62, 0.0);
				addBench(ax + 1.68, gy, az - 0.35, -PI / 2);
				for (const [px, pz] of [
					[ax - 1.48, az + 1.5],
					[ax + 1.5, az + 1.35],
					[ax - 1.6, az - 1.3],
				]) {
					mCyl('stone', '#a2988a', 0.075, 0.09, 0.14, 8, px, gy + 0.07, pz);
					for (let k = 0; k < 3; k++) inst('leaf', GEO.leaf, kit.matLeafPlain, U.color(r.pick(LEAF_COLORS)), locM(px + r.range(-0.05, 0.05), gy + 0.17, pz + r.range(-0.05, 0.05), r.range(0, 3), 0, 0, 0.05, 0.045, 0.05));
					inst('flower', GEO.flower, kit.matLeafPlain, U.color(r.pick(FLOWER_COLORS)), locM(px, gy + 0.2, pz, 0, 0, 0, 0.02, 0.018, 0.02));
				}
				// flag pole in the square
				addFlagpole(ax + 1.2, gy, az - 1.06, 0.6, '#b3453b');
				ctx.log('town: plaza built');
			}
			buildPlaza();

			// --- market hall ------------------------------------------
			function buildMarketHall() {
				const ax = L.ANCHORS.marketHall.pos[0] - 0.2,
					az = L.ANCHORS.marketHall.pos[1] + 0.05;
				const gy = L.groundHeight(ax, az);
				// front faces east (towards the plaza)
				CUR.makeRotationY(-PI / 2);
				CUR.setPosition(ax, 0, az);
				const B = gy + 0.02;
				worldData.landmarks.push({ name: 'marketHall', x: ax, z: az, r: 0.95 });
				const w = 1.34,
					d = 0.72,
					h = 0.92;
				// plinth + body
				mBox('stone', null, w + 0.06, 0.12, d + 0.06, 0, B + 0.06, 0);
				mBox('wall', '#efe2c9', w, h, d, 0, B + 0.12 + h / 2, 0);
				// front (local -z) arcade: 3 arches
				const fz = -d / 2 - 0.002;
				const nArch = 3;
				const bayW = w / nArch;
				for (let i = 0; i < nArch; i++) {
					const cx2 = -w / 2 + bayW * (i + 0.5);
					// pilasters between bays
					mBox('stone', null, 0.06, h, 0.06, -w / 2 + bayW * i, B + 0.12 + h / 2, fz - 0.02);
					const aw = bayW * 0.72,
						ah = 0.5;
					// dark interior back wall + floor so the arcade reads as a room
					mBox('trim', '#1e1a16', aw + 0.02, ah + 0.22, 0.02, cx2, B + 0.12 + ah / 2 + 0.06, d / 2 - 0.03);
					mBox('wood', '#5b4028', aw + 0.02, 0.03, d * 0.8, cx2, B + 0.13, 0.04);
					const arc = new THREE.TorusGeometry(aw / 2, 0.02, 5, 12, PI);
					mGeo('stone', null, arc, locM(cx2, B + 0.12 + ah + 0.06, fz - 0.03));
					// stalls inside the arcade
					if (i !== 1) {
						mBox('wood', '#8a6746', 0.24, 0.02, 0.16, cx2, B + 0.3, 0.06);
						mBox('wood', '#7c5a3c', 0.06, 0.2, 0.06, cx2 - 0.08, B + 0.2, 0.06);
						mBox('wood', '#7c5a3c', 0.06, 0.2, 0.06, cx2 + 0.08, B + 0.2, 0.06);
						for (let k = 0; k < 3; k++) inst('flower', GEO.flower, kit.matLeafPlain, U.color(r.pick(['#e0a24b', '#c0504d', '#8a9a4a'])), locM(cx2 + r.range(-0.08, 0.08), B + 0.33, 0.06 + r.range(-0.05, 0.05), 0, 0, 0, 0.02, 0.018, 0.02));
					}
				}
				// last pilaster
				mBox('stone', null, 0.06, h, 0.06, w / 2, B + 0.12 + h / 2, fz - 0.02);
				// upper band / entablature
				mBox('stone', null, w + 0.06, 0.09, d + 0.06, 0, B + 0.12 + h + 0.03, 0);
				mBox('trim', '#d8ccb2', w + 0.08, 0.03, 0.05, 0, B + 0.12 + h + 0.09, fz - 0.02);
				// roof: gable ridge along local x
				const eave = B + 0.12 + h + 0.08;
				const roofH = 0.42;
				const ov = 0.09;
				const A = GeoAccum();
				accQuadSized(A, [-w / 2 - ov, 0, -d / 2 - ov], [w / 2 + ov, 0, -d / 2 - ov], [w / 2 + ov, roofH, 0], [-w / 2 - ov, roofH, 0], [0, 1, -0.5], 0.55);
				accQuadSized(A, [w / 2 + ov, 0, d / 2 + ov], [-w / 2 - ov, 0, d / 2 + ov], [-w / 2 - ov, roofH, 0], [w / 2 + ov, roofH, 0], [0, 1, 0.5], 0.55);
				mGeo('roof', '#a9503d', accumGeo(A), locM(0, eave, 0));
				for (const sx of [-1, 1]) {
					const A2 = GeoAccum();
					accTri(A2, [sx * (w / 2), 0, -d / 2], [sx * (w / 2), 0, d / 2], [sx * (w / 2), roofH, 0], [sx, 0, 0]);
					mGeo('wall', '#efe2c9', accumGeo(A2), locM(0, eave, 0));
				}
				mCyl('roof', '#a9503d', 0.028, 0.028, w + ov * 2, 6, 0, eave + roofH, 0, { rz: PI / 2 });
				// roof lantern / vent
				mCyl('stone', null, 0.11, 0.13, 0.22, 8, 0, eave + roofH + 0.11, 0);
				const cone = new THREE.ConeGeometry(0.15, 0.16, 8);
				mGeo('roof', '#4a5560', cone, locM(0, eave + roofH + 0.3, 0));
				mCyl('brass', null, 0.008, 0.012, 0.12, 5, 0, eave + roofH + 0.42, 0);
				// sign over the arcade
				const si = 4;
				const rect = signUV(si);
				const A3 = GeoAccum();
				const base = A3.pos.length / 3;
				for (const q of [[-w * 0.3, -0.055, 0], [w * 0.3, -0.055, 0], [w * 0.3, 0.055, 0], [-w * 0.3, 0.055, 0]]) A3.pos.push(q[0], q[1], q[2]);
				A3.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
				A3.uv.push(rect[2], rect[1], rect[0], rect[1], rect[0], rect[3], rect[2], rect[3]);
				mGeo('sign', null, accumGeo(A3), locM(0, B + 0.12 + h + 0.17, fz - 0.04));
				mBox('trim', '#2e3230', w * 0.62, 0.14, 0.02, 0, B + 0.12 + h + 0.17, fz - 0.02);
				// lamps flanking the entrance
				CUR.identity();
				const c = Math.cos(-PI / 2),
					s = Math.sin(-PI / 2);
				const lx1 = ax + (0.0 * c + -(d / 2 + 0.25) * s),
					lz1 = az - (0.0 * s + -(d / 2 + 0.25) * c);
				addLamp(ax + s * -(d / 2 + 0.28), gy, az + c * -(d / 2 + 0.28), -PI / 2);
				// steps
				for (let i = 0; i < 2; i++) {
					const off = d / 2 + 0.06 + i * 0.07;
					mBox('stone', null, w * 0.8, 0.05, 0.14, ax + off, gy + 0.02 - i * 0.04, az, { ry: -PI / 2 });
				}
				ctx.log('town: market hall built');
			}
			buildMarketHall();

			// --- customs house (civic, facing the water) --------------
			function buildCustoms() {
				const ax = L.ANCHORS.customsHouse.pos[0] - 0.45,
					az = L.ANCHORS.customsHouse.pos[1] + 0.12;
				const gy = L.groundHeight(ax, az);
				CUR.makeRotationY(PI);
				CUR.setPosition(ax, 0, az);
				const B = gy + 0.02;
				worldData.landmarks.push({ name: 'customsHouse', x: ax, z: az, r: 1.1 });
				const w = 1.66,
					d = 0.92;
				const f0 = 0.56,
					f1 = 0.52;
				const top = B + 0.16 + f0 + f1;
				// plinth + body
				mBox('stone', null, w + 0.1, 0.18, d + 0.1, 0, B + 0.09, 0);
				mBox('wall', '#efe2c9', w, top - B - 0.16, d, 0, (B + 0.16 + top) / 2, 0);
				// rusticated quoin blocks
				for (const sx of [-1, 1]) {
					for (const sz of [-1, 1]) {
						for (let i = 0; i < 9; i++) {
							const qw = i % 2 ? 0.07 : 0.1;
							mBox('stone', null, qw, 0.11, 0.06, sx * (w / 2 - qw / 2 + 0.005), B + 0.22 + i * 0.12, sz * (d / 2 + 0.012));
							mBox('stone', null, 0.06, 0.11, qw, sx * (w / 2 + 0.012), B + 0.22 + i * 0.12, sz * (d / 2 - qw / 2 + 0.005));
						}
					}
				}
				// string course between floors
				mBox('stone', null, w + 0.08, 0.05, d + 0.08, 0, B + 0.16 + f0, 0);
				// front facade (local -z = towards the water)
				const fz = -d / 2 - 0.005;
				// ground floor: 3 arched openings
				const nBay = 3;
				const bayW = w / nBay;
				for (let i = 0; i < nBay; i++) {
					const cx2 = -w / 2 + bayW * (i + 0.5);
					const aw = bayW * 0.56,
						ah = 0.36;
					mBox('trim', '#1e1a16', aw, ah, 0.05, cx2, B + 0.16 + ah / 2 + 0.04, fz - 0.025);
					const arc = new THREE.TorusGeometry(aw / 2, 0.018, 5, 12, PI);
					mGeo('stone', null, arc, locM(cx2, B + 0.16 + ah + 0.04, fz - 0.03));
					addGlass(cx2, B + 0.16 + ah / 2 + 0.04, fz - 0.01, 0, aw * 0.86, ah * 0.84, i !== 1);
					// keystone
					mBox('stone', null, 0.05, 0.08, 0.07, cx2, B + 0.16 + ah + 0.1, fz - 0.03);
				}
				// main door on the centre bay (sign of entry)
				mBox('wood', '#4e3726', 0.24, 0.34, 0.03, 0, B + 0.16 + 0.17, fz - 0.045);
				mBox('brass', null, 0.02, 0.02, 0.02, 0.08, B + 0.16 + 0.18, fz - 0.065);
				// upper floor windows with pediments
				for (let i = 0; i < nBay; i++) {
					const cx2 = -w / 2 + bayW * (i + 0.5);
					const wy = B + 0.16 + f0 + f1 * 0.52;
					mBox('trim', '#d8ccb2', 0.24, 0.28, 0.05, cx2, wy, fz - 0.02);
					addGlass(cx2, wy, fz - 0.005, 0, 0.17, 0.22, i === 1);
					mBox('trim', '#d8ccb2', 0.018, 0.22, 0.03, cx2, wy, fz - 0.045);
					// pediment
					const A = GeoAccum();
					accTri(A, [-0.15, 0, 0], [0.15, 0, 0], [0, 0.08, 0], [0, 0, -1]);
					mGeo('trim', '#e3d7bd', accumGeo(A), locM(cx2, wy + 0.17, fz - 0.03));
					mBox('trim', '#e3d7bd', 0.32, 0.025, 0.05, cx2, wy + 0.15, fz - 0.03);
					// mini balcony
					mBox('stone', null, 0.26, 0.025, 0.09, cx2, wy - 0.15, fz - 0.05);
					for (let k = 0; k < 5; k++) mBox('metal', '#2f3336', 0.008, 0.1, 0.008, cx2 - 0.11 + k * 0.055, wy - 0.09, fz - 0.085);
					mBox('metal', '#2f3336', 0.25, 0.01, 0.01, cx2, wy - 0.04, fz - 0.085);
				}
				// pilasters between bays on the front
				for (let i = 0; i <= nBay; i++) {
					mBox('wall', '#f4efe3', 0.1, top - B - 0.2, 0.06, -w / 2 + bayW * i, (B + 0.16 + top) / 2 + 0.02, fz - 0.03);
					mBox('stone', null, 0.13, 0.07, 0.1, -w / 2 + bayW * i, top - 0.02, fz - 0.03);
					mBox('stone', null, 0.12, 0.06, 0.09, -w / 2 + bayW * i, B + 0.2, fz - 0.03);
				}
				// roof: hip slate
				const eave = top + 0.06;
				const roofH = 0.34;
				const ov = 0.1;
				mBox('trim', '#e3d7bd', w + 0.12, 0.05, d + 0.12, 0, top + 0.02, 0);
				const A2 = GeoAccum();
				const hw = w / 2 + ov,
					hd = d / 2 + ov;
				const ridge = Math.max(0.02, (w - d) / 2);
				accQuadSized(A2, [-hw, 0, -hd], [hw, 0, -hd], [ridge, roofH, 0], [-ridge, roofH, 0], [0, 1, -0.4], 0.55);
				accQuadSized(A2, [hw, 0, hd], [-hw, 0, hd], [-ridge, roofH, 0], [ridge, roofH, 0], [0, 1, 0.4], 0.55);
				accTri(A2, [-hw, 0, hd], [-hw, 0, -hd], [-ridge, roofH, 0], [-1, 0.4, 0]);
				accTri(A2, [hw, 0, -hd], [hw, 0, hd], [ridge, roofH, 0], [1, 0.4, 0]);
				mGeo('roof', '#4a5560', accumGeo(A2), locM(0, eave, 0));
				mCyl('roof', '#4a5560', 0.03, 0.03, ridge * 2, 6, 0, eave + roofH, 0, { rz: PI / 2 });
				// chimneys
				for (const sx of [-1, 1]) {
					mBox('stone', null, 0.1, 0.26, 0.1, sx * w * 0.3, eave + 0.16, -0.05);
					mBox('stone', null, 0.13, 0.03, 0.13, sx * w * 0.3, eave + 0.3, -0.05);
				}
				// central pediment with clock + flag pole
				const A3 = GeoAccum();
				accTri(A3, [-0.36, 0, 0], [0.36, 0, 0], [0, 0.28, 0], [0, 0, -1]);
				mGeo('wall', '#f4efe3', accumGeo(A3), locM(0, top + 0.06, fz - 0.05));
				const rect = signUV(29);
				const A4 = GeoAccum();
				const base = A4.pos.length / 3;
				for (const q of [[-0.1, -0.1, 0], [0.1, -0.1, 0], [0.1, 0.1, 0], [-0.1, 0.1, 0]]) A4.pos.push(q[0], q[1], q[2]);
				A4.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
				A4.uv.push(rect[2], rect[1], rect[0], rect[1], rect[0], rect[3], rect[2], rect[3]);
				mGeo('sign', null, accumGeo(A4), locM(0, top + 0.2, fz - 0.075, 0, 0, 0));
				mCyl('metal', '#5a5046', 0.008, 0.011, 0.5, 5, 0, top + 0.34, 0);
				// flag
				const A5 = GeoAccum();
				accQuad(A5, [0, 0, 0], [0.2, -0.03, 0.07], [0.2, -0.09, 0.07], [0, -0.12, 0], [1, 0, 0], [0, 0, 1, 0, 1, 1, 0, 1]);
				mGeo('fabric', '#3f6688', accumGeo(A5), locM(0, top + 0.72, 0));
				// wide steps towards the water
				for (let i = 0; i < 4; i++) {
					mBox('stone', null, w * 0.9 + i * 0.08, 0.05, 0.1, 0, B + 0.02 - i * 0.045, -d / 2 - 0.1 - i * 0.07);
				}
				// balustrade terrace facing the water
				for (let i = 0; i < 9; i++) {
					const bx = -w * 0.44 + i * (w * 0.11);
					mBox('stone', null, 0.05, 0.03, 0.05, bx, B + 0.18, -d / 2 - 0.34);
					mCyl('stone', null, 0.018, 0.024, 0.13, 6, bx, B + 0.1, -d / 2 - 0.34);
				}
				mBox('stone', null, w * 0.94, 0.04, 0.1, 0, B + 0.18, -d / 2 - 0.34);
				// lamps at the entrance
				CUR.identity();
				addLamp(ax - 0.72, gy, az + d / 2 + 0.3, 0);
				addLamp(ax + 0.72, gy, az + d / 2 + 0.3, 0);
				// ALFANDEGA sign over the door
				const rect2 = signUV(17);
				const A6 = GeoAccum();
				const pts2 = [[-0.3, -0.065, 0], [0.3, -0.065, 0], [0.3, 0.065, 0], [-0.3, 0.065, 0]];
				const b2 = A6.pos.length / 3;
				for (const q of pts2) A6.pos.push(q[0], q[1], q[2]);
				A6.idx.push(b2, b2 + 1, b2 + 2, b2, b2 + 2, b2 + 3);
				A6.uv.push(rect2[0], rect2[1], rect2[2], rect2[1], rect2[2], rect2[3], rect2[0], rect2[3]);
				// sign on the water front (world +z)
				mGeo('sign', null, accumGeo(A6), locM(ax, B + 0.16 + f0 + 0.32, az + d / 2 + 0.03, 0, 0, 0));
				mBox('trim', '#2e3230', 0.66, 0.15, 0.02, ax, B + 0.16 + f0 + 0.32, az + d / 2 + 0.015);
				ctx.log('town: customs house built');
			}
			buildCustoms();

			// --- fish market: open stalls on a quay platform ----------
			function buildFishMarket() {
				CUR.identity();
				const ax = L.ANCHORS.fishMarket.pos[0],
					az = L.ANCHORS.fishMarket.pos[1];
				const gy = L.groundHeight(ax, az);
				const y = gy + 0.02;
				worldData.landmarks.push({ name: 'fishMarket', x: ax, z: az + 0.5, r: 1.2 });
				const w = 1.76,
					z0 = az + 0.14,
					z1 = az + 1.32;
				const midZ = (z0 + z1) / 2;
				const d = z1 - z0;
				// stone pier below the deck (sinks into the water)
				mBox('stone', '#a49a8c', w, 2.2, d, ax, y - 1.12, midZ);
				// timber deck
				const planks = 9;
				for (let i = 0; i < planks; i++) {
					mBox('wood', i % 2 ? '#8a6746' : '#7c5a3c', w, 0.028, d / planks - 0.012, ax, y + 0.014, midZ - d / 2 + (i + 0.5) * (d / planks));
				}
				// stone edge curb on the water side
				mBox('stone', null, w + 0.06, 0.1, 0.12, ax, y + 0.05, z1 - 0.02);
				mBox('stone', null, 0.12, 0.1, d, ax - w / 2 - 0.02, y + 0.05, midZ);
				mBox('stone', null, 0.12, 0.1, d, ax + w / 2 + 0.02, y + 0.05, midZ);
				// bollards on the water side
				for (const bx of [-0.6, 0, 0.6]) {
					mCyl('metal', '#3a3530', 0.03, 0.04, 0.12, 8, ax + bx, y + 0.11, z1 - 0.06);
					mCyl('metal', '#3a3530', 0.05, 0.05, 0.025, 8, ax + bx, y + 0.175, z1 - 0.06);
				}
				// stairs down to the water on the east side
				for (let i = 0; i < 4; i++) {
					mBox('stone', null, 0.2, 0.26, 0.1, ax + w / 2 + 0.12, y - 0.06 - i * 0.12, z1 - 0.2 - i * 0.1);
				}
				// three stalls with canvas roofs
				for (let i = 0; i < 3; i++) {
					const sx = ax - 0.56 + i * 0.56;
					const sz = midZ + 0.02;
					// posts
					for (const ox of [-0.24, 0.24]) for (const oz of [-0.2, 0.2]) mCyl('wood', '#7c5a3c', 0.012, 0.015, 0.5, 5, sx + ox, y + 0.26, sz + oz);
					// table with fish crates
					mBox('wood', '#9a7a52', 0.5, 0.03, 0.34, sx, y + 0.24, sz);
					for (let k = 0; k < 3; k++) {
						const cx2 = sx - 0.15 + k * 0.15;
						mBox('wood', '#8a6746', 0.12, 0.055, 0.2, cx2, y + 0.28, sz + r.range(-0.04, 0.04));
						// fish: small silver bodies
						for (let f = 0; f < 3; f++) {
							inst('fishSilver', GEO.flower, kit.matMetalPlain, '#b9c4c6', locM(cx2 + r.range(-0.04, 0.04), y + 0.315, sz + r.range(-0.06, 0.06), 0, r.range(0, 3), 0, 0.035, 0.014, 0.012));
						}
					}
					// canvas awning
					const A = GeoAccum();
					accQuadSized(A, [-0.3, 0.48, 0.24], [0.3, 0.48, 0.24], [0.3, 0.4, -0.24], [-0.3, 0.4, -0.24], [0, 1, 0], 0.3);
					mGeo('fabric', i === 1 ? '#3f6688' : '#efe6d2', accumGeo(A), locM(sx, y, sz));
					// hanging bulb
					inst('glowGlass', GEO.winGlass, kit.matGlassLit, null, locM(sx, y + 0.42, sz, 0, 0, 0, 0.03, 0.04, 1));
				}
				// hanging scale (brass) on the middle stall
				mCyl('brass', null, 0.005, 0.005, 0.18, 4, ax, y + 0.4, midZ - 0.1);
				mCyl('brass', null, 0.05, 0.05, 0.012, 10, ax, y + 0.31, midZ - 0.1);
				// crates stacked at the ends
				for (let i = 0; i < 5; i++) {
					const cx2 = ax + (i % 2 ? 0.78 : -0.78) + r.range(-0.05, 0.05);
					const cz2 = midZ + r.range(-0.3, 0.3);
					const nStack = r.int(1, 2);
					for (let s2 = 0; s2 < nStack; s2++) {
						mBox('wood', r.pick(['#9a7a52', '#8a6746']), 0.16, 0.1, 0.14, cx2, y + 0.07 + s2 * 0.1, cz2, { ry: r.range(0, 1) });
					}
				}
				// barrels
				for (let i = 0; i < 3; i++) {
					mCyl('wood', '#7c5a3c', 0.055, 0.062, 0.14, 10, ax - 0.78 + i * 0.05, y + 0.07, midZ + 0.42 - i * 0.06);
				}
				// rope coils
				const coil = new THREE.TorusGeometry(0.07, 0.018, 5, 12);
				mGeo('rope', null, coil, locM(ax + 0.62, y + 0.03, midZ + 0.42, PI / 2, 0, 0));
				// sign board on posts facing the road (north)
				mBox('wood', '#5b4028', 0.05, 0.5, 0.05, ax - 0.72, y + 0.25, z0 + 0.06);
				mBox('wood', '#5b4028', 0.05, 0.5, 0.05, ax + 0.72, y + 0.25, z0 + 0.06);
				const rect = signUV(2);
				const A2 = GeoAccum();
				const base = A2.pos.length / 3;
				for (const q of [[-0.62, -0.09, 0], [0.62, -0.09, 0], [0.62, 0.09, 0], [-0.62, 0.09, 0]]) A2.pos.push(q[0], q[1], q[2]);
				A2.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
				A2.uv.push(rect[2], rect[1], rect[0], rect[1], rect[0], rect[3], rect[2], rect[3]);
				mGeo('sign', null, accumGeo(A2), locM(ax, y + 0.44, z0 + 0.05));
				// larger sign facing the harbour so it reads from the water side
				const A2b = GeoAccum();
				const baseB = A2b.pos.length / 3;
				for (const q of [[-0.55, -0.075, 0], [0.55, -0.075, 0], [0.55, 0.075, 0], [-0.55, 0.075, 0]]) A2b.pos.push(q[0], q[1], q[2]);
				A2b.idx.push(baseB, baseB + 1, baseB + 2, baseB, baseB + 2, baseB + 3);
				A2b.uv.push(rect[0], rect[1], rect[2], rect[1], rect[2], rect[3], rect[0], rect[3]);
				mGeo('sign', null, accumGeo(A2b), locM(ax, y + 0.2, z1 + 0.035));
				mBox('trim', '#2e3230', 1.18, 0.18, 0.03, ax, y + 0.2, z1 + 0.018);
				// flag pole
				addFlagpole(ax - 0.86, y, z1 - 0.1, 0.66, '#b3453b');
				ctx.log('town: fish market built');
			}
			buildFishMarket();

			// report
			ctx.log('town: houses placed = ' + placed.length + ' / lots ' + L.townLots.length + ' rejects=' + JSON.stringify(rejectLog));

			// ==========================================================
			// finalize geometry
			// ==========================================================
			const meshes = [];
			for (const [key, b] of merged) {
				if (!b.geos.length) continue;
				const geo = U.merge(b.geos);
				if (!geo) {
					console.warn('[town] merge failed for ' + key);
					continue;
				}
				geo.computeBoundingSphere();
				const mesh = new THREE.Mesh(geo, b.mat);
				mesh.name = 'town-' + key;
				mesh.castShadow = key === 'wall' || key === 'roof' || key === 'stone' || key === 'brick' || key === 'wood';
				mesh.receiveShadow = true;
				g.add(mesh);
				meshes.push(mesh);
				for (const gg of b.geos) gg.dispose && gg.dispose();
			}
			for (const [key, b] of batch) {
				if (!b.list.length) continue;
				const im = new THREE.InstancedMesh(b.geo, b.mat, b.list.length);
				im.name = 'town-' + key;
				for (let i = 0; i < b.list.length; i++) im.setMatrixAt(i, b.list[i]);
				im.instanceMatrix.needsUpdate = true;
				let hasColor = false;
				for (let i = 0; i < b.colors.length; i++) {
					if (b.colors[i]) {
						hasColor = true;
						break;
					}
				}
				if (hasColor) {
					const white = new THREE.Color(1, 1, 1);
					for (let i = 0; i < b.list.length; i++) im.setColorAt(i, b.colors[i] || white);
					im.instanceColor.needsUpdate = true;
				}
				im.castShadow = key === 'chimney' || key === 'leaf' || key === 'trunk';
				im.receiveShadow = true;
				g.add(im);
				meshes.push(im);
			}

			// publish keep-out info for other modules (props / cars / trees)

			// ==========================================================
			// night lights
			// ==========================================================
			const lampMat = kit.matGlassLit;
			let night = 0;
			function applyNight(n) {
				night = n;
				kit.matGlassLit.emissiveIntensity = n * 2.1;
				kit.matShopGlass.emissiveIntensity = 0.22 + n * 1.4;
				kit.matSign.emissiveIntensity = n * 0.7;
				kit.matWater.emissiveIntensity = 0.2 + n * 0.5;
			}

			return {
				buildings: worldData.buildings,
				landmarks: worldData.landmarks,
				update(dt, t) {
					// fountain jet subtle animation
				},
				onEnv(state) {
					applyNight(state.night || 0);
				},
			};
		},
	});
})(window.HARBOR);
