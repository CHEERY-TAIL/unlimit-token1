// Final hero screenshot batch for the miniature harbour.
// Run: node tools/shots-final.mjs [--pr 2]
//
// Produces qa/final/*.png (scene only, HUD-free, high resolution).
// The HTML/UI versions are captured separately with --capture both + composite.
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';
import { execFileSync } from 'node:child_process';

const ROOT = path.resolve(path.dirname(url.fileURLToPath(import.meta.url)), '..');
const OUT = path.join(ROOT, 'qa', 'final');
fs.mkdirSync(OUT, { recursive: true });

const pr = process.argv.includes('--pr') ? process.argv[process.argv.indexOf('--pr') + 1] : '1.5';
const only = process.env.HARBOR_SHOTS || '';
const shots = [
	{ id: 'final-01-overview-dusk', url: '/index.html?view=overview&hour=17.35&autorotate=0', w: 1600, h: 1000 },
	{ id: 'final-02-harbor-dusk', url: '/index.html?view=harbor&hour=17.55&autorotate=0', w: 1600, h: 1000 },
	{ id: 'final-03-town-dusk', url: '/index.html?view=town&hour=17.2&autorotate=0', w: 1600, h: 1000 },
	{ id: 'final-04-lighthouse-dusk', url: '/index.html?view=lighthouse&hour=17.6&autorotate=0', w: 1600, h: 1000 },
	{ id: 'final-05-marina-noon', url: '/index.html?view=marina&hour=12.4&autorotate=0', w: 1600, h: 1000 },
	{ id: 'final-06-overview-night', url: '/index.html?view=overview&hour=21.2&autorotate=0', w: 1600, h: 1000 },
	{ id: 'final-07-quay-dusk', url: '/index.html?view=quay&hour=17.4&autorotate=0', w: 1600, h: 1000 },
	{ id: 'final-08-top-plan', url: '/index.html?view=top&hour=15.5&autorotate=0', w: 1600, h: 1000 },
];

function run(id, u, w, h) {
	const out = `qa/final/${id}.png`;
	try {
		const args = ['tools/shot.mjs', '--id', `hf-${id}`, '--url', u + `&pr=${pr}`, '--w', String(w), '--h', String(h), '--wait', '1600', '--timeout', '150000', '--out', out];
		const res = execFileSync(process.execPath, args, { cwd: ROOT, encoding: 'utf8' });
		console.log(res.trim().split('\n').slice(0, 3).join('\n'));
	} catch (err) {
		console.error('[final] failed', id, err.message);
	}
}

for (const s of shots) {
	if (only && !only.split(',').some((k) => s.id.includes(k))) continue;
	run(s.id, s.url, s.w, s.h);
}
console.log('[final] done -> qa/final/');
