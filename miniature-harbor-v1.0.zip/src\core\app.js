/**
 * app.js — boot, module registry, shared context, render loop, URL params.
 * ==================================================================
 * Each world module registers itself:
 *
 *   HARBOR.register('water', {
 *     create(ctx) {
 *       const g = ctx.group('water');
 *       ...
 *       return { update(dt, t) {...}, onEnv(state) {...} };
 *     }
 *   });
 *
 * The returned object is optional; `update(dt, time)` and `onEnv(state)`
 * are the supported hooks. Keep your own file self-contained: everything
 * shared is on ctx.
 *
 * URL parameters (useful for QA screenshots):
 *   ?view=overview|harbor|town|lighthouse|marina|quay|top
 *   ?hour=17.35          time of day
 *   ?quality=high|medium|low
 *   ?ui=0                hide all HUD
 *   ?autorotate=0
 *   ?freeze=1&t=12       freeze animation at t seconds
 *   ?only=terrain,water  create only these modules
 *   ?skip=town,vessels   skip these modules
 *   ?pr=1                override pixel ratio
 *   ?debug=1             show module errors + stats
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;

	const modules = [];
	H.register = function (name, def) {
		modules.push({ name, def });
	};

	const state = {
		seed: H.layout.SEED,
		time: 0,
		dt: 0,
		hour: 17.35,
		quality: 'high',
		view: 'overview',
		autoRotate: true,
		freeze: false,
		uiVisible: true,
		ready: false,
		moduleNames: [],
	};

	const errors = [];
	let ctx = null;
	let updateFns = [];
	let world = {};
	let rafId = 0;
	let frameCount = 0;
	let fps = 0;
	let fpsAccum = 0;
	let fpsFrames = 0;
	let lastStatsUpdate = 0;

	function parseParams() {
		const p = new URLSearchParams(window.location.search);
		const get = (k, d) => (p.has(k) ? p.get(k) : d);
		const list = (v) =>
			String(v || '')
				.split(',')
				.map((s) => s.trim())
				.filter(Boolean);
		return {
			view: get('view', 'overview'),
			hour: parseFloat(get('hour', '17.35')),
			quality: get('quality', 'high'),
			ui: get('ui', '1') !== '0' && get('ui') !== 'false',
			autoRotate: get('autorotate', '1') !== '0',
			freeze: get('freeze', '0') === '1',
			t: parseFloat(get('t', '12.5')),
			only: list(get('only', '')),
			skip: list(get('skip', '')),
			seed: parseInt(get('seed', String(H.layout.SEED)), 10) || H.layout.SEED,
			pr: get('pr', '') ? parseFloat(get('pr')) : 0,
			debug: get('debug', '0') === '1',
			stats: get('stats', '1') !== '0',
		};
	}

	function addError(moduleName, err) {
		const msg = err && err.stack ? err.stack : String(err);
		errors.push({ module: moduleName, message: msg, time: Date.now() });
		console.error(`[harbor] module "${moduleName}" failed:`, err);
		if (H.ui && H.ui.showError) H.ui.showError(moduleName, err);
	}

	function nextFrame() {
		return new Promise((resolve) => requestAnimationFrame(() => resolve()));
	}

	function reportProgress(p, label) {
		if (H.ui && H.ui.setProgress) H.ui.setProgress(p, label);
	}

	async function createModules(P) {
		const only = new Set(P.only);
		const skip = new Set(P.skip);
		const list = modules.filter((m) => {
			if (only.size && !only.has(m.name)) return false;
			if (skip.has(m.name)) return false;
			return true;
		});
		state.moduleNames = list.map((m) => m.name);
		const total = Math.max(1, list.length);
		for (let i = 0; i < list.length; i++) {
			const m = list[i];
			reportProgress(0.08 + 0.82 * (i / total), m.name);
			await nextFrame();
			const t0 = performance.now();
			try {
				const def = typeof m.def === 'function' ? { create: m.def } : m.def;
				const res = def.create(ctx) || {};
				world[m.name] = res;
				if (typeof res.update === 'function') updateFns.push({ name: m.name, fn: res.update });
				if (typeof res.onEnv === 'function' && H.env) H.env.onEnv(res.onEnv);
				console.log(`[harbor] module ${m.name} built in ${(performance.now() - t0).toFixed(0)}ms`);
			} catch (err) {
				addError(m.name, err);
			}
		}
		reportProgress(0.94, 'lighting');
	}

	function startLoop(P) {
		let last = performance.now();
		let time = P.freeze ? P.t : 0;
		function frame(now) {
			rafId = requestAnimationFrame(frame);
			const rawDt = Math.min(0.06, Math.max(0, (now - last) / 1000));
			last = now;
			const dt = P.freeze ? 0 : rawDt;
			if (!P.freeze) time += rawDt;
			state.time = time;
			state.dt = dt;
			ctx.time = time;
			ctx.dt = dt;

			// fps
			fpsAccum += rawDt;
			fpsFrames++;
			if (fpsAccum >= 0.5) {
				fps = fpsFrames / fpsAccum;
				fpsAccum = 0;
				fpsFrames = 0;
			}

			try {
				H.env.update(rawDt);
			} catch (err) {
				addError('env', err);
			}
			for (let i = 0; i < updateFns.length; i++) {
				try {
					updateFns[i].fn(dt, time);
				} catch (err) {
					addError(updateFns[i].name, err);
				}
			}
			try {
				H.camera.update(rawDt);
			} catch (err) {
				addError('camera', err);
			}
			try {
				H.render.render(rawDt, time);
			} catch (err) {
				addError('render', err);
			}
			frameCount++;
			if (frameCount === 3) {
				state.ready = true;
				window.__HARBOR_READY__ = true;
				document.body.classList.add('harbor-ready');
				if (H.ui && H.ui.setReady) H.ui.setReady();
			}
			if (H.ui && H.ui.setStats && now - lastStatsUpdate > 420) {
				lastStatsUpdate = now;
				try {
					H.ui.setStats({ fps, stats: H.render.stats(), errors: errors.length, modules: world });
				} catch (err) {
					/* ignore */
				}
			}
		}
		rafId = requestAnimationFrame(frame);
	}

	async function boot() {
		const P = parseParams();
		state.freeze = P.freeze;
		state.view = P.view;
		state.autoRotate = P.autoRotate;
		state.hour = P.hour;
		state.quality = P.quality;

		const canvas = document.getElementById('stage');
		const scene = new THREE.Scene();
		scene.name = 'harbor-scene';

		// --- renderer & camera & environment -------------------------
		const camera = H.camera.init({ canvas, scene, layout: H.layout });
		H.render.init({ canvas, scene, camera, qualityName: P.quality, pixelRatioOverride: P.pr > 0 ? P.pr : 0 });
		H.materials.init();
		H.env.init({ scene, renderer: H.render.renderer });
		H.env.setHour(P.hour, true);

		const rng = U.rng(P.seed);
		const groups = {};
		ctx = {
			THREE,
			ADDONS: H.ADDONS,
			util: U,
			layout: H.layout,
			materials: H.materials,
			env: H.env,
			render: H.render,
			camera,
			controls: H.camera.controls,
			scene,
			renderer: H.render.renderer,
			canvas,
			state,
			params: P,
			seed: P.seed,
			rng,
			time: 0,
			dt: 0,
			quality: H.render.quality,
			world,
			debug: P.debug,
			group(name, parent) {
				const g = new THREE.Group();
				g.name = 'group:' + name;
				(parent || scene).add(g);
				groups[name] = g;
				return g;
			},
			add(obj) {
				scene.add(obj);
				return obj;
			},
			update(fn) {
				updateFns.push({ name: 'custom', fn });
			},
			onEnv(cb) {
				return H.env.onEnv(cb);
			},
			onQuality(cb) {
				return H.render.onQuality(cb);
			},
			view(name) {
				return H.camera.setView(name);
			},
			anchor(name) {
				return H.layout.ANCHORS[name];
			},
			groundHeight: H.layout.groundHeight,
			waterLevel: H.layout.WATER_Y,
			log: (...args) => console.log('[world]', ...args),
		};
		H.ctx = ctx;
		window.__harborCtx = ctx;
		H.world = world;

		if (H.ui && H.ui.init) H.ui.init({ layout: H.layout, env: H.env, render: H.render, camera: H.camera, state, params: P });
		if (!P.ui) document.body.classList.add('ui-hidden');
		document.body.classList.toggle('debug', P.debug);

		reportProgress(0.04, 'sky');
		await nextFrame();

		await createModules(P);

		// --- apply start state ---------------------------------------
		H.camera.setView(P.view, { instant: true });
		H.camera.setAutoRotate(P.autoRotate);
		H.render.setQuality(P.quality);
		if (H.ui && H.ui.setHour) H.ui.setHour(P.hour);
		if (H.ui && H.ui.setView) H.ui.setView(P.view);
		if (H.ui && H.ui.setQuality) H.ui.setQuality(P.quality);
		if (H.ui && H.ui.setAutoRotate) H.ui.setAutoRotate(P.autoRotate);

		// re-apply hour so modules that changed exposure keep consistency
		H.env.setHour(P.hour);

		startLoop(P);
		reportProgress(1, 'ready');
	}

	// ------------------------------------------------------------------
	// public api (used by UI and QA screenshots)
	// ------------------------------------------------------------------
	const api = {
		setView(name) {
			H.camera.setView(name, { instant: true });
			if (H.ui && H.ui.setView) H.ui.setView(name);
			state.view = name;
		},
		setHour(h) {
			H.env.setHour(h);
			state.hour = h;
			if (H.ui && H.ui.setHour) H.ui.setHour(h);
		},
		setQuality(q) {
			H.render.setQuality(q);
			state.quality = q;
			if (H.ui && H.ui.setQuality) H.ui.setQuality(q);
		},
		setAutoRotate(v) {
			H.camera.setAutoRotate(v);
			state.autoRotate = v;
			if (H.ui && H.ui.setAutoRotate) H.ui.setAutoRotate(v);
		},
		capture() {
			// render one frame and immediately grab the drawing buffer
			H.render.render(0, state.time);
			return H.render.renderer.domElement.toDataURL('image/png');
		},
		diagnostics() {
			return {
				ready: state.ready,
				fps: Math.round(fps),
				hour: H.env.hour(),
				view: state.view,
				modules: state.moduleNames,
				errors: errors.map((e) => ({ module: e.module, message: String(e.message).split('\n')[0] })),
				render: H.render.stats(),
				quality: H.render.quality.id,
			};
		},
		get state() {
			return state;
		},
		get scene() {
			return ctx ? ctx.scene : null;
		},
		get camera() {
			return ctx ? ctx.camera : null;
		},
		get renderer() {
			return H.render.renderer;
		},
		get layout() {
			return H.layout;
		},
		get env() {
			return H.env;
		},
		get modules() {
			return world;
		},
		get errors() {
			return errors;
		},
		ctx: () => ctx,
	};

	window.__harborDiagnostics = api.diagnostics;
	window.__harbor = api;

	H.app = api;
	H.state = state;
	H.boot = boot;
	H.errors = errors;

	window.addEventListener('error', (ev) => {
		if (ev && ev.message) console.error('[window error]', ev.message);
	});
	window.addEventListener('unhandledrejection', (ev) => {
		console.error('[unhandled rejection]', ev.reason);
	});
})(window.HARBOR);
