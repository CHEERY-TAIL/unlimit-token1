# 微型港口 · MINIATURE HARBOUR

> 一座完全由代码生成、可以 360° 自由旋转的微缩港口模型。
> A fully procedural, freely rotatable miniature harbour diorama.
>
> **双击 `index.html` 即可打开** — 无需服务器、无需网络、无需安装任何东西。

---

## 快速开始

1. 双击本目录下的 **`index.html`**（推荐 Chrome / Edge 最新版）。
2. 拖拽旋转、滚轮缩放、右键平移，随便看。
3. 右下角可以调时辰（0–24 点，黄昏/夜景/正午）、画质、自动旋转、保存截图、全屏。

> 整个项目零外部资源：所有几何、贴图、字体效果、动画都是运行时用代码生成的。
> 唯一的第三方库是预打包好的 Three.js（`vendor/harbor-lib.js`）。

---

## 操作

| 操作 | 说明 |
| --- | --- |
| 左键拖拽 | 360° 旋转（俯仰角也自由） |
| 滚轮 / 双指 | 缩放（从整盘到船坞近景） |
| 右键拖拽 | 平移 |
| `1` – `7` | 切换预设视角：总览 / 港湾 / 老城 / 灯塔 / 码头 / 作业区 / 鸟瞰 |
| `A` | 自动旋转开/关 |
| `R` | 重置到总览 |
| `H` | 隐藏 / 显示界面（截图用） |
| `S` | 保存当前画面为 PNG 截图 |
| `F` | 全屏 |

界面右下角还有：**时辰滑块**（清晨→正午→黄金时刻→夜晚，夜里全城亮灯、灯塔光束旋转）、**画质**（高/中/低）、**视角按钮**、**截图**、**全屏**。

---

## 这座港口里有什么

- **地形与海面**（`00-terrain` / `10-water`）：手工设计的海岸线、岩层悬崖、草地、沙滩、圆形树脂海底座与胡桃木/黄铜包边的展示台；水面有实时平面反射、程序化波浪法线、菲涅尔、深浅水色、岸边泡沫与太阳碎金。
- **码头与工业区**（`20-quay` / `21-industrial` / `22-lighthouse`）：4 座不同材质的栈桥、石砌岸壁与湿痕/苔藓、弧形防波堤与红白灯塔、绿色入港口灯标、石砌信号塔、瞭望塔废墟、集装箱堆场、门式岸桥、仓库、油罐、窄轨铁路与小火车。
- **老城**（`30-town` / `31-street`）：30 余栋带坡屋顶/烟囱/窗框百叶/店铺遮阳篷的民居、教堂钟塔、广场喷泉、市场拱廊、海关大楼、鱼市、石板街道、路灯、长椅、行人。
- **船与货**（`40-vessels` / `41-props`）：拖船、渔船、帆船、游艇、划艇、外海货船，系泊缆绳、浮标、渔网、木箱、油桶、托盘、树木植被、汽车……
- **氛围**（`50-atmosphere`）：低云堤与海雾、海鸥群、炊烟与蒸汽、旗帜、灯塔旋转光束、浮标闪烁、浪花飞沫、黄昏微尘。
- **光照与后期**：黄金时刻主光 + 天空补光/海面反弹、PMREM 环境光、软阴影、轻微泛光、微缩感移轴（tilt-shift）、色彩分级、暗角与胶片颗粒。

所有物体都按统一的微缩比例（约 1:220 的模型铁路比例）制作：一栋镇屋约 1–2 个世界单位高，一个人约 0.09 单位。

---

## 展示图

| | |
| --- | --- |
| ![总览 · 黄金时刻](qa/final/jpg/final-01-overview-dusk.jpg) | ![港内 · 作业区](qa/final/jpg/final-02-harbor-dusk.jpg) |
| 总览 · 黄金时刻 (17:21) | 港内 · 栈桥与码头 |
| ![老城](qa/final/jpg/final-03-town-dusk.jpg) | ![灯塔](qa/final/jpg/final-04-lighthouse-dusk.jpg) |
| 老城 · 教堂与商业街 | 防波堤灯塔 |
| ![夜景总览](qa/final/jpg/final-06-overview-night.jpg) | ![码头 · 正午](qa/final/jpg/final-05-marina-noon.jpg) |
| 夜景总览 (21:00) | 码头 · 正午 |

更多 3200×2000 高清图与九宫格见 `qa/final/`（`final-00-overview-ui.jpg` 为带 UI 的版本，
`sheet-final.jpg` 为总览九宫格）。

> 截图由无头 Chrome 直接读取 WebGL 帧缓冲（`gl.readPixels`）生成，无 HUD、无合成伪影。

---

## 技术实现

| 项 | 说明 |
| --- | --- |
| 渲染 | Three.js r170（预打包为 classic script，`file://` 直接可用） |
| 结构 | 无打包器：`index.html` 按顺序加载 classic scripts，模块通过 `window.HARBOR` 命名空间协作 |
| 资源 | 0 外部资源；全部纹理用 offscreen canvas 程序化生成（含法线/粗糙度贴图），几何全部代码构建 |
| 光照 | PMREM 环境贴图 + 方向光软阴影 + 半球光 + 海面补光；昼/夜关键帧插值 |
| 水面 | 每帧一次的平面反射 RT（high 1536²）+ 两层滚动法线 + 菲涅尔 + 深度色 + 泡沫 + 顶点波 |
| 后期 | EffectComposer：RenderPass → UnrealBloom → OutputPass → 自定义 DioramaPass（移轴/CA/分级/暗角/颗粒） |
| 性能（RTX 2070 Super 级 GPU 实测） | 整场景 **≈390 draw calls / ≈62 万三角形**；1600×1000 high 画质约 **50–60 fps**，中/低画质更高；任意视角 draw calls 234–396，均低于 550 预算 |
| 离线 | 无 fetch/XHR/Worker/外部字体；双击 `index.html` 即可运行（已用 file:// 自动化验证） |

---

## 目录结构

```
miniature-harbor/
├── index.html                 # 入口（双击打开）
├── src/
│   ├── ui.css                 # HUD 样式（黄铜/玻璃仪表风）
│   ├── core/
│   │   ├── util.js            # 随机/噪声/程序化贴图/几何工具
│   │   ├── layout.js          # ★ 空间总平面：海岸线、分区、高度场、栈桥、泊位、道路、锚点
│   │   ├── materials.js       # 共享 PBR 材质库（程序化贴图）
│   │   ├── env.js             # 天空/太阳/月亮/雾/环境光/昼夜关键帧
│   │   ├── render.js          # renderer + 后期链 + 画质档位
│   │   ├── camera.js          # 相机/轨道控制/视角预设/自动旋转
│   │   ├── ui.js              # HUD 交互
│   │   └── app.js             # 启动、模块注册、主循环、URL 参数、诊断
│   └── world/                 # 世界模块（见上）
├── vendor/harbor-lib.js       # 预打包的 Three.js r170 + 用到的 addons（勿手改）
├── tools/                     # 开发工具（构建 vendor / 视觉 QA 截图服务）
├── docs/                      # 美术方向、架构契约、QA 报告
└── qa/                        # QA 脚本、截图与报告
```

`src/core/layout.js` 是整座港口唯一的手工"总平面图"：海岸线多边形、各分区高度、
栈桥/泊位坐标、道路折线、地标锚点、相机机位都在里面。

---

## 开发 / 二次修改

```powershell
# 重新打包 vendor（修改 three 版本或 addons 列表后）
node tools/build-vendor.mjs

# 视觉 QA 截图（需要先启动常驻服务，见 docs/ARCHITECTURE.md）
node tools/shoot-daemon.mjs
node tools/shot.mjs --id my-view --url "/index.html?view=overview&hour=17.35" --w 1600 --h 1000
```

URL 参数（调试/截图用）：
`?view=overview|harbor|town|lighthouse|marina|quay|top`、`?hour=0..24`、
`?quality=high|medium|low`、`?ui=0`、`?autorotate=0`、`?freeze=1&t=12`、
`?only=terrain,water`、`?skip=town`、`?pr=2`（超采样截图）、`?debug=1`。

---

## 质量验证（自动化 QA，终检）

- **56 个端到端用例全部出图，0 页面错误 / 0 模块错误**：7 视角 × 黄昏/正午/夜晚 × 画质档位、
  `?only=` 单模块隔离 10 项、**360° 环视 8 方位**、移动端 390×780、HUD 整页、`?freeze` 可复现、
  `?skip` 容错、file:// 离线双击、UI/键盘/滑块/截图/全屏交互自检。
- **离线可用**：`file:///.../index.html` 直接打开验证通过（无 CORS / 无外部请求）。
- **性能**：全矩阵 draw calls **250–395**（预算 550），三角形 **54–62 万**（预算 250 万）；
  1600×1000 稳态约 36–56 fps（无头共享浏览器环境，真机通常更高）。
- 环视 8 方位均已确认无黑块、无断片；夜间灯塔光束、浮标灯、窗光、烟与云在旋转中稳定。
- 完整数据：`qa/rounds/round3-final/REPORT.md`。

已知非阻塞项：`?freeze=1` 连续截图存在水面微差（像素级平均值差 0.04，肉眼不可辨）；
无头浏览器全屏 API 需真机确认；极少数背光角度的悬崖切面细节低于正面。这些均不影响正常观看与交互。

---

## 制作

这个项目由 **DeepSeek Harness 的 Agent Team** 协作完成（无外部美术资源）：

- **Lead** — 引擎/相机/后期/UI/空间总平面/集成与美术方向
- **t1-terrain** — 地形、悬崖海岸、树脂底座、水面与反射
- **t2-structures** — 码头岸壁、栈桥、防波堤、工业设施、灯塔
- **t3-town** — 老城建筑、教堂/广场/市场、街道与街道生活
- **t4-vessels** — 船队、系泊、浮标、道具、植被、车辆
- **t5-atmosphere** — 云、海雾、海鸥、烟、旗帜、光束、粒子
- **t6-qa** — 自动化测试矩阵、性能基线、视觉审片与离线验证

> "微型港口 / MINIATURE HARBOUR" · DIORAMA No.01 · 可自由旋转，欢迎慢慢看。
