/**
 * build-vendor.mjs
 * ------------------------------------------------------------------
 * Converts three.js ESM builds + selected addons into a single classic
 * (non-module) script: vendor/harbor-lib.js
 *
 * Purpose: the harbor app must run by double-clicking index.html (file://)
 * with no bundler, no dev server required. Classic scripts have no CORS
 * restrictions on file://, ES modules do. So we pre-bake the library.
 *
 * Exposes:
 *   window.THREE           - all three.js exports
 *   window.HARBOR_ADDONS   - converted example addons
 *
 * Pure Node, no child processes, no dependencies beyond node:fs.
 * Run:  node tools/build-vendor.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import url from 'node:url';

const ROOT = path.resolve(path.dirname(url.fileURLToPath(import.meta.url)), '..');
const THREE_DIR = path.join(ROOT, 'node_modules', 'three');
const OUT_FILE = path.join(ROOT, 'vendor', 'harbor-lib.js');

// ------------------------------------------------------------------
// three.module.js  ->  global THREE
// ------------------------------------------------------------------
function convertThree() {
	const src = fs.readFileSync(path.join(THREE_DIR, 'build', 'three.module.js'), 'utf8');
	const exportIdx = src.lastIndexOf('\nexport {');
	if (exportIdx < 0) throw new Error('three.module.js: export block not found');
	const body = src.slice(0, exportIdx);
	let exportBlock = src.slice(exportIdx + 1);
	// strip trailing sourceMappingURL comment if any
	const closeIdx = exportBlock.lastIndexOf('}');
	if (closeIdx < 0) throw new Error('three.module.js: malformed export block');
	const inner = exportBlock.slice(exportBlock.indexOf('{') + 1, closeIdx);
	const entries = inner
		.split(',')
		.map((s) => s.trim())
		.filter(Boolean)
		.map((entry) => {
			const parts = entry.split(/\s+as\s+/);
			return parts.length === 2 ? `${parts[1]}: ${parts[0]}` : parts[0];
		});

	if (/^import\s/m.test(body)) throw new Error('three.module.js unexpectedly contains imports');
	if (/import\.meta/.test(body)) {
		// Harmless inside our IIFE as long as nothing executes it at module top level.
		console.warn('[vendor] warning: three.module.js references import.meta; patching to a plain object');
	}

	const revision = JSON.parse(fs.readFileSync(path.join(THREE_DIR, 'package.json'), 'utf8')).version;
	const patched = body.replace(/import\.meta/g, '({ url: "" })');
	return {
		revision,
		code: `/* ===== three.js r${revision} (built from three.module.js) ===== */
(function (global) {
'use strict';
${patched}
;global.THREE = global.THREE || {};
Object.assign(global.THREE, {
${entries.join(',\n')}
});
})(typeof window !== 'undefined' ? window : globalThis);
`,
	};
}

// ------------------------------------------------------------------
// example addons -> classic scripts inside one closure
// ------------------------------------------------------------------
function convertAddon(relPath) {
	let src = fs.readFileSync(path.join(THREE_DIR, 'examples', 'jsm', relPath), 'utf8');
	const exported = [];

	// import { A, B as C } from 'three' | './X.js'
	src = src.replace(/import\s*\{([\s\S]*?)\}\s*from\s*['"]([^'"]+)['"];?/g, (full, names, source) => {
		const mapping = names
			.split(',')
			.map((s) => s.trim())
			.filter(Boolean)
			.map((entry) => {
				const parts = entry.split(/\s+as\s+/);
				return parts.length === 2 ? `${parts[0]}: ${parts[1]}` : parts[0];
			});
		if (source === 'three') return `const { ${mapping.join(', ')} } = THREE;`;
		if (source.startsWith('.')) return `const { ${mapping.join(', ')} } = ADDONS;`;
		throw new Error(`${relPath}: unsupported import source "${source}"`);
	});

	// export function/class/const/let/var NAME
	src = src.replace(/\bexport\s+(function|class|const|let|var)\s+([A-Za-z0-9_$]+)/g, (full, kw, name) => {
		exported.push(name);
		return `${kw} ${name}`;
	});

	// export { A, B as C };
	src = src.replace(/export\s*\{([\s\S]*?)\}\s*;?/g, (full, names) => {
		for (const entry of names.split(',').map((s) => s.trim()).filter(Boolean)) {
			const parts = entry.split(/\s+as\s+/);
			const local = parts[0];
			const pub = parts.length === 2 ? parts[1] : parts[0];
			exported.push(pub === local ? local : `${pub}: ${local}`);
		}
		return '';
	});

	if (/\bexport\s+default\b/.test(src)) throw new Error(`${relPath}: default export unsupported`);
	if (/\bexport\s/.test(src)) throw new Error(`${relPath}: leftover export statement`);

	return `/* ===== addon: ${relPath} ===== */
(function () {
'use strict';
${src}
;Object.assign(ADDONS, {
${exported.join(',\n')}
});
})();
`;
}

const ADDON_ORDER = [
	'shaders/CopyShader.js',
	'shaders/OutputShader.js',
	'postprocessing/Pass.js',
	'postprocessing/ShaderPass.js',
	'postprocessing/MaskPass.js',
	'postprocessing/EffectComposer.js',
	'postprocessing/RenderPass.js',
	'shaders/LuminosityHighPassShader.js',
	'postprocessing/UnrealBloomPass.js',
	'postprocessing/OutputPass.js',
	'controls/OrbitControls.js',
	'utils/BufferGeometryUtils.js',
	'geometries/RoundedBoxGeometry.js',
	'math/ImprovedNoise.js',
	'environments/RoomEnvironment.js',
	'objects/Sky.js',
	'controls/TrackballControls.js',
	'misc/Timer.js',
];

function main() {
	const three = convertThree();
	const parts = [
		'/* harbor-lib.js — generated by tools/build-vendor.mjs. Do not edit by hand. */',
		'(function (global) {',
		"'use strict';",
		'const ADDONS = {};',
	];
	// three itself is an IIFE assigning global.THREE, emitted inside our wrapper too.
	parts.push(three.code);
	parts.push('const THREE = global.THREE;');
	for (const rel of ADDON_ORDER) {
		const abs = path.join(THREE_DIR, 'examples', 'jsm', rel);
		if (!fs.existsSync(abs)) {
			console.warn(`[vendor] skip missing addon ${rel}`);
			continue;
		}
		parts.push(convertAddon(rel));
	}
	parts.push('global.HARBOR_ADDONS = ADDONS;');
	parts.push('})(typeof window !== \'undefined\' ? window : globalThis);');
	parts.push('');

	const out = parts.join('\n');
	fs.mkdirSync(path.dirname(OUT_FILE), { recursive: true });
	fs.writeFileSync(OUT_FILE, out, 'utf8');
	const kb = (Buffer.byteLength(out, 'utf8') / 1024).toFixed(1);
	console.log(`[vendor] three r${three.revision} + ${ADDON_ORDER.length} addons -> vendor/harbor-lib.js (${kb} KB)`);
	console.log(`[vendor] addons: ${ADDON_ORDER.map((p) => p.split('/').pop().replace('.js', '')).join(', ')}`);
}

main();
