/**
 * 10-water.js —the harbour water surface.
 * OWNER: t1-terrain (exclusive write: 00-terrain.js + this file).
 *
 * A single custom-shaded disc at y = 0 (r = 14) that provides:
 *  - one planar-reflection render per frame (resolution from
 *    ctx.render.quality.reflection, graceful sky-only fallback on low)
 *  - a cheap sky reflection fallback so low quality still reads as water
 *  - two scrolling procedural ripple normal layers on top of 3 gerstner-ish
 *    wave layers displaced in the vertex shader
 *  - fresnel blend of depth colour (deep teal / shallow turquoise) and the
 *    reflected image, sun / moon glitter, animated shore + structure foam
 *  - night response (darker body, brighter reflections of lit windows)
 *  - fog matched to the env module
 *
 * Contract:
 *  - surface at HARBOR.layout.WATER_Y, circular, clipped to the base
 *  - the water hides itself while the reflection is rendered
 *      (meshes tagged userData.noReflect are hidden too)
 *  - published: HARBOR._t1water = { surface, reflectionRT, enabled }
 */
(function (H) {
	'use strict';
	const U = H.util;
	const THREE = H.THREE;
	const L = H.layout;
	const PAL = U.PALETTE;
	const TAU = Math.PI * 2;
	const clamp = U.clamp;
	const lerp = U.lerp;
	const smoothstep = U.smoothstep;

	const RIM_R = L.DISC_RADIUS - 0.01;

	// ------------------------------------------------------------------
	// ripple normal texture: tileable height field -> tangent normal map
	// ------------------------------------------------------------------
	function makeRippleNormal() {
		const S = 512;
		const height = U.createCanvas(S);
		const hc = height.getContext('2d');
		const field = U.tileableNoise(S, { period: 7, octaves: 5, seed: 913 });
		const field2 = U.tileableNoise(S, { period: 19, octaves: 3, seed: 411 });
		const img = hc.createImageData(S, S);
		for (let i = 0; i < field.length; i++) {
			const x = i % S,
				y = (i / S) | 0;
			// cross-hatched swell pattern: interference of rotated sine sets
			const u = (x / S) * TAU,
				v = (y / S) * TAU;
			const s1 = Math.sin(u * 3.0 + v * 2.0);
			const s2 = Math.sin(u * -2.0 + v * 4.0 + 1.3);
			const s3 = Math.sin(u * 5.0 - v * 3.0 + 2.1);
			let h = (s1 + s2 * 0.72 + s3 * 0.46) * 0.18;
			h += (field[i] - 0.5) * 0.72 + (field2[i] - 0.5) * 0.34;
			const val = clamp(128 + h * 210, 0, 255);
			const j = i * 4;
			img.data[j] = img.data[j + 1] = img.data[j + 2] = val;
			img.data[j + 3] = 255;
		}
		hc.putImageData(img, 0, 0);
		const nrm = U.heightToNormalCanvas(height, 1.6);
		return U.canvasTex(nrm, { srgb: false, repeat: [1, 1], cacheKey: 't1-water-nrm' });
	}

	// ------------------------------------------------------------------
	// shaders
	// ------------------------------------------------------------------
	const WATER_VERT = `
		uniform float uTime;
		uniform float uWaveAmp;
		uniform mat4 uTextureMatrix;
		attribute float aDepth;
		attribute float aShore;
		attribute float aStruct;
		varying vec3 vWorld;
		varying vec3 vNrm;
		varying vec4 vRefl;
		varying float vDepth;
		varying float vShore;
		varying float vStruct;
		varying float vRim;

		vec2 waveDir(float a) { return vec2(cos(a), sin(a)); }

		void main() {
			vec3 p = position;
			float r = length(p.xz);
			float rim = smoothstep(13.1, 13.92, r);
			float shoreFade = smoothstep(0.04, 0.55, aDepth);
			float amp = uWaveAmp * (0.3 + 0.7 * shoreFade) * (1.0 - rim);
			vec2 xz = p.xz;
			// three travelling swells (miniature scale, very slow)
			vec2 d1 = waveDir(0.62), d2 = waveDir(-0.95), d3 = waveDir(2.35);
			float f1 = 1.05, f2 = 1.85, f3 = 3.1;
			float p1 = dot(xz, d1) * f1 + uTime * 0.62;
			float p2 = dot(xz, d2) * f2 + uTime * 0.88;
			float p3 = dot(xz, d3) * f3 + uTime * 1.35;
			float h = sin(p1) * 0.62 + sin(p2) * 0.3 + sin(p3 * 1.7) * 0.12;
			vec2 dh = d1 * cos(p1) * f1 * 0.62 + d2 * cos(p2) * f2 * 0.3 + d3 * cos(p3 * 1.7) * f3 * 1.7 * 0.12;
			p.y += h * amp;
			vec3 wn = normalize(vec3(-dh.x * amp * 1.15, 1.0, -dh.y * amp * 1.15));
			vWorld = p;
			vNrm = wn;
			vRefl = uTextureMatrix * vec4(p, 1.0);
			vDepth = aDepth;
			vShore = aShore;
			vStruct = aStruct;
			vRim = rim;
			gl_Position = projectionMatrix * viewMatrix * vec4(p, 1.0);
		}
	`;

	const WATER_FRAG = `
		uniform sampler2D tReflect;
		uniform sampler2D tNormal;
		uniform float uTime;
		uniform float uHasReflect;
		uniform float uNight;
		uniform float uSunI;
		uniform float uFogDensity;
		uniform float uReflectStrength;
		uniform float uReflectH;
		uniform vec3 uSunDir;
		uniform vec3 uGlintDir;
		uniform vec3 uSunColor;
		uniform vec3 uZenith;
		uniform vec3 uHorizon;
		uniform vec3 uFogColor;
		uniform vec3 uDeep;
		uniform vec3 uShallow;
		uniform vec3 uFoam;
		varying vec3 vWorld;
		varying vec3 vNrm;
		varying vec4 vRefl;
		varying float vDepth;
		varying float vShore;
		varying float vStruct;
		varying float vRim;

		vec3 skyReflect(vec3 dir) {
			float t = clamp(dir.y, 0.0, 1.0);
			vec3 sky = mix(uHorizon, uZenith, pow(t, 0.52));
			float sd = max(dot(dir, uSunDir), 0.0);
			sky += uSunColor * pow(sd, 5.0) * 0.18 * uSunI;
			sky += uSunColor * pow(sd, 60.0) * 0.9 * uSunI;
			return sky;
		}

		void main() {
			vec3 V = normalize(cameraPosition - vWorld);
			float vDist = length(cameraPosition - vWorld);
			float nearF = smoothstep(30.0, 7.0, vDist);
			vec3 N0 = normalize(vNrm);
			vec2 p = vWorld.xz;
			// two scrolling normal layers (busier ripples: no dead-mirror look)
			vec2 uvA = p * 0.8 + uTime * vec2(0.019, 0.011);
			vec2 uvB = p * 1.6 - uTime * vec2(0.014, 0.021);
			vec3 nA = texture2D(tNormal, uvA).xyz * 2.0 - 1.0;
			vec3 nB = texture2D(tNormal, uvB).xyz * 2.0 - 1.0;
			vec2 det = (nA.xy * 0.72 + nB.xy * 0.5);
			float detFade = smoothstep(0.0, 0.25, vDepth) * (1.0 - smoothstep(13.4, 13.9, length(p)));
			vec3 N = normalize(vec3(N0.x + det.x * (0.18 + 0.26 * nearF) * detFade, N0.y, N0.z + det.y * (0.18 + 0.26 * nearF) * detFade));
			float ndv = clamp(dot(N, V), 0.0, 1.0);
			// ---- body colour: deep saturated teal, turquoise only in shallows
			float dt = smoothstep(0.06, 0.5, vDepth);
			vec3 body = mix(uShallow, uDeep, dt);
			body += uShallow * 0.09 * (1.0 - dt) * (0.6 + 0.4 * sin(uTime * 0.4 + p.x * 1.7));
			// ---- planar reflection (3 taps, slight vertical stretch, sharp)
			vec2 ruv = vRefl.xy / max(vRefl.w, 1e-4);
			ruv += det * (0.007 + 0.011 * nearF) * detFade;
			ruv = clamp(ruv, vec2(0.003), vec2(0.997));
			vec3 refl;
			if (uHasReflect > 0.5) {
				vec2 tp = vec2(0.0, 1.0 / uReflectH);
				refl = texture2D(tReflect, ruv).rgb * 0.6;
				refl += texture2D(tReflect, clamp(ruv + tp * 0.8, vec2(0.003), vec2(0.997))).rgb * 0.2;
				refl += texture2D(tReflect, clamp(ruv - tp * 0.8, vec2(0.003), vec2(0.997))).rgb * 0.2;
			} else {
				refl = skyReflect(reflect(-V, N));
			}
			refl *= vec3(1.1, 1.0, 0.84); // warm golden cast, never milky white
			refl = mix(refl, uDeep * 0.55, 0.22); // 22% deep teal in the mirror
			// ---- fresnel: sky at grazing angles, saturated body when looking down
			float fres = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
			fres = clamp(fres * 0.55, 0.0, 0.86);
			// kill the hard milky ring at the disc edge: sky reflection fades out
			fres *= 1.0 - 0.6 * vRim;
			vec3 col = mix(body, refl, fres);
			// ---- golden sun glitter: artistic low light in front of the viewer
			// plus the physical sun/moon specular (visible when looking sunward)
			vec3 Hv = normalize(uGlintDir + V);
			float nh = max(dot(N, Hv), 0.0);
			float spark = 0.3 + 0.95 * texture2D(tNormal, p * 2.6 + uTime * vec2(0.031, 0.019)).g;
			float glint = pow(nh, 1300.0) * 6.5 * spark + pow(nh, 600.0) * 0.16 * spark + pow(nh, 110.0) * 0.018;
			vec3 Ht = normalize(uSunDir + V);
			float nht = max(dot(N, Ht), 0.0);
			glint += pow(nht, 1200.0) * 2.6 * spark;
			vec3 spec = uSunColor * min(glint, 2.4) * (0.3 + 0.7 * uSunI) * (1.0 - 0.6 * vRim);
			col += spec;
			// ---- foam: a thin broken waterline edge + small structure foam
			float foamNoise = texture2D(tNormal, p * 3.4 + uTime * vec2(0.021, 0.012)).g;
			float foamNoise2 = texture2D(tNormal, p * 0.9 - uTime * vec2(0.009, 0.011)).g;
			float pulse = 0.62 + 0.38 * sin(uTime * 0.85 + foamNoise2 * 4.0);
			float shoreF = smoothstep(0.12, 0.0, -vShore);
			float foamShore = shoreF * smoothstep(0.55, 0.74, foamNoise * 0.72 + foamNoise2 * 0.34) * pulse;
			float structF = smoothstep(0.1, 0.0, vStruct);
			float foamStruct = structF * smoothstep(0.58, 0.78, foamNoise * 0.8 + foamNoise2 * 0.3) * pulse;
			float foam = clamp(foamShore * 0.25 + foamStruct * 0.3, 0.0, 1.0) * (1.0 - 0.5 * vRim);
			foam *= 1.0 - smoothstep(12.6, 12.9, length(p)); // never foam the outer rim
			col = mix(col, uFoam * (1.0 - 0.4 * uNight), foam * 0.72);
			// ---- night: near-black teal body but keep lamp/window reflections alive
			vec3 nightBody = uDeep * 0.28;
			float nrefl = clamp(fres * 1.3 + 0.26, 0.0, 0.96);
			vec3 nightRefl = refl * 1.8;
			col = mix(col, mix(nightBody, nightRefl, nrefl), uNight * 0.65);
			// ---- outer rim dies into the resin lip (no neon halo, day OR night)
			vec3 rimCol = (body * 0.43 + uShallow * 0.02) * (1.0 - 0.82 * uNight);
			col = mix(col, rimCol, vRim * 0.96);
			// fog
			float dist = length(cameraPosition - vWorld);
			float fogF = 1.0 - exp(-uFogDensity * uFogDensity * dist * dist);
			col = mix(col, uFogColor, fogF);
			// transparency: deep water is opaque, only the shallows read through
			float alpha = mix(0.55, 1.0, smoothstep(0.0, 0.22, vDepth));
			alpha = mix(alpha, 1.0, fres * 0.9);
			alpha = max(alpha, foam * 0.9);
			alpha = max(alpha, vRim * 0.9);
			gl_FragColor = vec4(col, alpha);
		}
	`;

	// ------------------------------------------------------------------
	// water body
	// ------------------------------------------------------------------
	function buildGeometry() {
		const NS = 320,
			NR = 90;
		const count = NS * (NR + 1);
		const positions = new Float32Array(count * 3);
		const depth = new Float32Array(count);
		const shore = new Float32Array(count);
		const struct = new Float32Array(count);
		const t1 = H._t1;
		const heightFn = t1 ? t1.height : null;
		const coastQuery = t1 ? t1.coastQuery : null;
		const _q = {};
		// structure distance helper data
		const bw = L.BREAKWATER.path;
		const piers = L.PIERS.map((p) => ({
			x: p.start[0],
			z: p.start[1],
			dx: p.dir[0] / Math.hypot(p.dir[0], p.dir[1]),
			dz: p.dir[1] / Math.hypot(p.dir[0], p.dir[1]),
			len: p.length,
			half: p.width / 2,
		}));
		const distToStruct = (x, z) => {
			let best = 9;
			// breakwater rock base (path + width)
			for (let i = 1; i < bw.length; i++) {
				const ax = bw[i - 1][0],
					az = bw[i - 1][1],
					bx = bw[i][0],
					bz = bw[i][1];
				const vx = bx - ax,
					vz = bz - az;
				const t = clamp(((x - ax) * vx + (z - az) * vz) / (vx * vx + vz * vz || 1e-6), 0, 1);
				best = Math.min(best, Math.hypot(x - (ax + vx * t), z - (az + vz * t)) - 0.85);
			}
			for (const p of piers) {
				const vx = x - p.x,
					vz = z - p.z;
				const t = clamp(vx * p.dx + vz * p.dz, 0, p.len);
				const px = p.x + p.dx * t,
					pz = p.z + p.dz * t;
				best = Math.min(best, Math.hypot(x - px, z - pz) - p.half - 0.06);
			}
			return clamp(best, 0, 1.3);
		};
		let k = 0;
		for (let ri = 0; ri <= NR; ri++) {
			const f = ri / NR;
			for (let si = 0; si < NS; si++) {
				const a0 = (si / NS) * TAU;
				const ca = Math.cos(a0),
					sa = Math.sin(a0);
				const ja = U.noise2(ca * 2.1 + f * 0.6, sa * 2.1 - f * 0.4, 4);
				const ang = a0 + (ja * 0.3 * TAU) / NS;
				const rad = RIM_R * Math.pow(f, 1.0);
				const x = Math.cos(ang) * rad;
				const z = Math.sin(ang) * rad;
				const q = coastQuery ? coastQuery(x, z, _q) : null;
				const h = heightFn ? heightFn(x, z, q) : L.groundHeight(x, z);
				positions[k * 3] = x;
				positions[k * 3 + 1] = 0;
				positions[k * 3 + 2] = z;
				depth[k] = clamp(-h / 1.55, 0, 1);
				shore[k] = q ? clamp(q.d, -2.0, 2.0) : 0;
				struct[k] = distToStruct(x, z);
				k++;
			}
		}
		const indices = [];
		for (let ri = 0; ri < NR; ri++) {
			for (let si = 0; si < NS; si++) {
				const sn = (si + 1) % NS;
				const a = ri * NS + si;
				const b = ri * NS + sn;
				const c = (ri + 1) * NS + si;
				const d = (ri + 1) * NS + sn;
				indices.push(a, b, c, b, d, c);
			}
		}
		const geo = new THREE.BufferGeometry();
		geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
		geo.setAttribute('aDepth', new THREE.BufferAttribute(depth, 1));
		geo.setAttribute('aShore', new THREE.BufferAttribute(shore, 1));
		geo.setAttribute('aStruct', new THREE.BufferAttribute(struct, 1));
		geo.setIndex(indices);
		return geo;
	}

	// ------------------------------------------------------------------
	// module
	// ------------------------------------------------------------------
	H.register('water', {
		create(ctx) {
			const g = ctx.group('water');
			const renderer = ctx.renderer;
			const scene = ctx.scene;
			const ripple = makeRippleNormal();

			const uniforms = {
				uTime: { value: 0 },
				uWaveAmp: { value: 0.022 },
				uHasReflect: { value: 0 },
				uNight: { value: 0 },
				uSunI: { value: 1 },
				uFogDensity: { value: 0.007 },
				uReflectStrength: { value: 0.94 },
				uReflectH: { value: 1024 },
				uSunDir: { value: new THREE.Vector3(0.6, 0.3, 0.74) },
				// artistic glitter light: kept in front of the viewer so the sun
				// path reads even when the sun itself is behind the camera
				uGlintDir: { value: new THREE.Vector3(-0.7, 0.25, -0.6).normalize() },
				uSunColor: { value: new THREE.Color('#ffc077') },
				uZenith: { value: new THREE.Color(PAL.skyZenith) },
				uHorizon: { value: new THREE.Color(PAL.skyHorizon) },
				uFogColor: { value: new THREE.Color(PAL.fog) },
				uDeep: { value: new THREE.Color('#0e4653') },
				uShallow: { value: new THREE.Color('#35838b') },
				uFoam: { value: new THREE.Color(PAL.foam) },
				uTextureMatrix: { value: new THREE.Matrix4() },
				tReflect: { value: null },
				tNormal: { value: ripple },
			};
			const waterMat = new THREE.ShaderMaterial({
				uniforms,
				vertexShader: WATER_VERT,
				fragmentShader: WATER_FRAG,
				transparent: true,
				depthWrite: false,
				side: THREE.FrontSide,
				fog: false,
				toneMapped: false,
			});
			const geo = buildGeometry();
			const surface = new THREE.Mesh(geo, waterMat);
			surface.name = 'water-surface';
			surface.position.y = L.WATER_Y;
			surface.frustumCulled = false;
			g.add(surface);

			// ---------- planar reflection setup ----------
			const mirrorCam = new THREE.PerspectiveCamera();
			const noReflect = [];
			let reflectRT = null;
			let reflectEnabled = false;
			let rtSize = 0;
			const texMatrix = new THREE.Matrix4();
			const _camWorld = new THREE.Vector3();
			const _view = new THREE.Vector3();
			const _target = new THREE.Vector3();
			const _lookAt = new THREE.Vector3();
			const _rot = new THREE.Matrix4();
			const _normal = new THREE.Vector3(0, 1, 0);
			const _plane = new THREE.Vector4();
			const _clip = new THREE.Vector4();
			const _q = new THREE.Vector4();
			const _mirrorPos = new THREE.Vector3(0, 0, 0);

			const setupQuality = (q) => {
				const base = q && q.reflectionEnabled && q.reflection > 0 ? q.reflection : 0;
				// high quality gets a sharper mirror; medium keeps the budget value
				const wantSize = base > 0 ? Math.min(2048, Math.round(base * (q.id === 'high' ? 1.5 : 1))) : 0;
				reflectEnabled = wantSize > 0;
				uniforms.uHasReflect.value = reflectEnabled ? 1 : 0;
				if (reflectEnabled) {
					if (rtSize !== wantSize || !reflectRT) {
						if (reflectRT) reflectRT.dispose();
						reflectRT = new THREE.WebGLRenderTarget(wantSize, wantSize, {
							type: THREE.HalfFloatType,
							depthBuffer: true,
							stencilBuffer: false,
							minFilter: THREE.LinearFilter,
							magFilter: THREE.LinearFilter,
							generateMipmaps: false,
						});
						reflectRT.texture.name = 't1-water-reflection';
						rtSize = wantSize;
						uniforms.tReflect.value = reflectRT.texture;
						uniforms.uReflectH.value = wantSize;
					}
					// shadows are the same for every view: render them once in the
					// reflection pass, reuse in the main pass
					renderer.shadowMap.autoUpdate = false;
					renderer.shadowMap.needsUpdate = true;
				} else {
					if (reflectRT) {
						reflectRT.dispose();
						reflectRT = null;
						rtSize = 0;
					}
					uniforms.tReflect.value = null;
					renderer.shadowMap.autoUpdate = true;
				}
			};
			if (ctx.render && ctx.render.onQuality) ctx.render.onQuality(setupQuality);
			else setupQuality(ctx.render ? ctx.render.quality : null);

			// collect meshes that must not appear in the reflection
			scene.traverse((o) => {
				if (o.isMesh && o.userData && o.userData.noReflect) noReflect.push(o);
			});

			const updateMirrorCamera = () => {
				const cam = ctx.camera;
				cam.updateMatrixWorld();
				_camWorld.setFromMatrixPosition(cam.matrixWorld);
				_view.subVectors(_mirrorPos, _camWorld);
				if (_view.dot(_normal) > 0) return false;
				_view.reflect(_normal).negate();
				_view.add(_mirrorPos);
				_rot.extractRotation(cam.matrixWorld);
				_lookAt.set(0, 0, -1).applyMatrix4(_rot);
				_lookAt.add(_camWorld);
				_target.subVectors(_mirrorPos, _lookAt);
				_target.reflect(_normal).negate();
				_target.add(_mirrorPos);
				mirrorCam.position.copy(_view);
				mirrorCam.up.set(0, 1, 0).applyMatrix4(_rot).reflect(_normal);
				mirrorCam.lookAt(_target);
				mirrorCam.near = cam.near;
				mirrorCam.far = cam.far;
				mirrorCam.fov = cam.fov;
				mirrorCam.aspect = cam.aspect;
				mirrorCam.updateMatrixWorld();
				mirrorCam.projectionMatrix.copy(cam.projectionMatrix);
				// oblique near plane: clip everything below the water plane
				_plane.set(_normal.x, _normal.y, _normal.z, 0);
				_plane.applyMatrix4(mirrorCam.matrixWorldInverse);
				_clip.set(_plane.x, _plane.y, _plane.z, _plane.w);
				const pm = mirrorCam.projectionMatrix;
				_q.x = (Math.sign(_clip.x) + pm.elements[8]) / pm.elements[0];
				_q.y = (Math.sign(_clip.y) + pm.elements[9]) / pm.elements[5];
				_q.z = -1.0;
				_q.w = (1.0 + pm.elements[10]) / pm.elements[14];
				const dot = _clip.x * _q.x + _clip.y * _q.y + _clip.z * _q.z + _clip.w * _q.w;
				_clip.multiplyScalar(2.0 / (dot || 1e-6));
				pm.elements[2] = _clip.x;
				pm.elements[6] = _clip.y;
				pm.elements[10] = _clip.z + 1.0;
				pm.elements[14] = _clip.w;
				texMatrix.set(0.5, 0, 0, 0.5, 0, 0.5, 0, 0.5, 0, 0, 0.5, 0.5, 0, 0, 0, 1);
				texMatrix.multiply(mirrorCam.projectionMatrix);
				texMatrix.multiply(mirrorCam.matrixWorldInverse);
				uniforms.uTextureMatrix.value.copy(texMatrix);
				return true;
			};

			const renderReflection = () => {
				if (!reflectEnabled || !reflectRT) return;
				if (!updateMirrorCamera()) return;
				surface.visible = false;
				for (let i = 0; i < noReflect.length; i++) noReflect[i].visible = false;
				renderer.shadowMap.needsUpdate = true;
				const prevTarget = renderer.getRenderTarget();
				renderer.setRenderTarget(reflectRT);
				renderer.clear();
				renderer.render(scene, mirrorCam);
				renderer.setRenderTarget(prevTarget);
				surface.visible = true;
				for (let i = 0; i < noReflect.length; i++) noReflect[i].visible = true;
			};

			// ---------- env response ----------
			const applyEnv = (st) => {
				if (!st || !st.colors) return;
				const c = st.colors;
				uniforms.uSunDir.value.copy(st.sunLightDir).normalize();
				uniforms.uSunColor.value.copy(c.sun);
				uniforms.uZenith.value.copy(c.zenith);
				uniforms.uHorizon.value.copy(c.horizon);
				uniforms.uFogColor.value.copy(c.fog);
				uniforms.uFogDensity.value = st.fogD;
				uniforms.uSunI.value = clamp(st.sunI / 3.0, 0.1, 1.3);
				uniforms.uNight.value = st.night;
				// night water is much darker, shallows lose their turquoise
				const deep = new THREE.Color('#0e4653');
				const shallow = new THREE.Color('#35838b');
				// high sun: deeper, less turquoise (noon used to read fluoro cyan)
				const dayF = smoothstep(2.4, 3.55, st.sunI);
				deep.multiplyScalar(1 - 0.16 * dayF);
				shallow.multiplyScalar((1 - 0.34 * dayF) * 0.85 * 0.9);
				deep.lerp(new THREE.Color('#040d13'), st.night * 0.85);
				shallow.lerp(new THREE.Color('#0a1e26'), st.night * 0.9);
				uniforms.uDeep.value.copy(deep);
				uniforms.uShallow.value.copy(shallow);
			};
			if (ctx.env && ctx.env.onEnv) ctx.env.onEnv(applyEnv);
			else applyEnv(ctx.env ? ctx.env.state : null);

			// artistic glitter light: rotate the true sun direction toward the
			// current view azimuth so the golden path reads from most angles
			const _fwd = new THREE.Vector3();
			const updateGlintDir = () => {
				const cam = ctx.camera;
				cam.getWorldDirection(_fwd);
				_fwd.y = 0;
				if (_fwd.lengthSq() < 1e-6) return;
				_fwd.normalize();
				const sx = uniforms.uSunDir.value.x;
				const sz = uniforms.uSunDir.value.z;
				const crossY = _fwd.z * sx - _fwd.x * sz;
				const ang = (crossY >= 0 ? -1 : 1) * 0.35;
				const ca = Math.cos(ang),
					sa = Math.sin(ang);
				const gx = _fwd.x * ca - _fwd.z * sa;
				const gz = _fwd.x * sa + _fwd.z * ca;
				// raise the artistic light so the golden path lands on the visible
				// water in front of the camera instead of beyond the diorama rim
				const camDist = Math.max(6, cam.position.distanceTo(ctx.controls ? ctx.controls.target : new THREE.Vector3()));
				const elev = clamp((cam.position.y * 1.05) / (camDist * 0.55), 0.3, 1.05);
				uniforms.uGlintDir.value.set(gx, elev, gz).normalize();
			};

			H._t1water = { surface, get reflectionRT() { return reflectRT; }, get enabled() { return reflectEnabled; } };

			return {
				update(dt, time) {
					uniforms.uTime.value = time;
					updateGlintDir();
					renderReflection();
				},
			};
		},
	});
})(window.HARBOR);
