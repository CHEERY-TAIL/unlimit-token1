# QA 自动报告 · 微型港口 MINIATURE HARBOUR

- 轮次: **final-acceptance**（round=3-final）
- 生成时间: 2026-10-27T03:11:23.814Z
- 总耗时: 1242.9s，用例 56 个
- 截图服务: 正常 ✓
- 被测源码: 21 个文件，最后改动 `layout.js` @ 2026/10/27 10:52:18

## 0. 结论摘要

✅ 本轮无阻塞性错误：所有用例成功出图，无页面/模块错误。

- Draw calls: 最大 **498**（用例 qa-r3-final-quality-low），预算 550 → 达标 ✓
- Triangles: 最大 **953K**（用例 qa-r3-final-quality-low），预算 2.50M → 达标 ✓
- high 画质最低 fps: **22**（用例 qa-r3-final-freeze-2），目标 55 → ⚠ 未达标（无头共享 daemon 下 fps 仅作参考，以真机为准）
- `?freeze=1` 可复现性: 两张同参数截图 hash **不一致 ✗**（52721f512cadf5bc vs b1e10afeac838bff）
- 截图口径: 场景图 = WebGL canvas 原像素（1600×1000 @1.5 DPR → 2400×1500，无 HUD）；HUD / 移动端 / 交互用例 = 整页截图（含 HUD，可能存在 headless 瓦片黑块，仅作 UI 验证）

## 1. 主矩阵（7 视角 × 黄昏/正午/夜晚，high，1600×1000，ui=0，canvas 原像素）

| 视角 / 时间 | view | hour | 画质 | fps | draw | tri | 错误 | 输出像素 | 截图 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 总览 / 黄昏 | overview | 17.35 | high | 60 | 394 | 623K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-overview-dusk.png` |
| 港湾 / 黄昏 | harbor | 17.35 | high | 45 | 356 | 608K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-harbor-dusk.png` |
| 老城 / 黄昏 | town | 17.35 | high | 73 | 256 | 543K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-town-dusk.png` |
| 灯塔 / 黄昏 | lighthouse | 17.35 | high | 55 | 336 | 608K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-lighthouse-dusk.png` |
| 码头 / 黄昏 | marina | 17.35 | high | 49 | 312 | 579K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-marina-dusk.png` |
| 作业区 / 黄昏 | quay | 17.35 | high | 30 | 282 | 572K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-quay-dusk.png` |
| 鸟瞰 / 黄昏 | top | 17.35 | high | 32 | 369 | 613K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-top-dusk.png` |
| 总览 / 正午 | overview | 12.00 | high | 56 | 388 | 623K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-overview-day.png` |
| 港湾 / 正午 | harbor | 12.00 | high | 49 | 354 | 608K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-harbor-day.png` |
| 老城 / 正午 | town | 12.00 | high | 47 | 256 | 543K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-town-day.png` |
| 灯塔 / 正午 | lighthouse | 12.00 | high | 58 | 332 | 608K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-lighthouse-day.png` |
| 码头 / 正午 | marina | 12.00 | high | 48 | 312 | 579K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-marina-day.png` |
| 作业区 / 正午 | quay | 12.00 | high | 57 | 282 | 572K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-quay-day.png` |
| 鸟瞰 / 正午 | top | 12.00 | high | 43 | 367 | 613K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-top-day.png` |
| 总览 / 夜晚 | overview | 21.00 | high | 34 | 395 | 622K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-overview-night.png` |
| 港湾 / 夜晚 | harbor | 21.00 | high | 26 | 357 | 607K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-harbor-night.png` |
| 老城 / 夜晚 | town | 21.00 | high | 34 | 257 | 542K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-town-night.png` |
| 灯塔 / 夜晚 | lighthouse | 21.00 | high | 42 | 337 | 607K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-lighthouse-night.png` |
| 码头 / 夜晚 | marina | 21.00 | high | 42 | 313 | 578K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-marina-night.png` |
| 作业区 / 夜晚 | quay | 21.00 | high | 40 | 284 | 571K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-quay-night.png` |
| 鸟瞰 / 夜晚 | top | 21.00 | high | 31 | 370 | 612K | 0 | 2400×1500 | `qa/shots/qa-r3-final-view-top-night.png` |

## 2. 画质档位（总览 / 黄昏）

| 画质 | fps | draw calls | triangles | 分辨率 | 错误 | 截图 |
| --- | --- | --- | --- | --- | --- | --- |
| medium | 25 | 394 | 623K | 1600×1000 | 0 | `qa/shots/qa-r3-final-quality-medium.png` |
| low | 88 | 498 | 953K | 1600×1000 | 0 | `qa/shots/qa-r3-final-quality-low.png` |

## 2.5 真实稳态 fps（`capture=none`，无像素读回开销，wait 3.5s，`freeze=0` 动画运行）

| 用例 | 画质 | fps | draw calls | triangles | 错误 |
| --- | --- | --- | --- | --- | --- |
| 总览黄昏 high 稳态 fps | high | 36 | 394 | 623K | 0 |
| 总览夜晚 high 稳态 fps | high | 56 | 395 | 622K | 0 |
| 总览正午 high 稳态 fps | high | 49 | 388 | 623K | 0 |
| 港湾黄昏 high 稳态 fps | high | 45 | 356 | 608K | 0 |
| 总览黄昏 medium 稳态 fps | medium | 58 | 394 | 623K | 0 |
| 总览黄昏 low 稳态 fps | low | 99 | 498 | 953K | 0 |

> 数值来自无头 Chrome（软件渲染 + 6 agent 共享 daemon），仅作相对比较；交付性能以 Lead 真机 GPU 数据为准。

## 3. 模块隔离（?only=<模块>，用于错误归因）

| 模块 | only | 出图 | ready | draw | tri | 错误数 | 截图 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 地形/底座 | terrain | ✓ | ✓ | 34 | 301K | 0 | `qa/shots/qa-r3-final-only-terrain.png` |
| 水面 | water | ✓ | ✓ | 20 | 61K | 0 | `qa/shots/qa-r3-final-only-water.png` |
| 码头岸壁 | quay | ✓ | ✓ | 115 | 181K | 0 | `qa/shots/qa-r3-final-only-quay.png` |
| 工业区 | industrial | ✓ | ✓ | 138 | 16K | 0 | `qa/shots/qa-r3-final-only-industrial.png` |
| 灯塔 | lighthouse | ✓ | ✓ | 72 | 12K | 0 | `qa/shots/qa-r3-final-only-lighthouse.png` |
| 老城 | town | ✓ | ✓ | 51 | 104K | 0 | `qa/shots/qa-r3-final-only-town.png` |
| 街道 | street | ✓ | ✓ | 58 | 66K | 0 | `qa/shots/qa-r3-final-only-street.png` |
| 船只 | vessels | ✓ | ✓ | 92 | 112K | 0 | `qa/shots/qa-r3-final-only-vessels.png` |
| 道具 | props | ✓ | ✓ | 67 | 119K | 0 | `qa/shots/qa-r3-final-only-props.png` |
| 氛围 | atmosphere | ✓ | ✓ | 33 | 6K | 0 | `qa/shots/qa-r3-final-only-atmosphere.png` |

## 4. 移动端 / HUD / 冻结 / skip

| 组 | 用例 | 分辨率 | fps | draw | tri | 错误 | 截图 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| mobile | 移动端 390×780 / 黄昏 (含 HUD) | 390×780 | 36 | 287 | 576K | 0 | `qa/shots/qa-r3-final-mobile-dusk.png` |
| mobile | 移动端 390×780 / 夜晚 (含 HUD) | 390×780 | 50 | 288 | 575K | 0 | `qa/shots/qa-r3-final-mobile-night.png` |
| interaction | UI / 交互 / 键盘 / 截图 / 全屏 自检 | 1600×1000 | 30 | 394 | 623K | 0 | `qa/shots/qa-r3-final-ui-audit.png` |
| offline | file:// 双击离线打开 / 总览 / 黄昏 | 1600×1000 | 32 | 394 | 623K | 0 | `qa/shots/qa-r3-final-file-offline.png` |
| hud | 桌面 HUD 整页截图 / 黄昏 | 1600×1000 | 36 | 394 | 623K | 0 | `qa/shots/qa-r3-final-hud-desktop.png` |
| hud | 桌面纯场景（同视角 canvas） | 1600×1000 | 28 | 394 | 623K | 0 | `qa/shots/qa-r3-final-hud-scene.png` |
| freeze | 冻结复现 #1 / 港湾 | 1280×800 | 26 | 356 | 608K | 0 | `qa/shots/qa-r3-final-freeze-1.png` |
| freeze | 冻结复现 #2 / 港湾 | 1280×800 | 22 | 356 | 608K | 0 | `qa/shots/qa-r3-final-freeze-2.png` |
| skip | ?skip=atmosphere 容错 | 1280×800 | 41 | 378 | 619K | 0 | `qa/shots/qa-r3-final-skip-atmosphere.png` |

## 5. UI / 交互自检结果

| 检查项 | 结果 | 详情 |
| --- | --- | --- |
| boot_ready | ✅ pass | `{"flag":true,"bodyClass":"harbor-ready","loaderOpacity":"0","loaderVisibility":"hidden","loaderFill":"100%"}` |
| diagnostics_api | ✅ pass | `{"modules":10,"errors":0,"quality":"high","view":"overview"}` |
| renderer_alive | ✅ pass | `{"webgl2":true,"calls":394,"triangles":622922,"programs":70,"canvas":"2400x1500","geometries":360,"textures":111}` |
| view_buttons | ✅ pass | `{"buttons":7,"expected":7,"failures":[],"caption":"鸟瞰"}` |
| keyboard_views | ✅ pass | `{"failures":[],"afterR":"overview"}` |
| keyboard_toggle_ui | ✅ pass | `{"before":false,"hidden":true,"restored":false,"dockOpacityWhileHidden":"1","dockShownOpacity":"1"}` |
| autorotate_toggle | ✅ pass | `{"a0":true,"a1":false,"a2":true,"a3":false,"btnOn":false}` |
| pointer_orbit | ✅ pass | `{"stoppedByPointerDown":true,"autoRotateMovedCamera":0.0174,"controlsDamping":true}` |
| time_slider | ✅ pass | `{"h21":21,"night":0.9198250728862973,"h12":12,"dayNight":0,"label21":"21:00","back":17.35}` |
| quality_switch | ✅ pass | `{"medium":{"id":"medium","pr":1.15,"active":true},"low":{"id":"low","pr":1,"active":true},"high":{"id":"high","pr":1.5,"active":true}}` |
| reset_button | ✅ pass | `{"view":"overview","cameraNearOverview":true}` |
| screenshot_capture | ✅ pass | `{"dataUrlKB":8899,"hintChanged":true,"uiScreenshotFn":"function"}` |
| fullscreen | ✅ pass | `{"supported":true,"entered":false,"error":"Permissions check failed"}` |
| hud_stats | ✅ pass | `{"fps":"32","calls":"394","tris":"623K","errorChipHidden":true}` |
| fps_probe | ✅ pass | `{"fps":32,"frames":26,"note":"liveness only; real fps measured via capture=none"}` |
| scene_graph | ✅ pass | `{"meshes":353,"lights":27,"groups":63,"modules":10,"moduleErrors":0}` |
| url_params | ✅ pass | `{"view":"overview","hour":17.35,"quality":"high","query":"?autorotate=0&view=overview&hour=17.35&quality=high"}` |
| no_page_errors | ✅ pass | `{"moduleErrors":0}` |

> fullscreen: supported=true entered=false error=Permissions check failed（无头浏览器常拒绝，需人工确认）

## 6. 离线 file:// 打开验证

- 页面: `file:///D:/AICODE2/AITEST/ds1/miniature-harbor/index.html?view=overview&hour=17.35&quality=high&freeze=1&t=12&ui=0`
- 结果: ✅ 正常渲染（ready=true，模块齐全）
- 模块: terrain, water, quay, industrial, lighthouse, town, street, vessels, props, atmosphere
- 说明: daemon 直接用 file:// 打开 index.html（与双击文件等价、同一 Chrome），页面正常启动并渲染

## 7. 错误明细

✅ 没有错误。

## 8. 全部截图索引

| id | group | capture | 输出像素 | fps | draw | tri | flags | 截图 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| qa-r3-final-mobile-dusk | mobile | page | 390×780 | 36 | 287 | 576K | ⚠ low-fps | `qa/shots/qa-r3-final-mobile-dusk.png` |
| qa-r3-final-mobile-night | mobile | page | 390×780 | 50 | 288 | 575K | ⚠ low-fps | `qa/shots/qa-r3-final-mobile-night.png` |
| qa-r3-final-ui-audit | interaction | page | 1600×1000 | 30 | 394 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-ui-audit.png` |
| qa-r3-final-file-offline | offline | canvas | 2400×1500 | 32 | 394 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-file-offline.png` |
| qa-r3-final-view-overview-dusk | views | canvas | 2400×1500 | 60 | 394 | 623K | ✅ | `qa/shots/qa-r3-final-view-overview-dusk.png` |
| qa-r3-final-view-harbor-dusk | views | canvas | 2400×1500 | 45 | 356 | 608K | ⚠ low-fps | `qa/shots/qa-r3-final-view-harbor-dusk.png` |
| qa-r3-final-view-town-dusk | views | canvas | 2400×1500 | 73 | 256 | 543K | ✅ | `qa/shots/qa-r3-final-view-town-dusk.png` |
| qa-r3-final-view-lighthouse-dusk | views | canvas | 2400×1500 | 55 | 336 | 608K | ✅ | `qa/shots/qa-r3-final-view-lighthouse-dusk.png` |
| qa-r3-final-view-marina-dusk | views | canvas | 2400×1500 | 49 | 312 | 579K | ⚠ low-fps | `qa/shots/qa-r3-final-view-marina-dusk.png` |
| qa-r3-final-view-quay-dusk | views | canvas | 2400×1500 | 30 | 282 | 572K | ⚠ low-fps | `qa/shots/qa-r3-final-view-quay-dusk.png` |
| qa-r3-final-view-top-dusk | views | canvas | 2400×1500 | 32 | 369 | 613K | ⚠ low-fps | `qa/shots/qa-r3-final-view-top-dusk.png` |
| qa-r3-final-view-overview-day | views | canvas | 2400×1500 | 56 | 388 | 623K | ✅ | `qa/shots/qa-r3-final-view-overview-day.png` |
| qa-r3-final-view-harbor-day | views | canvas | 2400×1500 | 49 | 354 | 608K | ⚠ low-fps | `qa/shots/qa-r3-final-view-harbor-day.png` |
| qa-r3-final-view-town-day | views | canvas | 2400×1500 | 47 | 256 | 543K | ⚠ low-fps | `qa/shots/qa-r3-final-view-town-day.png` |
| qa-r3-final-view-lighthouse-day | views | canvas | 2400×1500 | 58 | 332 | 608K | ✅ | `qa/shots/qa-r3-final-view-lighthouse-day.png` |
| qa-r3-final-view-marina-day | views | canvas | 2400×1500 | 48 | 312 | 579K | ⚠ low-fps | `qa/shots/qa-r3-final-view-marina-day.png` |
| qa-r3-final-view-quay-day | views | canvas | 2400×1500 | 57 | 282 | 572K | ✅ | `qa/shots/qa-r3-final-view-quay-day.png` |
| qa-r3-final-view-top-day | views | canvas | 2400×1500 | 43 | 367 | 613K | ⚠ low-fps | `qa/shots/qa-r3-final-view-top-day.png` |
| qa-r3-final-view-overview-night | views | canvas | 2400×1500 | 34 | 395 | 622K | ⚠ low-fps | `qa/shots/qa-r3-final-view-overview-night.png` |
| qa-r3-final-view-harbor-night | views | canvas | 2400×1500 | 26 | 357 | 607K | ⚠ low-fps | `qa/shots/qa-r3-final-view-harbor-night.png` |
| qa-r3-final-view-town-night | views | canvas | 2400×1500 | 34 | 257 | 542K | ⚠ low-fps | `qa/shots/qa-r3-final-view-town-night.png` |
| qa-r3-final-view-lighthouse-night | views | canvas | 2400×1500 | 42 | 337 | 607K | ⚠ low-fps | `qa/shots/qa-r3-final-view-lighthouse-night.png` |
| qa-r3-final-view-marina-night | views | canvas | 2400×1500 | 42 | 313 | 578K | ⚠ low-fps | `qa/shots/qa-r3-final-view-marina-night.png` |
| qa-r3-final-view-quay-night | views | canvas | 2400×1500 | 40 | 284 | 571K | ⚠ low-fps | `qa/shots/qa-r3-final-view-quay-night.png` |
| qa-r3-final-view-top-night | views | canvas | 2400×1500 | 31 | 370 | 612K | ⚠ low-fps | `qa/shots/qa-r3-final-view-top-night.png` |
| qa-r3-final-quality-medium | quality | canvas | 1839×1150 | 25 | 394 | 623K | ✅ | `qa/shots/qa-r3-final-quality-medium.png` |
| qa-r3-final-quality-low | quality | canvas | 1600×1000 | 88 | 498 | 953K | ✅ | `qa/shots/qa-r3-final-quality-low.png` |
| qa-r3-final-only-terrain | isolation | canvas | 2400×1500 | 97 | 34 | 301K | ✅ | `qa/shots/qa-r3-final-only-terrain.png` |
| qa-r3-final-only-water | isolation | canvas | 2400×1500 | 144 | 20 | 61K | ✅ | `qa/shots/qa-r3-final-only-water.png` |
| qa-r3-final-only-quay | isolation | canvas | 2400×1500 | 144 | 115 | 181K | ✅ | `qa/shots/qa-r3-final-only-quay.png` |
| qa-r3-final-only-industrial | isolation | canvas | 2400×1500 | 144 | 138 | 16K | ✅ | `qa/shots/qa-r3-final-only-industrial.png` |
| qa-r3-final-only-lighthouse | isolation | canvas | 2400×1500 | 144 | 72 | 12K | ✅ | `qa/shots/qa-r3-final-only-lighthouse.png` |
| qa-r3-final-only-town | isolation | canvas | 2400×1500 | 144 | 51 | 104K | ✅ | `qa/shots/qa-r3-final-only-town.png` |
| qa-r3-final-only-street | isolation | canvas | 2400×1500 | 144 | 58 | 66K | ✅ | `qa/shots/qa-r3-final-only-street.png` |
| qa-r3-final-only-vessels | isolation | canvas | 2400×1500 | 136 | 92 | 112K | ✅ | `qa/shots/qa-r3-final-only-vessels.png` |
| qa-r3-final-only-props | isolation | canvas | 2400×1500 | 144 | 67 | 119K | ✅ | `qa/shots/qa-r3-final-only-props.png` |
| qa-r3-final-only-atmosphere | isolation | canvas | 2400×1500 | 126 | 33 | 6K | ✅ | `qa/shots/qa-r3-final-only-atmosphere.png` |
| qa-r3-final-hud-desktop | hud | page | 1600×1000 | 36 | 394 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-hud-desktop.png` |
| qa-r3-final-hud-scene | hud | canvas | 2400×1500 | 28 | 394 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-hud-scene.png` |
| qa-r3-final-freeze-1 | freeze | canvas | 1920×1200 | 26 | 356 | 608K | ⚠ low-fps | `qa/shots/qa-r3-final-freeze-1.png` |
| qa-r3-final-freeze-2 | freeze | canvas | 1920×1200 | 22 | 356 | 608K | ⚠ low-fps | `qa/shots/qa-r3-final-freeze-2.png` |
| qa-r3-final-skip-atmosphere | skip | canvas | 1920×1200 | 41 | 378 | 619K | ⚠ low-fps | `qa/shots/qa-r3-final-skip-atmosphere.png` |
| qa-r3-final-fps-overview-dusk-high | fps | none | 1600×1000 | 36 | 394 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-fps-overview-dusk-high.png` |
| qa-r3-final-fps-overview-night-high | fps | none | 1600×1000 | 56 | 395 | 622K | ✅ | `qa/shots/qa-r3-final-fps-overview-night-high.png` |
| qa-r3-final-fps-overview-day-high | fps | none | 1600×1000 | 49 | 388 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-fps-overview-day-high.png` |
| qa-r3-final-fps-harbor-dusk-high | fps | none | 1600×1000 | 45 | 356 | 608K | ⚠ low-fps | `qa/shots/qa-r3-final-fps-harbor-dusk-high.png` |
| qa-r3-final-fps-overview-dusk-medium | fps | none | 1600×1000 | 58 | 394 | 623K | ✅ | `qa/shots/qa-r3-final-fps-overview-dusk-medium.png` |
| qa-r3-final-fps-overview-dusk-low | fps | none | 1600×1000 | 99 | 498 | 953K | ✅ | `qa/shots/qa-r3-final-fps-overview-dusk-low.png` |
| qa-r3-final-orbit-000 | orbit | canvas | 2400×1500 | 57 | 394 | 623K | ✅ | `qa/shots/qa-r3-final-orbit-000.png` |
| qa-r3-final-orbit-045 | orbit | canvas | 2400×1500 | 53 | 394 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-orbit-045.png` |
| qa-r3-final-orbit-090 | orbit | canvas | 2400×1500 | 41 | 394 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-orbit-090.png` |
| qa-r3-final-orbit-135 | orbit | canvas | 2400×1500 | 31 | 394 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-orbit-135.png` |
| qa-r3-final-orbit-180 | orbit | canvas | 2400×1500 | 52 | 394 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-orbit-180.png` |
| qa-r3-final-orbit-225 | orbit | canvas | 2400×1500 | 51 | 394 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-orbit-225.png` |
| qa-r3-final-orbit-270 | orbit | canvas | 2400×1500 | 44 | 394 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-orbit-270.png` |
| qa-r3-final-orbit-315 | orbit | canvas | 2400×1500 | 30 | 394 | 623K | ⚠ low-fps | `qa/shots/qa-r3-final-orbit-315.png` |

---
_本报告由 `qa/run-qa.mjs` 自动生成。预算: draw calls ≤ 550，triangles ≤ 2.50M，high 画质 fps ≥ 55（1600×1000）。_