/**
 * layout.js — THE SPATIAL BIBLE of the miniature harbour.
 * ==================================================================
 * Every world module reads this file. It is owned by the Lead: geometry
 * that must line up between modules (coastline, quay line, pier berths,
 * plaza, roads, landmark anchors) lives here. Please do not edit it
 * without telling the Lead; instead publish/adjust inside your own
 * module and keep within the districts below.
 *
 * WORLD ORIENTATION
 * -----------------
 *   y  up, water surface at y = 0
 *   -z north (town / hills), +z south (open sea / camera default)
 *   -x west (beach cove / headland), +x east (breakwater point / open sea)
 *
 * The diorama is a round resin-sea plinth (r = 14). Land fills the
 * north-west half; the harbour basin is the sheltered water in the
 * south-centre behind the breakwater. Default camera looks from the
 * south-southeast, so the composition from front to back is:
 *
 *      breakwater + lighthouse  ->  harbour basin + piers + boats
 *      ->  working quay (containers, gantry crane, rail)
 *      ->  old town on the plateau, church tower  ->  wooded hills
 *
 * LEVELS
 * ------
 *   sea floor  -3.2   water 0
 *   beach       0.25
 *   quay deck   1.00  (working waterfront, promenade)
 *   fort point  1.50
 *   marina pontoon 0.45 (floating)
 *   breakwater crest 1.45
 *   town plateau 2.10
 *   upper town / hill cottages 3.10
 *   north cliffs 3.2 - 4.4 (natural, varies)
 */
(function (H) {
	'use strict';
	const U = H.util;
	const clamp = U.clamp,
		lerp = U.lerp,
		smoothstep = U.smoothstep,
		clamp01 = (v) => clamp(v, 0, 1);

	const DISC_RADIUS = 14.0;
	const PLINTH_RADIUS = 14.65;
	const WATER_Y = 0;
	const SEA_FLOOR = -3.2;
	const RESIN_BOTTOM = -1.55; // bottom of the translucent resin sea slab
	const PLINTH_TOP = RESIN_BOTTOM;
	const PLINTH_BOTTOM = -2.45;

	const LEVEL = {
		seaFloor: SEA_FLOOR,
		water: WATER_Y,
		beach: 0.25,
		pontoon: 0.45,
		quay: 1.0,
		breakwater: 1.3,
		fort: 1.5,
		town: 2.1,
		upper: 3.1,
		cliff: 3.8,
	};

	// ------------------------------------------------------------------
	// coastline (land polygon, clockwise, may extend past the disc rim:
	// the visible edge is clipped by the round base)
	// ------------------------------------------------------------------
	const COAST = [
		[-15.2, -11.6],
		[-12.6, -14.4],
		[-8.6, -15.2],
		[-3.8, -14.6],
		[0.2, -13.2],
		[3.6, -11.2],
		[6.2, -8.6],
		[8.0, -5.8],
		[8.7, -3.2],
		[8.6, -0.8],
		[7.8, 1.0],
		[7.4, 2.4],
		[6.7, 3.15], // Fort Point tip
		[6.05, 2.75],
		[5.85, 1.55],
		[5.15, 0.9],
		[4.0, 0.55],
		[2.1, 0.95],
		[-0.2, 1.45],
		[-2.7, 1.95],
		[-5.4, 2.55],
		[-8.3, 3.35],
		[-10.7, 4.85],
		[-12.5, 6.9],
		[-14.4, 9.8],
		[-15.6, 11.6], // beyond rim (clipped)
	];

	// ------------------------------------------------------------------
	// districts: polygons flattened to a level. Terrain must keep these
	// pads flat (+-0.06); buildings, roads and props sit on them.
	//
	// ORDER MATTERS: later districts override earlier ones inside their
	// polygons. The waterfront terrace (quay/yard) is applied LAST so the
	// industrial apron always wins over the town terrace blend and stays
	// perfectly flat at LEVEL.quay — the two-storey retaining wall between
	// them is built by the town module on the town polygon edge.
	// ------------------------------------------------------------------
	const DISTRICTS = [
		{
			id: 'beach',
			level: LEVEL.beach,
			blend: 0.55,
			// small sandy cove tucked in at the west end of the harbour,
			// where the quay road gives way to the shore path.
			poly: [
				[-12.05, 6.35],
				[-11.4, 6.05],
				[-10.8, 5.4],
				[-10.7, 4.9],
				[-11.35, 4.3],
				[-11.95, 4.85],
			],
		},
		{
			id: 'fort',
			level: LEVEL.fort,
			blend: 0.45,
			poly: [
				[5.5, 0.2],
				[7.3, 0.4],
				[8.1, 1.2],
				[7.6, 2.4],
				[6.6, 2.7],
				[5.9, 2.0],
				[5.7, 1.0],
			],
		},
		{
			id: 'town',
			level: LEVEL.town,
			blend: 0.85,
			poly: [
				[-10.2, -2.6],
				[-9.4, -6.4],
				[-7.6, -9.4],
				[-4.4, -10.4],
				[-1.2, -10.2],
				[1.4, -8.8],
				[2.6, -6.4],
				[2.7, -4.2],
				[1.0, -2.6],
				[-2.0, -2.2],
				[-5.6, -2.2],
				[-8.4, -2.2],
			],
		},
		{
			id: 'upper',
			level: LEVEL.upper,
			blend: 1.3,
			poly: [
				[-11.0, -6.2],
				[-9.6, -9.6],
				[-6.6, -11.4],
				[-4.2, -10.9],
				[-4.9, -8.6],
				[-6.9, -7.0],
				[-8.9, -5.4],
			],
		},
		{
			id: 'quay',
			level: LEVEL.quay,
			blend: 0.35,
			// The waterfront terrace: seaward edge follows the harbour
			// stretch of COAST exactly (T2 builds the quay wall on that
			// line), inland edge meets the town retaining wall at z=-2.4.
			// This is the flat apron where cranes, containers, fish market
			// and the quay road live. Applied after town so it wins.
			poly: [
				[5.85, 1.55],
				[5.15, 0.9],
				[4.0, 0.55],
				[2.1, 0.95],
				[-0.2, 1.45],
				[-2.7, 1.95],
				[-5.4, 2.55],
				[-8.3, 3.35],
				[-10.7, 4.85],
				[-10.6, 4.1],
				[-10.0, 2.4],
				[-9.6, 0.4],
				[-9.4, -2.3],
				[-6.8, -2.45],
				[-3.0, -2.5],
				[1.0, -2.3],
				[3.6, -1.3],
				[4.7, 0.1],
				[5.55, 0.9],
			],
		},
		{
			id: 'yard',
			level: LEVEL.quay,
			blend: 0.3,
			poly: [
				[-9.2, 0.1],
				[-8.9, -2.3],
				[-5.4, -2.5],
				[-1.6, -2.3],
				[1.6, -1.9],
				[3.3, -0.9],
				[3.9, 0.3],
				[1.8, 0.5],
				[-0.4, 1.0],
				[-3.0, 1.55],
				[-5.7, 1.75],
				[-8.2, 1.35],
			],
		},
	];

	// ------------------------------------------------------------------
	// breakwater: rock arm from Fort Point across the harbour mouth.
	// `crest` is the walking level, `width` the rock base width.
	// ------------------------------------------------------------------
	const BREAKWATER = {
		crest: LEVEL.breakwater,
		width: 1.3,
		path: [
			[7.2, 2.9],
			[7.35, 4.2],
			[7.0, 5.6],
			[6.3, 6.9],
			[5.2, 8.0],
			[3.8, 8.8],
			[2.2, 9.3],
			[0.4, 9.4],
			[-1.4, 9.1],
			[-3.0, 8.4],
			[-4.4, 7.4],
		],
		lighthouse: [-4.15, 7.55],
	};

	// ------------------------------------------------------------------
	// piers: T2 builds exactly these decks, T4 moors boats to the berths.
	// direction is the unit vector pointing from shore into the water.
	// ------------------------------------------------------------------
	const PIERS = [
		{
			id: 'pierA',
			name: 'cargo pier',
			start: [-7.55, 3.1],
			dir: [0.24, 0.97],
			length: 3.9,
			width: 1.55,
			deck: LEVEL.quay,
			style: 'concrete',
			berths: { left: 2, right: 2, boatLength: [1.6, 2.6] },
		},
		{
			id: 'pierB',
			name: 'fishing pier',
			start: [-3.15, 2.02],
			dir: [0.3, 0.95],
			length: 3.1,
			width: 1.15,
			deck: LEVEL.quay,
			style: 'timber',
			berths: { left: 2, right: 2, boatLength: [0.9, 1.8] },
		},
		{
			id: 'pierC',
			name: 'marina pontoon',
			start: [5.55, 1.2],
			dir: [-0.55, 0.84],
			length: 3.4,
			width: 1.0,
			deck: LEVEL.pontoon,
			style: 'pontoon',
			berths: { left: 3, right: 3, boatLength: [0.5, 1.0] },
		},
		{
			id: 'pierD',
			name: 'ferry jetty',
			start: [-10.2, 4.4],
			dir: [0.42, 0.91],
			length: 2.7,
			width: 1.35,
			deck: LEVEL.quay,
			style: 'stone',
			berths: { left: 1, right: 0, boatLength: [1.2, 2.0] },
		},
	];

	// ------------------------------------------------------------------
	// mooring berths, generated from the piers.
	// each: {id, pier, side, pos:[x,z], heading (radians, boat bow), length}
	// ------------------------------------------------------------------
	function generateBerths() {
		const out = [];
		for (const pier of PIERS) {
			const len = Math.hypot(pier.dir[0], pier.dir[1]);
			const dx = pier.dir[0] / len,
				dz = pier.dir[1] / len;
			// left normal = rotate dir +90deg
			const nx = -dz,
				nz = dx;
			const sides = [
				['left', 1],
				['right', -1],
			];
			for (const [sideName, sideSign] of sides) {
				const count = pier.berths[sideName];
				if (!count) continue;
				for (let i = 0; i < count; i++) {
					const t = (i + 0.8) / (count + 0.6);
					const along = 0.55 + t * (pier.length - 1.1);
					const off = pier.width / 2 + 0.35;
					const x = pier.start[0] + dx * along + nx * off * sideSign;
					const z = pier.start[1] + dz * along + nz * off * sideSign;
					// boat points against the pier, slightly angled
					const heading = Math.atan2(dx, dz) + (i % 2 ? 0.06 : -0.06);
					const [minL, maxL] = pier.berths.boatLength;
					const blend = (i + 0.5) / Math.max(1, count);
					out.push({
						id: `${pier.id}-${sideName}-${i}`,
						pier: pier.id,
						side: sideName,
						pos: [x, z],
						heading,
						length: lerp(minL, maxL, blend),
						kind: pier.style,
					});
				}
			}
		}
		return out;
	}

	// ------------------------------------------------------------------
	// roads / streets (polylines). T3 builds surfaces + curbs, T4 cars.
	// ------------------------------------------------------------------
	const ROADS = [
		{
			id: 'quayRoad',
			width: 0.95,
			level: LEVEL.quay,
			points: [
				[-9.5, 2.2],
				[-8.0, 2.2],
				[-6.0, 1.9],
				[-3.5, 1.3],
				[-1.0, 0.8],
				[1.5, 0.3],
				[3.6, -0.2],
				[4.5, 0.1],
			],
		},
		{
			id: 'mainStreet',
			width: 0.8,
			level: LEVEL.town,
			// starts on the quay (1.0) and climbs to the town terrace (2.1):
			// sample ctx.groundHeight along the polyline for the real profile
			points: [
				[-9.5, 2.2],
				[-9.4, 0.2],
				[-9.2, -1.9],
				[-8.9, -2.9],
				[-8.1, -4.4],
				[-6.2, -5.35],
				[-3.9, -5.7],
				[-1.6, -5.6],
				[0.5, -5.0],
				[1.8, -3.9],
				[2.3, -2.3],
				[2.6, -0.4],
				[3.3, 0.4],
			],
		},
		{
			id: 'hillLane',
			width: 0.62,
			level: LEVEL.town,
			points: [
				[-7.4, -5.15],
				[-7.9, -6.8],
				[-7.2, -8.4],
				[-5.4, -9.3],
				[-3.2, -9.4],
			],
		},
		{
			id: 'fortRoad',
			width: 0.66,
			level: LEVEL.fort,
			points: [
				[3.5, 0.4],
				[4.9, 0.75],
				[6.1, 1.0],
				[6.8, 1.75],
			],
		},
		{
			id: 'beachLane',
			width: 0.55,
			level: LEVEL.quay,
			points: [
				[-10.4, 3.5],
				[-10.9, 4.3],
				[-11.5, 4.9],
			],
		},
	];

	// ------------------------------------------------------------------
	// landmark anchors (x, z, optionally y). Modules publish geometry at
	// these spots; nothing else should occupy them.
	// ------------------------------------------------------------------
	const ANCHORS = {
		lighthouse: { pos: [-4.15, 7.55], note: 'breakwater head, red & white tower' },
		beaconGreen: { pos: [7.0, 3.05], note: 'Fort Point harbour entrance beacon' },
		fortTower: { pos: [6.75, 0.85], note: 'small stone fort / signal tower' },
		church: { pos: [-2.1, -7.9], note: 'bell tower, tallest town silhouette' },
		plaza: { pos: [-2.1, -6.9], radius: 1.55, note: 'town square, fountain' },
		marketHall: { pos: [-4.55, -6.55], note: 'arcaded market hall' },
		customsHouse: { pos: [-9.95, 2.55], note: 'civic building facing the water' },
		fishMarket: { pos: [-6.15, 2.3], note: 'open fish market on the quay apron' },
		warehouseA: { pos: [-4.6, -1.2], size: [2.5, 1.25], note: 'big cargo warehouse (north of quay road)' },
		warehouseB: { pos: [-7.7, -1.15], size: [1.9, 1.05], note: 'boat shed (north of quay road)' },
		containerYard: { pos: [-1.2, -1.2], size: [2.2, 1.1], note: 'container stacks in the yard' },
		gantryCrane: { pos: [0.5, -0.6], note: 'ship-to-shore gantry, rails along x, cantilever over quay road' },
		fuelTank: { pos: [2.75, -1.05], radius: 0.45, note: 'small fuel tank with bund wall' },
		railYard: { pos: [-9.0, -1.6], note: 'narrow gauge siding + engine shed behind warehouses' },
		beachCove: { pos: [-11.35, 5.15], note: 'sandy cove, fishing huts' },
		cottageHill: { pos: [-7.2, -8.7], note: 'white cottage on the upper terrace' },
		watchtower: { pos: [3.35, -8.15], note: 'ruined watch tower on NE cliffs' },
		windmill: { pos: [-10.6, -7.9], note: 'small stone windmill on the west ridge' },
		seaStack: { pos: [11.2, -6.4], note: 'rocks in the eastern sea' },
		lighthouseRock: { pos: [-5.6, 9.6], note: 'rocky outcrop off breakwater head' },
	};

	// ------------------------------------------------------------------
	// town lots: generated frontage along the main street + hill lane.
	// T3 uses these as building sites (may tweak inside its own file).
	// ------------------------------------------------------------------
	function polylineLength(pts) {
		let l = 0;
		for (let i = 1; i < pts.length; i++) l += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
		return l;
	}
	function samplePolyline(pts, t) {
		// returns {x,z,dirX,dirZ} at normalized length t
		const total = polylineLength(pts);
		let target = clamp01(t) * total;
		for (let i = 1; i < pts.length; i++) {
			const a = pts[i - 1],
				b = pts[i];
			const seg = Math.hypot(b[0] - a[0], b[1] - a[1]);
			if (target <= seg || i === pts.length - 1) {
				const f = seg === 0 ? 0 : target / seg;
				const dx = (b[0] - a[0]) / seg,
					dz = (b[1] - a[1]) / seg;
				return { x: lerp(a[0], b[0], f), z: lerp(a[1], b[1], f), dirX: dx, dirZ: dz };
			}
			target -= seg;
		}
		return { x: pts[0][0], z: pts[0][1], dirX: 1, dirZ: 0 };
	}
	function polylineNormals(pts, t) {
		const s = samplePolyline(pts, t);
		return { ...s, nx: -s.dirZ, nz: s.dirX };
	}

	function generateTownLots() {
		const r = U.rng(20261027);
		const lots = [];
		const streets = [ROADS[1], ROADS[2]];
		// dense frontage along main street, sparser on the hill lane
		const specs = [
			{ street: 0, t0: 0.26, t1: 0.85, spacing: 0.085, offset: 0.95, count: null },
			{ street: 1, t0: 0.1, t1: 0.85, spacing: 0.16, offset: 0.8, count: null },
		];
		for (const spec of specs) {
			const street = streets[spec.street];
			const total = polylineLength(street.points);
			for (const side of [-1, 1]) {
				let t = spec.t0;
				while (t < spec.t1) {
					const s = polylineNormals(street.points, t);
					const off = spec.offset + r.range(0, 0.25);
					const x = s.x + s.nx * off * side;
					const z = s.z + s.nz * off * side;
					const rot = Math.atan2(s.dirX, s.dirZ);
					const w = r.range(0.7, 1.35);
					const d = r.range(0.8, 1.25);
					const floors = r.pick([2, 2, 2, 3, 3, 1]);
					lots.push({
						id: `lot-${lots.length}`,
						pos: [x, z],
						rot,
						width: w,
						depth: d,
						floors,
						styleSeed: Math.floor(r.next() * 1e6),
						street: street.id,
						side: side > 0 ? 'left' : 'right',
					});
					t += (w + r.range(0.1, 0.35)) / total;
				}
			}
		}
		return lots;
	}

	// ------------------------------------------------------------------
	// polygon maths
	// ------------------------------------------------------------------
	function pointInPoly(px, pz, poly) {
		let inside = false;
		for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
			const xi = poly[i][0],
				zi = poly[i][1];
			const xj = poly[j][0],
				zj = poly[j][1];
			if (zi > pz !== zj > pz && px < ((xj - xi) * (pz - zi)) / (zj - zi || 1e-9) + xi) inside = !inside;
		}
		return inside;
	}
	function distToSegment(px, pz, ax, az, bx, bz) {
		const vx = bx - ax,
			vz = bz - az;
		const wx = px - ax,
			wz = pz - az;
		const len2 = vx * vx + vz * vz || 1e-9;
		const t = clamp01((wx * vx + wz * vz) / len2);
		return Math.hypot(px - (ax + vx * t), pz - (az + vz * t));
	}
	function signedDistToPoly(px, pz, poly) {
		let minD = Infinity;
		for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
			const d = distToSegment(px, pz, poly[j][0], poly[j][1], poly[i][0], poly[i][1]);
			if (d < minD) minD = d;
		}
		return pointInPoly(px, pz, poly) ? minD : -minD;
	}
	function distToPolyline(px, pz, pts) {
		let minD = Infinity;
		for (let i = 1; i < pts.length; i++) {
			const d = distToSegment(px, pz, pts[i - 1][0], pts[i - 1][1], pts[i][0], pts[i][1]);
			if (d < minD) minD = d;
		}
		return minD;
	}

	// ------------------------------------------------------------------
	// height field
	// ------------------------------------------------------------------
	function naturalLandHeight(x, z) {
		// broad land shape before districts
		let h = 2.05;
		// north ridge rises towards -z
		h += 1.75 * smoothstep(-3.5, -11.5, z);
		// east headland rises
		h += 0.9 * smoothstep(2.0, 8.0, x) * smoothstep(0.5, -7.0, z);
		// gentle undulation, stronger on hills
		const hillness = smoothstep(-2.0, -9.0, z);
		h += U.fbm(x * 0.16, z * 0.16, { octaves: 4, seed: 11 }) * (0.55 + hillness * 0.85);
		h += U.fbm(x * 0.6, z * 0.6, { octaves: 3, seed: 21 }) * 0.12;
		return h;
	}

	function groundHeight(x, z) {
		const dCoast = signedDistToPoly(x, z, COAST);
		// steep coastal transition (quay walls / cliffs hide the slope)
		const landW = smoothstep(-0.55, 0.45, dCoast);
		const sea = SEA_FLOOR + U.fbm(x * 0.14, z * 0.14, { octaves: 3, seed: 5 }) * 0.5;
		let h = lerp(sea, naturalLandHeight(x, z), landW);
		// district pads
		for (const dist of DISTRICTS) {
			const d = signedDistToPoly(x, z, dist.poly);
			if (d > -dist.blend) {
				const w = smoothstep(-dist.blend, 0, d);
				h = lerp(h, dist.level, w);
			}
		}
		return h;
	}

	function waterDepth(x, z) {
		return Math.max(0, WATER_Y - groundHeight(x, z));
	}
	function isWater(x, z, margin = 0.0) {
		return groundHeight(x, z) < WATER_Y - margin;
	}
	function districtAt(x, z) {
		for (const dist of DISTRICTS) if (pointInPoly(x, z, dist.poly)) return dist.id;
		return 'wild';
	}

	// ------------------------------------------------------------------
	// roads sampling helper (also reused for rail / walking paths)
	// ------------------------------------------------------------------
	function pointAlong(pts, distance) {
		const total = polylineLength(pts);
		let target = clamp(distance, 0, total);
		for (let i = 1; i < pts.length; i++) {
			const a = pts[i - 1],
				b = pts[i];
			const seg = Math.hypot(b[0] - a[0], b[1] - a[1]);
			if (target <= seg || i === pts.length - 1) {
				const f = seg === 0 ? 0 : target / seg;
				const dx = (b[0] - a[0]) / seg,
					dz = (b[1] - a[1]) / seg;
				return { x: lerp(a[0], b[0], f), z: lerp(a[1], b[1], f), dirX: dx, dirZ: dz, angle: Math.atan2(dx, dz) };
			}
			target -= seg;
		}
		const a = pts[0];
		return { x: a[0], z: a[1], dirX: 1, dirZ: 0, angle: 0 };
	}

	// ------------------------------------------------------------------
	// camera presets (world units). `target` is the orbit pivot.
	// ------------------------------------------------------------------
	const VIEWS = {
		overview: {
			pos: [13.7, 13.2, 33.2],
			target: [0.2, 1.9, 2.4],
			fov: 30,
			label: '总览',
			labelEn: 'OVERVIEW',
		},
		harbor: {
			pos: [7.8, 6.6, 15.2],
			target: [-0.4, 0.9, 3.8],
			fov: 33,
			label: '港湾',
			labelEn: 'HARBOUR',
		},
		town: {
			pos: [-2.2, 8.2, 11.2],
			target: [-4.3, 1.9, -4.8],
			fov: 32,
			label: '老城',
			labelEn: 'OLD TOWN',
		},
		lighthouse: {
			pos: [8.2, 6.4, 17.6],
			target: [-2.6, 1.2, 7.2],
			fov: 33,
			label: '灯塔',
			labelEn: 'LIGHTHOUSE',
		},
		marina: {
			pos: [10.9, 5.5, 11.8],
			target: [4.2, 0.8, 3.4],
			fov: 33,
			label: '码头',
			labelEn: 'MARINA',
		},
		quay: {
			pos: [-0.8, 5.8, 11.6],
			target: [-2.2, 0.9, 2.2],
			fov: 32,
			label: '作业区',
			labelEn: 'QUAY',
		},
		top: {
			pos: [0.2, 33.0, 6.2],
			target: [0.2, 0.0, 0.2],
			fov: 28,
			label: '鸟瞰',
			labelEn: 'PLAN',
		},
	};

	// ------------------------------------------------------------------
	H.layout = {
		DISC_RADIUS,
		PLINTH_RADIUS,
		PLINTH_TOP,
		PLINTH_BOTTOM,
		RESIN_BOTTOM,
		WATER_Y,
		SEA_FLOOR,
		LEVEL,
		COAST,
		DISTRICTS,
		BREAKWATER,
		PIERS,
		ROADS,
		ANCHORS,
		VIEWS,
		berths: generateBerths(),
		townLots: generateTownLots(),
		// helpers
		pointInPoly,
		distToSegment,
		distToPolyline,
		signedDistToPoly,
		groundHeight,
		waterDepth,
		isWater,
		districtAt,
		naturalLandHeight,
		polylineLength,
		samplePolyline,
		polylineNormals,
		pointAlong,
		// how far outside the land polygon the water goes before the rim
		SEED: 20261027,
	};
})(window.HARBOR);
